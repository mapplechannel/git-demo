#!/bin/bash

# 执行sudo chmod +x tar_un_pack.sh 增加可执行权限
# 执行命令：./tar_un_pack.sh testuser  # (参数 testuser 为普通用户名，根据实际替换即可) ，解压缩并拷贝应用包至/usr/local/hsm-os/pack目录下
target=/home/$1
echo $target

cd $target

ls 测试应用包_解压缩每个应用包并拷贝第二层压缩包至工程师站_usr_local_hsm-os_pack目录下.tar.gz -l

sudo chmod 766 测试应用包_解压缩每个应用包并拷贝第二层压缩包至工程师站_usr_local_hsm-os_pack目录下.tar.gz

sudo tar -zxf 测试应用包_解压缩每个应用包并拷贝第二层压缩包至工程师站_usr_local_hsm-os_pack目录下.tar.gz

cd 测试应用包_解压缩每个应用包并拷贝第二层压缩包至工程师站_usr_local_hsm-os_pack目录下/
echo "解压缩应用包至当前目录：/home/$1/测试应用包_解压缩每个应用包并拷贝第二层压缩包至工程师站_usr_local_hsm-os_pack目录下/"
sudo tar -zxf hsm-io-it-0.1.2.tar.gz

sudo tar -zxf hsm-io-it-front-0.1.2.tar.gz

sudo tar -zxf hsm-opm-0.1.2.tar.gz

sudo tar -zxf javademo1-0.2.1.tar.gz

sudo tar -zxf javademo2-0.2.1.tar.gz

sudo tar -zxf javademo3-0.2.1.tar.gz

sudo tar -zxf javademo-image1-0.2.1.tar.gz

sudo tar -zxf javademo-image2-0.2.1.tar.gz

sudo tar -zxf mysql-5.7.41.tar.gz

sudo tar -zxf node-server-0.2.1.tar.gz

echo "拷贝包至/usr/local/hsm-os/pack目录"
sudo cp hsm-io-it-0.1.2/hsm-io-it-0.1.2.tar.gz /usr/local/hsm-os/pack

sudo cp hsm-io-it-front-0.1.2/hsm-io-it-front-0.1.2.tar.gz /usr/local/hsm-os/pack

sudo cp hsm-opm-0.1.2/hsm-opm-0.1.2.tar.gz /usr/local/hsm-os/pack

sudo cp javademo1-0.2.1/javademo1-0.2.1.tar.gz /usr/local/hsm-os/pack

sudo cp javademo2-0.2.1/javademo2-0.2.1.tar.gz /usr/local/hsm-os/pack

sudo cp javademo3-0.2.1/javademo3-0.2.1.tar.gz /usr/local/hsm-os/pack

sudo cp javademo-image1-0.2.1/javademo-image1-0.2.1.tar.gz /usr/local/hsm-os/pack

sudo cp javademo-image2-0.2.1/javademo-image2-0.2.1.tar.gz /usr/local/hsm-os/pack

sudo cp mysql-5.7.41/mysql-5.7.41.tar.gz /usr/local/hsm-os/pack

sudo cp node-server-0.2.1/node-server-0.2.1.tar.gz /usr/local/hsm-os/pack

echo "hsm-smc、hsm-env 解包并拷贝包至/usr/local/hsm-os/pack目录"
cd $target
sudo tar -zxf hsm-smc-0.2.2.tar.gz
sudo tar -zxf hsm-env-0.2.2.tar.gz

sudo cp hsm-smc-0.2.2/hsm-smc-0.2.2.tar.gz /usr/local/hsm-os/pack

sudo cp  hsm-env-0.2.2/hsm-env-0.2.2.tar.gz /usr/local/hsm-os/pack

echo "执行chmod 766 ./* 增加读写权限 "

cd /usr/local/hsm-os/pack
sudo chmod 766 ./*

echo "执行chown hsm-os:hsm-os ./* 修改文件所有者和所属组为hsm-os "
sudo chown hsm-os:hsm-os ./* 
echo "解包完毕！GOGOGO"