#!/bin/bash

version=$1
echo ${version}

mkdir -p  /opt/hsm-os/自测包/HSM-IO信息系统/HSM-OS_V${version}

cd /opt/hsm-os/自测包/HSM-IO信息系统/HSM-OS_V${version}
wget -nd -r -np --no-cache http://172.21.44.57:9000/hsm-env/hsm-io-it/develop/hsm-io-it-${version}.tar.gz
wget -nd -r -np --no-cache http://172.21.44.57:9000/hsm-env/hsm-io-it-front/develop/hsm-io-it-front-${version}.tar.gz
