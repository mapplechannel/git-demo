#!/bin/bash

# 执行sudo chmod +x hsm-install.sh 增加可执行权限
# 执行命令：./hsm-install.sh IP

echo "请选择安装服务类型！"
echo "输入1. 安装SK服务"
echo "输入2. 安装工程配置框架"
echo "输入3. 安装SK服务+工程配置框架"
# 读取用户输入
read option
ip=$1
template=""
if [ $option = "2" -o $option = "3" ];then
  if [ -z "$1" ];then
     echo "请输入工程师站IP"
     exit 1	
  fi
  if [  $option = "2" -o $option = "3" ];then
    pattern="^([0-9]{1,3}\.){3}[0-9]{1,3}$"
    if [[ $ip =~ $pattern ]];then
      echo $ip
    else
      # ip地址错误
      echo "ip地址格式错误"
      exit 1
    fi

    str=$(ip -o -4 addr show | awk '{print $4}' | grep $ip | cut -d '/' -f 1)
    if [ "$str" != "$ip" ];then
      echo "网卡中未找到指定IP:$ip"
      exit 1
    fi
  fi

  echo "请选择部署方式！"
  echo "输入1. 安装单机版"
  echo "输入2. 安装多机版"
  # 读取用户输入
  read installType
  case $installType in
    1)
        template="single-default.ini" 	
        ;;
    2)
        template="multi-default.ini"
        ;;
    *)
        echo "无效的输入"
	exit 1;
        ;;
  esac

fi

# 获取当前脚本所在目录
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
# 指定系统内核程序名
SK="hsm-sk"
# 查询同级目录下所有文件名为 hsm-sk 的文件
SK_FILE=$(find $DIR -maxdepth 1 -type f -name "*$SK" -printf "%f" | head -n 1)
# 输出变量值
echo "SK程序文件名为: $SK_FILE"

# 指定软件产品安装包后缀名
EXTENSION=".tar.gz"
# 查询同级目录下所有后缀名为 .tar.gz 的文件
FILE=$(find $DIR -maxdepth 1 -type f -name "hsm-install*$EXTENSION" | head -n 1)
# 输出变量值
echo "工程配置框架包文件名为: $FILE"

# 根据选项执行相应操作
case $option in
    1)
        echo "安装SK服务"		
	#拷贝系统内核程序至指定目录
	sudo cp ./$SK_FILE /usr/bin	
	#为当前程序增加可执行权限
	sudo chmod +x /usr/bin/$SK_FILE
	#检查并初始化节点软件安装目录，并将系统内核注册为系统服务
	sudo $SK_FILE init
	#启动系统内核服务
	sudo systemctl start $SK_FILE
	echo "安装SK服务完成！"
        ;;
    2)
        echo "安装工程配置框架"
	#解压缩安装包并拷贝至指定目录
	sudo $SK_FILE install -H $ip -t $template -f $FILE
	echo "安装部署,请稍后..."
	sleep 3
	echo "安装工程配置框架完成！"	
        ;;
     3)
        echo "安装SK服务+工程配置框架"
	#拷贝系统内核程序至指定目录
	sudo cp ./$SK_FILE /usr/bin	
	#为当前程序增加可执行权限
	sudo chmod +x /usr/bin/$SK_FILE
	#检查并初始化节点软件安装目录，并将系统内核注册为系统服务
	sudo $SK_FILE init	
	#启动系统内核服务，后续启动部署工具服务及工程配置环境
	sudo systemctl start $SK_FILE
	#解压缩软件安装包并拷贝至指定目录
	sudo $SK_FILE install -H $ip -t $template -f $FILE
	echo "安装部署,请稍后..."
	sleep 3
	echo "安装SK服务+工程配置框架完成！"
        ;;
    *)
        echo "无效的输入"
	exit 1;
        ;;
esac

#在当前目录下生成卸载脚本
#文件名称
file_name="$DIR/hsm-uninstall.sh"
# 组装文件内容
file_content+="#!/bin/bash \n"
file_content+="echo \"开始执行卸载脚本\" \n"
file_content+="echo \"停止hsm-sk项目\" \n"
file_content+="sudo systemctl stop hsm-sk \n"
file_content+="echo \"卸载pgsql\" \n"
file_content+="# 获取满足前缀模糊检索的文件夹列表的第一个 \n"
file_content+="folder=\$(find \"/usr/local/hsm-os/apps\" -type d -name \"postgresql14.8-*\" | head -n 1) \n"
file_content+="echo \"\$folder\" \n"
file_content+="# 检查文件夹列表是否为空 \n"
file_content+="if [ -n \"\$folder\" ];then \n"
file_content+="  cd \$folder/bin \n"
file_content+=" ./uninstall.sh 2> /dev/null \n"
file_content+="fi \n"
file_content+="# 获取满足前缀模糊检索的文件夹列表的第一个 \n"
file_content+="folder_keep=\$(find \"/usr/local/hsm-os/apps\" -type d -name \" keepalived2.2-*\" | head -n 1) \n"
file_content+="echo \"\$folder_keep\" \n"
file_content+="# 检查文件夹列表是否为空 \n"
file_content+="if [ -n \"\$folder_keep\" ];then \n"
file_content+="  cd \$folder_keep/bin \n"
file_content+=" ./uninstall.sh 2> /dev/null \n"
file_content+="fi \n"
file_content+="echo \"卸载glusterfs10.1\" \n"
file_content+="# 获取满足前缀模糊检索的文件夹列表的第一个 \n"
file_content+="gfs=\$(find \"/usr/local/hsm-os/apps\" -type d -name \"glusterfs10.1-*\" | head -n 1) \n"
file_content+="echo \"\$gfs\" \n"
file_content+="# 检查文件夹列表是否为空 \n"
file_content+="if [ -n \"\$gfs\" ];then \n"
file_content+="  cd \$gfs/bin \n"
file_content+=" ./uninstall.sh 2> /dev/null \n"
file_content+="fi \n"
file_content+="echo \"停止所有服务\" \n"
file_content+="sudo cat /sys/fs/cgroup/system.slice/hsm-sk.service/cgroup.procs |xargs kill -9 2> /dev/null \n"
file_content+="sudo pgrep containerd |xargs kill -9 2> /dev/null \n"
file_content+="echo \"取消ini文件隐藏属性\" \n"
file_content+="sudo chattr -i /usr/local/hsm-os/nodemanifest.ini 2> /dev/null \n"
file_content+="sudo chattr -i /usr/local/hsm-os/data/hsm-install/namespace.txt 2> /dev/null \n"
file_content+="echo \"删除hsm-os下的目录\" \n"
file_content+="sudo ip link del cni0 2> /dev/null \n"
file_content+="sudo ip link del hsmeth0 2> /dev/null \n"
file_content+="sudo rm -rf /usr/local/hsm-os 2> /dev/null \n"
file_content+="sudo rm -rf /opt/cni /etc/cni 2> /dev/null \n"
file_content+="echo \"删除influxdb配置文件\" \n"
file_content+="sudo rm -rf /root/.influxdbv2 2> /dev/null \n"
# 生成文件到当前目录
echo -e "$file_content" > "$file_name"
#给卸载脚本增加可执行权限
sudo chmod +x $file_name
echo "生成卸载脚本文件：$file_name"