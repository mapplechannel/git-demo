#!/bin/bash

echo "开始执行卸载脚本"


echo "停止hsm-sk项目"
sudo systemctl stop hsm-sk

echo "停止所有服务"
sudo cat /sys/fs/cgroup/system.slice/hsm-sk.service/cgroup.procs |xargs kill -9
sudo pgrep containerd |xargs kill -9

echo "取消ini文件隐藏属性"
sudo chattr -i /usr/local/hsm-os/nodemanifest.ini
sudo chattr -i /usr/local/hsm-os/data/hsm-install/namespace.txt

echo "删除hsm-os下的目录"
sudo ip link del cni0
sudo ip link del hsmeth0
sudo rm -rf /usr/local/hsm-os
sudo rm -rf /opt/cni /etc/cni

echo "删除influxdb配置文件"
sudo rm -rf /root/.influxdbv2