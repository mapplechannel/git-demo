#!/bin/bash

# 执行sudo chmod +x update-sln-promanifest.sh 增加可执行权限

# 执行命令：./update-sln-promanifest.sh


# 获取当前脚本所在目录
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

# 指定软件产品安装包后缀名
EXTENSION=".tar.gz"
# 查询同级目录下所有后缀名为 .tar.gz 的文件
FILE=$(find $DIR -maxdepth 1 -type f -name "*$EXTENSION" -printf "%f" | head -n 1)

sudo cp $FILE ./$FILE-backup
echo "备份安装包($FILE-backup)至当前目录下"

#指定待更新配置文件后缀名
INI=".ini"
# 查询同级目录下所有后缀名为 .ini 的文件
INI_FILES=$(find $DIR -maxdepth 1 -type f -name "*$INI")
echo "待更新文件：$INI_FILES"

#解压安装包
# 从字符串 FILE 的末尾删除指定后缀名
substring=${FILE%"$EXTENSION"}
echo "解压安装包"
tar -xzf $FILE
if [ $? -eq 0 ]; then
  echo "解压第一层完成，继续执行后续操作"

  tar -xzf ./$substring/$FILE -C ./$substring/
  if [ $? -eq 0 ]; then
      echo "解压第二层完成，继续执行后续操作"
  
      HSM_OS="hsm-os/data/hsm-install/template/"
     # 循环遍历变量 INI_FILES 中的文件列表
     for ff in $INI_FILES ; do
	    echo "更新部署配置文件: $ff"
	    sudo cp -f $ff ./$substring/$HSM_OS
     done
     
     echo "重新压缩安装包"
     tar -czf ./$substring/$FILE ./$substring/hsm-os/
     if [ $? -eq 0 ]; then
           echo "压缩第二层包完成，继续执行后续操作"
           sudo rm -rf ./$substring/hsm-os
           if [ $? -eq 0 ]; then
               tar -czf $FILE ./$substring/   
               if [ $? -eq 0 ]; then
                   echo "压缩第一层包完成，继续执行后续操作"
                   sudo rm -rf ./$substring
                   echo "更新文件到安装包内完成"
               else
                   echo "压缩第一层包出错，停止执行后续操作"
               fi 

            else
                echo "删除解压后临时文件夹hsm-os出错,停止执行后续操作"
            fi
	
      else
          echo "压缩第二层包出错，停止执行后续操作"
      fi 

   else
       echo "解压第二层包出错，停止执行后续操作"
   fi  

else
  echo "解压第一层包出错，停止执行后续操作"
fi
