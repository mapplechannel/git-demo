#!/bin/bash
###################################################################################################
#  执行脚本之前，请先阅读我！！！
#  传统应用解包后拷贝至/usr/local/hsm-os/apps/目录下；
#  容器应用可通过执行脚本，加载镜像到容器环境服务。
#   进入部署节点系统，执行如下步骤：
#
# 	 1）进入unzip-cp-pack.sh 所在目录
#
#    2）授权unzip-cp-pack.sh为可执行程序：chmod +x unzip-cp-pack.sh
#
#    3）执行脚本，需传入ip变量：./unzip-cp-pack.sh ip  。例如：./unzip-cp-pack.sh 172.21.44.151
####################################################################################################
me=`whoami`
version="0.1.2"
echo ${version}

# 1.执行前先杀死所有服务的存活的进程
ps aux | grep hsm | grep -v grep | awk '{print $2}' | xargs sudo kill -9
ps aux | grep nginx | grep -v grep | awk '{print $2}' | xargs sudo kill -9
ps aux | grep grafana | grep -v grep | awk '{print $2}' | xargs sudo kill -9
ps aux | grep prometheus | grep -v grep | awk '{print $2}' | xargs sudo kill -9
ps aux | grep demo1 | grep -v grep | awk '{print $2}' | xargs sudo kill -9

# 2.从GitLab下载系统内核安装包至部署节点临时目录/home/temp/ 下
temp_dir="$HOME/temp"
if [ ! -d "$temp_dir" ]; then 
    mkdir ${temp_dir}
fi

cd ${temp_dir}
wget -nd -r -np --no-cache http://172.21.44.57:9000/hsm-env/hsm-sk/develop/hsm-sk-${version}.tar.gz
tar -mzxvf hsm-sk-${version}.tar.gz > /dev/null
sudo rm -f /usr/local/hsm-os/data/hsm-sk/sk.db
sudo rm -f /usr/bin/hsm-sk
sudo rm -f /usr/local/hsm-os/apps/hsm-sk/sk.yml
sudo cp hsm-sk-${version}/hsm-sk /usr/bin/

# 3.启动系统内核服务
# 创建hsm-os父目录，并授权
if [ ! -d "/usr/local/hsm-os" ]; then 
    sudo mkdir /usr/local/hsm-os
fi
sudo chown $me:$me /usr/local/hsm-os
cd /usr/bin
sudo chmod +x hsm-sk
rm -rf /usr/local/hsm-os/pack/*
sudo rm -rf /usr/local/hsm-os/apps/*
sudo rm -rf /usr/local/hsm-os/vendors/*
hsm-sk init
sudo -b nohup ./hsm-sk --config /usr/local/hsm-os/apps/hsm-sk/config/sk.yml > /usr/local/hsm-os/logs/hsm-sk/sk1.log 2>&1 &


# 4.从GitLab下载应用安装包至部署节点指定目录/usr/local/hsm-os/pack/ 下
echo "下载安装包-start"
# cp $HOME/hsm-io-it-front-${version}.tar.gz /usr/local/hsm-os/pack/
cd /usr/local/hsm-os/pack
wget -nd -r -np --no-cache http://172.21.44.57:9000/hsm-env/hsm-env/develop/hsm-env-${version}.tar.gz
wget -nd -r -np --no-cache http://172.21.44.57:9000/hsm-env/hsm-io-it/develop/hsm-io-it-${version}.tar.gz
wget -nd -r -np --no-cache http://172.21.44.57:9000/hsm-env/hsm-io-it-front/develop/hsm-io-it-front-${version}.tar.gz
wget -nd -r -np --no-cache http://172.21.44.57:9000/hsm-env/hsm-opm/develop/hsm-opm-${version}.tar.gz
wget -nd -r -np --no-cache http://172.21.44.57:9000/hsm-env/hsm-smc/develop/hsm-smc-${version}.tar.gz
wget -nd -r -np --no-cache http://172.21.44.57:9000/hsm-env/hsm-env-pub/develop/hsm-env-pub-${version}.tar.gz

wget -nd -r -np --no-cache http://172.21.44.57:9000/hsm-env/tools/nginx-1.22.1.tar.gz
wget -nd -r -np --no-cache http://172.21.44.57:9000/hsm-env/tools/jdk-8u261-linux-x64.tar.gz

wget -nd -r -np --no-cache http://172.21.44.57:9000/hsm-env/tools/demo1-0.1.1.tar.gz
wget -nd -r -np --no-cache http://172.21.44.57:9000/hsm-env/tools/demoapi-0.1.1.tar.gz
# wget -nd -r -np --no-cache http://172.21.44.57:9000/hsm-env/tools/dist2-0.1.1.tar.gz
wget -nd -r -np --no-cache http://172.21.44.57:9000/hsm-env/tools/mysql-5.7.41.tar.gz

cp ${temp_dir}/hsm-sk-${version}.tar.gz /usr/local/hsm-os/pack/
cp $HOME/dist2-0.1.1.tar.gz /usr/local/hsm-os/pack/

echo "下载安装包-end"

# 5.从/usr/local/hsm-os/pack/ 拷贝环境依赖包至部署节点临时目录/home/temp/ 下
cp /usr/local/hsm-os/pack/nginx-1.22.1.tar.gz ${temp_dir}/
cp /usr/local/hsm-os/pack/jdk-8u261-linux-x64.tar.gz ${temp_dir}/

# 6.从/usr/local/hsm-os/pack/ 拷贝节点配置文件 nodemanifest.ini 至部署节点指定目录/usr/local/hsm-os/ 下
cp /usr/local/hsm-os/pack/hsm-env-pub-${version}.tar.gz ${temp_dir}/
cd ${temp_dir}
tar -mzxvf hsm-env-pub-${version}.tar.gz > /dev/null
rm -f /usr/local/hsm-os/nodemanifest.ini
cp hsm-env-pub-${version}/nodemanifest.ini /usr/local/hsm-os/

# 7.应用安装包：解包，并拷贝至/usr/local/hsm-os/apps/目录下
# 进入原始安装包目录
cd /usr/local/hsm-os/pack
tar -mzxvf hsm-opm-${version}.tar.gz -C /usr/local/hsm-os/apps/ > /dev/null
tar -mzxvf hsm-env-${version}.tar.gz -C /usr/local/hsm-os/apps/ > /dev/null
tar -mzxvf hsm-smc-${version}.tar.gz -C /usr/local/hsm-os/apps/ > /dev/null
tar -mzxvf hsm-io-it-${version}.tar.gz -C /usr/local/hsm-os/apps/ > /dev/null
tar -mzxvf hsm-io-it-front-${version}.tar.gz -C /usr/local/hsm-os/apps/ > /dev/null
tar -mzxvf demo1-0.1.1.tar.gz -C /usr/local/hsm-os/apps/ > /dev/null

cd /usr/local/hsm-os/apps
mv hsm-env-${version} hsm-env
mv hsm-opm-${version} hsm-opm
mv hsm-smc-${version} hsm-smc
mv hsm-io-it-${version} hsm-io-it
mv hsm-io-it-front-${version} hsm-io-it-front
mv demo1-0.1.1 demo1

# 8.环境依赖包：解包，删除环境依赖包压缩文件
cd ${temp_dir}
# 部署jdk
tar -mzxvf jdk-8u261-linux-x64.tar.gz -C /usr/local/hsm-os/vendors/ > /dev/null

# 部署nginx
tar -mzxvf nginx-1.22.1.tar.gz -C /usr/local/hsm-os/vendors/ > /dev/null

# 启动nginx
#chmod +x /usr/local/hsm-os/vendors/nginx-1.22.1/sbin/nginx
#sudo /usr/local/hsm-os/vendors/nginx-1.22.1/sbin/nginx
#echo "启动nginx成功"

# 9.删除临时文件夹/home/temp
rm -rf ${temp_dir}

# 10.授权hsm-os文件夹下所有程序可执行
cd /usr/local/hsm-os/
sudo chmod a+x ./

# 11.调用hsm-env启动脚本
cd /usr/local/hsm-os/apps/hsm-env/bin
sudo ./install.sh

# 12.加载容器应用的镜像
sudo ./hsm-env load-image

cd /usr/local/hsm-os/apps/hsm-io-it-front/bin
./install.sh $1 8080

# 13.调用hsm-sk 接口
curl localhost:8880/v1/app/update