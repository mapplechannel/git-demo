#!/bin/bash

if [ -z "$1" ]
then
  echo "请输入解决方案模板路径"
  exit 1
fi

if [ -z "$2" ]
then
  echo "请输入install home路径"
  exit 1
fi

if [ "$1" != "null" ]; then
    hsm-sk templates ./$1 ./$2
fi

if [ "$2" != "null" ]; then
    echo "============ 开始打包 ============="
    cd $2
    tar -zcvf $2.tar.gz ./hsm-os
    rm -rf ./hsm-os

    cd ..
    tar -zcvf $2.tar.gz ./$2
fi

