package nodeapp

import (
	"archive/tar"
	"compress/gzip"
	"errors"
	"fmt"
	"io"
	"io/ioutil"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"github.com/BurntSushi/toml"

	"github.com/google/uuid"
)

// 从文件中解析节点配置结构体实例
func ParseNodeConfig(path string, entity *NodeConfig) error {
	if _, err := toml.DecodeFile(path, entity); err != nil {
		if strings.Contains(err.Error(), "strictMode") || strings.Contains(err.Error(), "privileged") || strings.Contains(err.Error(), "notNeedGuard") || strings.Contains(err.Error(), "adminNode") {
			a := err.Error()[:strings.Index(err.Error(), "):")+1] + " 只能是true或false"
			return errors.New(a)
		}
		return err
	}
	return nil
}

// 从文件中解析应用配置结构体实例
func ParseAppConfig(path string, entity *AppConfig) error {
	isexist := fileExists(path)
	if !isexist {
		return errors.New("应用配置文件:appmanifest.ini不存在")
	}
	if _, err := toml.DecodeFile(path, entity); err != nil {
		if strings.Contains(err.Error(), "strictMode") || strings.Contains(err.Error(), "privileged") || strings.Contains(err.Error(), "notNeedGuard") || strings.Contains(err.Error(), "adminNode") {
			a := err.Error()[6:strings.Index(err.Error(), "):")+1] + " 只能是true或false"
			return errors.New(a)
		}
		return err
	}
	return nil
}

// 从节点配置文件中获取当前节点的所有应用信息
func GetCurrentServices(nodeConfig NodeConfig) (services []Service, err error) {
	//当前节点名称
	var currentNodeName = nodeConfig.CurrentNode
	services, err = GetServices(nodeConfig, currentNodeName)
	if err != nil {
		return services, err
	}
	return services, nil
}

// 从节点配置文件中获取指定节点的所有应用信息
func GetServices(nodeConfig NodeConfig, nodeName string) (services []Service, err error) {
	//循环节点配置信息，获取当前节点的应用配置信息
	var node *Node
	for _, nodeMessage := range nodeConfig.Nodes {
		if nodeName == nodeMessage.Code {
			node = &nodeMessage
			break
		}
	}
	if node == nil {
		return services, errors.New("节点名称不存在")
	}
	//获取节点配置的应用部署信息
	services = node.Services
	return services, nil
}

// 判断文件是否存在
func fileExists(path string) bool {
	_, err := os.Stat(path) //获取文件信息，err为nil时文件存在
	if err != nil {
		return os.IsExist(err)
	}
	return true
}

func DeleteTempDir(path string) {
	if path != "" {
		os.RemoveAll(path)
	}
}
func checkPackStruct(dirPath string, tempName string) error {
	files, err := ioutil.ReadDir(dirPath)
	if err != nil {
		return err
	}
	if len(files) != 1 {
		return errors.New("压缩包结构不正确！")
	}
	fir := files[0]
	if !fir.IsDir() {
		return errors.New("压缩包结构不正确！")
	}
	if fir.Name() != tempName {
		return errors.New("压缩包命名不一致！")
	}
	return nil
}
func Check(path string) (bool, error) {
	//解压
	//appPackageRootPath,path, appName, dirPath, err := DecAppPackage(path)
	appPackageRootPath, secondDirPath, appName, dirPath, err := DecAppPackage(path)
	if err != nil {
		DeleteTempDir(dirPath)
		return false, fmt.Errorf(err.Error())
	}
	appmanifestPath := filepath.Join(appPackageRootPath, "appmanifest.ini")
	appPath := filepath.Join(secondDirPath, appName)
	appConfig := AppConfig{}
	err = ParseAppConfig(appmanifestPath, &appConfig)
	if err != nil {
		DeleteTempDir(dirPath)
		return false, errors.New("【描述配置文件合规性检查】" + err.Error())
	}
	//配置文件字段校验
	err = StructValidate(&appConfig)
	if err != nil {
		DeleteTempDir(dirPath)
		return false, errors.New("【描述配置文件合规性检查】" + err.Error())
	}
	if appConfig.Info.Id+"-"+appConfig.Info.Version != appName {
		DeleteTempDir(dirPath)
		return false, errors.New("应用压缩包名字应为:应用ID-应用版本")
	}
	//校验依赖中是否包含自己
	err = ServiceDependencyCheck(appConfig)
	if err != nil {
		DeleteTempDir(dirPath)
		return false, err
	}
	err = CheckPackIsComplete(appConfig, appPath, appPackageRootPath)
	if err != nil {
		DeleteTempDir(dirPath)
		return false, errors.New("【应用包组成检查】" + err.Error())
	}
	//生成验证文件
	//if err = GenerateCSR(appConfig); err != nil {
	//	return false, err
	//}
	DeleteTempDir(dirPath)
	//检测其是否需要为root权限启动，若是，需要警告。
	isRoot := appConfig.Execute.Privileged
	return isRoot, nil
}
func GenerateCSR(appConfig AppConfig) error {
	//生成认证文件
	rootPath, err := os.Getwd()
	if err != nil {
		return errors.New(err.Error())
	}
	//地址
	csrPath := filepath.Join(rootPath, appConfig.Info.Id+".csr")
	//内容
	csrInfo := strings.Join([]string{appConfig.Info.Id, appConfig.Info.Version, uuid.New().String()}, "-")
	err = os.WriteFile(csrPath, []byte(csrInfo), 0755)
	if err != nil {
		return errors.New("生成认证文件出错：" + err.Error())
	}
	return nil
}

func DecAppPackage(path string) (string, string, string, string, error) {
	//外层压缩文件包位置
	path = filepath.Clean(path)
	//获取外层压缩包的目录
	dirPath := filepath.Dir(path)
	//获取文件名
	fileName := filepath.Base(path)
	//若文件不是tar.gz则报错
	if !strings.HasSuffix(fileName, ".tar.gz") {
		return "", "", "", "", errors.New("检查的应用包后缀不是.tar.gz:" + fileName)
	}
	tempName := fileName[0 : len(fileName)-7]
	if fileExists("/usr/local/hsm-os/pack") {
		dirPath = "/usr/local/hsm-os/pack"
	}
	//生成解压后所在的外层路径：/home/hollysys/temp1680848538
	dirPath = filepath.Join(dirPath, tempName+strconv.FormatInt(time.Now().Unix(), 10))
	//解压外层压缩包
	_, err := ExtractTarGz(dirPath, path)
	if err != nil {
		return "", "", "", dirPath, err
	}
	//获取dirPath下的文件夹个数以及文件名字,判断压缩包结构和外层压缩包名称是否正确
	err = checkPackStruct(dirPath, tempName)
	if err != nil {
		return "", "", "", dirPath, err
	}
	//获取解压缩包的路径：/home/hollysys/temp1680848538/testapplint
	appPackageRootPath := filepath.Join(dirPath, tempName)

	//读取/home/hollysys/temp1680848538/testapplint下的文件名（包括压缩包）
	fileInfos, err := ioutil.ReadDir(appPackageRootPath)
	if err != nil {
		return "", "", "", dirPath, errors.New(err.Error())
	}
	//获取应用包的压缩包名字
	var appPackageName string
	var tarNumber int
	for _, fileInfo := range fileInfos {
		if strings.HasSuffix(fileInfo.Name(), ".tar.gz") {
			appPackageName = fileInfo.Name()
			tarNumber += 1
		}
	}
	if tarNumber > 1 {
		return "", "", "", dirPath, errors.New("压缩包结构不正确！")
	}
	if appPackageName == "" {
		return "", "", "", dirPath, errors.New("应用压缩包不存在！")
	}
	before, _, _ := strings.Cut(appPackageName, ".tar.gz")
	if tempName != before {
		return "", "", "", dirPath, errors.New("内外压缩包名字不一致！")
	}
	//应用压缩包的路径/home/hollysys/temp1680848780/testapplint/testapplint.tar.gz
	appPackagePath := filepath.Join(appPackageRootPath, appPackageName)
	//解压
	///home/hollysys/temp1680848780/testapplint/temp1680848781
	secondDirPath := filepath.Join(appPackageRootPath, tempName+strconv.FormatInt(time.Now().Unix(), 10))
	_, err = ExtractTarGz(secondDirPath, appPackagePath)
	if err != nil {
		return "", "", "", dirPath, err
	}
	//获取secondDirPath下的文件夹个数以及文件名字,判断压缩包结构和内层压缩包名称是否正确
	err = checkPackStruct(secondDirPath, tempName)
	if err != nil {
		return "", "", "", dirPath, err
	}

	//dirPath：临时目录，before:第二层压缩所包不带后缀名字，appPackageRootPath解压后的目录
	return appPackageRootPath, secondDirPath, before, dirPath, nil
}

// 根据配置文件检查所需文件是否存在
// 代码走查-wangbin 圈复杂度高（18>10）9
func CheckPackIsComplete(appConfig AppConfig, appPath string, firstPath string) error {
	// 判断 文件名不空时文件存在 appPath第二层包目录：/home/hollysys/testapplint1683338559/testapplint/testapplint1683338559/testapplin，firstPath第一层包目录：/home/hollysys/testapplint1683338559/testapplint
	errString := []string{}
	certFile := appConfig.Info.CertFile
	if certFile != "" {
		cerFilePath := filepath.Join(firstPath, certFile)
		if exists := FileExists(cerFilePath); !exists {
			errString = append(errString, "证书文件："+certFile+"不存在")
		}
	}
	fingerprintFile := appConfig.Info.FingerprintFile
	if fingerprintFile != "" {
		fingerprintFilePath := filepath.Join(firstPath, fingerprintFile)
		//fmt.Println(fingerprintFilePath)
		if exists := FileExists(fingerprintFilePath); !exists {
			errString = append(errString, "指纹验证文件："+fingerprintFile+"不存在")
		}
	}
	installProgramName := appConfig.Package.InstallProgramName
	if installProgramName != "" {
		installFilePath := filepath.Join(appPath, installProgramName)
		if exists := FileExists(installFilePath); !exists {
			errString = append(errString, "安装文件："+installProgramName+"不存在")
		}
	}
	unInstallProgramName := appConfig.Package.UnInstallProgramName
	if unInstallProgramName != "" {
		unInstallFilePath := filepath.Join(appPath, unInstallProgramName)
		if exists := FileExists(unInstallFilePath); !exists {
			errString = append(errString, "卸载文件："+unInstallProgramName+"不存在")
		}
	}
	startProgramName := appConfig.Execute.StartProgramName
	if startProgramName != "" {
		startFIlePath := filepath.Join(appPath, startProgramName)
		//fmt.Println(startFIlePath)
		if exists := FileExists(startFIlePath); !exists {
			errString = append(errString, "启动文件:"+startProgramName+"不存在")
		}
	}
	if appConfig.Info.Type == "container" {
		if len(errString) != 0 {
			return errors.New(strings.Join(errString, ","))
		}
		return nil
	}
	stopProgramName := appConfig.Execute.StopProgramName
	if stopProgramName != "" {
		stopFilePath := filepath.Join(appPath, stopProgramName)
		if exists := FileExists(stopFilePath); !exists {
			errString = append(errString, "停止文件："+stopProgramName+"不存在")
		}
	}
	if len(appConfig.Execute.Programs) > 0 {
		for _, program := range appConfig.Execute.Programs {
			progName := program.ProgName
			if progName != "" {
				progFilePath := filepath.Join(appPath, progName)
				if exists := FileExists(progFilePath); !exists {
					errString = append(errString, "主程序："+progName+"不存在")
				}
			}
		}
	}
	if len(errString) != 0 {
		return errors.New(strings.Join(errString, ","))
	}
	return nil
}

func ListDirToFile(dirname string) ([]string, error) {
	infos, err := os.ReadDir(dirname)
	if err != nil {
		return nil, err
	}
	var names []string
	for _, info := range infos {
		if info == nil {
			continue
		}
		fileName := info.Name()
		if strings.Contains(fileName, ".tar.gz") {
			names = append(names, fileName)
		}
	}
	return names, nil
}

// func getFileFunction(path string) (string, bool, error) {

// 	//如果fileStr为空，
// 	//1.在目录下获取tar.gz文件如果只有一个包，直接解包
// 	//2.在目录下获取tar.gz文件如果有多个包，用户进行交互，选择之后再进行处理
// 	if path == "" {
// 		//若用户没有填校验包的路径，我们需要获取applint程序所在的文件夹路径
// 		appLintPath, err := os.Executable()
// 		if err != nil {
// 			return "", true, fmt.Errorf("获取当前文件夹出错: %w", err)
// 		}
// 		dirPath := filepath.Dir(appLintPath)
// 		filenames, err := ListDirToFile(dirPath)
// 		if err != nil {
// 			return "", true, fmt.Errorf("获取文件报错: %w", err)
// 		}
// 		if len(filenames) == 0 {
// 			return "", true, fmt.Errorf("不存在tar.gz 文件")
// 		}
// 		if len(filenames) == 1 {
// 			path = filenames[0]
// 		} else {
// 			//选择文件
// 			result, shouldReturn, returnValue := chooseFileFunction(filenames)
// 			if shouldReturn {
// 				return path, true, returnValue
// 			}
// 			path = result
// 		}
// 	}
// 	return path, false, nil
// }

// // 选择文件
// func chooseFileFunction(filenames []string) (string, bool, error) {
// 	prompt := promptui.Select{
// 		Label: "Select tar file",
// 		Items: filenames,
// 	}
// 	_, result, err := prompt.Run()

// 	if err != nil {
// 		return "", true, fmt.Errorf("choose file err: %w", err)
// 	}
// 	return result, false, nil
// }

// 校验依赖中是否有自己
func ServiceDependencyCheck(appConfig AppConfig) error {
	appId := appConfig.Info.Id
	appDependencys := appConfig.Info.AppDependency
	for _, appDependency := range appDependencys {
		appIdVersion := appDependency.AppIdVersion
		appDependencyId := appIdVersion[0:strings.LastIndex(appIdVersion, "-")]
		if appDependencyId == appId {
			return errors.New("应用依赖中不能包含当前应用！")
		}
	}
	return nil

}
func ExtractTarGz(dst, src string) (string, error) {
	gzipStream, err := os.Open(filepath.Clean(src))
	if err != nil {
		return "", err
	}
	uncompressedStream, err := gzip.NewReader(gzipStream)
	if err != nil {
		return "", err
	}

	tarReader := tar.NewReader(uncompressedStream)
	extractName := ""

	for {
		header, err := tarReader.Next()

		if err == io.EOF {
			break
		}

		if err != nil {
			//log.Printf("ExtractTarGz: Next() failed: %s", err.Error())
			return "", err
		}
		extractName = filepath.Clean(header.Name)
		//fmt.Println(extractName)
		dstName := filepath.Join(dst, extractName)
		switch header.Typeflag {
		case tar.TypeDir:
			if err := os.MkdirAll(dstName, 0755); err != nil {
				//log.Printf("ExtractTarGz: Mkdir() failed: %s", err.Error())
				return "", err
			}
		case tar.TypeReg:
			dir := filepath.Dir(dstName)
			if err := os.MkdirAll(dir, 0755); err != nil {
				//log.Printf("ExtractTarGz: Mkdir() failed: %s", err.Error())
				return "", err
			}
			outFile, err := os.Create(dstName)
			if err != nil {
				//log.Printf("ExtractTarGz: Create() failed: %s", err.Error())
				return "", err
			}
			defer outFile.Close()
			if _, err := io.Copy(outFile, tarReader); err != nil {
				//log.Printf("ExtractTarGz: Copy() failed: %s", err.Error())
				return "", err
			}
		default:
			// log.Fatalf(
			// 	"ExtractTarGz: uknown type: %s in %s",
			// 	header.Typeflag,
			// 	header.Name)
		}
	}
	return extractName, nil
}

// 判断文件是否存在
func FileExists(path string) bool {
	_, err := os.Stat(path) //获取文件信息，err为nil时文件存在
	if err != nil {
		return os.IsExist(err)
	}
	return true
}
func CreateOrOpenFile(path string) (*os.File, error) {
	dir := filepath.Dir(path)
	err := os.MkdirAll(dir, 0755)
	if err != nil {
		return nil, err
	}
	f, err := os.OpenFile(path, os.O_CREATE|os.O_RDWR|os.O_APPEND, 0644)
	if err != nil {
		return nil, err
	}
	return f, nil
}

// 从文件中解析模板配置结构体实例
func ParseTemplateConfig(path string, entity *TemplateConfig) error {
	if _, err := toml.DecodeFile(path, entity); err != nil {
		return err
	}
	return nil
}
