package nodeapp

// 节点配置文件结构体
type NodeConfig struct {
	//当前节点
	CurrentNode string `json:"currentNode" validate:"required" toml:"currentNode"`
	//节点配置文件版本号
	Version int `json:"version" validate:"required" toml:"version"`
	//NTP校时服务器列表,多个ip之间用空格分割
	NTP string `json:"NTP" validate:"required,validate_ip" toml:"NTP"`
	//可接受的秒数最大误差(秒)
	RootDistanceMaxSec uint `json:"RootDistanceMaxSec" validate:"len=30" toml:"RootDistanceMaxSec"`
	//最小轮询间隔秒数
	PollIntervalMinSec uint `json:"PollIntervalMinSec" validate:"omitempty,gte=16,ltfield=PollIntervalMaxSec" toml:"PollIntervalMinSec"`
	//最大轮询间隔秒数
	PollIntervalMaxSec uint `json:"PollIntervalMaxSec" validate:"omitempty,lte=2048,gtfield=PollIntervalMinSec" toml:"PollIntervalMaxSec"`
	//服务启动顺序
	//StartRank []StartRank `json:"startRank" validate:"required,min=1,dive"`
	//节点组
	Nodes []Node `json:"nodes" validate:"required,dive" toml:"nodes"`

	Namespace string            `json:"namespace" toml:"namespace"`
	Envs      map[string]string `json:"envs" toml:"envs"`
}
type Node struct {
	//节点唯一标识
	Code string `json:"code" validate:"required,max=30" toml:"code"`
	//节点名称
	Name string `json:"name" validate:"required,max=64" toml:"name"`
	//节点系统用户名
	NodeSysUser string `json:"nodeSysUser" toml:"nodeSysUser"`
	//节点系统密码
	NodeSysPwd string `json:"nodeSysPwd" toml:"nodeSysPwd"`
	//IP地址组
	Ip1       string `json:"ip1" validate:"required,ip" toml:"ip1"`
	Ip2       string `json:"ip2" validate:"omitempty,ip" toml:"ip2"`
	Groupname string `json:"groupname" toml:"groupname"`
	//NodeIp []string `json:"nodeIp" validate:"required,dive,ip"`
	MasterNodes []string `json:"masterNodes" toml:"masterNodes"`
	//核数
	Cpu string `json:"cpu" toml:"cpu"`
	//内存
	Memory string `json:"memory" toml:"memory"`
	//磁盘
	Disk string `json:"disk" toml:"disk"`
	//容器网络地址段
	CniCidr string `json:"cniCidr" validate:"required" toml:"cniCidr"`
	//服务网络地址段
	ServiceCidr string `json:"serviceCidr" validate:"required" toml:"serviceCidr"`
	//是否为工程站节点标识
	AdminNode bool `json:"adminNode" toml:"adminNode"`
	//服务信息
	Services   []Service `json:"services" validate:"dive" toml:"services"`
	HsmLocalIp string    `json:"hsmLocalIp" validate:"required" toml:"hsmLocalIp"`
}

type Service struct {
	Info Info `json:"info" validate:"required,dive" toml:"info"`
	//安装程序信息
	Package ServicePackage `json:"package" toml:"package"`
	//运行信息
	Execute Execute `json:"execute" toml:"execute"`
}

type ServicePackage struct {
	//#是否冗余（0表是无，1表示有）
	//IsRedundance uint `json:"isRedundance" validate:"oneof=0 1"`
	//节点标识组（冗余服务所在的节点组， 若冗余标识为0，则此字段无效）
	//RedundanceNodeCode []string `json:"redundanceNodeCode"`
	//服务类型（主服务，从服务，普通服务）
	ServiceType string `json:"servicetype" validate:"required,oneof=master slave normal" toml:"serviceType"`
	//实例数
	CaseNumber uint `json:"caseNumber" validate:"required" toml:"caseNumber"`
	//安装文件名称
	InstallProgramName string `json:"installProgramName" toml:"installProgramName"`
	//安装参数
	InstallParams        []string `json:"installParams" toml:"installParams"`
	UnInstallProgramName string   `json:"unInstallProgramName" toml:"unInstallProgramName"`
	//安装时提供环境变量
	Install map[string]string `json:"install" toml:"install"`
	Mounts  []Mount           `json:"volume" toml:"mounts"`

	AppGrade           string            `json:"appGrade" toml:"appGrade"`
	UpgradeProgramName string            `json:"upgradeProgramName" toml:"upgradeProgramName"`
	UpgradeParams      []string          `json:"upgradeParams" toml:"upgradeParams"`
	UpgradeEnvs        map[string]string `json:"upgradeEnvs" toml:"upgradeEnvs"`
	DegradeProgramName string            `json:"degradeProgramName" toml:"degradeProgramName"`
	DegradeParams      []string          `json:"degradeParams" toml:"degradeParams"`
	DegradeEnvs        map[string]string `json:"degradeEnvs" toml:"degradeEnvs"`
}

type Mount struct {
	//存储卷读写权限
	Permission string `json:"permission" validate:"required,oneof=read write" toml:"permission"`
	//存储卷类型
	Type string `json:"type" validate:"required,oneof=Volumn Bind" toml:"type"`
	//源目录
	Source string `json:"source" validate:"required" toml:"source"`
	//目标目录
	Target string `json:"target" validate:"required" toml:"target"`
}
type StartRank struct {
	AppId   string `json:"appId" validate:"required,max=30,validate_id" toml:"appId"`
	Version string `json:"version" validate:"required" toml:"version"`
	NodCode string `json:"nodeCode" validate:"required" toml:"nodCode"`
	Rank    int    `json:"rank" validate:"required" toml:"rank"`
}
