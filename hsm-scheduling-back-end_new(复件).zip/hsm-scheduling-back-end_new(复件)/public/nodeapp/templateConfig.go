package nodeapp

type TemplateConfig struct {
	Name     string
	Version  string
	Type     string
	Desc     string
	Template []Template
}
type Template struct {
	Desc         string
	Type         string
	TempFileName string
	Nodes        []TemplateNode
}
type TemplateNode struct {
	Code        string
	Name        string
	Ip1         string
	Ip2         string
	MasterNodes []string
	GroupName       string
	CniCidr     string
	HsmLocalIp  string
	ServiceCidr string
	AdminNode   bool
	Services    []string
}
