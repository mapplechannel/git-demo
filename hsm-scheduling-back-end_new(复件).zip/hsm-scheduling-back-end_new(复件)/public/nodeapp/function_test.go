package nodeapp

import (
	"fmt"
	"log"
	"os"
	"path/filepath"
	"testing"
	// "github.com/agiledragon/gomonkey/v2"
	// . "github.com/smartystreets/goconvey/convey"
)

func Test_ParseTemplateConfig(t *testing.T) {
	currPath, err := os.Getwd()
	if err != nil {
		log.Fatalln(err)
	}
	path := filepath.Join(currPath, "template.ini")
	var entity TemplateConfig
	err = ParseTemplateConfig(path, &entity)
	fmt.Println(entity.Desc)
	fmt.Println(entity.Name)
	fmt.Println(entity.Template[0].TempFileName)
	if err != nil {
		log.Fatalln(err)
	}
	if err != nil {
		log.Fatalln(err)
	}

}


func Test_ParseNodeConfig(t *testing.T) {
	currPath, err := os.Getwd()
	if err != nil {
		log.Fatalln(err)
	}
	path := filepath.Join(currPath, "nodemanifestExample.ini")
	var entity NodeConfig
	err = ParseNodeConfig(path, &entity)
	fmt.Println(entity.PollIntervalMaxSec)
	fmt.Println(entity.PollIntervalMinSec)
	fmt.Println(entity.RootDistanceMaxSec)
	if err != nil {
		log.Fatalln(err)
	}
	err = StructValidate(&entity)
	if err != nil {
		log.Fatalln(err)
	}
}

func Test_ParseAppConfig(t *testing.T) {
	currPath, err := os.Getwd()
	if err != nil {
		log.Fatalln(err)
	}
	path := filepath.Join(currPath, "appConfigEx.ini")
	var entity AppConfig
	err = ParseAppConfig(path, &entity)
	fmt.Println(entity.Execute.Env["spring.datasource.password"])
	if err != nil {
		log.Fatalln(err)
	}
	err = StructValidate(&entity)
	if err != nil {
		log.Fatalln(err)
	}
}
func Test_Check(t *testing.T) {
	path := "/home/hollysys/apptest/725/hsm-db-device-model-svc-0.4.1.tar.gz"
	_, err := Check(path)
	if err != nil {
		fmt.Printf("检测失败：%s", err.Error())
		return
	}
	fmt.Println("检测通过")

}
