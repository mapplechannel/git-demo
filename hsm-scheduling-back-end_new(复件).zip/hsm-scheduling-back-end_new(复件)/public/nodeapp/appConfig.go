package nodeapp

//应用配置结构体

import (
	"errors"
	"net"
	"regexp"
	"strconv"
	"strings"

	"github.com/go-playground/locales/zh"
	ut "github.com/go-playground/universal-translator"
	"github.com/go-playground/validator/v10"
	zh_translations "github.com/go-playground/validator/v10/translations/zh"
)

// 应用配置文件.ini文件结构体
type AppConfig struct {
	//应用信息
	Info Info `json:"info" toml:"info"`
	//安装程序信息
	Package Package `json:"package" toml:"package"`
	//运行信息
	Execute Execute `json:"execute" toml:"execute"`
}

// app
type Info struct {
	//基础信息
	Id   string `json:"ID" validate:"required,max=30,validate_id" toml:"ID"`
	Name string `json:"name" validate:"required,max=64" toml:"name"`
	//应用类型（legacy-传统应用；container-容器应用）
	Type     string `json:"type" validate:"required,oneof=legacy container" toml:"type"`
	Version  string `json:"version" validate:"required" toml:"version"`
	Solution string `json:"solution" toml:"solution"`
	//证书文件名称
	CertFile string `json:"certFile" toml:"certFile"`
	//指纹验证文件名称
	FingerprintFile string `json:"fingerprintFile" toml:"fingerprintFile"`
	//功能描述
	FuncDesc string `json:"funcDesc" validate:"max=255" toml:"funcDesc"`
	//发布升级说明
	ReleaseNote string `json:"releaseNode" validate:"max=255" toml:"releaseNote"`
	// EnvDependency []string `json:"envDependency" validate:"dive,validate_app_envDependency"`
	Source string `json:"source" validate:"required" toml:"source"`
	//应用兼容模式（standard-标准应用；custom-定制化应用）
	AppMode string `json:"appMode" validate:"required,oneof=standard custom" toml:"appMode"`
	//严格模式（true:严格模式；false:正常模式）
	StrictMode bool `json:"strictMode" toml:"strictMode"`
	//支持linux系统的发行版类型
	SupSysType []string `json:"SupSysType" validate:"required,min=1,dive,required" toml:"supSysType"`
	//依赖
	AppDependency []AppDependency `json:"appDependency" validate:"dive" toml:"appDependency"`
	HiddenDependency []HiddenDependency `json:"hiddenDependency" toml:"hiddenDependency"`
	Appsets       string          `json:"appsets" toml:"appsets"`
	//PublishTime   string       `json:"publishTime" validate:"required"`
	PkgMd5               string `json:"pkgMd5" toml:"pkgMd5"`
	NotSuptDegrade    bool   `json:"notSupDegrade" toml:"notSupDegrade"`
	LowVersionDegrade string `json:"lowVersionDegrade" validate:"validate_degrade_version" toml:"lowVersionDegrade"`
}
type AppDependency struct {
	AppIdVersion string `json:"appIdVersion"  validate:"validate_app_appDependency" toml:"appIdVersion"`
	//依赖类型（strong-强依赖；weak-弱依赖）
	DependencyType string `json:"dependencyType" validate:"oneof=strong weak" toml:"dependencyType"`
}
type HiddenDependency struct {
	Id string `json:"id" toml:"id"`
	//依赖类型（strong-强依赖；weak-弱依赖）
	Version string `json:"version" toml:"version"`
}
// package
type Package struct {
	//存储卷映射列表
	TargetPaths []string `json:"targetPaths" toml:"targetPaths"`
	//安装脚本文件名称
	InstallProgramName string `json:"installProgramName" toml:"installProgramName"`
	//安装参数
	InstallParams        []string `json:"installParams" toml:"installParams"`
	UnInstallProgramName string   `json:"unInstallProgramName" toml:"unInstallProgramName"`
	//安装时提供环境变量
	Install            map[string]string `json:"install" toml:"install"`
	AppGrade           string            `json:"appGrade" toml:"AppGrade"`
	UpgradeProgramName string            `json:"upgradeProgramName" toml:"upgradeProgramName"`
	UpgradeParams      []string          `json:"upgradeParams" toml:"upgradeParams"`
	UpgradeEnvs        map[string]string `json:"upgradeEnvs" toml:"upgradeEnvs"`
	DegradeProgramName string            `json:"degradeProgramName" toml:"degradeProgramName"`
	DegradeParams      []string          `json:"degradeParams" toml:"degradeParams"`
	DegradeEnvs        map[string]string `json:"degradeEnvs" toml:"degradeEnvs"`
}

// env
type Execute struct {
	Ports []Port `json:"ports" toml:"ports"`
	//建议核数大小
	CpuLimit string `json:"cpuLimit" toml:"cpuLimit"`
	//建议内存大小
	MemoryLimit string `json:"memoryLimit" toml:"memoryLimit"`
	//启动文件名称
	StartProgramName string `json:"startProgramName" toml:"startProgramName"`
	//启动程序类型
	ProgramType string `json:"programType" validate:"required,oneof=java web nodejs python dotnet exec container common" toml:"programType"`
	Privileged  bool   `json:"privileged" toml:"privileged"`
	//启动参数
	StartParams []string `json:"startParams" toml:"startParams"`
	//停止文件名称
	StopProgramName string `json:"stopProgramName" toml:"stopProgramName"`
	//数据存储目录
	DataDir []string `json:"dataDir" toml:"dataDir"`
	//日志收集配置
	Log LogSettings `json:"log" toml:"log"`
	//守护和健康检查配置
	Programs []Program `json:"programs" validate:"dive" toml:"programs"`
	//运行时提供环境变量
	Env    map[string]string `json:"env" toml:"env"`
	Web    Web               `json:"web" validate:"dive" toml:"web"`
	NewIp  string            `json:"newIp" toml:"newIp"`
	Extend interface{}       `json:"extend" toml:"extend"`
	//EngMenu []EngMenu         `json:"engMenu" validate:"dive" toml:"engMenu"`
}
type EngMenu struct {
	Id      string    `json:"id" toml:"id"`
	Name    string    `json:"name" toml:"name"`
	Icon    string    `json:"icon" toml:"icon"`
	Enabled bool      `json:"enabled" toml:"enabled"`
	Order   int       `json:"order" toml:"order"`
	Items   []EngMenu `json:"items" toml:"items"`
	Active  Active    `json:"active" validate:"dive" toml:"active"`
}
type Active struct {
	Kind string `json:"kind" validate:"omitempty,oneof=open close" toml:"kind"`
	Data string `json:"data" toml:"data"`
}
type Web struct {
	Mode   string   `json:"mode" validate:"omitempty,oneof=hash history" toml:"mode"`
	Routes []Routes `json:"routes" validate:"dive" toml:"routes"`
}
type Routes struct {
	Path         string `json:"path" toml:"path"`
	Type         string `json:"type" validate:"omitempty,oneof=alias proxy_pass try_files custom" toml:"type"`
	Target       string `json:"target" toml:"target"`
	Content      string `json:"content" toml:"content"`
	TargetFilter string `json:"targetFilter" validate:"omitempty,oneof=A E L R" toml:"targetFilter"`
}

type LogSettings struct {
	//日志存储路径
	LogDir string `json:"logDir" toml:"logDir"`
	//日志文件格式
	LogFileFormat []string `json:"logFileFormat" toml:"logFileFormat"`
	//日志分隔符
	LogSep string `json:"logSep" toml:"logSep"`
	//日志格式
	LogFormat string `json:"logFormat" toml:"logFormat"`
}

type Program struct {
	//主程序名称
	ProgName string `json:"progName" validate:"required" toml:"progName"`
	//主程序启动参数
	ProgParams   []string `json:"progParams" toml:"progParams"`
	NotNeedGuard bool     `json:"notNeedGuard" toml:"notNeedGuard"`
	//健康检查类型
	HealthCheckAliveType      string `json:"healthCheckAliveType" validate:"validate_healthCheckAliveType" toml:"healthCheckAliveType"`
	HealthCheckAliveInterface string `json:"healthCheckAliveInterface" toml:"healthCheckAliveInterface"`
	HealthCheckAliveHttpPort  string `json:"healthCheckAliveHttpPort" validate:"validate_port" toml:"healthCheckAliveHttpPort"`
	HealthCheckAliveTcpPort   string `json:"healthCheckAliveTcpPort" validate:"validate_port" toml:"healthCheckAliveTcpPort"`
	HealthCheckAliveShellCmd  string `json:"healthCheckAliveShellCmd" toml:"healthCheckAliveShellCmd"`

	HealthCheckReadyType      string `json:"healthCheckReadyType" validate:"validate_healthCheckReadyType" toml:"healthCheckReadyType"`
	HealthCheckReadyInterface string `json:"healthCheckReadyInterface" toml:"healthCheckReadyInterface"`
	HealthCheckReadyHttpPort  string `json:"healthCheckReadyHttpPort" validate:"validate_port" toml:"healthCheckReadyHttpPort"`
	HealthCheckReadyTcpPort   string `json:"healthCheckReadyTcpPort" validate:"validate_port" toml:"healthCheckReadyTcpPort"`
	HealthCheckReadyShellCmd  string `json:"healthCheckReadyShellCmd" toml:"healthCheckReadyShellCmd"`
	//表明第一次检测在容器启动后多长时间后开始
	AliveDelaySeconds uint `json:"aliveDelaySeconds" toml:"aliveDelaySeconds"`
	//检测的超时时间
	AliveTimeoutSeconds uint `json:"aliveTimeoutSeconds" toml:"aliveTimeoutSeconds"`
	//检查间隔时间
	AlivePeriodSeconds uint `json:"alivePeriodSeconds" toml:"alivePeriodSeconds"`
	//表明第一次检测在容器启动后多长时间后开始
	ReadyDelaySeconds uint `json:"readyDelaySeconds" toml:"readyDelaySeconds"`
	//检测的超时时间
	ReadyTimeoutSeconds uint `json:"readyTimeoutSeconds" toml:"readyTimeoutSeconds"`
	//检查间隔时间
	ReadyPeriodSeconds uint `json:"readyPeriodSeconds" toml:"readyPeriodSeconds"`
}
type Port struct {
	//应用原始端口号
	SourcePort string `json:"sourcePort" validate:"validate_port" toml:"sourcePort"`
	// 对外暴露端口号
	TargetPort string `json:"targetPort" validate:"validate_port" toml:"targetPort"`
}

// 使用单个实例，缓存结构信息
var (
	uni      *ut.UniversalTranslator
	validate *validator.Validate
)

// 结构体校验
func StructValidate(file interface{}) error {
	//中文翻译
	zh := zh.New()
	uni = ut.New(zh, zh)
	trans, _ := uni.GetTranslator("zh") //先写死，之后通过获取国际化配置值
	validate = validator.New()

	// 注册翻译器到校验器

	validate.RegisterValidation("validate_degrade_version", validate_degrade_version)
	validate.RegisterValidation("validate_app_version", validate_app_version)
	validate.RegisterValidation("validate_app_envDependency", validate_app_envDependency)
	validate.RegisterValidation("validate_app_appDependency", validate_app_appDependency)
	validate.RegisterValidation("validate_healthCheckAliveType", validate_healthCheckAliveType)
	validate.RegisterValidation("validate_healthCheckReadyType", validate_healthCheckAliveType)
	validate.RegisterValidation("validate_id", validate_id)
	validate.RegisterValidation("validate_port", validate_port)
	validate.RegisterValidation("validate_ip", validate_ip)

	//注册自定义验证错误信息
	validate.RegisterTranslation("validate_ip", trans, func(ut ut.Translator) error {
		return ut.Add("validate_ip", "{0}字段值格式不合法!", true) // see universal-translator for details
	}, func(ut ut.Translator, fe validator.FieldError) string {
		t, err := ut.T("validate_ip", fe.Field())
		if err != nil {
			return err.Error()
		}
		return t
	})
	validate.RegisterTranslation("validate_app_version", trans, func(ut ut.Translator) error {
		return ut.Add("validate_app_version", "{0} 只能是x.x.x如1.1.0", true) // see universal-translator for details
	}, func(ut ut.Translator, fe validator.FieldError) string {
		t, err := ut.T("validate_app_version", fe.Field())
		if err != nil {
			return err.Error()
		}
		return t
	})
	validate.RegisterTranslation("validate_degrade_version", trans, func(ut ut.Translator) error {
		return ut.Add("validate_degrade_version", "{0} 只能是x.x.x如1.1.0", true) // see universal-translator for details
	}, func(ut ut.Translator, fe validator.FieldError) string {
		t, err := ut.T("validate_degrade_version", fe.Field())
		if err != nil {
			return err.Error()
		}
		return t
	})
	validate.RegisterTranslation("validate_app_envDependency", trans, func(ut ut.Translator) error {
		return ut.Add("validate_app_envDependency", "{0} 只能是env-x.x.x如app-1.1.0", true) // see universal-translator for details
	}, func(ut ut.Translator, fe validator.FieldError) string {
		t, err := ut.T("validate_app_envDependency", fe.Field())
		if err != nil {
			return err.Error()
		}
		return t
	})
	validate.RegisterTranslation("validate_app_appDependency", trans, func(ut ut.Translator) error {
		return ut.Add("validate_app_appDependency", "{0} 只能是app-x如app-1.1.0", true) // see universal-translator for details
	}, func(ut ut.Translator, fe validator.FieldError) string {
		t, err := ut.T("validate_app_appDependency", fe.Field())
		if err != nil {
			return err.Error()
		}
		return t
	})
	validate.RegisterTranslation("validate_healthCheckAliveType", trans, func(ut ut.Translator) error {
		return ut.Add("validate_healthCheckAliveType", "{0} 不空时只能是tcp,http,shell中的一个", true) // see universal-translator for details
	}, func(ut ut.Translator, fe validator.FieldError) string {
		t, err := ut.T("validate_healthCheckAliveType", fe.Field())
		if err != nil {
			return err.Error()
		}
		return t
	})
	validate.RegisterTranslation("validate_healthCheckReadyType", trans, func(ut ut.Translator) error {
		return ut.Add("validate_healthCheckReadyType", "{0} 不空时只能是tcp,http,shell中的一个", true) // see universal-translator for details
	}, func(ut ut.Translator, fe validator.FieldError) string {
		t, err := ut.T("validate_healthCheckReadyType", fe.Field())
		if err != nil {
			return err.Error()
		}
		return t
	})
	validate.RegisterTranslation("validate_id", trans, func(ut ut.Translator) error {
		return ut.Add("validate_id", "{0} 支持小写字母、数字、“-”、“_”和“.”", true) // see universal-translator for details
	}, func(ut ut.Translator, fe validator.FieldError) string {
		t, err := ut.T("validate_id", fe.Field())
		if err != nil {
			return err.Error()
		}
		return t
	})
	validate.RegisterTranslation("validate_port", trans, func(ut ut.Translator) error {
		return ut.Add("validate_port", "{0}代表的数值大小需要大于等于1024且小于等于65535", true) // see universal-translator for details
	}, func(ut ut.Translator, fe validator.FieldError) string {
		t, err := ut.T("validate_port", fe.Field())
		if err != nil {
			return err.Error()
		}
		return t
	})
	zh_translations.RegisterDefaultTranslations(validate, trans) //翻译

	err := validate.Struct(file)
	if err != nil {
		errString := []string{}
		for _, e := range err.(validator.ValidationErrors).Translate(trans) {
			errString = append(errString, e)
		}
		return errors.New(strings.Join(errString, ","))
	}
	return nil

}

// app-version校验
func validate_app_version(fl validator.FieldLevel) bool {
	field := fl.Field().String()
	if field == "" {
		return false
	}
	ok, err := regexp.MatchString("^\\d\\.\\d\\.\\d$", field)
	if err != nil {
		return false
	}
	return ok

}

// app-version校验
func validate_degrade_version(fl validator.FieldLevel) bool {
	field := fl.Field().String()
	if field == "" {
		return true
	}
	ok, err := regexp.MatchString(`^\d+\.\d+\.\d+$`, field)
	if err != nil {
		return false
	}
	return ok

}

// app-envDependency校验
func validate_app_envDependency(fl validator.FieldLevel) bool {
	field := fl.Field().String()
	if field == "" {
		return false
	}
	ok, err := regexp.MatchString("(?i)^env-\\d.\\d.\\d$", field)
	if err != nil {
		return false
	}
	return ok

}

// app-appDependency校验
func validate_app_appDependency(fl validator.FieldLevel) bool {
	field := fl.Field().String()
	if field == "" {
		return false
	}
	// ok, err := regexp.MatchString("-\\d\\.\\d\\.\\d$", field)
	// if err != nil {
	// 	return false
	// }
	// return ok
	return true
}

func validate_healthCheckAliveType(fl validator.FieldLevel) bool {
	field := fl.Field().String()
	if field == "" {
		return true

	}
	var s = []string{"tcp", "http", "shell"}
	for _, value := range s {
		if value == field {
			return true
		}
	}
	return false
}

func validate_id(fl validator.FieldLevel) bool {
	field := fl.Field().String()
	ok, err := regexp.MatchString("^[0-9a-z-_.]+$", field)
	if err != nil {
		return false
	}
	return ok
}

func validate_port(fl validator.FieldLevel) bool {
	field := fl.Field().String()
	if field == "" {
		return true
	}
	port, err := strconv.Atoi(field)
	if err != nil {
		return false
	}
	if port < 1024 || port > 65535 {
		return false
	}
	return true
}

func validate_ip(fl validator.FieldLevel) bool {
	field := fl.Field().String()
	ips := strings.Split(field, " ")
	for _, ip := range ips {
		if address := net.ParseIP(ip); address == nil {
			return false
		}

	}
	return true
}
