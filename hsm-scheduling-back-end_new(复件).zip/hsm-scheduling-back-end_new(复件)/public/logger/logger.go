package logger

// import (
// 	"fmt"
// 	"os"
// 	"path/filepath"
// 	"strings"

// 	"hsm-sk/public/lumberjack"

// 	"hsm-sk/config"

// 	"github.com/rs/zerolog"
// )

// // init函数主要解决未启动服务而调用命令时使用，单元测试时不需要对打印日志的方法进行打桩
// func init() {
// 	var logConf config.Log
// 	//各个应用自定义默认的文件路径和文件名
// 	logConf.Filename = "hsm-sk/sk.log"
// 	logConf.Level = "INFO"
// 	logConf.MaxNumber = 10
// 	logConf.MaxSize = 10
// 	Init(logConf)
// }

// // 日志文件操作结构体
// type Jacklog struct {
// 	JackLog *lumberjack.Logger
// }

// func (j *Jacklog) Write(p []byte) (n int, err error) {
// 	_, err = os.Stat(j.JackLog.Filename)
// 	if os.IsNotExist(err) {
// 		j.JackLog.SetFile(nil)
// 	}
// 	return j.JackLog.Write(p)
// }

// // 定义变量
// var l zerolog.Logger

// // New -.初始化日志组件
// func Init(logConf config.Log) {
// 	var ll zerolog.Level

// 	switch strings.ToLower(logConf.Level) {
// 	case "error":
// 		ll = zerolog.ErrorLevel
// 	case "warn":
// 		ll = zerolog.WarnLevel
// 	case "info":
// 		ll = zerolog.InfoLevel
// 	case "debug":
// 		ll = zerolog.DebugLevel
// 	default:
// 		ll = zerolog.InfoLevel
// 	}

// 	//全局变量设置:输出级别,时间精度（毫秒）
// 	zerolog.SetGlobalLevel(ll)
// 	zerolog.TimeFieldFormat = zerolog.TimeFormatUnixMs

// 	//上下文打印信息跳出级别
// 	skipFrameCount := 3
// 	//输出日志文件路径
// 	logPath := filepath.Join("/usr/local/hsm-os/logs", logConf.Filename)

// 	lumberjackLog := &lumberjack.Logger{
// 		Filename:   logPath,           //日志文件名
// 		MaxSize:    logConf.MaxSize,   //单个日志的文件大小（MB）
// 		MaxBackups: logConf.MaxNumber, //旧日志文件的数量，默认保留所有
// 		LocalTime:  true,              //是否启用本地时间，否则使用UTC时间
// 	}

// 	l = zerolog.
// 		New(zerolog.MultiLevelWriter(zerolog.ConsoleWriter{Out: os.Stdout, TimeFormat: "2006-01-02 15:04:05.000 ", PartsOrder: []string{"level", "time", "caller", "message"}}, zerolog.ConsoleWriter{Out: &Jacklog{JackLog: lumberjackLog}, TimeFormat: "2006-01-02 15:04:05.000", NoColor: true, PartsOrder: []string{"level", "time", "caller", "message"}})).
// 		With().
// 		Timestamp().
// 		CallerWithSkipFrameCount(skipFrameCount).
// 		Logger()

// }

// // Debug -.
// func Debug(message string, args ...interface{}) {
// 	l.Debug().Msgf(message, args...)
// }

// // Info -.
// func Info(message string, args ...interface{}) {
// 	l.Info().Msgf(message, args...)
// }

// // Warn -.
// func Warn(message string, args ...interface{}) {
// 	l.Warn().Msgf(message, args...)
// }

// // Error -.
// func Error(message interface{}, args ...interface{}) {
// 	switch msg := message.(type) {
// 	case error:
// 		l.Error().Msgf(msg.Error(), args...)
// 	case string:
// 		l.Error().Msgf(msg, args...)
// 	default:
// 		l.Error().Msgf(fmt.Sprintf("message %v has unknown type %v", message, msg), args...)
// 	}
// }

// // Fatal -.
// func Fatal(message string, args ...interface{}) {
// 	l.Error().Msgf(message, args...)
// 	os.Exit(1)
// }
