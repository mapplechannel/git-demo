# Go单元测试指导
## 引入测试框架：
Gomonkey：变量，函数打桩
Goconvey：测试用例管理，结果断言，（可视化）
引入方式（离线方式）：将最新go代码框架vendor目录下该四个目录拷贝到云桌面内对应工程vendor目录下
```
hsm-os-go-template\vendor\github.com\agiledragon
hsm-os-go-template\vendor\github.com\gopherjs
hsm-os-go-template\vendor\github.com\smartystreets
hsm-os-go-template\vendor\github.com\jtolds
```

## 测试用例目录规范：
1).  Go文件同级目录下创建xxx_test.go 
2).  涉及测试用例用到的材料放在工程根目录tests目录下
## 测试用例示例：
```
import (
	"fmt"
	"hsm-os-go-template/cmd/app"
	"testing"

	"github.com/agiledragon/gomonkey/v2"
	. "github.com/smartystreets/goconvey/convey"
)

func TestLoadImage(t *testing.T) {
	Convey("load image success", t, func() {
		patch := gomonkey.ApplyFunc(app.GetContainerAppNames, func() ([]string, error) {
			return []string{"app1", "app2"}, nil
		})
		defer patch.Reset()
		images, err := app.LoadImage()
		So(err, ShouldBeNil)
		So(len(images), ShouldEqual, 2)
	})

	Convey("load image failed", t, func() {
		patch := gomonkey.ApplyFunc(app.GetContainerAppNames, func() ([]string, error) {
			return nil, fmt.Errorf("get app names err")
		})
		defer patch.Reset()
		images, err := app.LoadImage()
		So(err, ShouldNotBeNil)
		So(len(images), ShouldEqual, 0)
	})
}
```
## 测试用例执行
在工程根目录下执行go test ./...  则会遍历目录执行所有目录下的测试用例。可以通过-run !./{path}对目录进行过滤豁免。如：
go test ./... -run !./tests !./config
PS E:\gospace\src\hsm-os-go-template> go test ./... -run !./tests !./config
?       hsm-os-go-template/cmd  [no test files]
?       hsm-os-go-template/cmd/app      [no test files]
ok      hsm-os-go-template/config       0.310s [no tests to run]
?       hsm-os-go-template/internal/app [no test files]
?       hsm-os-go-template/internal/constants   [no test files]
?       hsm-os-go-template/internal/controller/v1       [no test files]
?       hsm-os-go-template/internal/entity      [no test files]
ok      hsm-os-go-template/internal/usecase     0.242s [no tests to run]
?       hsm-os-go-template/internal/usecase/repo        [no test files]
?       hsm-os-go-template/internal/usecase/webapi      [no test files]
ok      hsm-os-go-template/internal/utils       0.248s [no tests to run]
?       hsm-os-go-template/pkg/httpserver       [no test files]
?       hsm-os-go-template/pkg/logger   [no test files]
?       hsm-os-go-template/pkg/sqllite  [no test files]
ok      hsm-os-go-template/tests        0.540s [no tests to run]

## 测试用例目标：
场景覆盖率：60%
如：
场景梳理：0. 加载镜像 1. 运行容器 2. 运行容器端口映射 3. 运行容器cpu限制 4. 运行容器memory限制 5. 运行容器目录挂载 6. 运行容器日志挂载 7. 运行容器环境变量 8 . 删除容器 9. 运行容器cni网络 10. 运行容器跨主机网络通信

经验分享：
1）. 可以一个用例覆盖几个场景，不必每个场景需要单独一个用例去覆盖
例如：运行容器，涉及容器运行资源限制，容器日志目录，端口映射等场景可以在一个用例里面同时覆盖
2）. 轻量级测试
例如：运行容器，在校验用例结果时，只需进行函数级别校验，如检查容器对象属性，不必去真实去查询一次容器结果
3）. 关注点分离，对测试场景支撑的部分可以采取打桩处理
例如：加载镜像，加载本地node.ini文件可以采用函数打桩
4）. 用例主要关注核心业务，像应用层，接口层可以不太关注
例如：加载镜像，端到端加载需要执行hsm-env image_load。我们只需进行函数级别测试，应用层不用关注

代码覆盖率：60%
1）. 场景覆盖率是目标，代码覆盖率作为检验参考（是否遗漏场景，或者存在无效代码）


## 测试用例的价值：
更好的守护功能，大胆的重构。
测试用例驱动出更好的代码（最近的代码走查问题整改可以和测试用例结合起来搞。）

示例：
1）.圈复杂度高
```
func loadImage(appFile string, namespce string) error {
	var fileNames []string
	if appFile == "" {
		names, err := ListDirTozipFile(IMAGE_BASE_PATH)
		if err != nil {
			return fmt.Errorf("read app package err, %V", err)
		}
		fmt.Printf("read local file names %v", names)
		serviceArr, err := utils.ReadLocalContainers()
		if err != nil {
			return fmt.Errorf("read nodemanifest err: %v", err)
		}
		mp := make(map[string]bool)
		for _, service := range serviceArr {
			name := service.Info.Id
			if len(service.Info.Version) != 0 {
				name = name + "-" + service.Info.Version + ".tar.gz"
			}
			if _, ok := mp[name]; !ok {
				mp[name] = true
			}
		}
		for _, filename := range names {
			if _, ok := mp[filename]; ok {
				fileNames = append(fileNames, filename)
			}
		}
	} else {
		// /usr/local/hsm-os/pack/xxx.zip
		fileNames = append(fileNames, appFile)
	}
	fmt.Printf("fileNames %v", fileNames)
	for _, fileNameAll := range fileNames {

		tarFilePath := fileNameAll
		if !strings.Contains(fileNameAll, IMAGE_BASE_PATH) && !pathExistsBool(fileNameAll) {
			tarFilePath = IMAGE_BASE_PATH + fileNameAll
		}
		extractName := getExtractName(fileNameAll)
		basePath := IMAGE_BASE_PATH + "/" + extractName
		// 解压前先清理文件夹
		if err := os.RemoveAll(basePath); err != nil {
			fmt.Printf("remove path %s err, %v", basePath, err)
		}
		fmt.Printf("image_base_path %s tarFilePath %s fileNameAll %s \n", IMAGE_BASE_PATH, tarFilePath, fileNameAll)
		_, err := utils.ExtractTarGz(IMAGE_BASE_PATH, tarFilePath)
		if err != nil {
			return fmt.Errorf("unzip err message: %v", &err)
		}
		imagesPath := basePath + "/images"
		imagesPath = filepath.Clean(imagesPath)
		boolEix, err := pathExists(imagesPath)
		if err != nil {
			fmt.Println("check images err: ", err)
			continue
		}
		if !boolEix {
			fmt.Printf("check images failed, path %s not exist", imagesPath)
			continue
		}
		arr, err := getAllImage(imagesPath)
		if err != nil {
			fmt.Println("check images path err: ", err)
			continue
		}
		if len(arr) == 0 {
			fmt.Println("images is empty")
			continue
		}
		containerdAPI := containerapi.NewContainerdAPI()
		for _, filePath := range arr {
			// load zipFilePath/images/*.tar
			if len(namespce) == 0 {
				containerdAPI = containerdAPI.WithDedaultNamespace()
			} else {
				containerdAPI = containerdAPI.WithNamespace(namespce)
			}
			fmt.Println(filePath)
			imgUsercase := usecase.NewImageServiceUsecase(containerdAPI)
			if err := loadImageWithRetry(imgUsercase, filePath, 3); err != nil {
				fmt.Printf("load image err: %v \n", err)
				continue
			}
		}
		// 解压后再清理文件夹
		errRmove := os.RemoveAll(basePath)
		if errRmove != nil {
			fmt.Println("load image remove error:", err)
			continue
		}
	}
	return nil
}
```

2）.测试用例
```
func TestLoadImage(t *testing.T) {
	Convey("load image success", t, func() {
		patch := initAppPackage()
		defer patch.Reset()
		loadImages, err := app.LoadImage("")
		So(err, ShouldBeNil)
		So(len(loadImages), ShouldEqual, 1)
		fmt.Printf("image name %s", loadImages[0].Name)
	})
}

func initAppPackage() *gomonkey.Patches {
	clearCommand := exec.Command("rm -f /usr/local/hsm-os/pack/dist2-0.1.1.tar.gz")
	createCommand := exec.Command("cp ./appPackage/dist2-0.1.1.tar.gz /usr/local/hsm-os/pack/")
	clearCommand.Run()
	createCommand.Run()
	patch := gomonkey.ApplyFunc(utils.ReadLocalContainerApps, func() ([]nodeapp.Service, error) {
		apps := []nodeapp.Service{}
		service := nodeapp.Service{
			Info: nodeapp.Info{
				Id:      "dist2",
				Name:    "dist2",
				Version: "0.1.1",
			},
		}
		apps = append(apps, service)
		return apps, nil
	})
	return patch
}
```

3）.代码重构后代码
```
// 代码走查，问题1. 圈复杂度高 -> 完成整改
func LoadImage(appFile string) (loadImages []images.Image, err error) {
	appPackages := []string{appFile}
	if appFile == "" {
		appPackages, err = getContainerAppPackages()
		if err != nil {
			fmt.Printf("get image paths err, %v \n", err)
			return nil, err
		}
	}
	for _, appPackage := range appPackages {
		var (
			appPackagePath = IMAGE_BASE_PATH + "/" + appPackage
			appName        = getExtractName(appPackage)
			appPath        = IMAGE_BASE_PATH + "/" + appName
			imagesPath     = appPath + "/images"
		)
		images, err := loadAppImage(appPath, imagesPath, appPackagePath)
		if err != nil {
			fmt.Printf("load app image err, %v \n ", err)
			continue
		}
		loadImages = append(loadImages, images...)
	}
	return loadImages, nil
}
```
