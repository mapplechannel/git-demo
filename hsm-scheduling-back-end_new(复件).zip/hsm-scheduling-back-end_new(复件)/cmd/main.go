package main

import (
	"hsm-scheduling-back-end/cmd/app"
	"os"
)

// @title HSM-IOI 信息信息系统集成
// @version V0.1.2
func main() {
	command := app.NewRootCommand()
	if err := command.Execute(); err != nil {
		os.Exit(1)
	}
}
