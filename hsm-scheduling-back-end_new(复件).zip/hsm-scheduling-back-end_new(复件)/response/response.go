package response

import (
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
)

const (
	REQUEST_PARAM_INVALID = 306

	DATABASE_CONNECT_FAILED = 601

	DATABASE_OPERATION_FAILED = 602

	DATABASE_READ_FAILED = 616

	DATABASE_UPDATE_FAILED = 618

	DELETE_FAILED = 1100601

	EXPORT_FAILED = 1100602

	SEARCH_FAILED = 1100603

	IMPORT_FAILED = 1100605

	OPERATION_FAILED = 1100607

	GET_INFO_FAILED = 1100608

	CHECK_FAILED = 1100609

	GATEWAY_FAILED = 1100610

	// 优先级接口
	JOB_ALREADY_EXIST           = 1100611
	JSON_DESERIALIZATION_FAILED = 1100612
	FILE_ERROR                  = 1100613

	FILE_NOT_FOUND            = 1100614
	RUNNING_JOB_NOT_OP        = 1100615
	JSON_SERIALIZATION_FAILED = 1100616

	START_JOB_FAILED = 1100617
	STOP_JOB_FAILED  = 1100618

	COMPRESS_FAILED    = 1100619
	DELETE_FILE_FAILED = 1100620
	CONTENT_EMPTY      = 1100621

	SAVE_FILE_FAILED = 1100622

	PORT_IS_OCCUPIED = 1100623

	EXIST_JOB          = 1100624
	EXECUTOR_MAXTASKS  = 1100625
	EXECUTOR_SAME_NAME = 1100626
)

var ERROR_CODE_MAP = map[int]MsgInfo{
	REQUEST_PARAM_INVALID:     {En: "Invalid parameters", Zh: "无效的请求参数"},
	DATABASE_CONNECT_FAILED:   {En: "Database connection failed", Zh: "数据库连接失败"},
	DATABASE_OPERATION_FAILED: {En: "Database operation failed", Zh: "数据库操作失败"},
	DATABASE_READ_FAILED:      {En: "Database read failed", Zh: "数据库读取失败"},
	DATABASE_UPDATE_FAILED:    {En: "Database update failed", Zh: "数据库更新失败"},
	DELETE_FAILED:             {En: "Delete failed", Zh: "删除失败"},
	EXPORT_FAILED:             {En: "Export failed", Zh: "导出失败"},
	SEARCH_FAILED:             {En: "Search failed", Zh: "查询失败"},
	IMPORT_FAILED:             {En: "Import failed", Zh: "导入失败"},
	OPERATION_FAILED:          {En: "Operation failed", Zh: "操作失败"},
	GET_INFO_FAILED:           {En: "Get infomation failed", Zh: "获取失败"},
	CHECK_FAILED:              {En: "Check failed", Zh: "校验失败"},
	GATEWAY_FAILED:            {En: "Gateway error", Zh: "网关错误"},

	JOB_ALREADY_EXIST:           {En: "Job Already exist", Zh: "作业已存在"},
	JSON_DESERIALIZATION_FAILED: {En: "Json Deserialization failed", Zh: "json反序列化出错"},
	FILE_ERROR:                  {En: "Job Already exist", Zh: "文件出错"},

	FILE_NOT_FOUND:            {En: "File not found", Zh: "文件不存在"},
	RUNNING_JOB_NOT_OP:        {En: "Job is running,connot de deleted", Zh: "作业正在运行中，不允许操作"},
	JSON_SERIALIZATION_FAILED: {En: "Json serialization failed", Zh: "json序列化错误"},
	START_JOB_FAILED:          {En: "Start job failed", Zh: "作业启动失败"},
	STOP_JOB_FAILED:           {En: "Stop job failed", Zh: "作业停止失败"},
	COMPRESS_FAILED:           {En: "Compress failed", Zh: "压缩失败"},
	DELETE_FILE_FAILED:        {En: "Delete file failed", Zh: "删除文件失败"},
	CONTENT_EMPTY:             {En: "Content empty", Zh: "内容为空"},
	SAVE_FILE_FAILED:          {En: "Save file failed", Zh: "保存文件失败"},
	PORT_IS_OCCUPIED:          {En: "Port is Occupied", Zh: "端口被占用，请重新输入"},
	EXIST_JOB:                 {En: "Executor has job, cannot delete", Zh: "执行器下存在作业，无法删除"},
	EXECUTOR_MAXTASKS:         {En: "Executor maxTasks less than existTasks", Zh: "执行器已有作业数大于最大作业数，请重新输入"},
	EXECUTOR_SAME_NAME:        {En: "There exists an executor with the same name", Zh: "存在同名的执行器"},
}

type MsgInfo struct {
	En string `json:"en"`
	Zh string `json:"zh"`
}

func GetMsg(code int) string {
	return ERROR_CODE_MAP[code].Zh
}

func Response(ctx *gin.Context, httpStatus int, code int, data gin.H, msg string) {
	ctx.JSON(httpStatus, gin.H{
		"code":    code,
		"results": data,
		"message": msg,
	})
}

func Success(ctx *gin.Context, data gin.H, msg string) {
	Response(ctx, http.StatusOK, 200, data, msg)
}

func Fail(ctx *gin.Context, msg string, data gin.H) {
	Response(ctx, http.StatusOK, 400, data, msg)
}

func ENG_Response(ctx *gin.Context, httpStatus int, code int, data interface{}, msg string, timestamp time.Time) {
	ctx.JSON(httpStatus, gin.H{
		"code":      code,
		"data":      data,
		"message":   msg,
		"timestamp": timestamp.Unix(),
	})
}

func ENG_Success(ctx *gin.Context, msg string, data interface{}, timestamp time.Time) {
	ENG_Response(ctx, http.StatusOK, 0, data, msg, timestamp)
}

func ENG_Fail(ctx *gin.Context, msg string, data interface{}, timestamp time.Time) {
	ENG_Response(ctx, http.StatusOK, -1, data, msg, timestamp)
}

func DataPublish_Response(ctx *gin.Context, httpStatus int, code int, data interface{}, msg string, timestamp time.Time) {
	ctx.JSON(httpStatus, gin.H{
		// "status":    code,
		"code":      code,
		"message":   msg,
		"timestamp": timestamp.Unix(),
		"data":      data,
	})
}

func DataPublish_Success(ctx *gin.Context, msg string, data interface{}, timestamp time.Time) {
	DataPublish_Response(ctx, http.StatusOK, 0, data, msg, timestamp)
}

func DataPublish_Fail(ctx *gin.Context, msg string, data interface{}, timestamp time.Time) {
	DataPublish_Response(ctx, http.StatusOK, -1, data, msg, timestamp)
}

func Api_Success(ctx *gin.Context, data interface{}, msg string, timestamp time.Time) {
	ctx.JSON(http.StatusOK, gin.H{
		"code":      0,
		"message":   msg,
		"data":      data,
		"timestamp": timestamp.Unix(),
	})
}

func Api_Fail(ctx *gin.Context, msg string, timestamp time.Time) {
	ctx.JSON(http.StatusOK, gin.H{
		"code":      -1,
		"message":   msg,
		"timestamp": timestamp.Unix(),
	})
}

func Api_Code_Fail(ctx *gin.Context, code int, timestamp time.Time) {
	ctx.JSON(http.StatusOK, gin.H{
		"code":      code,
		"message":   GetMsg(code),
		"timestamp": timestamp.Unix(),
	})
}
