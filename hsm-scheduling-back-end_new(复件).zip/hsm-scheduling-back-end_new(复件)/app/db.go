package app

import (
	"errors"
	"fmt"
	"hsm-scheduling-back-end/config"
	"os"
	"strconv"
)

func New() {
	// logger := logger.New(
	// 	log.Default(),
	// 	logger.Config{
	// 		LogLevel: logger.Error,
	// 		//LogLevel:                  2,
	// 		IgnoreRecordNotFoundError: true,
	// 		Colorful:                  true,
	// 	},
	// )

	//从环境变量读取pg信息
	envPg, err := buildPgConfFromEnv()
	if err == nil {
		config.ConfigAll.Postgres = envPg
	} else {
		fmt.Println("环境变量不存在pg连接信息,默认连接config.yml中的pg配置")
	}

	// logger.Info("envPg:%v", envPg)
	// logger.Info("envPg:%v", config.ConfigAll.Postgres.Url)

	// //连接store数据库
	// db, err := gorm.Open(postgres.Open(fmt.Sprintf("%s dbname=%s", pg.Url, pg.DbName)), &gorm.Config{
	// 	Logger: logger,
	// })
	// if err != nil {
	// 	return nil, fmt.Errorf("open postgres datasource err, %v", err)
	// }
	// sqlDb, err := db.DB()
	// if err != nil {
	// 	return nil, fmt.Errorf("config postgres datasource err, %v", err)
	// }
	// sqlDb.SetMaxIdleConns(pg.MaxIdleConns)                                    //设置连接池中的最大空闲连接数，默认值为2
	// sqlDb.SetMaxOpenConns(pg.MaxOpenConns)                                    //设置连接池中的最大连接数，默认值为0，表示没有限制
	// sqlDb.SetConnMaxIdleTime(time.Second * time.Duration(pg.ConnMaxIdleTime)) //设置连接在连接池中的最大空闲时间，默认0，表示没有限制
	// sqlDb.SetConnMaxLifetime(time.Second * time.Duration(pg.ConnMaxLifetime)) //设置连接在连接池中的最大生存时间。默认值为0，表示没有限制。
}

// 从环境变量读取pg信息
func buildPgConfFromEnv() (config.Postgres, error) {
	pgConf := config.Postgres{}

	pgDbName := os.Getenv("DB_DATASOURCE")
	databaseIp := os.Getenv("database_ip")
	databasePort := os.Getenv("database_port")
	databaseUser := os.Getenv("database_user")
	databasePwd := os.Getenv("database_pwd")
	if databaseIp == "" || databasePort == "" || databaseUser == "" || databasePwd == "" {
		return pgConf, errors.New("环境变量不存在数据库连接信息")
	}
	pgUrl := "host=" + databaseIp + " port=" + databasePort + " user=" + databaseUser + " password=" + databasePwd + " sslmode=disable TimeZone=Asia/Shanghai"
	
	pgMaxIdleConnsStr := os.Getenv("POSTGRES_MAX_IDLE_CONNS")
	pgMaxIdleConns, err := strconv.Atoi(pgMaxIdleConnsStr)
	if err != nil {
		return pgConf, err
	}
	pgMaxOpenConnsStr := os.Getenv("POSTGRES_MAX_OPEN_CONNS")
	pgMaxOpenConns, err := strconv.Atoi(pgMaxOpenConnsStr)
	if err != nil {
		return pgConf, err
	}
	pgConnMaxIdleTimeStr := os.Getenv("POSTGRES_CONN_MAX_IDLE_TIME")
	pgConnMaxIdleTime, err := strconv.Atoi(pgConnMaxIdleTimeStr)
	if err != nil {
		return pgConf, err
	}
	pgConnMaxLifetimeStr := os.Getenv("POSTGRES_CONN_MAX_LIFETIME")
	pgConnMaxLifetime, err := strconv.Atoi(pgConnMaxLifetimeStr)
	if err != nil {
		return pgConf, err
	}
	pgConf.Url = pgUrl
	pgConf.DbName = pgDbName
	pgConf.MaxIdleConns = pgMaxIdleConns
	pgConf.MaxOpenConns = pgMaxOpenConns
	pgConf.ConnMaxIdleTime = pgConnMaxIdleTime
	pgConf.ConnMaxLifetime = pgConnMaxLifetime
	return pgConf, nil
}
