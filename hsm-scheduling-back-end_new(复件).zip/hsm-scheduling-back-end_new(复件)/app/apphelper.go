package app

import (
	"context"
	"fmt"
	jobschedule "hsm-scheduling-back-end/internal/job_schedule"
	"hsm-scheduling-back-end/internal/util"
	"hsm-scheduling-back-end/internal/vo"
	"hsm-scheduling-back-end/pkg/logger"
	"os"
	"os/exec"
	"strings"
	"time"

	"gorm.io/gorm"
)

func InitSys() {
	util.GetNodeServer()
	// 初始化portal菜单
	if checkArch() == "x86_64" {
		logger.Info("初始化菜单")
		InitPortalMenu()
	}
	New()
	InitDB()
	jobschedule.InitExecutor()
	go jobschedule.FailOver()
	StartJobs()
}

func InitPortalMenu() {
	shPath := "./meun.sh"

	cmd := exec.Command("bash", shPath)
	output, err := cmd.Output()
	if err != nil {
		logger.Info("Init portal menu failed:%v", err)
	}
	logger.Info(string(output))
}

func InitDB() {
	db, err := jobschedule.GetPgConnByGORM()
	if err != nil {
		logger.Info("Fail to connect pg:%v", err)
	}

	schemaName := "hsm_scheduling"

	if !schemaExists(db, schemaName) {
		createSchema(db, schemaName)
	}

	db = db.Exec(fmt.Sprintf("SET search_path TO %s", schemaName))

	if err = db.AutoMigrate(&vo.Task{}, &vo.RuningLog{}, &vo.SysLog{}, &vo.Executor{}); err != nil {
		logger.Info("Failed to AutoMigrate:%v", err)
	}

	var count int64
	db.Raw(`SELECT COUNT(1) FROM pg_indexes WHERE schemaname = 'hsm_scheduling' AND tablename = 'sys_logs' AND indexname = 'idx_logtime'`).Scan(&count)

	if count == 0 {
		err := db.Exec(`CREATE INDEX idx_logtime on hsm_scheduling.sys_logs (logtime);`)
		if err != nil {
			logger.Info("create index failed:%v", err)
		}
	} else {
		logger.Info("index already exist")
	}

}

func schemaExists(db *gorm.DB, schemaName string) bool {
	var exists bool
	query := `SELECT EXISTS (SELECT 1 FROM pg_catalog.pg_namespace WHERE nspname = $1)`
	db.Raw(query, schemaName).Scan(&exists)
	return exists
}

func createSchema(db *gorm.DB, schemaName string) {
	query := fmt.Sprintf("CREATE SCHEMA %s", schemaName)
	if err := db.Exec(query).Error; err != nil {
		logger.Info("failed to create schema:%v", err)
	}
}

func checkArch() string {
	cmd := exec.Command("uname", "-m")
	output, err := cmd.Output()
	if err != nil {
		logger.Info("uname -m报错:%v", err)
	}
	arch := strings.TrimSpace(string(output))
	logger.Info("当前架构为:%v", arch)
	return arch
}

func StartJobs() {
	hsmTemplate := os.Getenv("HSM_TEMPLATE")

	logger.Info("hsmTemplate is :%v", hsmTemplate)
	var tasks []vo.UpdateJob
	// if hsmTemplate == "single" {
	err := jobschedule.GlobalDb.Table("hsm_scheduling.tasks").Where("status = ?", "1").Find(&tasks).Error
	if err != nil {
		logger.Info("err is :%v", err)
	}
	for i := range tasks {
		jobkey := vo.GetID{
			ID: tasks[i].ID,
		}
		StartRun(jobkey)
	}

	// 	requestBody, err := json.Marshal(jobkey)

	// 	if err != nil {
	// 		logger.Info("Fail to mapping:%v", err)
	// 	}
	// 	// ip := util.ServerCode + constants.DomainName
	// 	req, err := http.NewRequest("POST", constants.Http+"172.21.222.10"+":6222/api/hsm-ds/task/run", bytes.NewBuffer(requestBody))
	// 	if err != nil {
	// 		logger.Info("Fail to send request:%v", err)
	// 	}
	// 	req.Header.Set("Content-Type", "application/json")
	// 	client := &http.Client{}
	// 	resp, err := client.Do(req)
	// 	if err != nil {
	// 		logger.Info("Failed to excute job:%v", err)
	// 	} else {
	// 		defer resp.Body.Close()
	// 		if resp.StatusCode != http.StatusOK {
	// 			logger.Info("Failed to excute job:%v", err)
	// 		}
	// 		body, err := ioutil.ReadAll(resp.Body)
	// 		if err != nil {
	// 			logger.Info("Failed to excute job:%v", err)
	// 		}
	// 		logger.Info("body:%v", string(body))
	// 	}
	// }
	// }

	// if hsmTemplate == "double-integ-manifest" {
	// 	// 如果只有一个挂掉，怎么判断，
	// }
}

func StartRun(idVo vo.GetID) {
	_, task := jobschedule.FindTask(context.Background(), idVo.ID)
	_ = jobschedule.UpdateStatus(task.ID, "1")

	if strings.HasPrefix(task.Integrated, "IOIT") {
		if task.ScheduleType == "cron" && task.Each.Type == "once" {
			uniqueSlice := strings.Split(task.Integrated, "@")
			namespace := uniqueSlice[1]
			code := uniqueSlice[2]
			var ioitJob vo.JobInfoIoit
			if err := jobschedule.GlobalDb.Table("ioit.job_info").Where("code = ? AND namespace = ?", code, namespace).First(&ioitJob).Error; err != nil {
				logger.Info("select ioitinfo err :%v", err)
			}
			logger.Info("ioitJob.CronDetail is :%v", ioitJob.CronDetail)
			logger.Info("ioitJob.PeriodDetail is :%v", ioitJob.PeriodDetail)
			failover := vo.FailOverNode{
				TaskId:      task.ID,
				RunningNode: util.ServerCode,
			}
			jobschedule.UpsertFailOverNode(&failover)

			startDate, err := time.Parse("2006-01-02 15:04:05", ioitJob.CronDetail.EffectiveDate)
			if err != nil {
				logger.Info("parse effectiveDate error:%v", err)
			}

			tarTime := time.Date(startDate.Year(), startDate.Month(), startDate.Day(), startDate.Hour(), startDate.Minute(), startDate.Second(), 0, time.Local)

			duration := time.Until(tarTime)
			logger.Info("duration:%v", duration)
			if duration <= 0 {
				logger.Info("time is in the past")
			}
			time.AfterFunc(duration, func() { jobschedule.ManualRunTask(task, nil) })
			return
		}
	}

	if task.ScheduleType == "none" {
		code := jobschedule.GenerateCode()
		runningLog := vo.RuningLog{
			ID:       code,
			Operator: task.CreateUser,
			JobName:  task.JobName,
			Executor: task.Executor,
			TaskId:   task.ID,
		}
		if !strings.HasPrefix(task.Integrated, "IOIT") {
			jobschedule.UpdateInstanceEndTimeIfEmpty(task.LastInstanceId)
			jobschedule.UpdateInstanceIdByTaskId(task.ID, code)
		}
		failover := vo.FailOverNode{
			TaskId:      task.ID,
			RunningNode: util.ServerCode,
		}
		jobschedule.UpsertFailOverNode(&failover)
		go jobschedule.ManualRunTask(task, &runningLog)
	} else {
		if task.Each.Type == "once" {
			date, err := time.Parse("2006-01-02", task.Each.EffectiveDate)
			if err != nil {
				logger.Info("failed to parse date:%v", err)
			}

			parseTime, err := time.Parse("15:04:05", task.Each.Time)
			if err != nil {
				logger.Info("failed to parse time:%v", err)
			}

			failover := vo.FailOverNode{
				TaskId:      task.ID,
				RunningNode: util.ServerCode,
			}
			jobschedule.UpsertFailOverNode(&failover)

			tarTime := time.Date(date.Year(), date.Month(), date.Day(), parseTime.Hour(), parseTime.Minute(), parseTime.Second(), 0, time.Local)

			duration := time.Until(tarTime)
			if duration <= 0 {
				logger.Info("time is in the past")
			}
			code := jobschedule.GenerateCode()
			runningLog := vo.RuningLog{
				ID:       code,
				Operator: task.CreateUser,
				JobName:  task.JobName,
				Executor: task.Executor,
				TaskId:   task.ID,
			}
			jobschedule.UpdateInstanceEndTimeIfEmpty(task.LastInstanceId)
			jobschedule.UpdateInstanceIdByTaskId(task.ID, code)
			time.AfterFunc(duration, func() { jobschedule.ManualRunTask(task, &runningLog) })
		} else {
			go jobschedule.GlobalScheduler.StartTask(*task)
		}
	}
}
