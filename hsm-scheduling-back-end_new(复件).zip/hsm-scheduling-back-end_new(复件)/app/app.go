package app

import (
	"hsm-scheduling-back-end/config"
	"hsm-scheduling-back-end/internal/constants"
	"hsm-scheduling-back-end/internal/route"

	"hsm-scheduling-back-end/pkg/logger"

	"github.com/gin-gonic/gin"
)

func Run(cfg *config.Config) {
	logger.Info("hsm-scheduling: start....")
	// 初始化日志组件
	logger.Init(cfg.Log)
	// 初始化配置文件
	// CheckFile(cfg)
	// 设置服务器运行模式
	gin.SetMode(gin.ReleaseMode)
	r := gin.New()
	// 匹配路由
	r = route.CollectRoute(r)

	InitSys()
	port := cfg.HTTP.Port
	logger.Info("开始启动定时调度")

	// 启动服务
	if port != constants.EmptyContent {
		panic(r.Run(constants.AddressSplicingSymbols + port))
	}
	panic(r.Run())

}
