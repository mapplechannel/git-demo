package config

import (
	"fmt"

	"github.com/ilyakaznacheev/cleanenv"
)

// Config -.
type Config struct {
	App      `yaml:"app"`
	HTTP     `yaml:"http"`
	Log      `yaml:"logger"`
	Postgres `yaml:"postgres"`
	FILE     `yaml:"file"`
}

// App -.
type App struct {
	Name    string `env-required:"true" yaml:"name"    env:"APP_NAME"`
	Version string `env-required:"true" yaml:"version" env:"APP_VERSION"`
}

// HTTP -.
type HTTP struct {
	Port string `env-required:"true" yaml:"port" env:"HTTP_PORT"`
}

// Log -.
type Log struct {
	Level     string `env-required:"true" yaml:"level"   env:"LEVEL"`
	MaxSize   int    `env-required:"true" yaml:"max_size"   env:"MAX_SIZE"`
	MaxNumber int    `env-required:"true" yaml:"max_number"   env:"MAX_NUMBER"`
	Filename  string `env-required:"true" yaml:"filename"   env:"FILENAME"`
}

// PG -.
type Postgres struct {
	Url             string `yaml-required:"true" yaml:"url" env:"URL"`
	DbName          string `yaml-required:"true" yaml:"db_name" env:"DBNAME"`
	MaxIdleConns    int    `yaml-required:"true" yaml:"max_idle_conns" env:"MAX_IDLE_CONNS"`
	MaxOpenConns    int    `yaml-required:"true" yaml:"max_open_conns" env:"MAX_OPEN_CONNS"`
	ConnMaxIdleTime int    `yaml-required:"false" yaml:"conn_max_idle_time" env:"CONN_MAX_IDLE_TIME"`
	ConnMaxLifetime int    `yaml-required:"false" yaml:"conn_max_lifetime" env:"CONN_MAX_LIFETIME"`
}

type FILE struct {
	Path           string `env-required:"true" yaml:"path"`
	Project        string `env-required:"true" yaml:"project"`
	BenthosLogs    string `env-required:"true" yaml:"benthos_log"`
	BenthosData    string `env-required:"true" yaml:"benthos_data"`
	BenthosMetrics string `env-required:"true" yaml:"benthos_metrics"`
}

// 定义配置文件的全局变量
var ConfigAll *Config

// 创建一个新的配置
func NewConfig(cfgFile string) (*Config, error) {
	cfg := &Config{}

	// 解析配置文件
	err := cleanenv.ReadConfig(cfgFile, cfg)
	if err != nil {
		return nil, fmt.Errorf("config error: %w", err)
	}

	// 解析环境变量
	err = cleanenv.ReadEnv(cfg)
	if err != nil {
		return nil, err
	}
	ConfigAll = cfg
	return cfg, nil
}
