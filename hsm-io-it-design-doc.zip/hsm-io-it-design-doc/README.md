# 设计说明

1. 本库是信息系统集成工具的设计文档，包括：设计文档的目录结构、设计文档的章节、文档章节的编写概要。

2. 设计文档采用`gitbook`规范编写，采用`Markdown`语法格式，`gitbook-cli`工具进行发布。

3. 设计文档的编写规则，参见 `hsm-os/hsm-sepc/devops-spec` 库中 `设计管理` 章节。

## 目录说明

采用`Markdown`格式编写，存储在 `gitlab` 仓库中,目录结构说明入下：

```bash
.
├── docs                ---- gitbook设计文档存储目录
│   ├── module          ---- 设计文档中模块子目录根据子系统模块重新命名
│   │   └── images      ---- 模块设计中的图片存储
│   ├── README.md       ---- 设计文档的概述
│   └── SUMMARY.md      ---- 设计文档的目录结构
├── files               ---- 存储设计类源文件
│   └── eng.axure       ---- 原型图设计源文件
├── package.json        ---- 编译发布配置文件
└── README.md           ---- 设计文档库描述性说明
```

## 启动预览

`npm run serve`
