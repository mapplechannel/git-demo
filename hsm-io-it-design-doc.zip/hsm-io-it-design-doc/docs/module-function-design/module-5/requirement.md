# 需求编号

|需求编号|需求名称|
|:-|:-:|
|HSM-OS-IOI-SRS-SW-A-M03-01|作业信息监控|
|HSM-OS-IOI-SRS-SW-A-M03-02|作业运行日志|
|HSM-OS-IOI-SRS-SW-A-M03-03|作业状态报警|
