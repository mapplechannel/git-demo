# 界面设计

## 作业信息监控

### 页面原型

![作业监控](./images/image1.png)

## 作业运行日志

### 页面原型

![日志](./images/image2.png)
