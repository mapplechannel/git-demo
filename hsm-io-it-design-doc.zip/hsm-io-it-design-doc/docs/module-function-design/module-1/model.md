# 模型或数据设计

## 数据结构

### 作业列表数据结构

|字段名称|字段类型|字段描述|
|:-|:-:|:-:|
|code|String|作业编号|
|id|String|作业id|
|name|String|作业名称|
|status|Int|状态|
|create_time|String|创建时间|
|edite_time|String|编辑时间|
|create_use|String|创建用户|
|describe|String|作业描述|
|isAutoSelectId|String|发布时是否自动选中|
|s_node|String|所属服务器名称|
|node|Int|所属服务器编号|

### 作业画布数据结构

|字段名称|字段类型|字段描述|
|:-|:-:|:-:|
|canvas|Object|画布元素（组件、连线）集合|
|content|Object|作业配置YAML集合|
|code|String|作业编号|
|cron_id|String|定时任务编号|
|describe|String|作业描述|
|is_http|Boolean|是否为http客户端输入|
|namespace|String|ENG项目id|
|name|String|作业名称|
|nickName|String|创建用户|
|node|Int|所属服务器编号|
|s_node|String|所属服务器名称|
|schedule|String|调度类型|
|schedule_cycle|String|调度数值|
|schedule_details|String|调度详情（cron表达式）|
|schedule_unit|String|调度单位|
