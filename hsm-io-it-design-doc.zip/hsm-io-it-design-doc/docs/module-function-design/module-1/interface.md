# 接口设计

作业配置管理的接口列表如下：

|API名称|请求类型|访问地址|
|:-|:-:|:-:|
|add|POST|[链接](#信息系统集成页面新增作业)|
|delete|DELETE|[链接](#信息系统集成页面删除作业)|
|saveJobInfo|POST|[链接](#信息系统集成页面保存作业)|
|getJobList|POST|[链接](#信息系统集成页面获取作业列表)|
|exportBatchJob|POST|[链接](#信息系统集成导出项目)|
|exportJob|POST|[链接](#信息系统集成导出作业)|
|importBatchJobs|POST|[链接](#信息系统集成导入项目)|
|importJob|POST|[链接](#信息系统集成导入作业)|

## 信息系统集成页面新增作业

```json
 点击新增图标，新增作业
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/job/add

### 请求方式

> POST

### Content-Type

> json

### 请求Body参数

```json
{
  "schedule": "2",
  "s_node": "e1",
  "nickName": "admin",
  "name": "新建作业",
  "namespace": "165581d8e58a42bebe9e929cd043fecc",
  "schedule_cycle": "5",
  "schedule_unit": "second"
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| name | 新建作业  | String   | 是       | 作业名称        |
| namespace | 165581d8e58a42bebe9e929cd043fecc  | String   | 是       | 项目id        |
| nickName | admin  | String   | 是       | 创建人        |
| s_node | e1  | String   | 是       | 服务器编号        |
| schedule | 2  | String   | 是       | 调度类型        |
| schedule_cycle | 5  | String   | 是       | 周期调度值        |
| schedule_unit | second  | String   | 是       | 周期调度单位        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{
  "code": 0,
  "data": {
    "node": 0,
    "code": "job_m7n8fz1i",
    "id": "job_m7n8fz1i",
    "name": "新建作业",
    "status": 0,
    "create_time": "2023-12-02 10:41:46",
    "edite_time": "2023-12-02 10:41:46",
    "create_use": "admin",
    "describe": "",
    "isAutoSelectId": true,
    "s_node": "e1"
  },
  "message": "",
  "timestamp": 1701484906
}
```

### 异常响应编码
```
306 / 1100611 / 1100612 / 1100613 / 1100607
```

## 信息系统集成页面删除作业

```json
 点击删除图标，删除作业
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/job/delete

### 请求方式

> DELETE

### Content-Type

> json

### 请求Body参数

```json
{
  "code": "job_ehyuvn00",
  "namespace": "165581d8e58a42bebe9e929cd043fecc"
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| code | job_ehyuvn00  | String   | 是       | 作业编号        |
| namespace | 165581d8e58a42bebe9e929cd043fecc  | String   | 是       | 项目id        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{ 
    "code": 0, 
    "data": true, 
    "message": "", 
    "timestamp": 1701486108 
}
```

### 异常响应编码
```
306 / 1100614 / 1100615 / 1100616 / 1100601
```

## 信息系统集成页面保存作业

```json
 点击保存图标，保存作业数据
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/job/saveJobInfo

### 请求方式

> POST

### Content-Type

> json

### 请求Body参数

```json
{
  "namespace": "165581d8e58a42bebe9e929cd043fecc",
  "nickName": "admin",
  "node": 0,
  "s_node": "e1",
  "code": "job_e2yjh2uo",
  "name": "新建作业",
  "describe": "",
  "schedule": "2",
  "schedule_details": "",
  "schedule_cycle": "5",
  "schedule_unit": "second",
  "cron_id": "",
  "is_http": false,
  "schedule_type": "period",
  "canvas": {
    "nodeList": [
      {
        "absoluteLeft": "656px",
        "allowDrag": true,
        "attrs": { "fileName": "新建作业", "fileType": "json" },
        "flowNodeType": "output",
        "id": "e1d8f825-b9cd-d66b-6718-0f7e74c41637",
        "img": "file",
        "inputdata": {
          "arrType": [],
          "objType": {
            "JSON": {
              "assemble": {
                "file2": {
                  "txtData": "你好啊1!\r\nhow are you2!\r\n你也好啊3！\r\n"
                }
              },
              "item": {
                "txtData": "你好啊1!\r\nhow are you2!\r\n你也好啊3！\r\n"
              },
              "source": {
                "fileType": "txt",
                "resultKey": "txtData",
                "sourceData": "{\"txtData\":\"你好啊1!\\r\\nhow are you2!\\r\\n你也好啊3！\\r\\n\"}",
                "type": "json"
              }
            }
          }
        },
        "isConfig": true,
        "label": "文件系统输出",
        "left": "41.75px",
        "message": "配置完毕",
        "needConfig": true,
        "noConfigMsg": "请配置文件信息",
        "nodeMark": "file",
        "nodeType": "inputOrOutput",
        "outputdata": {
          "arrType": [],
          "objType": {
            "JSON": {
              "assemble": {
                "file2": {
                  "txtData": "你好啊1!\r\nhow are you2!\r\n你也好啊3！\r\n"
                }
              },
              "item": {
                "txtData": "你好啊1!\r\nhow are you2!\r\n你也好啊3！\r\n"
              },
              "source": {
                "fileType": "txt",
                "resultKey": "txtData",
                "sourceData": "{\"txtData\":\"你好啊1!\\r\\nhow are you2!\\r\\n你也好啊3！\\r\\n\"}",
                "type": "json"
              }
            }
          }
        },
        "resultKey": "file1",
        "status": "success",
        "top": "101px",
        "value": "File"
      },
      {
        "absoluteLeft": "26px",
        "allowDrag": true,
        "attrs": {
          "clientAttr": {
            "form": {
              "delimiter": ",",
              "fileName": "文本数据换行.txt",
              "source": "client"
            },
            "state": {
              "uploadFilePath": "/usr/local/hsm-os/data/hsm-io-it/data/project/165581d8e58a42bebe9e929cd043fecc/upload/文本数据换行_1701488298.txt",
              "uploadFileType": "text/plain"
            }
          },
          "fileSource": "client"
        },
        "flowNodeType": "input",
        "id": "cbcf55fe-c840-8bba-f2e7-73bf9a60b3eb",
        "img": "file",
        "isConfig": true,
        "label": "文件系统输入",
        "left": "26px",
        "message": "配置完毕",
        "needConfig": true,
        "noConfigMsg": "请配置文件信息",
        "nodeMark": "file",
        "nodeType": "inputOrOutput",
        "outputdata": {
          "arrType": [],
          "objType": {
            "JSON": {
              "assemble": {
                "file2": {
                  "txtData": "你好啊1!\r\nhow are you2!\r\n你也好啊3！\r\n"
                }
              },
              "item": {
                "txtData": "你好啊1!\r\nhow are you2!\r\n你也好啊3！\r\n"
              },
              "source": {
                "fileType": "txt",
                "resultKey": "txtData",
                "sourceData": "{\"txtData\":\"你好啊1!\\r\\nhow are you2!\\r\\n你也好啊3！\\r\\n\"}",
                "type": "json"
              }
            }
          }
        },
        "resultKey": "file2",
        "status": "success",
        "top": "82px",
        "value": "File"
      }
    ],
    "lineList": [
      {
        "anchors": [
          [1, 0, 0, 0, -1, 40],
          [0, 0, 0, 0, 1, 40]
        ],
        "source": "cbcf55fe-c840-8bba-f2e7-73bf9a60b3eb",
        "target": "e1d8f825-b9cd-d66b-6718-0f7e74c41637",
        "uuids": [
          "cbcf55fe-c840-8bba-f2e7-73bf9a60b3eb_Right_1",
          "e1d8f825-b9cd-d66b-6718-0f7e74c41637_Left_1"
        ]
      }
    ]
  },
  "content": {
    "benthos_yaml": "input:\n  file:\n    codec: all-bytes\n    paths:\n      - /usr/local/hsm-os/data/hsm-io-it/data/project/165581d8e58a42bebe9e929cd043fecc/upload/文本数据换行_1701488298.txt\n  label: file2_1\npipeline:\n  processors:\n    - label: file2_2\n      mapping: |\n        root.txtData = content().string()\noutput:\n  broker:\n    outputs:\n      - label: log\n        test_stdout: {}\n      - file:\n          path: /usr/local/hsm-os/data/hsm-io-it/data/benthos/temp/新建作业@job_e2yjh2uo.json\nlogger:\n  level: ALL\n  format: json\n  add_timestamp: true\n  file:\n    path: /usr/local/hsm-os/data/hsm-io-it/data/benthos/json/job_e2yjh2uo.json\n    rotate: true\n",
    "benthos_componnet": null,
    "node_yaml_map": {
      "input": {
        "cbcf55fe-c840-8bba-f2e7-73bf9a60b3eb": {
          "hasInputAndProcess": true,
          "input": {
            "file": {
              "codec": "all-bytes",
              "paths": [
                "/usr/local/hsm-os/data/hsm-io-it/data/project/165581d8e58a42bebe9e929cd043fecc/upload/文本数据换行_1701488298.txt"
              ]
            },
            "label": "file2_1"
          },
          "processors": {
            "label": "file2_2",
            "mapping": "root.txtData = content().string()\n"
          }
        }
      },
      "output": {
        "e1d8f825-b9cd-d66b-6718-0f7e74c41637": {
          "broker": {
            "outputs": [
              { "label": "log", "test_stdout": {} },
              {
                "file": {
                  "path": "/usr/local/hsm-os/data/hsm-io-it/data/benthos/temp/新建作业@job_e2yjh2uo.json"
                }
              }
            ]
          }
        }
      },
      "transform": {}
    }
  }
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| name | 新建作业  | String   | 是       | 作业名称        |
| code | job_e2yjh2uo  | String   | 是       | 作业编号        |
| namespace | 165581d8e58a42bebe9e929cd043fecc  | String   | 是       | 项目id        |
| nickName | admin  | String   | 是       | 创建人        |
| describe | MES系统的作业  | String   | 是       | 作业描述        |
| s_node | e1  | String   | 是       | 服务器编号        |
| schedule | 2  | String   | 是       | 调度类型        |
| schedule_cycle | 5  | String   | 是       | 周期调度值        |
| schedule_unit | second  | String   | 是       | 周期调度单位        |
| canvas | {nodeList: [], lineList: []}  | Object   | 是       | 周期调度单位        |
| content | -  | Object   | 是       | 周期调度单位        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{ 
  "code": 0, 
  "data": true, 
  "message": "保存成功", 
  "timestamp": 1701488807
}
```

## 信息系统集成页面获取作业列表

```json
 获取作业列表
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/job/getJobList

### 请求方式

> POST

### Content-Type

> json

### 请求Body参数

```json
{
  "namespace": "165581d8e58a42bebe9e929cd043fecc"
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| namespace | 165581d8e58a42bebe9e929cd043fecc  | String   | 是       | 项目id        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{
  "code": 0,
  "data": [
    {
      "id": "e1",
      "name": "工程师站",
      "ip": "172.21.44.119",
      "children": [
        {
          "node": 0,
          "code": "job_e2yjh2uo",
          "id": "job_e2yjh2uo",
          "name": "新建作业",
          "status": 0,
          "create_time": "2023-12-02 11:10:47",
          "edite_time": "2023-12-02 14:02:17",
          "create_use": "admin",
          "describe": "",
          "isAutoSelectId": true,
          "s_node": "e1"
        }
      ]
    }
  ],
  "message": "",
  "timestamp": 1701496979
}
```

### 异常响应编码
```
306
```

## 信息系统集成导出项目

```json
 导出项目
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/job/exportBatchJob

### 请求方式

> POST

### Content-Type

> json

### 请求Body参数

```json
{
  "namespace": "165581d8e58a42bebe9e929cd043fecc"
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| namespace | 165581d8e58a42bebe9e929cd043fecc  | String   | 是       | 项目id        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
文件流
```

### 异常响应编码
```
306 / 1100619 / 1100620
```

## 信息系统集成导出作业

```json
 导出作业
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/job/exportJob

### 请求方式

> POST

### Content-Type

> json

### 请求Body参数

```json
{
  "code": "job_ugc8qjok",
  "namespace": "165581d8e58a42bebe9e929cd043fecc",
  "databaseandcodes": [],
  "uploadfilepaths": []
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| code | job_ugc8qjok  | String   | 是       | 作业编号        |
| namespace | 165581d8e58a42bebe9e929cd043fecc  | String   | 是       | 项目id        |
| databaseandcodes | []  | String   | 是       | 作业数据库连接信息        |
| uploadfilepaths | []  | String   | 是       | 作业文件系统输入配置信息        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
文件流
```

### 异常响应编码
```
306 / 1100614 / 1100621 / 1100616 / 1100612 / 1100619 / 1100620
```

## 信息系统集成导入项目

```json
 导入项目
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/job/importBatchJobs

### 请求方式

> POST

### Content-Type

> form-data

### 请求Body参数

```json
{
  "file": 二进制,
  "namespace": "165581d8e58a42bebe9e929cd043fecc",
  "nickName": "admin"
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| file | -  | String   | 二进制       | 文件包数据        |
| namespace | 165581d8e58a42bebe9e929cd043fecc  | String   | 是       | 项目id        |
| nickName | admin  | String   | 是       | 创建人        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{
    "code": 0,
    "data": true,
    "message": "导入成功",
    "timestamp": 1701503805
}
```

### 异常响应编码
```
306 / 1100622 / 1100605 / 1100615 / 1100616
```

## 信息系统集成导入作业

```json
 导入作业
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/job/importJob

### 请求方式

> POST

### Content-Type

> form-data

### 请求Body参数

```json
{
  "file": 二进制,
  "namespace": "165581d8e58a42bebe9e929cd043fecc",
  "nickName": "admin"
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| file | -  | String   | 二进制       | 文件包数据        |
| namespace | 165581d8e58a42bebe9e929cd043fecc  | String   | 是       | 项目id        |
| nickName | admin  | String   | 是       | 创建人        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{
    "code": 0,
    "data": {
        "data": {
            "node": 0,
            "code": "job_yyvnuhmm",
            "name": "新建作业",
            "status": 0,
            "create_time": "2023-12-02 15:41:26",
            "edite_time": "2023-12-02 15:56:04",
            "create_use": "admin",
            "describe": "",
            "s_node": "e1"
        },
        "flag": true
    },
    "message": "导入成功",
    "timestamp": 1701503764
}
```


### 异常响应编码
```
306 / 1100622 / 1100613
```

