# 需求编号

|需求编号|需求名称|
|:-|:-:|
|HSM-OS-IOI-SRS-SW-A-M01-01|作业列表管理|
|HSM-OS-IOI-SRS-SW-A-M01-02|可视化作业组态|
|HSM-OS-IOI-SRS-SW-A-M01-18|作业预览|
|HSM-OS-IOI-SRS-SW-A-M02-05|作业基础维护|
|HSM-OS-IOI-SRS-SW-A-M02-06|实时作业的启停|
