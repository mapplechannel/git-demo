# 接口设计

数据转换组件管理的接口列表如下：

|API名称|请求类型|访问地址|
|:-|:-:|:-:|
|validate|POST|[链接](#数据校验中正则合法校验)|

## 数据校验中正则合法校验

```json
 在数据校验组件选择正则校验输入正则，点击确定
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/component/validate

### 请求方式

> POST

### Content-Type

> json

### 请求Body参数

```json
{
  "validateRegExpExpress": "/d1"
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| validateRegExpExpress | /d1  | String   | 是       | 转义后的正则表达式        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{
  "code":0,
  "data":true,
  "message":"/d1",
  "timestamp":1702542144
}
```
