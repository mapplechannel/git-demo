# 模型或数据设计

## 数据库信息

数据库配置信息数据结构：

|字段名称|字段类型|字段描述|
|:-|:-:|:-:|
|code|String|唯一标识|
|namespace|String|项目Id|
|connectname|String|连接名称|
|username|String|连接用户名|
|password|String|连接密码|
|host|String|数据库ip|
|port|String|端口号|
|databasetype|String|数据库类型|
