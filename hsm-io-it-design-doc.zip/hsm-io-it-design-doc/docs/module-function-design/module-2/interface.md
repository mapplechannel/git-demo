# 接口设计

数据源管理的接口列表如下：

|API名称|请求类型|访问地址|
|:-|:-:|:-:|
|sftpConnection|POST|[链接](#sftp连接)|
|getSftpFiles|POST|[链接](#获取sftp文件)|
|readSftpFilesData|POST|[链接](#获取sftp文件内容)|
|testConnectInfo|POST|[链接](#测试连接数据库)|
|getConnectList|POST|[链接](#获取数据库连接列表)|
|addConnect|POST|[链接](#添加数据库连接)|
|getConnect|POST|[链接](#连接数据库)|
|updateConnect|POST|[链接](#更新数据库连接信息)|
|getTables|POST|[链接](#获取数据库表)|
|getTablesPrimary|POST|[链接](#获取数据库表主键)|
|getColumns|POST|[链接](#获取数据库表字段)|
|getData|POST|[链接](#获取数据库表数据)|

## SFTP连接

```md
 打开文件输入组件选择SFTP文件，输入连接信息测试连接
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/component/file/sftpConnection

### 请求方式

> POST

### Content-Type

> json

### 请求Body参数

```json
{
  "host":"172.21.44.34",
  "port":"22",
  "user":"root",
  "password":"123456",
  "retry":"5"
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| host | 172.21.44.34  | String   | 是       | 主机地址        |
| port | 22  | String   | 是       | 端口        |
| user | root  | String   | 是       | 用户名        |
| password | 123456  | String   | 是       | 密码        |
| retry | 5  | String   | 是       | 重连次数        |

### 认证方式

```json
noauth
```

### 预执行脚本

```md
暂无预执行脚本
```

### 后执行脚本

```md
暂无后执行脚本
```

### 成功响应示例

```json
{
  "code":0,
  "data":true,
  "message":"服务器连接成功",
  "timestamp":1702517868
}
```

## 获取SFTP文件

```md
 连接SFTP成功后获取SFTP目录文件
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/component/file/getSftpFiles

### 请求方式

> POST

### Content-Type

> json

### 请求Body参数

```json
{
  "path":"/"
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| path | /  | String   | 是       | 文件路径        |

### 认证方式

```md
noauth
```

### 预执行脚本

```md
暂无预执行脚本
```

### 后执行脚本

```md
暂无后执行脚本
```

### 成功响应示例

```json
{
  "code": 0,
  "data": [
      {
          "name": "var/",
          "type": "folder",
          "size": 0,
          "parentPath": "/"
      }
  ],
  "message": "文件信息获取成功",
  "timestamp": 1702518060
}
```

## 获取SFTP文件内容

```md
 获取SFTP目录文件成功后，预览文件数据
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/component/file/readSftpFilesData

### 请求方式

> POST

### Content-Type

> json

### 请求Body参数

```json
{
  "path":"/home/test.txt",
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| path | /home/test.txt  | String   | 是       | SFTP文件路径        |

### 认证方式

```md
noauth
```

### 预执行脚本

```md
暂无预执行脚本
```

### 后执行脚本

```md
暂无后执行脚本
```

### 成功响应示例

```json
{
  "code":0,
  "data":true,
  "message":"策略不允许执行未授权的脚本，导致执行后无法添加，需要执行策略组",
  "timestamp":1702517868
}
```

## 测试连接数据库

```md
 测试连接数据库
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/component/mysql/testConnectInfo

### 请求方式

> POST

### Content-Type

> json

### 请求Body参数

```json
{
  "connectname":"333",
  "databasetype":"MySQL",
  "host":"172.21.220.10",
  "namespace":"79a18887829049d1b4c3930acfcb9100",
  "password":"123456",
  "port":"3306",
  "retry":"5",
  "username":"root"
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| connectname | 333  | String   | 是       | 连接名称        |
| databasetype | MySQL  | String   | 是       | 源数据库类型        |
| host | 172.21.220.10  | String   | 是       | ip        |
| namespace | 79a18887829049d1b4c3930acfcb9100  | String   | 是       | 项目Id        |
| password | 123456  | String   | 是       | 密码        |
| port | 3306  | String   | 是       | 端口        |
| retry | 5  | String   | 是       | 重连次数        |
| username | root  | String   | 是       | 用户名        |

### 认证方式

```md
noauth
```

### 预执行脚本

```md
暂无预执行脚本
```

### 后执行脚本

```md
暂无后执行脚本
```

### 成功响应示例

```json
{
  "code":0,
  "data":true,
  "message":"连接成功",
  "timestamp":1702517868
}
```

## 获取数据库连接列表

```md
 获取已添加的数据库连接列表
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/component/mysql/getConnectList

### 请求方式

> POST

### Content-Type

> json

### 请求Body参数

```json
{
  "namespace":"79a18887829049d1b4c3930acfcb9100"
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| namespace | 79a18887829049d1b4c3930acfcb9100  | String   | 是       | 项目Id        |

### 认证方式

```md
noauth
```

### 预执行脚本

```md
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{
  "code":0,
  "data":[
    {
      "connectname":"26"
      "dbpath":""
      "dbname":""
      "databasetype":"MySQL"
      "code":"mysql_94823088"
      "username":"root"
      "password":"123456"
      "host":"172.21.220.10"
      "port":"3306"
      "schemaname":""
      "tablename":""
    }
  ]
  "message":"连接成功",
  "timestamp":1702517868
}
```

## 添加数据库连接

```json
 添加数据库连接
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/component/mysql/addConnect

### 请求方式

> POST

### Content-Type

> json

### 请求Body参数

```json
{
  "connectname":"333",
  "databasetype":"MySQL",
  "host":"172.21.220.10",
  "namespace":"79a18887829049d1b4c3930acfcb9100",
  "password":"123456",
  "port":"3306",
  "retry":"5",
  "username":"root"
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| connectname | 333  | String   | 是       | 连接名称        |
| databasetype | MySQL  | String   | 是       | 源数据库类型        |
| host | 172.21.220.10  | String   | 是       | ip        |
| namespace | 79a18887829049d1b4c3930acfcb9100  | String   | 是       | 项目Id        |
| password | 123456  | String   | 是       | 密码        |
| port | 3306  | String   | 是       | 端口        |
| retry | 5  | String   | 是       | 重连次数        |
| username | root  | String   | 是       | 用户名        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{
  "code":0,
  "data":true
  "message":"mysql_51495980",
  "timestamp":1702517868
}
```

## 连接数据库

```json
 连接数据库，获取数据库中的库信息
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/component/mysql/getConnect

### 请求方式

> POST

### Content-Type

> json

### 请求Body参数

```json
{
  "host":"172.21.220.10",
  "password":"123456",
  "port":"3306",
  "username":"root"
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| host | 172.21.220.10  | String   | 是       | ip        |
| password | 123456  | String   | 是       | 密码        |
| port | 3306  | String   | 是       | 端口        |
| username | root  | String   | 是       | 用户名        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{
  "code":0,
  "data":[
    {
      "name":"benthos"
    },
    {
      "name":"sys"
    }
  ]
  "message":"连接成功",
  "timestamp":1702517868
}
```

## 更新数据库连接信息

```json
 更新数据库连接信息
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/component/mysql/updateConnect

### 请求方式

> POST

### Content-Type

> json

### 请求Body参数

```json
{
  "code":"mysql_51495980"
  "connectname":"333",
  "host":"172.21.220.10",
  "namespace":"79a18887829049d1b4c3930acfcb9100",
  "password":"123456",
  "port":"3306",
  "username":"root"
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| connectname | 333  | String   | 是       | 连接名称        |
| code | mysql_51495980  | String   | 是       |  连接code       |
| host | 172.21.220.10  | String   | 是       | ip        |
| namespace | 79a18887829049d1b4c3930acfcb9100  | String   | 是       | 项目Id        |
| password | 123456  | String   | 是       | 密码        |
| port | 3306  | String   | 是       | 端口        |
| username | root  | String   | 是       | 用户名        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{
  "code":0,
  "data":true
  "message":"更新成功",
  "timestamp":1702517868
}
```

## 获取数据库表

```json
 获取数据库表
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/component/mysql/getTables

### 请求方式

> POST

### Content-Type

> json

### 请求Body参数

```json
{
  "db_name":"benthos"
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| db_name | benthos  | String   | 是       | 数据库名称        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{
  "code":0,
  "data":[
    {
      "name":"device",
      "type":"BASE TABLE"
    },
    {
      "name":"erp",
      "type":"BASE TABLE"
    }
  ]
  "message":"查询成功",
  "timestamp":1702517868
}
```

## 获取数据库表主键

```json
 获取数据库表主键
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/component/mysql/getTablesPrimary

### 请求方式

> POST

### Content-Type

> json

### 请求Body参数

```json
{
  "db_name":"benthos",
  "table_name":"device"
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| db_name | benthos  | String   | 是       | 数据库名称        |
| table_name | device  | String   | 是       | 数据库表名        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{
  "code":0,
  "data":[
    "id"
  ]
  "message":"查询成功",
  "timestamp":1702517868
}
```

## 获取数据库表字段

```json
 获取数据库表字段
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/component/mysql/getColumns

### 请求方式

> POST

### Content-Type

> json

### 请求Body参数

```json
{
  "db_name":"benthos",
  "table_name":"device"
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| db_name | benthos  | String   | 是       | 数据库名称        |
| table_name | device  | String   | 是       | 数据库表名        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{
  "code":0,
  "data":[
    {
      "name":"id",
      "type":"int(11)",
      "comment":"id"
    },
    {
      "name":"deviceName",
      "type":"varchar(255)",
      "comment":"设备名称"
    }
  ]
  "message":"查询成功",
  "timestamp":1702517868
}
```

## 获取数据库表数据

```json
 获取数据库表数据
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/component/mysql/getData

### 请求方式

> POST

### Content-Type

> json

### 请求Body参数

```json
{
  "db_name":"benthos",
  "table_name":"device",
  "sql":"select id from device"
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| db_name | benthos  | String   | 是       | 数据库名称        |
| table_name | device  | String   | 是       | 数据库表名        |
| sql | select id from device  | String   | 是       | sql语句        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{
  "code":0,
  "data":{
    "cols":["id"],
    "cols_info":[
      {
        "column_name":"id",
        "column_comment":"id"
      },
      {
        "column_name":"deviceName",
        "column_comment":"设备名称"
      }
    ],
    "list":[
      {
        id:1
      },
      {
        id:1
      }
    ]
  }
  "message":"查询成功",
  "timestamp":1702517868
}
```
