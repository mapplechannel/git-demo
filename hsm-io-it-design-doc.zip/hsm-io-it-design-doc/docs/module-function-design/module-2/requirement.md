# 需求编号

|需求编号|需求名称|
|:-|:-:|
|HSM-OS-IOI-SRS-SW-A-M01-03|信息模型管理|
|HSM-OS-IOI-SRS-SW-A-M01-04|文件系统管理|
|HSM-OS-IOI-SRS-SW-A-M01-05|关系库系统管理|
|HSM-OS-IOI-SRS-SW-A-M01-06|NoSQL数据库管理|
|HSM-OS-IOI-SRS-SW-A-M01-07|网络服务管理|
|HSM-OS-IOI-SRS-SW-A-M01-08|消息服务管理|
|HSM-OS-IOI-SRS-SW-A-M01-09|数据源组件扩展|
|HSM-OS-IOI-SRS-SW-A-M01-19|模拟数据源组件|
|HSM-OS-IOI-SRS-SW-A-M01-07|WebService 输入|
|HSM-OS-IOI-SRS-SW-A-M04-17|SAP生产订单状态-XML（去向）|
