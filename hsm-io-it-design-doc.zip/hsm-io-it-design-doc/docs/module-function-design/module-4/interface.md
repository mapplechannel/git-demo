# 接口设计

作业执行引擎的接口列表如下：

|API名称|请求类型|访问地址|
|:-|:-:|:-:|
|getJobInfo|POST|[链接](#信息系统集成页面获取作业信息)|
|start|POST|[链接](#信息系统集成页面启动作业)|
|stop|POST|[链接](#信息系统集成页面停止作业)|

## 信息系统集成页面获取作业信息

```json
 获取作业信息
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/job/getJobInfo

### 请求方式

> POST

### Content-Type

> json

### 请求Body参数

```json
{
  "code":"job_e2yjh2uo",
  "namespace":"165581d8e58a42bebe9e929cd043fecc"
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| code | job_e2yjh2uo  | String   | 是       | 作业编号        |
| namespace | 165581d8e58a42bebe9e929cd043fecc  | String   | 是       | 项目id        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{
  "code": 0,
  "data": {
    "namespace": "165581d8e58a42bebe9e929cd043fecc",
    "nickName": "admin",
    "node": 0,
    "s_node": "e1",
    "code": "job_e2yjh2uo",
    "name": "新建作业",
    "describe": "",
    "schedule": "2",
    "schedule_details": "",
    "schedule_cycle": "5",
    "schedule_unit": "second",
    "content": {
      "benthos_yaml": "input:\n  file:\n    codec: all-bytes\n    paths:\n      - /usr/local/hsm-os/data/hsm-io-it/data/project/165581d8e58a42bebe9e929cd043fecc/upload/文本数据换行_1701488298.txt\n  label: file2_1\npipeline:\n  processors:\n    - label: file2_2\n      mapping: |\n        root.txtData = content().string()\noutput:\n  broker:\n    outputs:\n      - label: log\n        test_stdout: {}\n      - file:\n          path: /usr/local/hsm-os/data/hsm-io-it/data/benthos/temp/新建作业@job_e2yjh2uo.json\nlogger:\n  level: ALL\n  format: json\n  add_timestamp: true\n  file:\n    path: /usr/local/hsm-os/data/hsm-io-it/data/benthos/json/job_e2yjh2uo.json\n    rotate: true\n",
      "benthos_componnet": null,
      "node_yaml_map": {
        "input": {
          "cbcf55fe-c840-8bba-f2e7-73bf9a60b3eb": {
            "hasInputAndProcess": true,
            "input": {
              "file": {
                "codec": "all-bytes",
                "paths": [
                  "/usr/local/hsm-os/data/hsm-io-it/data/project/165581d8e58a42bebe9e929cd043fecc/upload/文本数据换行_1701488298.txt"
                ]
              },
              "label": "file2_1"
            },
            "processors": {
              "label": "file2_2",
              "mapping": "root.txtData = content().string()\n"
            }
          }
        },
        "output": {
          "e1d8f825-b9cd-d66b-6718-0f7e74c41637": {
            "broker": {
              "outputs": [
                { "label": "log", "test_stdout": {} },
                {
                  "file": {
                    "path": "/usr/local/hsm-os/data/hsm-io-it/data/benthos/temp/新建作业@job_e2yjh2uo.json"
                  }
                }
              ]
            }
          }
        },
        "transform": {}
      }
    },
    "cron_id": "",
    "is_http": false,
    "canvas": {
      "lineList": [
        {
          "anchors": [
            [1, 0, 0, 0, -1, 40],
            [0, 0, 0, 0, 1, 40]
          ],
          "source": "cbcf55fe-c840-8bba-f2e7-73bf9a60b3eb",
          "target": "e1d8f825-b9cd-d66b-6718-0f7e74c41637",
          "uuids": [
            "cbcf55fe-c840-8bba-f2e7-73bf9a60b3eb_Right_1",
            "e1d8f825-b9cd-d66b-6718-0f7e74c41637_Left_1"
          ]
        }
      ],
      "nodeList": [
        {
          "absoluteLeft": "656px",
          "allowDrag": true,
          "attrs": { "fileName": "新建作业", "fileType": "json" },
          "flowNodeType": "output",
          "id": "e1d8f825-b9cd-d66b-6718-0f7e74c41637",
          "img": "file",
          "inputdata": {
            "arrType": [],
            "objType": {
              "JSON": {
                "assemble": {
                  "file2": {
                    "txtData": "你好啊1!\r\nhow are you2!\r\n你也好啊3！\r\n"
                  }
                },
                "item": {
                  "txtData": "你好啊1!\r\nhow are you2!\r\n你也好啊3！\r\n"
                },
                "source": {
                  "fileType": "txt",
                  "resultKey": "txtData",
                  "sourceData": "{\"txtData\":\"你好啊1!\\r\\nhow are you2!\\r\\n你也好啊3！\\r\\n\"}",
                  "type": "json"
                }
              }
            }
          },
          "isConfig": true,
          "label": "文件系统输出",
          "left": "41.75px",
          "message": "配置完毕",
          "needConfig": true,
          "noConfigMsg": "请配置文件信息",
          "nodeMark": "file",
          "nodeType": "inputOrOutput",
          "outputdata": {
            "arrType": [],
            "objType": {
              "JSON": {
                "assemble": {
                  "file2": {
                    "txtData": "你好啊1!\r\nhow are you2!\r\n你也好啊3！\r\n"
                  }
                },
                "item": {
                  "txtData": "你好啊1!\r\nhow are you2!\r\n你也好啊3！\r\n"
                },
                "source": {
                  "fileType": "txt",
                  "resultKey": "txtData",
                  "sourceData": "{\"txtData\":\"你好啊1!\\r\\nhow are you2!\\r\\n你也好啊3！\\r\\n\"}",
                  "type": "json"
                }
              }
            }
          },
          "resultKey": "file1",
          "status": "success",
          "top": "101px",
          "value": "File"
        },
        {
          "absoluteLeft": "26px",
          "allowDrag": true,
          "attrs": {
            "clientAttr": {
              "form": {
                "delimiter": ",",
                "fileName": "文本数据换行.txt",
                "source": "client"
              },
              "state": {
                "uploadFilePath": "/usr/local/hsm-os/data/hsm-io-it/data/project/165581d8e58a42bebe9e929cd043fecc/upload/文本数据换行_1701488298.txt",
                "uploadFileType": "text/plain"
              }
            },
            "fileSource": "client"
          },
          "flowNodeType": "input",
          "id": "cbcf55fe-c840-8bba-f2e7-73bf9a60b3eb",
          "img": "file",
          "isConfig": true,
          "label": "文件系统输入",
          "left": "26px",
          "message": "配置完毕",
          "needConfig": true,
          "noConfigMsg": "请配置文件信息",
          "nodeMark": "file",
          "nodeType": "inputOrOutput",
          "outputdata": {
            "arrType": [],
            "objType": {
              "JSON": {
                "assemble": {
                  "file2": {
                    "txtData": "你好啊1!\r\nhow are you2!\r\n你也好啊3！\r\n"
                  }
                },
                "item": {
                  "txtData": "你好啊1!\r\nhow are you2!\r\n你也好啊3！\r\n"
                },
                "source": {
                  "fileType": "txt",
                  "resultKey": "txtData",
                  "sourceData": "{\"txtData\":\"你好啊1!\\r\\nhow are you2!\\r\\n你也好啊3！\\r\\n\"}",
                  "type": "json"
                }
              }
            }
          },
          "resultKey": "file2",
          "status": "success",
          "top": "82px",
          "value": "File"
        }
      ]
    }
  },
  "message": "查询成功",
  "timestamp": 1701489453
}
```

## 信息系统集成页面启动作业

```json
 作业配置完整后，点击启动图标，启动作业
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/job/start

### 请求方式

> POST

### Content-Type

> json

### 请求Body参数

```json
{
  "code": "job_e2yjh2uo",
  "namespace": "165581d8e58a42bebe9e929cd043fecc"
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| code | job_e2yjh2uo  | String   | 是       | 作业名编号        |
| namespace | 165581d8e58a42bebe9e929cd043fecc  | String   | 是       | 项目id        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{ 
    "code": 0, 
    "data": true, 
    "message": "启动成功", 
    "timestamp": 1701495330 
}
```


### 异常响应编码
```
306 / 1100614 / 1100615 / 1100616 / 1100617
```

## 信息系统集成页面停止作业

```json
 作业运行中时，点击停止图标，停止作业
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/job/stop

### 请求方式

> POST

### Content-Type

> json

### 请求Body参数

```json
{
  "code": "job_e2yjh2uo",
  "namespace": "165581d8e58a42bebe9e929cd043fecc"
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| code | job_e2yjh2uo  | String   | 是       | 作业名编号        |
| namespace | 165581d8e58a42bebe9e929cd043fecc  | String   | 是       | 项目id        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{
    "code":0,
    "data":true,
    "message":"停止成功",
    "timestamp":1701495586
}
```

### 异常响应编码
```
306 / 1100618 / 1100614 / 1100616
```
