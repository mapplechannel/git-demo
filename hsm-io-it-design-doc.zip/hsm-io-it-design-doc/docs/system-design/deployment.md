# 部署设计

信息系统支持离线（ENG）、在线（PORTAL）、运维（HSM-OPM）三种环境下的部署，遵循各环境框架的各种规则，工具相关的界面集成、发布、下装等规则均由各环境统一设计。  

HSM-IO系统为前后端分离系统。在开发环境中，前、后端可以都运行在本地，使用localhost地址进行访问。HSM-IO系统可以部署在以下环境中：

- 单机环境：ENG和PORTAL环境在一台服务器上。
- 1+1环境：ENG和PORTAL环境分别在不同的服务器上。
- 1+2/1+4环境：ENG和PORTAL环境分别在不同的服务器上 。

![install](./images/install.png)

在不同的环境中，HSM-IO系统支持将ENG的数据发布到PORTAL环境中。

ENG环境下的数据发布如图所示：

![ENG](./images/dpteng.png)

发布到PORTAL环境下的作业如下图所示：

![ENG](./images/dptpor.png)

在生产环境中，前端和后端需要分别部署在不同的服务器上。前端需要打包成静态文件，可以使用Nginx等web服务器进行部署；后端需要打包为可执行程序。
