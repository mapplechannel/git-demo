# 技术选型

> 语言、框架、库的选择

- 后端框架：gin，zerolog，gin-swagger，benthos

- 数据库ORM框架：gorm

- 前端框架：vue3

- 状态管理：pinia

- UI框架：element-plus

> 架构设计的选择

- B/S架构

> 数据库选择

- PostgreSQL
