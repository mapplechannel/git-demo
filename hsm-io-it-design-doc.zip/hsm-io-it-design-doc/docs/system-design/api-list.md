# API 清单列表

> 当前设计文档中涉及到的所有 API 接口清单列表。以服务为单位进行划分，每个服务下面包含多个 API 接口。

## 信息系统集成后端 API 清单

服务名称：`hsm-io-it`

|模块名称<div style="width:65px">|API名称<div style="width:70px">|协议<div style="width:25px">|方法<div style="width:25px">|类型<div style="width:30px">|访问地址<div style="width:70px">|简介|详细地址<div style="width:30px">|
|:-|:-:|:-:|:-:|:-:|:-|:-|:-:|
|ENG工程树|add|RestFul|POST|服务内部|/api/hsm-io-it/eng|ENG工程树新增|[链接](../module-boundary-description/interface.md#eng树上新增作业)|
|ENG工程树|update|RestFul|PUT|服务内部|/api/hsm-io-it/eng|ENG工程树编辑|[链接](../module-boundary-description/interface.md#eng树上编辑作业)|
|ENG工程树|delete|RestFul|DELETE|服务内部|/api/hsm-io-it/eng|ENG工程树删除|[链接](../module-boundary-description/interface.md#eng树上删除作业)|
|ENG工程树|getJobList|RestFul|POST|服务内部|/api/hsm-io-it/eng|ENG工程树作业列表|[链接](../module-boundary-description/interface.md#eng树上获取列表)|
|ENG项目|exportData|RestFul|POST|服务内部|/api/hsm-io-it/|ENG项目导出|[链接](../module-boundary-description/interface.md#eng导出项目)|
|ENG项目|exportData|RestFul|POST|服务内部|/api/hsm-io-it/cancel|ENG取消导出|[链接](../module-boundary-description/interface.md#eng取消导出项目)|
|ENG项目|exportResult|RestFul|POST|服务内部|/api/hsm-io-it/|ENG导出项目结果查询|[链接](../module-boundary-description/interface.md#eng导出项目结果查询)|
|ENG项目|importData|RestFul|POST|服务内部|/api/hsm-io-it/|ENG导入项目|[链接](../module-boundary-description/interface.md#eng导入项目)|
|ENG项目|importData|RestFul|POST|服务内部|/api/hsm-io-it/cancel/|ENG取消导入项目|[链接](../module-boundary-description/interface.md#eng取消导入项目)|
|ENG项目|importResult|RestFul|POST|服务内部|/api/hsm-io-it/|ENG导入项目结果查询|[链接](../module-boundary-description/interface.md#eng导入项目结果查询)|
|ENG项目|deleteNotify|RestFul|POST|服务内部|/api/hsm-io-it/eng/project/|ENG删除项目|[链接](../module-boundary-description/interface.md#eng删除项目)|
|ENG数据发布|dataPublish|RestFul|POST|服务内部|/api/hsm-io-it/|ENG数据发布|[链接](../module-boundary-description/interface.md#发布作业)|
|ENG数据发布|compile|RestFul|POST|服务外部|/dpt/|编译打包|[链接](../module-boundary-description/interface.md#编译打包)|
|ENG数据发布|status|RestFul|POST|服务外部|/dpt/|获取编译状态|[链接](../module-boundary-description/interface.md#获取编译状态)|
|ENG数据发布|getLog|RestFul|POST|服务外部|/dpt/|获取编译日志|[链接](../module-boundary-description/interface.md#获取编译日志)|
|作业管理|add|RestFul|POST|服务内部|/api/hsm-io-it/job|新增作业|[链接](../module-function-design/module-1/interface.md#信息系统集成页面新增作业)|
|作业管理|delete|RestFul|DELETE|服务内部|/api/hsm-io-it/job|删除作业|[链接](../module-function-design/module-1/interface.md#信息系统集成页面删除作业)|
|作业管理|saveJobInfo|RestFul|POST|服务内部|/api/hsm-io-it/job|保存画布|[链接](../module-function-design/module-1/interface.md#信息系统集成页面保存作业)|
|作业管理|getJobInfo|RestFul|POST|服务内部|/api/hsm-io-it/job|获取画布信息|[链接](../module-function-design/module-4/interface.md#信息系统集成页面获取作业信息)|
|作业管理|start|RestFul|POST|服务内部|/api/hsm-io-it/job|启动作业|[链接](../module-function-design/module-4/interface.md#信息系统集成页面启动作业)|
|作业管理|stop|RestFul|POST|服务内部|/api/hsm-io-it/job|停止作业|[链接](../module-function-design/module-4/interface.md#信息系统集成页面停止作业)|
|作业管理|getJobList|RestFul|POST|服务内部|/api/hsm-io-it/job|获取作业列表|[链接](../module-function-design/module-1/interface.md#信息系统集成页面获取作业列表)|
|作业管理|exportBatchJob|RestFul|POST|服务内部|/api/hsm-io-it/job|信息系统集成导出项目|[链接](../module-function-design/module-1/interface.md#信息系统集成导出项目)|
|作业管理|exportJob|RestFul|POST|服务内部|/api/hsm-io-it/job|导出作业|[链接](../module-function-design/module-1/interface.md#信息系统集成导出作业)|
|作业管理|importBatchJobs|RestFul|POST|服务内部|/api/hsm-io-it/job|批量导入作业|[链接](../module-function-design/module-1/interface.md#信息系统集成导入项目)|
|作业管理|importJob|RestFul|POST|服务内部|/api/hsm-io-it/job|导入作业|[链接](../module-function-design/module-1/interface.md#信息系统集成导入作业)|
