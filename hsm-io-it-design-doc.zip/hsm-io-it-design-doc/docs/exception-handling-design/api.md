# API异常

在处理 API 请求时，可能会出现各种异常情况，例如参数错误、权限不足、数据库错误等。在处理这些异常时，可以使用 HTTP 状态码和错误消息来向客户端返回有意义的错误信息。在处理 API 异常时，可以使用以下实现：

```javascript
app.get('/api/some-resource', (req, res) => {
  try {
    // 处理 API 请求
    res.send('Response Data');
  } catch (error) {
    console.error('API Exception:', error);
    // 记录日志或发送警报等操作
    res.status(500).send('Internal Server Error'); // 发送 HTTP 状态码和错误消息
  }
});

```
