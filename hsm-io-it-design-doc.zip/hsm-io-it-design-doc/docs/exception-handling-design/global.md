# 全局异常

在应用程序中，可以通过捕获所有未处理的异常并执行一些操作来处理全局异常。

## 一、Go语言应用

### Go语言异常处理

在Go语言中，可以使用多返回值来返回错误。不要用异常来代替错误，更不要用异常来控制流程。在极个别的情

况下，才使用Go中引入的Exception处理：defer, panic, recover。

  1.panic用法挺简单的, 其实就是相当于java的throw exception

  2.recover也是golang的一个内建函数， 其实就相当于是try catch。

同时在使用recover时需要注意以下几点：

  1.recover必须在defer函数中使用，才能起到拦截作用。

  2.在正常函数执行过程中，调用recover没有任何意义, 会直接返回 nil ，比如fmt.Println(recover()) 。

  3.如果当前的goroutine panic了，那么recover将会捕获这个panic的值，这样可以让程序正常执行下
  
  去，不会导致程序crash。

### panic和recover使用原则

  1.调用panic后，调用方函数执行从当前调用点退出。

  2.通过panic可以设定返回值。

  3.recover函数只有在defer代码块中才会有效果。

  一旦产生panic之后，golang是逐级查找的，最终会查找到main函数。 如果在main函数中的defer还没有
  
  recover函数，golang会抛出最终的异常信息。

### 示例

``` go

package main

import “fmt”

func main() {

  fmt.Println(“a”)

  defer func() { // 必须要先声明defer，否则不能捕获到panic异常

    fmt.Println(“d”)

    if err := recover(); err != nil {

      fmt.Println(err) // 这里的err其实就是panic传入的内容

    }

    fmt.Println(“e”)

  }()

  test() //开始调用test

  fmt.Println(“f”) //unreachable

}

func test() {

  fmt.Println(“b”)

  panic(“error”)

  fmt.Println(“c”) //unreachable

}

```
