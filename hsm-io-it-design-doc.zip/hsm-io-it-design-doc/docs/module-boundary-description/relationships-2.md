# 信息系统与PORTAL的关系

## 界面集成

 ![portal1](./images/portal1.png)

 ![portal2](./images/portal2.png)

 ![portal3](./images/portal3.png)

- 信息系统集成添加到PORTAL中，集成方式：在PORTAL菜单管理中添加信息系统集成工具。

## 公共功能

- 信息系统工程配置工具满足统一规范约束的保存、回滚/重做操作支持接口，运行环境调用；

- 信息系统工程在PORTAL中支持页签刷新、关闭、切换联动；
