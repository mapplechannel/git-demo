# 接口设计

相关的接口列表如下：

|API名称|请求类型|访问地址|
|:-|:-:|:-:|
|add|POST|[链接](#eng树上新增作业)|
|update|PUT|[链接](#eng树上编辑作业)|
|delete|DELETE|[链接](#eng树上删除作业)|
|getJobList|POST|[链接](#eng树上获取列表)|
|exportData|POST|[链接](#eng导出项目)|
|exportData|POST|[链接](#eng取消导出项目)|
|exportResult|POST|[链接](#eng导出项目结果查询)|
|importData|POST|[链接](#eng导入项目)|
|importData|POST|[链接](#eng取消导入项目)|
|importResult|POST|[链接](#eng导入项目结果查询)|
|deleteNotify|POST|[链接](#eng删除项目)|
|dataPublish|POST|[链接](#发布作业)|
|compile|POST|[链接](#编译打包)|
|status|POST|[链接](#获取编译状态)|
|progress|POST|[链接](#获取编译进度)|
|getLog|POST|[链接](#获取编译日志)|

## ENG树上新增作业

```json
 点击ENG树的新增图标，新增作业
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/eng/add

### 请求方式

> POST

### Content-Type

> json

### 请求Body参数

```json
{
  "schedule": "2",
  "s_node": "e1",
  "nickName": "admin",
  "name": "新建作业",
  "namespace": "165581d8e58a42bebe9e929cd043fecc",
  "schedule_cycle": "5",
  "schedule_unit": "second"
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| name | 新建作业  | String   | 是       | 作业名称        |
| namespace | 165581d8e58a42bebe9e929cd043fecc  | String   | 是       | 项目id        |
| nickName | admin  | String   | 是       | 创建人        |
| s_node | e1  | String   | 是       | 服务器编号        |
| schedule | 2  | String   | 是       | 调度类型        |
| schedule_cycle | 5  | String   | 是       | 周期调度值        |
| schedule_unit | second  | String   | 是       | 周期调度单位        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{
  "code": 0,
  "data": {
    "node": 0,
    "code": "job_gtd14tgu",
    "id": "job_gtd14tgu",
    "name": "新建作业",
    "status": 0,
    "create_time": "2023-12-02 10:38:43",
    "edite_time": "2023-12-02 10:38:43",
    "create_use": "admin",
    "describe": "",
    "isAutoSelectId": true,
    "s_node": "e1"
  },
  "message": "",
  "timestamp": 1701484723
}
```

## ENG树上编辑作业

```json
 点击ENG树的编辑图标，编辑作业名称
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/eng/update

### 请求方式

> PUT

### Content-Type

> json

### 请求Body参数

```json
{
  "code": "job_ehyuvn00",
  "s_node": "e1",
  "nickName": "admin",
  "name": "新建作业编辑名字",
  "namespace": "165581d8e58a42bebe9e929cd043fecc"
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| name | 新建作业编辑名字  | String   | 是       | 作业名称        |
| code | job_ehyuvn00  | String   | 是       | 作业编号        |
| namespace | 165581d8e58a42bebe9e929cd043fecc  | String   | 是       | 项目id        |
| nickName | admin  | String   | 是       | 创建人        |
| s_node | e1  | String   | 是       | 服务器编号        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{
  "code": 0,
  "data": {
    "node": 0,
    "code": "job_ehyuvn00",
    "id": "job_ehyuvn00",
    "name": "新建作业test",
    "status": 0,
    "create_time": "2023-12-02 10:47:07",
    "edite_time": "2023-12-02 10:47:17",
    "create_use": "admin",
    "describe": "",
    "isAutoSelectId": true,
    "s_node": "e1"
  },
  "message": "保存成功",
  "timestamp": 1701485237
}
```

## ENG树上删除作业

```json
 点击ENG树的删除图标，删除作业
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/eng/delete

### 请求方式

> DELETE

### Content-Type

> json

### 请求Body参数

```json
{
  "code": "job_ehyuvn00",
  "nickName": "admin",
  "namespace": "165581d8e58a42bebe9e929cd043fecc"
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| code | job_ehyuvn00  | String   | 是       | 作业编号        |
| namespace | 165581d8e58a42bebe9e929cd043fecc  | String   | 是       | 项目id        |
| nickName | admin  | String   | 是       | 创建人        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{ 
    "code": 0, 
    "data": true, 
    "message": "", 
    "timestamp": 1701486108 
}
```

## ENG树上获取列表

```json
 获取ENG树上的作业列表
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/eng/getJobList

### 请求方式

> POST

### Content-Type

> json

### 请求Body参数

```json
{
  "namespace": "165581d8e58a42bebe9e929cd043fecc"
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| namespace | 165581d8e58a42bebe9e929cd043fecc  | String   | 是       | 项目id        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{
  "code": 0,
  "data": [
    {
      "id": "e1",
      "name": "工程师站",
      "ip": "172.21.44.119",
      "children": [
        {
          "node": 0,
          "code": "job_e2yjh2uo",
          "id": "job_e2yjh2uo",
          "name": "新建作业",
          "status": 0,
          "create_time": "2023-12-02 11:10:47",
          "edite_time": "2023-12-02 14:02:17",
          "create_use": "admin",
          "describe": "",
          "isAutoSelectId": true,
          "s_node": "e1"
        }
      ]
    }
  ],
  "message": "",
  "timestamp": 1701496979
}
```

## ENG导出项目

```json
 点击ENG的导出，导出项目
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/exportData

### 请求方式

> POST

### Content-Type

> json

### 请求Header参数

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| namespace | 09d3d0fe0ebf4d908fd0e66fb8ca572b  | String   | 是       | 项目id        |

### 请求Body参数

```json
{
  "filePath": "",
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| filePath | -  | String   | 是       | 文件路径        |
| namespace | 165581d8e58a42bebe9e929cd043fecc  | String   | 是       | 项目id        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{ 
  "code": 0, 
  "data": {
    "status":1
  }, 
  "message": "", 
  "timestamp": 1701486108 
}
```

## ENG取消导出项目

```json
 取消导出项目
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/cancel/exportData

### 请求方式

> POST

### Content-Type

> json

### 请求Header参数

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| namespace | 09d3d0fe0ebf4d908fd0e66fb8ca572b  | String   | 是       | 项目id        |

### 请求Body参数

```json
{
  "filePath": "",
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| filePath | -  | String   | 是       | 文件路径        |
| namespace | 165581d8e58a42bebe9e929cd043fecc  | String   | 是       | 项目id        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{ 
  "code": 0, 
  "data": {
    "status":1
  }, 
  "message": "", 
  "timestamp": 1701486108 
}
```

## ENG导出项目结果查询

```json
 导出项目查询
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/exportResult

### 请求方式

> POST

### Content-Type

> json

### 请求Header参数

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| namespace | 09d3d0fe0ebf4d908fd0e66fb8ca572b  | String   | 是       | 项目id        |

### 请求Body参数

```json
{
  "filePath": "",
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| filePath | -  | String   | 是       | 文件路径        |
| namespace | 165581d8e58a42bebe9e929cd043fecc  | String   | 是       | 项目id        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{ 
  "code": 0, 
  "data": {
    "status":1,
    "rate":10
  }, 
  "message": "", 
  "timestamp": 1701486108 
}
```

## ENG导入项目

```json
 点击ENG的导入，导入项目
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/importData

### 请求方式

> POST

### Content-Type

> json

### 请求Header参数

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| namespace | 09d3d0fe0ebf4d908fd0e66fb8ca572b  | String   | 是       | 项目id        |

### 请求Body参数

```json
{
  "filePath": "",
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| filePath | -  | String   | 是       | 文件路径        |
| namespace | 165581d8e58a42bebe9e929cd043fecc  | String   | 是       | 项目id        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{ 
  "code": 0, 
  "data": {
    "status":1
  }, 
  "message": "", 
  "timestamp": 1701486108 
}
```

## ENG取消导入项目

```json
 取消导出项目
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/cancel/importData

### 请求方式

> POST

### Content-Type

> json

### 请求Header参数

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| namespace | 09d3d0fe0ebf4d908fd0e66fb8ca572b  | String   | 是       | 项目id        |

### 请求Body参数

```json
{
  "filePath": "",
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| filePath | -  | String   | 是       | 文件路径        |
| namespace | 165581d8e58a42bebe9e929cd043fecc  | String   | 是       | 项目id        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{ 
  "code": 0, 
  "data": {
    "status":1
  }, 
  "message": "", 
  "timestamp": 1701486108 
}
```

## ENG导入项目结果查询

```json
 导入项目查询
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/importResult

### 请求方式

> POST

### Content-Type

> json

### 请求Header参数

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| namespace | 09d3d0fe0ebf4d908fd0e66fb8ca572b  | String   | 是       | 项目id        |

### 请求Body参数

```json
{
  "filePath": "",
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| filePath | -  | String   | 是       | 文件路径        |
| namespace | 165581d8e58a42bebe9e929cd043fecc  | String   | 是       | 项目id        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{ 
  "code": 0, 
  "data": {
    "status":1,
    "rate":50
  }, 
  "message": "", 
  "timestamp": 1701486108 
}
```

## ENG删除项目

```json
 点击ENG项目列表的删除按钮，删除项目
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/api/hsm-io-it/eng/project/deleteNotify

### 请求方式

> POST

### Content-Type

> json

### 请求Body参数

```json
{
  "namespace": "165581d8e58a42bebe9e929cd043fecc"
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| namespace | 165581d8e58a42bebe9e929cd043fecc  | String   | 是       | 项目id        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{ 
  "code": 0, 
  "data": true, 
  "message": "", 
  "timestamp": 1701486108 
}
```

## 发布作业

```json
 点击发布图标，发布作业
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/dpt/dataPublish

### 请求方式

> POST

### Content-Type

> json

### 请求Header参数

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| namespace | 09d3d0fe0ebf4d908fd0e66fb8ca572b  | String   | 是       | 项目id        |

### 请求Body参数

```json
{
  "DataFilePath": "/usr/local/hsm-os/data/mdp/download/origin/09d3d0fe0ebf4d908fd0e66fb8ca572b#s1#hsm-io-it#V20231202112158#isAll#notClear.tar.gz"
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| DataFilePath | /usr/local/hsm-os/data/mdp/download/origin/09d3d0fe0ebf4d908fd0e66fb8ca572b#s1#hsm-io-it#V20231202112158#isAll#notClear.tar.gz  | String   | 是       | 数据发布文件路径        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{ 
    "code": 0, 
    "data": true, 
    "message": "", 
    "timestamp": 1701486108 
}
```

## 编译打包

```json
 编译打包
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/dpt/compile

### 请求方式

> POST

### Content-Type

> json

### 请求Header参数

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| namespace | 09d3d0fe0ebf4d908fd0e66fb8ca572b  | String   | 是       | 项目id        |

### 请求Body参数

```json
{
  "version": "V20231202112158",
  "ServerRange":
  [
    {
      "isClear": true,
      "isAll": true,
      "serverId": "e1",
      "appId": "hsm-io-it",
      "dataRange": ["job_mtnff5aq","job_uip7tdj7"],
      "packName": "09d3d0fe0ebf4d908fd0e66fb8ca572b#e1#hsm-io-it#V20231202112158#isASll#isClear"
    }
  ]
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| version | V20231202112158  | String   | 是       | 版本号        |
| ServerRange[*].isClear | true  | Boolean   | 是       | 是否清空        |
| ServerRange[*].isAll | true  | Boolean   | 是       | 是否全选        |
| ServerRange[*].serverId | e1  | String   | 是       | 服务器节点Id        |
| ServerRange[*].appId | hsm-io-it  | String   | 是       | 应用Id        |
| ServerRange[*].dataRange | ["job_mtnff5aq","job_uip7tdj7"]  | []string   | 是       | 发布范围        |
| ServerRange[*].packName | 09d3d0fe0ebf4d908fd0e66fb8ca572b#e1#hsm-io-it#V20231202112158#isASll#isClear  | String   | 是       | 压缩包名称        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{ 
    "code": 0, 
    "data": true, 
    "message": "", 
    "timestamp": 1701486108 
}
```

## 获取编译状态

```json
 获取编译状态
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/dpt/status

### 请求方式

> POST

### Content-Type

> json

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{ 
    "code": 0, 
    "data": {
      "result": "underway"
    }, 
    "message": "", 
    "timestamp": 1701486108 
}
```

## 获取编译进度

```json
 获取编译进度
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/dpt/progress

### 请求方式

> POST

### Content-Type

> json

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{ 
    "code": 0, 
    "data": {
      "result": 20 
    }, 
    "message": "", 
    "timestamp": 1701486108 
}
```

## 获取编译日志

```json
 获取编译日志
```

### 接口状态

> 开发完成

### 接口URL

> {{host}}{{port}}/dpt/getLog

### 请求方式

> POST

### Content-Type

> json

### 请求Header参数

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| namespace | 09d3d0fe0ebf4d908fd0e66fb8ca572b  | String   | 是       | 项目id   |  

### 请求Body参数

```json
{
  "version": "V20231202112158",
  "length": 10,
}
```

| 参数名    | 示例值 | 参数类型 | 是否必填 | 参数描述 |
| --------- | ------ | -------- | -------- | -------- |
| version | V20231202112158 | String   | 是       | 版本号        |
| length | 10  | int   | 是       | 日志条数        |

### 认证方式

```json
noauth
```

### 预执行脚本

```json
暂无预执行脚本
```

### 后执行脚本

```json
暂无后执行脚本
```

### 成功响应示例

```json
{ 
    "code": 0, 
    "data": [
      {
        "project":"",
        "node":"",
        "level":"",
        "content":"",
        "serviceId":"",
        "type":"",
        "dataVersion":"",
        "recordTime":"",
        "jumpUrl":""
      }
    ], 
    "message": "", 
    "timestamp": 1701486108 
}
```
