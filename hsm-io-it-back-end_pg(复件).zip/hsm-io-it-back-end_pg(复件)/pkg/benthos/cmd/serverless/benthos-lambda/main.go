package main

import (
	"hsm-io-it-back-end/pkg/internal/serverless/lambda"

	// Import all plugins defined within the repo.
	_ "hsm-io-it-back-end/pkg/public/components/all"
)

func main() {
	lambda.Run()
}
