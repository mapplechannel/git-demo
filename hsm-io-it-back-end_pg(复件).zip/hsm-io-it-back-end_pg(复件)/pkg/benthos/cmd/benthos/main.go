package main

import (
	"context"

	"hsm-io-it-back-end/pkg/benthos/internal/cli"

	// Import all plugins defined within the repo.
	_ "hsm-io-it-back-end/pkg/benthos/public/components/all"
)

func main() {
	cli.Run(context.Background())
}
