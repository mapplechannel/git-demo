// Package policy provides tooling for creating and executing Benthos message
// batch policies.
package policy
