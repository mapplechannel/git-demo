// Package test implements the Benthos service unit testing command.
package test
