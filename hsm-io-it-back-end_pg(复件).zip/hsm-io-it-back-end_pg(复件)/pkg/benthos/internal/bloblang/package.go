package bloblang

import (
	"hsm-io-it-back-end/pkg/benthos/internal/bloblang/plugins"
)

func init() {
	if err := plugins.Register(); err != nil {
		panic(err)
	}
}
