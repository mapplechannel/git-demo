// Package mapping provides a parser for the full bloblang mapping spec.
package mapping
