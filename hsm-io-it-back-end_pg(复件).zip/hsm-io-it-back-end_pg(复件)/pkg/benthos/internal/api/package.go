// Package api implements a type used for creating the Benthos HTTP API.
package api
