package output

// DropConfig contains configuration fields for the drop output type.
type DropConfig struct{}

// NewDropConfig creates a new DropConfig with default values.
func NewDropConfig() DropConfig {
	return DropConfig{}
}
