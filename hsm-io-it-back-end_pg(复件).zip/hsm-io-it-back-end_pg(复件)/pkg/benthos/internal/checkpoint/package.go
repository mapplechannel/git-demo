// Package checkpoint implements a mechanism for tracking checkpointed integer
// offsets for sequential read at-least-once queue systems such as Kafka or
// Kinesis.
package checkpoint
