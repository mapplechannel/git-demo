package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"os"

	_ "hsm-io-it-back-end/pkg/benthos/public/components/all"

	"hsm-io-it-back-end/pkg/benthos/public/service"
)

// var streamMap sync.Map

func main() {

	// str, _ := os.Getwd()
	// fmt.Println(str)
	// data := ReadFile(str + "/file/mysql.yaml")
	// fmt.Println(data)
	executeBenthos()

	// fmt.Println("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
	// time.Sleep(time.Second * 15)
	// StopHttp("aaa")

}

func executeBenthos() {
	panicOnErr := func(err error) {
		if err != nil {
			panic(err)
		}
	}

	configSpec := service.NewConfigSpec()

	constructor := func(conf *service.ParsedConfig, mgr *service.Resources) (service.Processor, error) {
		return newReverseProcessor(mgr.Logger(), mgr.Metrics()), nil
	}

	err := service.RegisterProcessor("mes_json", configSpec, constructor)
	if err != nil {
		panic(err)
	}

	builder := service.NewStreamBuilder()

	str, _ := os.Getwd()
	fmt.Println(str)
	data := ReadFile(str + "/file/el1.yml")
	err = builder.SetYAML(data)

	panicOnErr(err)

	stream, err := builder.Build()
	panicOnErr(err)

	err = stream.Run(context.Background())
	panicOnErr(err)
}

func ReadFile(path string) (data string) {
	//打开文件
	open, err := os.Open(path)
	if err != nil {
		fmt.Printf("打开文件失败 %s", err.Error())
	}
	defer open.Close()
	file, err := ioutil.ReadAll(open)
	if err != nil {
		fmt.Println(err.Error())
		return
	}
	return string(file)
}

// func init() {
// 	// Config spec is empty for now as we don't have any dynamic fields.
// 	configSpec := service.NewConfigSpec()

// 	constructor := func(conf *service.ParsedConfig, mgr *service.Resources) (service.Processor, error) {
// 		return newReverseProcessor(mgr.Logger(), mgr.Metrics()), nil
// 	}

// 	err := service.RegisterProcessor("mes_json", configSpec, constructor)
// 	if err != nil {
// 		panic(err)
// 	}
// }

//------------------------------------------------------------------------------

type reverseProcessor struct {
	logger *service.Logger
}

func newReverseProcessor(logger *service.Logger, metrics *service.Metrics) *reverseProcessor {
	// The logger and metrics components will already be labelled with the
	// identifier of this component within a config.
	return &reverseProcessor{
		logger: logger,
	}
}

func (r *reverseProcessor) Process(ctx context.Context, m *service.Message) (service.MessageBatch, error) {
	bytesContent, err := m.AsBytes()
	if err != nil {
		return nil, err
	}
	fmt.Println("process")
	newBytes := processBytes(bytesContent)

	m.SetBytes(newBytes)
	return []*service.Message{m}, nil
}

func (r *reverseProcessor) Close(ctx context.Context) error {
	return nil
}

func processBytes(data []byte) []byte {
	// 定义一个空的interface{}变量
	var result interface{}

	// 将字节流反序列化为interface{}类型的数据
	err := json.Unmarshal(data, &result)
	if err != nil {
		return nil
	}
	fmt.Println("ProcessMap")

	// 调用processMap方法处理数据
	ProcessMap(result)
	newBytes, _ := json.Marshal(result)
	if err != nil {
		return nil
	}
	return newBytes
}

func ProcessMap(data interface{}) {

	switch v := data.(type) {
	case map[string]interface{}:
		for key, value := range v {
			if attrs, ok := value.(map[string]interface{}); ok {
				if nilValue, exists := attrs["-nil"]; exists {

					if va, ok := nilValue.(bool); ok && va {
						fmt.Println(va)
						v[key] = nil
					} else if _, textExists := attrs["#text"]; textExists {
						// 如果存在 "#text" 属性，则直接将其值赋给父节点
						v[key] = attrs["#text"]
					}
				} else {
					// 递归处理子节点
					ProcessMap(value)
				}
			} else {
				// 递归处理子节点
				ProcessMap(value)
			}
		}
	case []interface{}:
		// 遍历数组元素，递归处理
		for _, item := range v {
			ProcessMap(item)
		}
	}
}
