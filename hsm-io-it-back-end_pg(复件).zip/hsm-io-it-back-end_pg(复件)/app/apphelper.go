package app

import (
	"hsm-io-it-back-end/config"
	"hsm-io-it-back-end/internal/constants"
	"hsm-io-it-back-end/internal/service"
	"hsm-io-it-back-end/internal/util"
	"hsm-io-it-back-end/internal/vo"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"

	"hsm-io-it-back-end/pkg/logger"
)

func InitPortalMenu() {
	shPath := "./meun.sh"

	cmd := exec.Command("bash", shPath)
	output, err := cmd.Output()
	if err != nil {
		logger.Info("Init portal menu failed:%v", err)
	}
	logger.Info(string(output))
}

func InitIOIT() {
	logger.Info("start init")
	New()
	util.GetNodeServer()
	// 初始化portal菜单
	if checkArch() == "x86_64" {
		if util.IsAuth {
			logger.Info("初始化菜单")
			InitPortalMenu()
		}
	}

	util.CreateGormDb()
	InitDB()
	copyTemplate()
	logger.Info("复制模板文件成功")
	if service.GetHsmTemplate() == "double-integ-manifest" {
		go service.FailOver()
	} else {
		ServiceStatus()
	}

	util.Sub()
}

func CheckFile(cfg *config.Config) {
	logger.Info("hsm-io-it-2024-end-v%v start....", config.ConfigAll.Version)
	// 项目文件夹
	projectPath := cfg.FILE.Path + cfg.FILE.Project
	// benthos数据文件夹
	benthosData := cfg.FILE.Path + cfg.FILE.BenthosData
	// benthos日志文件夹
	benthosLogs := cfg.FILE.Path + cfg.FILE.BenthosLogs
	// benthos指标文件夹
	benthosMetrics := cfg.FILE.Path + cfg.FILE.BenthosMetrics
	// 项目临时文件夹
	tempPath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp
	// dataConfig := projectPath + constants.DataBaseInfo + constants.Suffix

	// 创建项目所需的文件夹
	util.CreateDir(projectPath)
	util.CreateDir(benthosData)
	util.CreateDir(benthosLogs)
	util.CreateDir(benthosMetrics)
	util.CreateDir(tempPath)
	// util.CreateFile(dataConfig)
}

// 启动作业状态为运行的作业
func ServiceStatus() {
	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败:%v", err)
	}
	defer db.Close()

	query := `SELECT namespace, code, s_node FROM ioit.job_info WHERE status = 1`

	rows, err := db.Query(query)

	if err != nil {
		logger.Info("数据库查询失败:%v", err)
	}

	defer rows.Close()

	var jobs []vo.JobKeyInfo

	for rows.Next() {
		var job vo.JobKeyInfo
		if err := rows.Scan(&job.NameSpace, &job.Code, &job.SKNode); err != nil {
			logger.Info("数据库查询失败:%v", err)
		}
		logger.Info("job is:%v", job)
		jobs = append(jobs, job)
	}

	for _, v := range jobs {
		if util.ServerCode == v.SKNode {
			flag, _, _ := service.StartJob(&v)
			if flag {
				logger.Info("项目%v作业%v启动成功", v.Code, v.NameSpace)
			} else {
				logger.Error("项目%v作业%v启动失败", v.Code, v.NameSpace)
			}
		}
	}
}

func copyTemplate() {
	destDir := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.ProjectTemplate
	sourceDir := constants.HSM_OS_ROOT + "/apps/hsm-io-it-" + config.ConfigAll.Version + "/bin/template/"

	if _, err := os.Stat(destDir); os.IsNotExist(err) {
		err := os.MkdirAll(destDir, 0755)
		if err != nil {
			return
		}
	}

	err := filepath.Walk(sourceDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		relPath, err := filepath.Rel(sourceDir, path)
		if err != nil {
			return err
		}

		destPath := filepath.Join(destDir, relPath)

		if info.IsDir() {
			err := os.MkdirAll(destPath, 0755)
			if err != nil {
				return err
			}
		} else {
			srcFile, err := os.Open(path)
			if err != nil {
				return err
			}

			defer srcFile.Close()

			destFile, err := os.Create(destPath)
			if err != nil {
				return err
			}
			defer destFile.Close()
			_, err = io.Copy(destFile, srcFile)
			if err != nil {
				return err
			}
		}
		return nil
	})

	if err != nil {
		return
	}
}

func checkArch() string {
	cmd := exec.Command("uname", "-m")
	output, err := cmd.Output()
	if err != nil {
		logger.Info("uname -m报错:%v", err)
	}
	arch := strings.TrimSpace(string(output))
	logger.Info("当前架构为:%v", arch)
	return arch
}
