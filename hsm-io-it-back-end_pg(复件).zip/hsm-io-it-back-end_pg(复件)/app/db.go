package app

import (
	"bufio"
	"database/sql"
	"errors"
	"fmt"
	"hsm-io-it-back-end/config"
	"hsm-io-it-back-end/internal/util"
	"hsm-io-it-back-end/internal/vo"
	"hsm-io-it-back-end/pkg/logger"
	"io"
	"os"
	"strconv"
	"strings"

	"gorm.io/gorm"
)

func New() {

	//从环境变量读取pg信息
	envPg, err := buildPgConfFromEnv()
	if err == nil {
		config.ConfigAll.Postgres = envPg
	} else {
		logger.Info("err is:%v", err)
		logger.Info("环境变量不存在pg连接信息,默认连接config.yml中的pg配置")
	}

	logger.Info("envPg:%v", config.ConfigAll.Postgres.DbName)
}

// 从环境变量读取pg信息
func buildPgConfFromEnv() (config.Postgres, error) {
	pgConf := config.Postgres{}

	pgDbName := os.Getenv("DB_DATASOURCE")
	databaseIp := os.Getenv("database_ip")
	databasePort := os.Getenv("database_port")
	databaseUser := os.Getenv("database_user")
	databasePwd := os.Getenv("database_pwd")
	if databaseIp == "" || databasePort == "" || databaseUser == "" || databasePwd == "" {
		return pgConf, errors.New("环境变量不存在数据库连接信息")
	}
	pgUrl := "host=" + databaseIp + " port=" + databasePort + " user=" + databaseUser + " password=" + databasePwd + " sslmode=disable TimeZone=Asia/Shanghai"

	pgMaxIdleConnsStr := os.Getenv("POSTGRES_MAX_IDLE_CONNS")
	pgMaxIdleConns, err := strconv.Atoi(pgMaxIdleConnsStr)
	if err != nil {
		return pgConf, err
	}
	pgMaxOpenConnsStr := os.Getenv("POSTGRES_MAX_OPEN_CONNS")
	pgMaxOpenConns, err := strconv.Atoi(pgMaxOpenConnsStr)
	if err != nil {
		return pgConf, err
	}
	pgConnMaxIdleTimeStr := os.Getenv("POSTGRES_CONN_MAX_IDLE_TIME")
	pgConnMaxIdleTime, err := strconv.Atoi(pgConnMaxIdleTimeStr)
	if err != nil {
		return pgConf, err
	}
	pgConnMaxLifetimeStr := os.Getenv("POSTGRES_CONN_MAX_LIFETIME")
	pgConnMaxLifetime, err := strconv.Atoi(pgConnMaxLifetimeStr)
	if err != nil {
		return pgConf, err
	}
	pgConf.Url = pgUrl
	pgConf.DbName = pgDbName
	pgConf.MaxIdleConns = pgMaxIdleConns
	pgConf.MaxOpenConns = pgMaxOpenConns
	pgConf.ConnMaxIdleTime = pgConnMaxIdleTime
	pgConf.ConnMaxLifetime = pgConnMaxLifetime
	return pgConf, nil
}

func InitDB() {

	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("Fail to connect pg:%v", err)
	}

	defer db.Close()

	// 创建ioit模式
	exists := ensureSchemaExists(db, "ioit")
	logger.Info("ioit schema exists:%v", exists)

	// 建表
	schemaName := "ioit"
	tableNames := []interface{}{&vo.CreateJobRequest{}, &vo.JobNode{}, &vo.JobCata{}}

	newDb := util.GlobalGormDb.Exec(fmt.Sprintf("SET search_path TO %s", schemaName))

	// err = newDb.AutoMigrate(
	// 	&vo.CreateJobRequest{},
	// 	&vo.JobNode{},
	// 	&vo.JobCata{},
	// 	&vo.DatabaseInfoRequest{},
	// 	&vo.ComponentDb{},
	// 	&vo.ComponentCata{},
	// 	&vo.BusinessDataReq{},
	// )
	for _, table := range tableNames {
		if !newDb.Migrator().HasTable(table) {
			err := newDb.Migrator().CreateTable(table)
			if err != nil {
				logger.Info("failed to create table:%v", err)
			}
		}
	}

	if !exists {
		if err := executeSQLFile(db, "./sql/ioit.sql"); err != nil {
			logger.Info("Fail to execute file:%v", err)
		}
	}

	// 删除job_info中id主键设置
	deletePriKeyId()
	// 添加job_info的索引
	addIndexNamespace()
	// 添加database_info的retry字段
	addRetry()
	// 添加component的api_type字段
	addApiType()
	// 增加1.0初始化数据
	insertNewData(db)
	// 修改作业创建和更新时间
	updateCreateAndEditeTime()
}

func insertNewData(db *sql.DB) {
	var businessData vo.BusinessDataReq
	err := util.GlobalGormDb.Where("id = ?", "eOv6eA8w8QSuJNoXytarM").First(&businessData).Error
	if err != nil {
		if err == gorm.ErrRecordNotFound {
			// 插入1.0数据
			if err := executeSQLFile(db, "./sql/db13.sql"); err != nil {
				logger.Info("Fail to execute file:%v", err)
			}
		}
		logger.Info("select id failed:%v", err)
	}
}

func addRetry() {
	var count int64
	if err := util.GlobalGormDb.Raw("SELECT count(*) FROM information_schema.columns WHERE table_schema = 'ioit' AND table_name = 'database_info' AND column_name = 'retry'").Scan(&count).Error; err != nil {
		logger.Info("Fail to check retry:%v", err)
	}

	if count == 0 {
		if err := util.GlobalGormDb.Migrator().AddColumn(&vo.DatabaseInfoRequest{}, "Retry"); err != nil {
			logger.Info("Fail to add retry:%v", err)
		}

		if err := util.GlobalGormDb.Model(&vo.DatabaseInfoRequest{}).Where("retry IS NULL").Update("retry", "5").Error; err != nil {
			logger.Info("Fail to update retry:%v", err)
		}
	} else {
		logger.Info("retry already exist")
	}
}

func addApiType() {
	var count int64
	if err := util.GlobalGormDb.Raw("SELECT count(*) FROM information_schema.columns WHERE table_schema = 'ioit' AND table_name = 'component' AND column_name = 'api_type'").Scan(&count).Error; err != nil {
		logger.Info("Fail to check api_type:%v", err)
	}

	if count == 0 {
		if err := util.GlobalGormDb.Migrator().AddColumn(&vo.ComponentDb{}, "ApiType"); err != nil {
			logger.Info("Fail to add api_type:%v", err)
		}

		if err := util.GlobalGormDb.Model(&vo.ComponentDb{}).Where("api_type IS NULL").Update("api_type", "").Error; err != nil {
			logger.Info("Fail to update api_type:%v", err)
		}
	} else {
		logger.Info("api_type already exist")
	}
}

func deletePriKeyId() {
	var constraints string
	err := util.GlobalGormDb.Raw(`SELECT conname FROM pg_constraint WHERE conrelid = 'ioit.job_info'::regclass AND contype = 'p'`).Scan(&constraints).Error
	if err != nil {
		logger.Info("select pkey error:%v", err)
	}
	logger.Info("constraints:%v", constraints)
	if constraints != "" {
		err = util.GlobalGormDb.Exec(fmt.Sprintf(`ALTER TABLE ioit.job_info DROP CONSTRAINT %s`, constraints)).Error
		if err != nil {
			logger.Info("select pkey error:%v", err)

		}
	}
}

func updateCreateAndEditeTime() {
	createSql1 := `ALTER TABLE ioit.job_info ALTER COLUMN create_time TYPE VARCHAR(255);`
	editeSql1 := `ALTER TABLE ioit.job_info ALTER COLUMN edite_time TYPE VARCHAR(255);`
	createSqlTochar := `UPDATE ioit.job_info SET create_time = to_char(create_time::timestamptz,'YYYY-MM-DD HH24:MI:SS')`
	edieteSqlTochar := `UPDATE ioit.job_info SET edite_time = to_char(edite_time::timestamptz,'YYYY-MM-DD HH24:MI:SS')`

	sqlArr := []string{createSql1, editeSql1, createSqlTochar, edieteSqlTochar}
	for i := range sqlArr {
		err := util.GlobalGormDb.Exec(sqlArr[i]).Error
		if err != nil {
			logger.Info("Update time field error:%v", err)
		}
	}
}

func addIndexNamespace() {
	var count int64
	err := util.GlobalGormDb.Raw(`SELECT COUNT(1) FROM pg_indexes WHERE schemaname = 'ioit' AND tablename = 'job_info' AND indexname = 'idx_namespace'`).Scan(&count).Error

	if err != nil {
		logger.Info("select index failed:%v", err)
	}

	if count == 0 {
		err := util.GlobalGormDb.Exec(`CREATE INDEX idx_namespace on ioit.job_info (namespace);`)
		if err != nil {
			logger.Info("create index failed:%v", err)
		}
	} else {
		logger.Info("index already exist")
	}
}

func ensureSchemaExists(db *sql.DB, schemaName string) bool {
	var exists bool
	query := `SELECT EXISTS (SELECT 1 FROM pg_catalog.pg_namespace WHERE nspname = $1)`
	if err := db.QueryRow(query, schemaName).Scan(&exists); err != nil {
		logger.Info("Fail to check schema:%v", err)
	}

	if !exists {
		createSchemaSQL := fmt.Sprintf(`CREATE SCHEMA %s`, schemaName)
		if _, err := db.Exec(createSchemaSQL); err != nil {
			logger.Info("Fail to create schema:%v", err)
		}
	} else {
		logger.Info("scheam is exists")
	}
	return exists
}

func executeSQLFile(db *sql.DB, sqlPath string) error {
	file, err := os.Open(sqlPath)
	if err != nil {
		logger.Info("Fail to open file:%v", err)
	}
	defer file.Close()

	reader := bufio.NewReader(file)
	var sb strings.Builder

	for {
		line, err := reader.ReadString(';')
		if err != nil && err != io.EOF {
			logger.Info("Fail to read sql:%v", err)
			return err
		}

		line = strings.TrimSpace(line)
		if line != "" {
			sb.WriteString(line)
		}
		if err == io.EOF {
			break
		}
	}

	queries := strings.Split(sb.String(), ";")
	for _, query := range queries {
		query = strings.TrimSpace(query)
		if query != "" {
			if _, err := db.Exec(query); err != nil {
				logger.Info("Fail to excute sql:%v", err)
				return err
			}
		}
	}
	return nil
}
