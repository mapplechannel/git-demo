package app

import (
	"hsm-io-it-back-end/config"
	"hsm-io-it-back-end/internal/constants"
	"hsm-io-it-back-end/internal/route"

	"hsm-io-it-back-end/pkg/logger"

	"github.com/gin-gonic/gin"
)

func Run(cfg *config.Config) {
	// 初始化日志组件
	logger.Init(cfg.Log)
	// 初始化配置文件
	CheckFile(cfg)
	// 设置服务器运行模式
	gin.SetMode(gin.ReleaseMode)
	r := gin.New()
	// 匹配路由
	r = route.CollectRoute(r)
	InitIOIT()
	port := cfg.HTTP.Port
	// 启动服务
	if port != constants.EmptyContent {
		panic(r.Run(constants.AddressSplicingSymbols + port))
	}
	panic(r.Run())

}
