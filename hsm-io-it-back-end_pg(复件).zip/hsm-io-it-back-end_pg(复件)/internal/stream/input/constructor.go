package input

type Config struct {
	Type       string           `json:"type" yaml:"type"`
	HTTPClient HTTPClientConfig `json:"http_client" yaml:"http_client"`
	CSVFile    CSVFileConfig    `json:"csv" yaml:"csv"`
}
