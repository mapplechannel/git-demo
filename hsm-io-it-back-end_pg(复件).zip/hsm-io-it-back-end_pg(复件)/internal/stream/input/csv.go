package input

// CSVFileConfig contains configuration values for the CSVFile input type.
type CSVFileConfig struct {
	Paths          []string `json:"paths" yaml:"paths"`
	ParseHeaderRow bool     `json:"parse_header_row" yaml:"parse_header_row"`
	Delim          string   `json:"delimiter" yaml:"delimiter"`
	BatchCount     int      `json:"batch_count" yaml:"batch_count"`
}
