package http

// Config is a configuration struct for an HTTP client.
type Config struct {
	URL                 string            `json:"url" yaml:"url"`
	Verb                string            `json:"verb" yaml:"verb"`
	Headers             map[string]string `json:"headers" yaml:"headers"`
	CopyResponseHeaders bool              `json:"copy_response_headers" yaml:"copy_response_headers"`
	RateLimit           string            `json:"rate_limit" yaml:"rate_limit"`
	Timeout             string            `json:"timeout" yaml:"timeout"`
	Retry               string            `json:"retry_period" yaml:"retry_period"`
	MaxBackoff          string            `json:"max_retry_backoff" yaml:"max_retry_backoff"`
	NumRetries          int               `json:"retries" yaml:"retries"`
	BackoffOn           []int             `json:"backoff_on" yaml:"backoff_on"`
	DropOn              []int             `json:"drop_on" yaml:"drop_on"`
	SuccessfulOn        []int             `json:"successful_on" yaml:"successful_on"`
}
