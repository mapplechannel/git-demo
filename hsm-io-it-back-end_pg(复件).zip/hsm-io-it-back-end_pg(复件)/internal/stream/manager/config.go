package stream

import "hsm-io-it-back-end/internal/stream/input"

type Config struct {
	Input input.Config `json:"input" yaml:"input"`
}
