package sapmes

import (
	"hsm-io-it-back-end/internal/service/sap"
	"hsm-io-it-back-end/pkg/logger"
	"hsm-io-it-back-end/response"
	"io/ioutil"
	"time"

	"github.com/gin-gonic/gin"
)

// gateway
func Gateway(c *gin.Context) {
	requestBody := sap.ResolveRequestBody(c)

	go sap.ObjectOrList(requestBody)

	response.Api_Success(c, "flag", "执行网关成功", time.Now())
}

// 获取实时任务模板
func GetTemplate(c *gin.Context) {
	template := sap.GetTemplateInfo()
	response.Api_Success(c, template, "get template success", time.Now())
}

// 透传：物料主数据
func PenetrateMaterial(c *gin.Context) {
	requestBody := sap.PenetrateDataResolve(c)
	go sap.SplitMaterialData(requestBody)
	response.Api_Success(c, true, "PenetrateMaterial success", time.Now())
}

// 透传：产品Bom
func PenetratePbom(c *gin.Context) {
	requestBody := sap.PenetrateDataResolve(c)
	go sap.SplitPbomData(requestBody)
	response.Api_Success(c, true, "PenetratePbom success", time.Now())
}

// 透传：生产订单
func PenetrateOrder(c *gin.Context) {
	requestBody := sap.PenetrateDataResolve(c)
	go sap.SplitOrderData(requestBody)
	response.Api_Success(c, true, "PenetrateOrder success", time.Now())
}

// 透传：SN码
func PenetrateSN(c *gin.Context) {
	requestBody := sap.PenetrateDataResolve(c)
	go sap.SplitSNData(requestBody)
	response.Api_Success(c, true, "PenetrateSN success", time.Now())
}

// 透传：工艺路线
func PenetrateProcess(c *gin.Context) {
	requestBody := sap.PenetrateDataResolve(c)
	go sap.SplitProcessData(requestBody)
	response.Api_Success(c, true, "PenetrateProcess success", time.Now())
}

// 透传：生产订单
func PenetrateProductOrder(c *gin.Context) {
	requestBody := sap.PenetrateDataResolve(c)
	go sap.SplitProductOrderData(requestBody)
	response.Api_Success(c, true, "PenetrateProductOrder success", time.Now())
}

// 透传：工序
func PenetrateFlow(c *gin.Context) {
	requestBody := sap.PenetrateDataResolve(c)
	go sap.SplitFlowData(requestBody)
	response.Api_Success(c, true, "PenetrateFlow success", time.Now())
}

// ************************抽象**********************************
// 查重接口
func GetRepeatData(c *gin.Context) {
	dataType := c.Query("dataType")
	requestBody := sap.ResolveRequestBody(c)
	flag := sap.SearchRepeatData(requestBody, dataType)
	response.Api_Success(c, flag, "是否重复", time.Now())
}

// 添加接口
func AddData(c *gin.Context) {
	dataType := c.Query("dataType")
	requestBody := sap.ResolveRequestBody(c)

	flag := sap.AddData(requestBody, dataType)
	response.Api_Success(c, flag, "添加成功", time.Now())
}

// 删除接口
func DeleteData(c *gin.Context) {
	dataType := c.Query("dataType")
	requestBody := sap.ResolveRequestBody(c)

	flag := sap.DeleteData(requestBody, dataType)
	response.Api_Success(c, flag, "删除成功", time.Now())
}

// 更新接口
func EditData(c *gin.Context) {
	dataType := c.Query("dataType")
	requestBody := sap.ResolveRequestBody(c)

	flag := sap.EditData(requestBody, dataType)
	response.Api_Success(c, flag, "更新成功", time.Now())
}

// ************************抽象**********************************

// 更新订单状态
func EditOrderStatus(c *gin.Context) {
	requestBody := sap.ResolveRequestBody(c)

	flag := sap.EditOrderStatus(requestBody)

	response.Api_Success(c, flag, "更新订单状态成功", time.Now())
}

func StoreXML(c *gin.Context) {

	body, err := ioutil.ReadAll(c.Request.Body)
	if err != nil {
		logger.Info("请求体读取错误")
	}
	flag := sap.StoreXml(body)
	response.Api_Success(c, flag, "文件保存成功", time.Now())
}
