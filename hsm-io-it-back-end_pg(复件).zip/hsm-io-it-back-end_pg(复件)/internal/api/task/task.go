package task

import (
	"hsm-io-it-back-end/internal/service"
	"hsm-io-it-back-end/internal/vo"
	"hsm-io-it-back-end/response"
	"time"

	"github.com/gin-gonic/gin"
)

func Start(ctx *gin.Context) {
	var jobCanvasRequest = vo.JobKeyInfo{}
	if err := ctx.ShouldBind(&jobCanvasRequest); err != nil {
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, code, data := service.StartJob(&jobCanvasRequest)
	if flag { 
		response.Api_Success(ctx, flag, data, time.Now())
		return
	}
	response.Api_Code_Fail(ctx, code, time.Now())
}

func Excute(ctx *gin.Context) {
	var jobCanvasRequest = vo.JobKeyInfo{}
	if err := ctx.ShouldBind(&jobCanvasRequest); err != nil {
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, code, data := service.ExcuteJob(&jobCanvasRequest)
	if flag {
		response.Api_Success(ctx, flag, data, time.Now())
		return
	}
	response.Api_Code_Fail(ctx, code, time.Now())
}

func Stop(ctx *gin.Context) {
	var jobCanvasRequest = vo.JobKeyInfo{}
	if err := ctx.ShouldBind(&jobCanvasRequest); err != nil {
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, code, data := service.StopJob(&jobCanvasRequest)
	if flag {
		response.Api_Success(ctx, flag, data, time.Now())
		return
	}
	response.Api_Code_Fail(ctx, code, time.Now())

}

func StartRTJob(ctx *gin.Context) {
	var jobCanvasRequest = vo.CreateJobRequest{}
	if err := ctx.ShouldBind(&jobCanvasRequest); err != nil {
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	service.StartRealTimeJob(&jobCanvasRequest)
	response.Api_Success(ctx, "启动成功", "启动成功", time.Now())
}

func StopRTJob(ctx *gin.Context) {
	var jobCanvasRequest = vo.CreateJobRequest{}
	if err := ctx.ShouldBind(&jobCanvasRequest); err != nil {
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	service.StopRealTimeJob(&jobCanvasRequest)
	response.Api_Success(ctx, "停止成功", "停止成功", time.Now())
}
