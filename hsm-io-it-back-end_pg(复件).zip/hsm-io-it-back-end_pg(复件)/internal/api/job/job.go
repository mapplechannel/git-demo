package job

import (
	"hsm-io-it-back-end/internal/constants"
	"hsm-io-it-back-end/internal/service"
	"hsm-io-it-back-end/internal/vo"
	"hsm-io-it-back-end/pkg/logger"
	"hsm-io-it-back-end/response"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/gin-gonic/gin/binding"
)

// @Tag 添加作业
func Add(ctx *gin.Context) {
	var jobRequest vo.CreateJobRequest
	// 验证参数
	if err := ctx.ShouldBind(&jobRequest); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		logger.Error("数据验证错误:%v", err)
		return
	}
	flag, code, _, job := service.AddJob(&jobRequest)
	if flag {
		response.Api_Success(ctx, job, "新增作业<"+job.Name+">成功", time.Now())
		return
	}
	// response.Api_Fail(ctx, msg, time.Now())
	response.Api_Code_Fail(ctx, code, time.Now())
}

func AddCode(ctx *gin.Context) {
	var jobRequest vo.CreateJobRequest
	if err := ctx.ShouldBind(&jobRequest); err != nil {
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		logger.Error("数据验证错误:%v", err)
		return
	}
	flag := service.CheckCode(jobRequest.NameSpace, jobRequest.Code)
	if flag {
		response.Api_Success(ctx, flag, "编码校验成功", time.Now())
		return
	}
	response.Api_Code_Fail(ctx, response.EXIST_CODE, time.Now())
}

// @Tag 保存作业详情

func SaveJobInfo(ctx *gin.Context) {
	// 获取参数
	var jobRequest vo.CreateJobRequest
	// 验证参数
	if err := ctx.ShouldBind(&jobRequest); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		logger.Error("数据验证错误")
		return
	}
	flag, msg, code := service.SaveJob(&jobRequest)
	if flag {
		response.Api_Success(ctx, flag, msg, time.Now())
		return
	}
	// response.Api_Fail(ctx, msg, time.Now())
	response.Api_Code_Fail(ctx, code, time.Now())

}

// @Tag 修改作业
func Update(ctx *gin.Context) {
	var jobRequest = vo.CreateJobRequest{}
	if err := ctx.ShouldBind(&jobRequest); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		logger.Error("数据验证错误")
		return
	}
	flag, msg, _, code := service.UpdateJob(&jobRequest)
	if flag {
		response.Api_Success(ctx, flag, msg, time.Now())
		return
	}
	// response.Api_Fail(ctx, msg, time.Now())
	response.Api_Code_Fail(ctx, code, time.Now())
}

// @Tag 删除作业
func Delete(ctx *gin.Context) {
	var deleteJobRequest = vo.JobKeyInfo{}
	if err := ctx.ShouldBind(&deleteJobRequest); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, code, data := service.DeleteJob(&deleteJobRequest)
	if flag {
		response.Api_Success(ctx, flag, data, time.Now())
		return
	}
	// response.Api_Fail(ctx, msg, time.Now())
	response.Api_Code_Fail(ctx, code, time.Now())
}

// @Tag 查询作业信息列表
func GetJobList(ctx *gin.Context) {
	var getJobRequest = vo.JobListReq{}
	if err := ctx.ShouldBind(&getJobRequest); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	_, data, msg := service.GetJobList(&getJobRequest)
	response.Api_Success(ctx, data, msg, time.Now())
}

// @Tag 查询作业详情信息
func GetJobInfo(ctx *gin.Context) {
	var jobRequest = vo.JobKeyInfo{}
	if err := ctx.ShouldBind(&jobRequest); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, data, msg := service.GetJobInfo(&jobRequest)
	if flag {
		response.Api_Success(ctx, data, msg, time.Now())
		return
	}
	// response.Api_Fail(ctx, msg, time.Now())
	response.Api_Code_Fail(ctx, response.GET_INFO_FAILED, time.Now())
}

// @Tag 查询作业详情信息
func GetJobData(ctx *gin.Context) {
	var jobRequest = vo.JobKeyInfo{}
	if err := ctx.ShouldBind(&jobRequest); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, msg := service.GetJobData(&jobRequest)
	if flag {
		response.Api_Success(ctx, flag, msg, time.Now())
		return
	}
	// response.Api_Fail(ctx, msg, time.Now())
	response.Api_Code_Fail(ctx, response.GET_INFO_FAILED, time.Now())
}

// @Tag 查询作业详情信息
func GetJobLog(ctx *gin.Context) {
	var jobRequest = vo.JobKeyInfo{}
	if err := ctx.ShouldBind(&jobRequest); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, msg := service.GetJobLog(&jobRequest)
	if flag {
		response.Api_Success(ctx, msg, "查询成功", time.Now())
		return
	}
	// response.Api_Fail(ctx, "查询失败", time.Now())
	response.Api_Code_Fail(ctx, response.GET_INFO_FAILED, time.Now())
}

// @Tag 导出作业
func ExportJob(ctx *gin.Context) {
	var jobRequest = vo.JobKeyInfo{}

	var databaseslice vo.AttrsOfDatabase

	var uploadpathslice vo.AttrsOfFileUpload

	err1 := ctx.ShouldBindBodyWith(&databaseslice, binding.JSON)

	if err1 != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	err2 := ctx.ShouldBindBodyWith(&uploadpathslice, binding.JSON)

	if err2 != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	err3 := ctx.ShouldBindBodyWith(&jobRequest, binding.JSON)

	if err3 != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	flag, code, data := service.ExportJob(&jobRequest, ctx, &databaseslice, &uploadpathslice)

	if flag {
		response.Api_Success(ctx, flag, data, time.Now())
		return
	}
	// response.Api_Fail(ctx, msg, time.Now())
	response.Api_Code_Fail(ctx, code, time.Now())
}

func ExportBatchJob(ctx *gin.Context) {
	var projectRequest = vo.JobKeyInfo{}

	if err := ctx.ShouldBind(&projectRequest); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	flag, code, data := service.ExportBatchJob(&projectRequest, ctx)

	if flag {
		response.Api_Success(ctx, flag, data, time.Now())
		return
	}
	// response.Api_Fail(ctx, msg, time.Now())
	response.Api_Code_Fail(ctx, code, time.Now())
}

// @Tag 删除项目
func DeleteProject(ctx *gin.Context) {
	var projectRequest = vo.JobKeyInfo{}
	if err := ctx.ShouldBind(&projectRequest); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, msg := service.DeleteProject(&projectRequest)
	if flag {
		response.Api_Success(ctx, flag, msg, time.Now())
		return
	}
	// response.Api_Fail(ctx, msg, time.Now())
	response.Api_Code_Fail(ctx, response.DELETE_FAILED, time.Now())

}

// @Tag 导出项目
func ExportProject(ctx *gin.Context) {
	namespace := ctx.GetHeader("namespace")
	// 检查是否存在这个 Header 参数
	if namespace == "" {
		// response.Api_Fail(ctx, "namespace验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	var exportProjectRequest = vo.ExportProjectRequest{}
	if err := ctx.ShouldBind(&exportProjectRequest); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	filePath := exportProjectRequest.FilePath
	status, msg := service.ExportProject(namespace, filePath)

	if status == 1 {
		response.Api_Success(ctx, gin.H{"status": status}, msg, time.Now())
		return
	}
	// response.Api_Fail(ctx, msg, time.Now())
	response.Api_Code_Fail(ctx, response.EXPORT_FAILED, time.Now())
}

// @Tag 取消导出项目
func CancelExportProject(ctx *gin.Context) {
	namespace := ctx.GetHeader("namespace")
	// 检查是否存在这个 Header 参数
	if namespace == "" {
		// response.Api_Fail(ctx, "namespace验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	var exportProjectRequest = vo.ExportProjectRequest{}
	if err := ctx.ShouldBind(&exportProjectRequest); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	filePath := exportProjectRequest.FilePath
	status, msg := service.CancelExportProject(namespace, filePath)
	response.Api_Success(ctx, gin.H{"status": status}, msg, time.Now())
}

// @Tag 导出项目
func ExportResult(ctx *gin.Context) {

	namespace := ctx.GetHeader("namespace")
	// 检查是否存在这个 Header 参数
	if namespace == "" {
		// response.Api_Fail(ctx, "namespace验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	var exportProjectRequest = vo.ExportProjectRequest{}
	if err := ctx.ShouldBind(&exportProjectRequest); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	filePath := exportProjectRequest.FilePath
	status, rate := service.ExportResult(namespace, filePath)
	numRate, _ := strconv.Atoi(rate)
	ctx.Header("namespace", namespace)

	response.Api_Success(ctx, gin.H{"status": status, "rate": numRate}, "查询进度为："+rate, time.Now())
}

// @Tag 导入项目
func ImportProject(ctx *gin.Context) {
	namespace := ctx.GetHeader("namespace")
	if namespace == "" {
		// response.Api_Fail(ctx, "namespace验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	var exportProjectRequest = vo.ExportProjectRequest{}
	if err := ctx.ShouldBind(&exportProjectRequest); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	status, msg := service.ImportProject(namespace, exportProjectRequest.FilePath)

	if status == 1 {
		response.Api_Success(ctx, gin.H{"status": status}, msg, time.Now())
		return
	}
	// response.Api_Fail(ctx, msg, time.Now())
	response.Api_Code_Fail(ctx, response.EXPORT_FAILED, time.Now())
}

// @Tag 取消导入项目
func CancelImportProject(ctx *gin.Context) {
	namespace := ctx.GetHeader("namespace")
	// 检查是否存在这个 Header 参数
	if namespace == "" {
		// response.Api_Fail(ctx, "namespace验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	var exportProjectRequest = vo.ExportProjectRequest{}
	if err := ctx.ShouldBind(&exportProjectRequest); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	status, msg := service.CancelImportProject(namespace, exportProjectRequest.FilePath)
	response.Api_Success(ctx, gin.H{"status": status}, msg, time.Now())

}

// @Tag 导出项目
func ImportResult(ctx *gin.Context) {

	namespace := ctx.GetHeader("namespace")
	if namespace == "" {
		// response.Api_Fail(ctx, "namespace验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	var exportProjectRequest = vo.ExportProjectRequest{}
	if err := ctx.ShouldBind(&exportProjectRequest); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	filePath := exportProjectRequest.FilePath
	status, msg := service.ImportResult(namespace, filePath)

	logger.Info("导入项目状态：%v", status)

	ctx.Header("namespace", namespace)

	if status == 2 {
		response.Api_Success(ctx, gin.H{"status": status, "rate": 100}, msg, time.Now())
	} else {
		response.Api_Success(ctx, gin.H{"status": status, "rate": 50}, msg, time.Now())
	}

}

// @Tag 查询作业信息列表
func Search(ctx *gin.Context) {
	var getJobContent = vo.GetJobContent{}
	if err := ctx.ShouldBind(&getJobContent); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		logger.Info("err is :%v", err)
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	_, msg := service.Search(&getJobContent)
	response.Api_Success(ctx, msg, "查询成功", time.Now())
}

// ENG优化*************************************
func ENG_GetDefaultName(ctx *gin.Context) {
	var getJobRequest = vo.JobKeyInfo{}

	if err := ctx.ShouldBind(&getJobRequest); err != nil {
		// response.ENG_Fail(ctx, "数据验证错误", nil, time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	flag, res := service.DefaultName(&getJobRequest)
	if flag {
		response.ENG_Success(ctx, "", res, time.Now())
	} else {
		// response.ENG_Fail(ctx, res, nil, time.Now())
		response.Api_Code_Fail(ctx, response.GET_INFO_FAILED, time.Now())
	}
}

func ENG_Update(ctx *gin.Context) {
	var jobRequest vo.CreateJobRequest
	if err := ctx.ShouldBind(&jobRequest); err != nil {
		// response.ENG_Fail(ctx, "数据验证错误", nil, time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, msg, jobData := service.UpdateJob_ENG(&jobRequest)
	if flag {
		response.ENG_Success(ctx, msg, jobData, time.Now())
	} else {
		// response.ENG_Fail(ctx, msg, "", time.Now())
		response.Api_Code_Fail(ctx, response.OPERATION_FAILED, time.Now())
	}
}

func ENG_Delete(ctx *gin.Context) {
	var deleteJobRequest = vo.JobKeyInfo{}
	if err := ctx.ShouldBind(&deleteJobRequest); err != nil {
		// response.ENG_Fail(ctx, "数据验证错误", nil, time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	flag, code, msg := service.DeleteJob(&deleteJobRequest)
	if flag {
		response.ENG_Success(ctx, msg, flag, time.Now())
	} else {
		// response.ENG_Fail(ctx, msg, flag, time.Now())
		response.Api_Code_Fail(ctx, code, time.Now())
	}
}

func ENG_DeleteProject(ctx *gin.Context) {
	var proId = vo.ProjectDelRequest{}
	if err := ctx.ShouldBind(&proId); err != nil {
		// response.DataPublish_Fail(ctx, "数据验证错误", nil, time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	var deleteProReq = vo.JobKeyInfo{}
	deleteProReq.NameSpace = proId.ProjectId
	_, msg := service.DeleteProject(&deleteProReq)
	response.DataPublish_Success(ctx, msg, nil, time.Now())
}

// *******************数据发布*************************
func DataPublish_GetJobList(ctx *gin.Context) {
	namespace := ctx.Request.Header.Get("namespace")
	// code := ctx.Param("code")

	flag, res, msg := service.GetJobTree(namespace)
	if flag {
		response.DataPublish_Success(ctx, msg, res, time.Now())
	} else {
		// response.DataPublish_Fail(ctx, msg, nil, time.Now())
		response.Api_Code_Fail(ctx, response.GET_INFO_FAILED, time.Now())
	}
}

func DataPublish_Compress(ctx *gin.Context) {
	namespace := ctx.Request.Header.Get("namespace")
	var getDataPublishCompileRequest = vo.GetDataPublishCompileRequest{}

	if err := ctx.ShouldBind(&getDataPublishCompileRequest); err != nil {
		// response.DataPublish_Fail(ctx, "数据验证错误", nil, time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	flag, msg := service.CompressTargz(namespace, &getDataPublishCompileRequest)
	if flag {
		response.DataPublish_Success(ctx, msg, "success", time.Now())
	} else {
		// response.DataPublish_Fail(ctx, msg, "failed", time.Now())
		response.Api_Code_Fail(ctx, response.OPERATION_FAILED, time.Now())
	}

}

func DataPublish_Update(ctx *gin.Context) {
	namespace := ctx.Request.Header.Get("namespace")
	var getDataPublishRequest = vo.GetDataPublishRequest{}

	if err := ctx.ShouldBind(&getDataPublishRequest); err != nil {
		// response.DataPublish_Fail(ctx, "数据验证错误", nil, time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	flag, msg := service.DataUpdate(namespace, &getDataPublishRequest)

	if flag {
		response.DataPublish_Success(ctx, msg, flag, time.Now())
	} else {
		response.DataPublish_Fail(ctx, msg, flag, time.Now())
		// response.Api_Code_Fail(ctx, response.OPERATION_FAILED, time.Now())
	}

}

func DataPublish_Rollback(ctx *gin.Context) {
	namespace := ctx.Request.Header.Get("namespace")

	flag, msg, rollback_version := service.RollBack(namespace)

	if flag {
		response.DataPublish_Success(ctx, msg, rollback_version, time.Now())
	} else {
		// response.DataPublish_Fail(ctx, msg, rollback_version, time.Now())
		response.Api_Code_Fail(ctx, response.OPERATION_FAILED, time.Now())
	}

}

func DataPublish_PublishedRange(ctx *gin.Context) {
	namespace := ctx.Request.Header.Get("namespace")
	var getDataPublishCompileRequest vo.GetDataPublishCompileRequest

	if err := ctx.ShouldBind(&getDataPublishCompileRequest); err != nil {
		// response.DataPublish_Fail(ctx, "数据验证错误", nil, time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, msg := service.PublishedRange(namespace, &getDataPublishCompileRequest)
	if flag {
		response.DataPublish_Success(ctx, msg, msg, time.Now())
	} else {
		// response.DataPublish_Fail(ctx, msg, msg, time.Now())
		response.Api_Code_Fail(ctx, response.OPERATION_FAILED, time.Now())
	}
}

func DataPublish_GetDataUpdateStatus(ctx *gin.Context) {
	status, version := service.GetDataUpdateStatus()
	response.DataPublish_Success(ctx, "操作成功", gin.H{"version": version, "status": status}, time.Now())
}

func DataPublish_GetProgress(ctx *gin.Context) {
	progress := service.GetProgress()
	response.DataPublish_Success(ctx, "操作成功", gin.H{"result": progress}, time.Now())
}

func DataPublish_GetStatus(ctx *gin.Context) {
	status := service.GetStatus()
	response.DataPublish_Success(ctx, "操作成功", gin.H{"result": status}, time.Now())
}

func DataPublish_GetLog(ctx *gin.Context) {
	namespace := ctx.Request.Header.Get("namespace")
	var logRequest = vo.LogRequest{}

	if err := ctx.ShouldBind(&logRequest); err != nil {
		// response.DataPublish_Fail(ctx, "数据验证错误", nil, time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	log := service.GetLog(namespace, &logRequest)
	response.DataPublish_Success(ctx, "操作成功", log, time.Now())
}

// @Tag 导入作业校验
func ImportCheckJob1(ctx *gin.Context) {
	logger.Info("上传文件")
	file, err := ctx.FormFile("file")
	if err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	jobinfo, flag, msg := service.ImportJobCheck(file, ctx)
	response.Api_Success(ctx, gin.H{"flag1": jobinfo, "flag2": flag}, msg, time.Now())
}

func ImportJob1(ctx *gin.Context) {
	logger.Info("上传文件")
	file, err := ctx.FormFile("file")
	if err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, jobInfo, code, msg := service.ImportJob1(file, ctx)
	if flag {
		response.Api_Success(ctx, gin.H{"flag": flag, "data": jobInfo}, msg, time.Now())
		return
	}
	response.Api_Code_Fail(ctx, code, time.Now())
}

// 批量导入作业校验
func ImportBatchCheckJobs1(ctx *gin.Context) {

	file, err := ctx.FormFile("file")
	if err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag1, flag2, msg := service.ImportBatchCheckJobs1(file, ctx)
	response.Api_Success(ctx, gin.H{"flag1": flag1, "flag2": flag2}, msg, time.Now())
}

// 批量导入作业校验
func ImportBatchJobs1(ctx *gin.Context) {

	file, err := ctx.FormFile("file")
	if err != nil {
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag1, flag2, code, msg := service.ImportBatchJobs1(file, ctx)
	if flag2 {
		response.Api_Success(ctx, flag1, msg, time.Now())
		return
	}
	response.Api_Code_Fail(ctx, code, time.Now())
}

func GetJobCata(ctx *gin.Context) {
	var CataRequest = service.JobCataReq{}

	if err := ctx.ShouldBind(&CataRequest); err != nil {
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	root := service.BuildTree("")
	response.Api_Success(ctx, root.Children, "查询成功", time.Now())
}

// 添加作业分类
func AddJobCata(ctx *gin.Context) {
	var CataRequest = service.JobCataReq{}

	if err := ctx.ShouldBind(&CataRequest); err != nil {
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, respcode, data, name := service.AddJobCata(&CataRequest)
	if flag {
		response.Api_Success(ctx, data, "新增分类<"+name+">成功", time.Now())
	} else {
		response.Api_Code_Fail(ctx, respcode, time.Now())
	}
}

// 更新作业分类
func EditeJobCata(ctx *gin.Context) {
	var CataRequest = service.JobCataReq{}

	if err := ctx.ShouldBind(&CataRequest); err != nil {
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, code, name := service.EditJobCata(&CataRequest)
	if flag {
		response.Api_Success(ctx, flag, "编辑分类<"+name+">成功", time.Now())
	} else {
		response.Api_Code_Fail(ctx, code, time.Now())
	}
}

// 删除作业分类
func DeleteJobCata(ctx *gin.Context) {
	var CataRequest = service.JobCataReq{}

	if err := ctx.ShouldBind(&CataRequest); err != nil {
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, code, name := service.DeleteJobCata(CataRequest.NameSpace, CataRequest.CataCode)
	if flag {
		response.Api_Success(ctx, flag, "删除分类<"+name+">成功", time.Now())
	} else {
		response.Api_Code_Fail(ctx, code, time.Now())
	}
}

func XmlToJson(ctx *gin.Context) {
	var XmlRequest = vo.XmlToJson{}

	if err := ctx.ShouldBind(&XmlRequest); err != nil {
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	data, err, msg := service.XmlToMap(XmlRequest.Xml)

	if err == nil {
		response.Api_Success(ctx, data, "解析成功", time.Now())
	} else {
		response.Api_Fail(ctx, msg, time.Now())
	}
}

func TestConn(ctx *gin.Context) {
	var reqBody = vo.TestConnReq{}

	if err := ctx.ShouldBind(&reqBody); err != nil {
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	resp, respbody := service.TestHttpConn(&reqBody)

	ctx.Data(resp.StatusCode, resp.Header.Get("Content-Type"), respbody)

}

func DataCompare(ctx *gin.Context) {
	var req = service.CompareRequest{}

	if err := ctx.ShouldBind(&req); err != nil {
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	result := service.CompareHandler(req)
	response.Api_Success(ctx, result, "对比成功", time.Now())
}

func GetComponent(ctx *gin.Context) {
	var req = vo.ComponentTypeRep{}
	if err := ctx.ShouldBind(&req); err != nil {
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	categories, code := service.FetchCategories()
	if code != 0 {
		response.Api_Code_Fail(ctx, code, time.Now())
		return
	}
	components, err := service.FetchComponent(req.ApplicableType)
	if err != nil {
		response.Api_Code_Fail(ctx, response.DATABASE_READ_FAILED, time.Now())
		return
	}
	groupCate := service.GroupComponentsByCategory(components, categories)
	response.Api_Success(ctx, groupCate, "Get Component success", time.Now())
}

func GetComponentCate(ctx *gin.Context) {
	data, code := service.FetchCategories()
	if code != 0 {
		response.Api_Code_Fail(ctx, code, time.Now())
	} else {
		response.Api_Success(ctx, data, "Get ComponentCate success", time.Now())
	}
}

func AddComponent(ctx *gin.Context) {
	var req = vo.Component{}

	if err := ctx.ShouldBind(&req); err != nil {
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, code := service.AddComponent(&req)
	if flag {
		response.Api_Success(ctx, flag, "Add success", time.Now())
	} else {
		response.Api_Code_Fail(ctx, code, time.Now())
	}
}

func AddBusinessData(ctx *gin.Context) {
	var req = vo.BusinessDataReq{}

	if err := ctx.ShouldBind(&req); err != nil {
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, code := service.AddBusinessData(&req)
	if flag {
		response.Api_Success(ctx, flag, "Add success", time.Now())
	} else {
		response.Api_Code_Fail(ctx, code, time.Now())
	}
}

func GetBusinessData(ctx *gin.Context) {
	var req = vo.BusinessDataReq{}

	if err := ctx.ShouldBind(&req); err != nil {
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	data, code := service.GetBusinessData(&req)

	if code != 0 {
		response.Api_Code_Fail(ctx, code, time.Now())
	} else {
		response.Api_Success(ctx, data, "Add success", time.Now())
	}
}

func GetJobSchType(ctx *gin.Context) {
	var req = vo.JobKeyInfo{}

	if err := ctx.ShouldBind(&req); err != nil {
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	data := service.GetSchTypeForYaml(&req)

	response.Api_Success(ctx, data, "查询成功", time.Now())
}

func GetSkPath(ctx *gin.Context) {

	path := constants.GetHsmHome()

	response.Api_Success(ctx, path, "查询SK路径成功", time.Now())
}
