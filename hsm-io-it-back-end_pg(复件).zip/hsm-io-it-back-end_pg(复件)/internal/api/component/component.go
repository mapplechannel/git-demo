package component

import (
	"hsm-io-it-back-end/internal/service"
	"hsm-io-it-back-end/internal/vo"
	"hsm-io-it-back-end/response"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/gin-gonic/gin/binding"
)

// @Tag 测试连接数据库
func ConnectMySqlTest(ctx *gin.Context) {
	var mysqlInfoRequest = vo.DatabaseInfoRequest{}
	if err := ctx.ShouldBind(&mysqlInfoRequest); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, msg := service.ConnectMysqlTest(&mysqlInfoRequest)

	if flag {
		response.Api_Success(ctx, flag, msg, time.Now())
		return
	}
	response.Api_Fail(ctx, msg, time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_CONNECT_FAILED, time.Now())
}

// @Tag 添加数据库连接信息
func AddConenctMySql(ctx *gin.Context) {
	var mysqlInfoRequest = vo.DatabaseInfoRequest{}
	if err := ctx.ShouldBind(&mysqlInfoRequest); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, msg := service.AddConenctMySql(&mysqlInfoRequest)
	if flag {
		response.Api_Success(ctx, flag, msg, time.Now())
		return
	}
	response.Api_Fail(ctx, msg, time.Now())
	// response.Api_Code_Fail(ctx, response.OPERATION_FAILED, time.Now())
}

// @Tag 连接数据库
func GetConenctMySql(ctx *gin.Context) {
	var mysqlInfo = vo.DatabaseInfoRequest{}
	if err := ctx.ShouldBind(&mysqlInfo); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, data := service.GetConenctMySql(&mysqlInfo)

	if flag {
		response.Api_Success(ctx, data, "连接成功", time.Now())
		return
	}
	response.Api_Fail(ctx, "查询失败", time.Now())
	// response.Api_Code_Fail(ctx, response.GET_INFO_FAILED, time.Now())
}

// @Tag 获取数据库连接信息
func GetConnectList(ctx *gin.Context) {

	var mysqlListInfo = vo.DatabaseInfoRequest{}
	if err := ctx.ShouldBind(&mysqlListInfo); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, data := service.GetConnectInfo(&mysqlListInfo)

	if flag {
		response.Api_Success(ctx, data, "连接成功", time.Now())
		return
	}
	response.Api_Fail(ctx, "连接失败", time.Now())
	// response.Api_Code_Fail(ctx, response.GET_INFO_FAILED, time.Now())

}

// @Tag 获取数据库表列表
func GetTable(ctx *gin.Context) {
	var mysqlInfoRequest = vo.DatabaseInfoRequest{}

	err := ctx.ShouldBind(&mysqlInfoRequest)

	if err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	flag, data, msg := service.GetTable(&mysqlInfoRequest)

	if flag {
		response.Api_Success(ctx, data, msg, time.Now())
		return
	}
	response.Api_Fail(ctx, msg, time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_READ_FAILED, time.Now())
}

// @Tag 获取数据库表主键

func GetTablePrimary(ctx *gin.Context) {
	var mysqlInfoRequest = vo.DatabaseInfoRequest{}
	err := ctx.ShouldBind(&mysqlInfoRequest)
	if err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	flag, data := service.GetTablePrimary(&mysqlInfoRequest)

	if flag {
		response.Api_Success(ctx, data, "查询成功", time.Now())
		return
	}
	response.Api_Fail(ctx, "查询失败", time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_READ_FAILED, time.Now())
}

// @Tag 获取字段列表
func GetTableColumns(ctx *gin.Context) {
	var mysqlInfoRequest = vo.DatabaseInfoRequest{}

	err := ctx.ShouldBind(&mysqlInfoRequest)

	if err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	flag, data := service.GetTableColumns(&mysqlInfoRequest)

	if flag {
		response.Api_Success(ctx, data, "查询成功", time.Now())
		return
	}
	response.Api_Fail(ctx, "查询失败", time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_READ_FAILED, time.Now())
}

// @Tag 获取字段列表

func GetData(ctx *gin.Context) {
	var mysqlInfoRequest = vo.DatabaseInfoRequest{}

	err := ctx.ShouldBind(&mysqlInfoRequest)

	if err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	flag, data, msg := service.GetTableData(&mysqlInfoRequest)

	if flag {
		response.Api_Success(ctx, data, msg, time.Now())
		return
	}
	response.Api_Fail(ctx, msg, time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_READ_FAILED, time.Now())
}

// @Tag 修改数据库连接信息
func UpdateConnect(ctx *gin.Context) {
	var updateMysqlInfo = vo.DatabaseInfoRequest{}
	if err := ctx.ShouldBind(&updateMysqlInfo); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, msg := service.UpdateConnect(&updateMysqlInfo)

	if flag {
		response.Api_Success(ctx, flag, msg, time.Now())
		return
	}
	response.Api_Fail(ctx, msg, time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_UPDATE_FAILED, time.Now())
}

func ConnectPGTest(ctx *gin.Context) {
	var pgInfoRequest = vo.DatabaseInfoRequest{}
	if err := ctx.ShouldBind(&pgInfoRequest); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, msg := service.ConnectPGTest(&pgInfoRequest)

	if flag {
		response.Api_Success(ctx, flag, msg, time.Now())
		return
	}
	response.Api_Fail(ctx, msg, time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_CONNECT_FAILED, time.Now())
}

func GetPGConnectList(ctx *gin.Context) {

	var mysqlListInfo = vo.DatabaseInfoRequest{}
	if err := ctx.ShouldBind(&mysqlListInfo); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, data := service.GetPGConnectList(&mysqlListInfo)

	if flag {
		response.Api_Success(ctx, data, "连接成功", time.Now())
		return
	}
	response.Api_Fail(ctx, "连接失败", time.Now())
	// response.Api_Code_Fail(ctx, response.GET_INFO_FAILED, time.Now())
}

func AddConnectPG(ctx *gin.Context) {
	var pgInfoRequest = vo.DatabaseInfoRequest{}
	if err := ctx.ShouldBind(&pgInfoRequest); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, msg := service.AddConnectPG(&pgInfoRequest)

	if flag {
		response.Api_Success(ctx, flag, msg, time.Now())
		return
	}
	response.Api_Fail(ctx, msg, time.Now())
	// response.Api_Code_Fail(ctx, response.OPERATION_FAILED, time.Now())
}

func UpdateConnectPG(ctx *gin.Context) {
	var updatePGInfo = vo.DatabaseInfoRequest{}
	if err := ctx.ShouldBind(&updatePGInfo); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, msg := service.UpdateConnectPG(&updatePGInfo)

	if flag {
		response.Api_Success(ctx, flag, msg, time.Now())
		return
	}
	response.Api_Fail(ctx, msg, time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_UPDATE_FAILED, time.Now())
}

func GetPGDataBaseConnectList(ctx *gin.Context) {
	var pgInfoRequest = vo.DatabaseInfoRequest{}
	if err := ctx.ShouldBind(&pgInfoRequest); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, data, code := service.GetPGDataBaseConnectList(&pgInfoRequest)
	if flag {
		response.Api_Success(ctx, data, "查询成功", time.Now())
		return
	}
	// response.Api_Fail(ctx, "查询失败", time.Now())
	response.Api_Code_Fail(ctx, code, time.Now())
}

func GetPGModeList(ctx *gin.Context) {
	var databaseInfo = vo.DatabaseInfoRequest{}

	err := ctx.ShouldBind(&databaseInfo)

	if err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	flag, data := service.GetPGModeList(&databaseInfo)
	if flag {
		response.Api_Success(ctx, data, "查询成功", time.Now())
		return
	}
	response.Api_Fail(ctx, "查询失败", time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_READ_FAILED, time.Now())
}

func GetPGTableList(ctx *gin.Context) {
	var pgInfoRequest = vo.DatabaseInfoRequest{}
	if err := ctx.ShouldBind(&pgInfoRequest); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, data := service.GetPGTableList(&pgInfoRequest)

	if flag {
		response.Api_Success(ctx, data, "查询成功", time.Now())
		return
	}
	response.Api_Fail(ctx, "查询失败", time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_READ_FAILED, time.Now())
}

func GetPGTablesPrimary(ctx *gin.Context) {
	var dbName = vo.ModeAndTableName{}

	var pgInfoRequest = vo.DatabaseInfoRequest{}

	err := ctx.ShouldBindBodyWith(&dbName, binding.JSON)
	if err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	err = ctx.ShouldBindBodyWith(&pgInfoRequest, binding.JSON)

	if err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	flag, data := service.GetPGTablesPrimary(dbName.ModeName, dbName.TableName, &pgInfoRequest)

	if flag {
		response.Api_Success(ctx, data, "查询成功", time.Now())
		return
	}
	response.Api_Fail(ctx, "查询失败", time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_READ_FAILED, time.Now())
}

func GetPGTableColumns(ctx *gin.Context) {
	var dbName = vo.ModeAndTableName{}
	var pgInfoRequest = vo.DatabaseInfoRequest{}

	err := ctx.ShouldBindBodyWith(&dbName, binding.JSON)
	if err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	err = ctx.ShouldBindBodyWith(&pgInfoRequest, binding.JSON)

	if err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, data := service.GetPGTableColumns(dbName.ModeName, dbName.TableName, &pgInfoRequest)

	if flag {
		response.Api_Success(ctx, data, "查询成功", time.Now())
		return
	}
	response.Api_Fail(ctx, "查询失败", time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_READ_FAILED, time.Now())
}

func GetPGTableData(ctx *gin.Context) {
	var dbName = vo.TableSqlPG{}
	var pgInfoRequest = vo.DatabaseInfoRequest{}

	err := ctx.ShouldBindBodyWith(&dbName, binding.JSON)

	if err != nil {
		// response.Fail(ctx, "数据验证错误", nil)
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	err = ctx.ShouldBindBodyWith(&pgInfoRequest, binding.JSON)

	if err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	flag, msg, data := service.GetPGTableData(dbName.DbOrModeName, dbName.TableName, dbName.SQL, &pgInfoRequest)

	if flag {
		response.Api_Success(ctx, data, "查询成功", time.Now())
		return
	}
	response.Api_Fail(ctx, msg, time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_READ_FAILED, time.Now())

}

func Validate(ctx *gin.Context) {
	re_express := vo.ValidateRegexp{}
	if err := ctx.ShouldBind(&re_express); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, msg := service.Validate(&re_express)

	if flag {
		response.Api_Success(ctx, flag, msg, time.Now())
		return
	}
	// response.Api_Fail(ctx, msg, time.Now())
	response.Api_Code_Fail(ctx, response.CHECK_FAILED, time.Now())
}

func DataDisplay(ctx *gin.Context) {
	// 定义Yaml类型变量并绑定前端传递的数据
	yaml := vo.Yaml{}
	if err := ctx.ShouldBind(&yaml); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, data := service.ReturnData(&yaml)
	if flag {
		response.Api_Success(ctx, data, "查询成功", time.Now())
		return
	}
	// response.Api_Fail(ctx, data, time.Now())
	response.Api_Code_Fail(ctx, response.OPERATION_FAILED, time.Now())
}

func PortCheck(ctx *gin.Context) {
	// 定义Port类型变量并绑定前端传递的数据
	port := vo.Port{}
	if err := ctx.ShouldBind(&port); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, code, msg := service.ExistPort(&port)
	if flag {
		response.Api_Success(ctx, flag, msg, time.Now())
		return
	}
	// response.Api_Fail(ctx, msg, time.Now())
	response.Api_Code_Fail(ctx, code, time.Now())
}

// ********************文件系统****************
func LoadHandler(ctx *gin.Context) {
	file, err := ctx.FormFile("file")
	if err != nil {
		// response.Api_Fail(ctx, "获取上传文件失败", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	namespace := ctx.PostForm("namespace")
	dst, msg, flag := service.FileUpload(ctx, file, namespace)

	if flag {
		response.Api_Success(ctx, dst, msg, time.Now())
		return
	}
	response.Api_Fail(ctx, msg, time.Now())
	// response.Api_Code_Fail(ctx, response.OPERATION_FAILED, time.Now())
}

func SftpConnectionHandler(ctx *gin.Context) {
	msg, flag := service.SftpConnection(ctx)

	if flag {
		response.Api_Success(ctx, flag, msg, time.Now())
		return
	}
	// response.Api_Fail(ctx, msg, time.Now())
	response.Api_Code_Fail(ctx, response.OPERATION_FAILED, time.Now())
}

func GetSftpFiles(ctx *gin.Context) {
	var sftpPath vo.SftpPath

	err := ctx.ShouldBindJSON(&sftpPath)
	if err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	msg, res, flag := service.GetSftpFile(&sftpPath)

	if flag {
		response.Api_Success(ctx, res, msg, time.Now())
		return
	}
	// response.Api_Fail(ctx, msg, time.Now())
	response.Api_Code_Fail(ctx, response.GET_INFO_FAILED, time.Now())
}

func SftpReadFileHandler(ctx *gin.Context) {
	var csvTxtInfo vo.CsvTxtInfo

	if err := ctx.ShouldBindJSON(&csvTxtInfo); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	msg, flag, res := service.SftpReadFile(&csvTxtInfo)

	if flag {
		response.Api_Success(ctx, res, msg, time.Now())
		return
	}
	response.Api_Fail(ctx, msg, time.Now())
	// response.Api_Code_Fail(ctx, response.OPERATION_FAILED, time.Now())
}

func GetDataHandler(ctx *gin.Context) {
	var csvTxtInfo vo.CsvTxtInfo

	if err := ctx.ShouldBindJSON(&csvTxtInfo); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	msg, flag, res := service.GetLoadData(&csvTxtInfo)

	if flag {
		response.Api_Success(ctx, res, msg, time.Now())
		return
	}
	// response.Api_Fail(ctx, msg, time.Now())
	response.Api_Fail(ctx, msg, time.Now())
}

func SyncDBData(ctx *gin.Context) {
	dbinfo := vo.DBInfo{}
	if err := ctx.ShouldBind(&dbinfo); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	for i := range dbinfo.Tables {
		service.SyncPTOPTable(dbinfo, dbinfo.Tables[i])
	}

	for i := range dbinfo.Views {
		service.SyncPTOPView(dbinfo, dbinfo.Views[i])
	}

	response.Api_Success(ctx, "flag", "同步成功", time.Now())
}
