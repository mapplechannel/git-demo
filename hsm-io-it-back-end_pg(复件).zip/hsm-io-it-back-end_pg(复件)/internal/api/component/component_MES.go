package component

import (
	"hsm-io-it-back-end/internal/service"
	"hsm-io-it-back-end/internal/vo"
	"hsm-io-it-back-end/response"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/gin-gonic/gin/binding"
)

func ConnectMySqlTest_MES(ctx *gin.Context) {
	var mysqlInfoRequest = vo.DatabaseInfoRequest{}

	err := ctx.ShouldBind(&mysqlInfoRequest)

	if err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	flag, msg := service.ConnectMysqlTest_MES(&mysqlInfoRequest)
	if flag {
		response.Api_Success(ctx, flag, msg, time.Now())
		return
	}
	response.Api_Fail(ctx, msg, time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_CONNECT_FAILED, time.Now())
}

// @Tag 添加数据库连接信息
func AddConenctMySql_MES(ctx *gin.Context) {
	var mysqlInfoRequest = vo.DatabaseInfoRequest{}

	err := ctx.ShouldBindBodyWith(&mysqlInfoRequest, binding.JSON)

	if err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	
	flag, msg := service.AddConenctMySql_MES(&mysqlInfoRequest)
	if flag {
		response.Api_Success(ctx, flag, msg, time.Now())
		return
	}
	response.Api_Fail(ctx, msg, time.Now())
	// response.Api_Code_Fail(ctx, response.OPERATION_FAILED, time.Now())
}

// @Tag 连接数据库
func GetConenctMySql_MES(ctx *gin.Context) {
	var mysqlInfo = vo.DatabaseInfoRequest{}
	if err := ctx.ShouldBind(&mysqlInfo); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, data := service.GetConenctMySql_MES(&mysqlInfo)
	if flag {
		response.Api_Success(ctx, data, "连接成功", time.Now())
		return
	}
	response.Api_Fail(ctx, "查询失败", time.Now())
	// response.Api_Code_Fail(ctx, response.GET_INFO_FAILED, time.Now())
}

// @Tag 获取数据库连接信息
func GetConnectList_MES(ctx *gin.Context) {

	var mysqlListInfo = vo.DatabaseInfoRequest{}
	if err := ctx.ShouldBind(&mysqlListInfo); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, data := service.GetConnectInfo_MES(&mysqlListInfo)
	if flag {
		response.Api_Success(ctx, data, "连接成功", time.Now())
		return
	}
	response.Api_Fail(ctx, "连接失败", time.Now())
	// response.Api_Code_Fail(ctx, response.GET_INFO_FAILED, time.Now())

}

// @Tag 获取数据库表列表
func GetTable_MES(ctx *gin.Context) {
	var mysqlListInfo = vo.DatabaseInfoRequest{}
	if err := ctx.ShouldBind(&mysqlListInfo); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	flag, data := service.GetTable_MES(&mysqlListInfo)
	if flag {
		response.Api_Success(ctx, data, "查询成功", time.Now())
		return
	}
	response.Api_Fail(ctx, "查询失败", time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_READ_FAILED, time.Now())
}

// @Tag 获取数据库表主键
func GetTablePrimary_MES(ctx *gin.Context) {
	var mysqlListInfo = vo.DatabaseInfoRequest{}
	if err := ctx.ShouldBind(&mysqlListInfo); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	flag, data := service.GetTablePrimary_MES(&mysqlListInfo)
	if flag {
		response.Api_Success(ctx, data, "查询成功", time.Now())
		return
	}
	response.Api_Fail(ctx, "查询失败", time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_READ_FAILED, time.Now())
}

// @Tag 获取字段列表
func GetTableColumns_MES(ctx *gin.Context) {
	var mysqlListInfo = vo.DatabaseInfoRequest{}
	if err := ctx.ShouldBind(&mysqlListInfo); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	flag, data := service.GetTableColumns_MES(&mysqlListInfo)
	if flag {
		response.Api_Success(ctx, data, "查询成功", time.Now())
		return
	}
	response.Api_Fail(ctx, "查询失败", time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_READ_FAILED, time.Now())
}

// @Tag 获取字段列表
func GetData_MES(ctx *gin.Context) {
	var mysqlListInfo = vo.DatabaseInfoRequest{}
	if err := ctx.ShouldBind(&mysqlListInfo); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	flag, data, msg := service.GetTableData_MES(&mysqlListInfo)
	if flag {
		response.Api_Success(ctx, data, msg, time.Now())
		return
	}
	response.Api_Fail(ctx, msg, time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_READ_FAILED, time.Now())
}

// @Tag 修改数据库连接信息
func UpdateConnect_MES(ctx *gin.Context) {
	var updateMysqlInfo = vo.DatabaseInfoRequest{}

	err := ctx.ShouldBindBodyWith(&updateMysqlInfo, binding.JSON)

	if err != nil {
		// response.Fail(ctx, "数据验证错误", nil)
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	flag, msg := service.UpdateConnect_MES(&updateMysqlInfo)
	if flag {
		response.Api_Success(ctx, flag, msg, time.Now())
		return
	}
	response.Api_Fail(ctx, msg, time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_UPDATE_FAILED, time.Now())
}
