package component

import (
	"hsm-io-it-back-end/internal/service"
	"hsm-io-it-back-end/internal/vo"
	"hsm-io-it-back-end/response"
	"time"

	_ "github.com/denisenkom/go-mssqldb"
	"github.com/gin-gonic/gin"
)

func ConnectSqlSerTest(ctx *gin.Context) {
	var pgInfoRequest = vo.DatabaseInfoRequest{}
	if err := ctx.ShouldBind(&pgInfoRequest); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, msg := service.ConnectSqlSerTest(&pgInfoRequest)

	if flag {
		response.Api_Success(ctx, flag, msg, time.Now())
		return
	}
	response.Api_Fail(ctx, msg, time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_CONNECT_FAILED, time.Now())
}

func AddConnectSqlSer(ctx *gin.Context) {
	var pgInfoRequest = vo.DatabaseInfoRequest{}
	if err := ctx.ShouldBind(&pgInfoRequest); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, msg := service.AddConnectSqlSer(&pgInfoRequest)

	if flag {
		response.Api_Success(ctx, flag, msg, time.Now())
		return
	}
	response.Api_Fail(ctx, msg, time.Now())
	// response.Api_Code_Fail(ctx, response.OPERATION_FAILED, time.Now())
}

func UpdateConnectSqlSer(ctx *gin.Context) {
	var updatePGInfo = vo.DatabaseInfoRequest{}
	if err := ctx.ShouldBind(&updatePGInfo); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, msg := service.UpdateConnectSqlSer(&updatePGInfo)

	if flag {
		response.Api_Success(ctx, flag, msg, time.Now())
		return
	}
	response.Api_Fail(ctx, msg, time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_UPDATE_FAILED, time.Now())
}

func GetSqlSerDataBaseConnectList(ctx *gin.Context) {
	var dataBaseInfoReq = vo.DatabaseInfoRequest{}
	if err := ctx.ShouldBind(&dataBaseInfoReq); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, data := service.GetSqlSerDataBaseConnectList(&dataBaseInfoReq)

	if flag {
		response.Api_Success(ctx, data, "查询成功", time.Now())
		return
	}
	response.Api_Fail(ctx, "查询失败", time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_READ_FAILED, time.Now())
}

func GetSqlSerTableList(ctx *gin.Context) {
	var sqlSerInfoRequest = vo.DatabaseInfoRequest{}
	if err := ctx.ShouldBind(&sqlSerInfoRequest); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, data := service.GetSqlSerTableList(&sqlSerInfoRequest)

	if flag {
		response.Api_Success(ctx, data, "查询成功", time.Now())
		return
	}
	response.Api_Fail(ctx, "查询失败", time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_READ_FAILED, time.Now())
}

func GetSqlSerTablesPrimary(ctx *gin.Context) {
	var sqlSerInfoRequest = vo.DatabaseInfoRequest{}

	err := ctx.ShouldBind(&sqlSerInfoRequest)

	if err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	flag, data := service.GetSqlSerTablesPrimary(&sqlSerInfoRequest)

	if flag {
		response.Api_Success(ctx, data, "查询成功", time.Now())
		return
	}
	response.Api_Fail(ctx, "查询失败", time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_READ_FAILED, time.Now())
}

func GetSqlSerTableColumns(ctx *gin.Context) {
	var sqlSerInfoRequest = vo.DatabaseInfoRequest{}

	err := ctx.ShouldBind(&sqlSerInfoRequest)

	if err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	flag, data := service.GetSqlSerTableColumns(&sqlSerInfoRequest)

	if flag {
		response.Api_Success(ctx, data, "查询成功", time.Now())
		return
	}
	response.Api_Fail(ctx, "查询失败", time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_READ_FAILED, time.Now())
}

func GetSqlSerTableData(ctx *gin.Context) {
	var sqlSerInfoRequest = vo.DatabaseInfoRequest{}

	err := ctx.ShouldBind(&sqlSerInfoRequest)

	if err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	flag, data,msg := service.GetSqlSerTableData(&sqlSerInfoRequest)

	if flag {
		response.Api_Success(ctx, data, "查询成功", time.Now())
		return
	}
	response.Api_Fail(ctx, msg, time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_READ_FAILED, time.Now())
}

func GetDataBaseConnectList(ctx *gin.Context) {

	var mysqlListInfo = vo.DatabaseInfoRequest{}
	if err := ctx.ShouldBind(&mysqlListInfo); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, data := service.GetDataBaseConnectList(&mysqlListInfo)

	if flag {
		response.Api_Success(ctx, data, "连接成功", time.Now())
		return
	}
	// response.Api_Fail(ctx, "连接失败", time.Now())
	response.Api_Code_Fail(ctx, response.DATABASE_CONNECT_FAILED, time.Now())
}
