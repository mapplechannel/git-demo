package component

import (
	"hsm-io-it-back-end/internal/service"
	"hsm-io-it-back-end/internal/vo"
	"hsm-io-it-back-end/response"
	"time"

	"github.com/gin-gonic/gin"
)

func ConnectSqliteTest(ctx *gin.Context) {
	var sqliteInfoReq = vo.DatabaseInfoRequest{}
	if err := ctx.ShouldBind(&sqliteInfoReq); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, msg := service.ConnectSqliteTest(&sqliteInfoReq)

	if flag {
		response.Api_Success(ctx, flag, msg, time.Now())
		return
	}
	response.Api_Fail(ctx, msg, time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_CONNECT_FAILED, time.Now())
}

func AddConnectSqlite(ctx *gin.Context) {
	var sqliteInfo = vo.DatabaseInfoRequest{}
	if err := ctx.ShouldBind(&sqliteInfo); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, msg := service.AddConnectSqlite(&sqliteInfo)

	if flag {
		response.Api_Success(ctx, flag, msg, time.Now())
		return
	}
	response.Api_Fail(ctx, msg, time.Now())
	// response.Api_Code_Fail(ctx, response.OPERATION_FAILED, time.Now())
}

func UpdateConnectSqlite(ctx *gin.Context) {
	var updateSQLiteInfo = vo.DatabaseInfoRequest{}
	if err := ctx.ShouldBind(&updateSQLiteInfo); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, msg := service.UpdateConnectSqlite(&updateSQLiteInfo)

	if flag {
		response.Api_Success(ctx, flag, msg, time.Now())
		return
	}
	response.Api_Fail(ctx, msg, time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_UPDATE_FAILED, time.Now())
}

func GetSqliteDataBaseConnectList(ctx *gin.Context) {
	var dataBaseInfoReq = vo.DatabaseInfoRequest{}
	if err := ctx.ShouldBind(&dataBaseInfoReq); err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}
	flag, data := service.GetSqliteDataBaseConnectList(&dataBaseInfoReq)

	if flag {
		response.Api_Success(ctx, data, "查询成功", time.Now())
		return
	}
	response.Api_Fail(ctx, "查询失败", time.Now())
	// response.Api_Code_Fail(ctx, response.GET_INFO_FAILED, time.Now())
}

func GetSqliteTableList(ctx *gin.Context) {
	var dataBaseInfoReq = vo.DatabaseInfoRequest{}
	err := ctx.ShouldBind(&dataBaseInfoReq)

	if err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	flag, data := service.GetSqliteTableList(&dataBaseInfoReq)

	if flag {
		response.Api_Success(ctx, data, "查询成功", time.Now())
		return
	}
	response.Api_Fail(ctx, "查询失败", time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_READ_FAILED, time.Now())
}

func GetSqliteTablesPrimary(ctx *gin.Context) {
	var dataBaseInfoReq = vo.DatabaseInfoRequest{}
	err := ctx.ShouldBind(&dataBaseInfoReq)

	if err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	flag, data := service.GetSqliteTablesPrimary(&dataBaseInfoReq)

	if flag {
		response.Api_Success(ctx, data, "查询成功", time.Now())
		return
	}
	response.Api_Fail(ctx, "查询失败", time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_READ_FAILED, time.Now())
}

func GetSqliteTableColumns(ctx *gin.Context) {
	var dataBaseInfoReq = vo.DatabaseInfoRequest{}
	err := ctx.ShouldBind(&dataBaseInfoReq)

	if err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	flag, data := service.GetSqliteTableColumns(&dataBaseInfoReq)

	if flag {
		response.Api_Success(ctx, data, "查询成功", time.Now())
		return
	}
	response.Api_Fail(ctx, "查询失败", time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_READ_FAILED, time.Now())
}

func GetSqliteTableData(ctx *gin.Context) {
	var dataBaseInfoReq = vo.DatabaseInfoRequest{}
	err := ctx.ShouldBind(&dataBaseInfoReq)

	if err != nil {
		// response.Api_Fail(ctx, "数据验证错误", time.Now())
		response.Api_Code_Fail(ctx, response.REQUEST_PARAM_INVALID, time.Now())
		return
	}

	flag, data,msg := service.GetSqliteTableData(&dataBaseInfoReq)

	if flag {
		response.Api_Success(ctx, data, "查询成功", time.Now())
		return
	}
	response.Api_Fail(ctx, msg, time.Now())
	// response.Api_Code_Fail(ctx, response.DATABASE_READ_FAILED, time.Now())
}
