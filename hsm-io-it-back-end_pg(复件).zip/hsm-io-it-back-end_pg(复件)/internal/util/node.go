package util

import (
	"bytes"
	"encoding/json"
	"fmt"
	"hsm-io-it-back-end/config"
	"hsm-io-it-back-end/internal/constants"
	"hsm-io-it-back-end/pkg/logger"
	"hsm-io-it-back-end/public/nodeapp"
	"io/ioutil"
	"net/http"
	"path/filepath"
	"time"

	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

var ServerCode string
var MasterIp string
var IsExistSchedule bool
var IsAuth bool
var NodeLenth int
var GlobalGormDb *gorm.DB

var IsMaster bool
var MasterNode string
var BackupNode string
var BackupOrMasterIp string

func GetNodeServer() []string {

	currPath := constants.HSM_OS_ROOT
	path := filepath.Join(currPath, constants.NodeManifest)
	var entity nodeapp.NodeConfig
	err := nodeapp.ParseNodeConfig(path, &entity)

	if err != nil {
		fmt.Println(err)
		return nil
	}
	var res []string

	var index int
	nodeLenthlen := len(entity.Nodes)
	NodeLenth = nodeLenthlen
	// logger.Info("node节点长度，%v", nodeLenthlen)

	currentNode := entity.CurrentNode

	for i, node := range entity.Nodes {
		if node.Code == currentNode {
			index = i
		}
	}

	for _, node := range entity.Nodes {
		if node.Code == "e1" {
			MasterIp = node.Ip1
		}
	}

	for _, node := range entity.Nodes {
		for _, ser := range node.Services {
			if ser.Info.Id == constants.Scheduling {
				IsExistSchedule = true
			}
			if ser.Info.Id == constants.Auth {
				IsAuth = true
			}
		}
	}

	ip := entity.Nodes[index].Ip1
	masterNode := entity.Nodes[index].MasterNodes
	if masterNode == nil {
		// 表明是主机
		IsMaster = true
		for i, node := range entity.Nodes {
			if node.MasterNodes != nil {
				if node.MasterNodes[0] == currentNode {
					BackupNode = entity.Nodes[i].Code
					BackupOrMasterIp = entity.Nodes[i].Ip1
					logger.Info("BackupNode:%v,BackupOrMasterIp is:%v", BackupNode, BackupOrMasterIp)
				}
			}
		}
	} else {
		// 表明是从机
		for i, node := range entity.Nodes {
			if node.Code == masterNode[0] {
				MasterNode = masterNode[0]
				BackupOrMasterIp = entity.Nodes[i].Ip1
			}
		}
	}

	code := entity.Nodes[index].Code
	name := "数据服务器"
	// nodeName = name
	res = append(res, ip, code, name)
	// logger.Info("res:%v", res)
	ServerCode = currentNode
	return res
}

func CreateGormDb() error {
	dsn := config.ConfigAll.Postgres.Url + " dbname=" + config.ConfigAll.Postgres.DbName
	// logger.Info("Pg connect dsn:%v", dsn)
	db, err := gorm.Open(postgres.Open(dsn), &gorm.Config{})
	if err != nil {
		logger.Info("Pg connect failed:%v", err)
	}
	GlobalGormDb = db
	return nil
}

// 订阅功能
func Sub() {
	type webhook struct {
		MaxRetryTimes int    `json:"maxRetryTimes"`
		Url           string `json:"url"`
		Headers       string `json:"headers"`
		Params        string `json:"params"`
		Method        string `json:"method"`
		Timeout       int    `json:"timeout"`
		CallBackType  string `json:"callBackType"`
	}

	type subReq struct {
		AppId   string  `json:"appId"`
		AppName string  `json:"appName"`
		Topic   string  `json:"topic"`
		Webhook webhook `json:"webhook"`
	}

	if ServerCode == "e1" {
		ip := ServerCode + constants.DomainName

		request := subReq{
			AppId:   "hsm-io-it",
			AppName: "信息系统集成",
			Topic:   "search",
			Webhook: webhook{
				Url:    constants.Http + ip + ":6120/api/hsm-io-it/job/search",
				Params: "{\"rule\":${rule},\"namespace\":\"${projectId}\",\"content\":\"${keyword}\",\"sessionId\":\"${sessionId}\"}",
				Method: "POST",
			},
		}

		requestBody, err := json.Marshal(request)
		if err != nil {
			logger.Info("请求体解析错误:%v", err)
		}

		req, err := http.NewRequest("POST", constants.Http+ip+":7082/hsm-eng/v1/sub", bytes.NewBuffer(requestBody))
		if err != nil {
			logger.Info("Fail to send request")
		}

		req.Header.Set("Content-Type", "application/json")
		client := &http.Client{Timeout: 60 * time.Second}
		resp, err := client.Do(req)
		if err != nil {
			logger.Info("Fail to do request")
		}
		defer resp.Body.Close()
		if resp.StatusCode != http.StatusOK {
			logger.Info("Executor returned non-OK")
		} else {
			body, _ := ioutil.ReadAll(resp.Body)
			logger.Info("body:%v", string(body))
		}
	}

}
