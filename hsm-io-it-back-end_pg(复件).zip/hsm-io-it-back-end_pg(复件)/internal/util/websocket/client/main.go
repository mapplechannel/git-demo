package main

import (
	"fmt"
	"log"
	"net/url"
	"os"
	"os/signal"
	"time"

	"github.com/gorilla/websocket"
)

type LogMessage struct {
	Message string `json:"message"`
}

func main() {
	interrupt := make(chan os.Signal, 1)
	signal.Notify(interrupt, os.Interrupt)

	u := url.URL{Scheme: "ws", Host: "localhost:8081", Path: "/ws"}
	log.Printf("connecting to %s", u.String())

	c, _, err := websocket.DefaultDialer.Dial(u.String(), nil)
	if err != nil {
		log.Fatal("dial: ", err)
	}
	defer c.Close()

	done := make(chan struct{})
	ticker := time.NewTicker(time.Second)
	defer ticker.Stop()

	go func() {
		for {
			select {
			case <-done:
				return
			case t := <-ticker.C:
				msg := LogMessage{}
				err = c.ReadJSON(&msg)
				if err != nil {
					log.Println(err)
					close(done)
					return
				}
				fmt.Printf("[%v] %s\n", t.Format("2006-01-02 15:04:05"), msg.Message)
			}
		}
	}()

	for {
		select {
		case <-interrupt:
			fmt.Println("interrupt")
			close(done)
			return
		}
	}

}
