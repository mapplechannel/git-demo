package util

import (
	"hsm-io-it-back-end/internal/service/run"
	"hsm-io-it-back-end/pkg/logger"
	"sync"
	"time"
)

var JobQuene SyncQueue

type SyncQueue struct {
	items []ExecuteInfo
	size  int
	mu    sync.Mutex
}

type ExecuteInfo struct {
	Code        string `json:"code"`
	BenthosYaml string `json:"benthos_yaml"`
}

func NewSyncQueue(s int) SyncQueue {
	logger.Info("gggggg")
	return SyncQueue{size: s}
}

func (q *SyncQueue) Add(item ExecuteInfo) {
	q.mu.Lock()
	defer q.mu.Unlock()
	logger.Info("ffff")
	if len(q.items) == q.size {
		return
	}
	q.items = append(q.items, item)
}

func (q *SyncQueue) Poll() (ExecuteInfo, bool) {
	q.mu.Lock()
	defer q.mu.Unlock()
	if len(q.items) == 0 {
		return ExecuteInfo{}, false
	}
	item := q.items[0]
	q.items = q.items[1:]
	return item, true
}

func (q *SyncQueue) IsEmpty() bool {
	q.mu.Lock()
	defer q.mu.Unlock()
	return len(q.items) == 0
}

func (q *SyncQueue) Size() int {
	q.mu.Lock()
	defer q.mu.Unlock()
	return len(q.items)
}

func ProcessJobQuene(q *SyncQueue) {
	for {
		// q.mu.Lock()
		if !q.IsEmpty() {
			executeInfo, _ := q.Poll()
			// q.mu.Unlock()
			go run.ExecuteJob(executeInfo.Code, executeInfo.BenthosYaml)
			time.Sleep(15 * time.Second)
			run.Stop_corn(executeInfo.Code)
		} else {
			// q.mu.Unlock()
			time.Sleep(1 * time.Second)
		}
	}
}
