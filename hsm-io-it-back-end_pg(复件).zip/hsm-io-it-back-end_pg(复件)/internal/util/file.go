package util

import (
	"archive/zip"
	"bufio"
	"database/sql"
	"encoding/json"
	"fmt"
	"hsm-io-it-back-end/config"
	"hsm-io-it-back-end/internal/constants"
	"hsm-io-it-back-end/internal/vo"
	"hsm-io-it-back-end/pkg/logger"
	"io"
	"io/ioutil"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

// 建立pg库连接
func GetPgConn() (*sql.DB, error) {
	dsn := config.ConfigAll.Postgres.Url + " dbname=" + config.ConfigAll.Postgres.DbName

	db, err := sql.Open("postgres", dsn)
	if err != nil {
		return nil, err
	}
	return db, nil
}

type Codes struct {
	json.Encoder
}

func GetJobCodes(namespace string) []string {
	var codes []string
	err := GlobalGormDb.Raw("SELECT code FROM ioit.job_info WHERE namespace = ? AND is_auto_select_id = ?", namespace, false).Scan(&codes).Error
	if err != nil {
		logger.Info("err is %v", err)
	}
	return codes
}

// 获取作业
func GetJobDetailsInfo(namespace, code, skNode string) *vo.CreateJobRequest {
	var jobInfo vo.CreateJobRequest

	err := GlobalGormDb.Table("ioit.job_info").Where("namespace = ? AND code = ?", namespace, code).First(&jobInfo).Error

	if err != nil {
		logger.Info("查询作业失败%v", err)
	}

	jobInfo.NameSpace = namespace
	jobInfo.Code = code

	return &jobInfo
}

// 判断作业状态
func GetJobStatus(db *sql.DB, namespace, code, skNode string) bool {
	query := `SELECT status FROM ioit.job_info WHERE namespace = $1 AND code = $2`

	var status int

	err := db.QueryRow(query, namespace, code).Scan(&status)

	if err != nil {
		logger.Info("查询作业状态失败%v", err)
	}

	return status == 0
}

func FindStautsAndStop() []vo.JobKeyInfo {
	var jobInfos []vo.CreateJobRequest
	if err := GlobalGormDb.Table("ioit.job_info").Where("is_auto_select_id = ?", false).Where("status = ?", 1).Where("namespace = ?", constants.PORTALNAME).Find(&jobInfos).Error; err != nil {
		logger.Info("find status 1 err:%v", err)
	}

	var keyinfo []vo.JobKeyInfo
	for _, key := range jobInfos {
		info := vo.JobKeyInfo{
			NameSpace: key.NameSpace,
			Code:      key.Code,
			SKNode:    key.SKNode,
		}
		keyinfo = append(keyinfo, info)
	}
	logger.Info("keyinfo is :%v", keyinfo)
	return keyinfo
}

// 修改作业状态
func UpdateJobStatus(db *sql.DB, namespace, code, skNode string, status int) {
	updatesql := `UPDATE ioit.job_info SET status=$1 WHERE namespace = $2 AND code = $3`

	_, err := db.Exec(updatesql, status)
	if err == nil {
		logger.Info("更新状态成功：%s", code)

	} else {
		logger.Info("数据库更新失败:%v", err)
	}
}

// 更新作业
func UpdateJob(jobRequest *vo.CreateJobRequest) (bool, string, *vo.CreateJobRequest) {

	code := jobRequest.Code
	editeTime := time.Now().Format("2006-01-02 15:04:05")

	content, errs := json.Marshal(jobRequest.Content)
	if errs != nil {
		fmt.Println("json marshal error:", errs)
	}

	canvas, errs := json.Marshal(jobRequest.Canvas)
	if errs != nil {
		fmt.Println("json marshal error:", errs)
	}

	db, err := GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, "数据库连接失败", nil
	}
	defer db.Close()

	updatesql := `UPDATE ioit.job_info 
					SET 
						create_user=$1,		name=$2,				describe=$3,
						schedule=$4,		schedule_details=$5,	schedule_cycle=$6,
						schedule_unit=$7,	content=$8,				cron_id=$9,
						is_http=$10,		canvas=$11,				job_type=$12,
						template=$13,		id=$14,					status=$15,
						edite_time=$16,		is_auto_select_id=$17,  job_class=$18, s_node=$19
					WHERE namespace = $20 AND code = $21`

	_, err = db.Exec(updatesql,
		jobRequest.CreateUse, jobRequest.Name, jobRequest.Describe, jobRequest.Schedule,
		jobRequest.ScheduleDetails, jobRequest.ScheduleCycle, jobRequest.ScheduleUnit,
		content, jobRequest.CronId, jobRequest.IsHttp, canvas, jobRequest.JobType,
		jobRequest.Template, code, jobRequest.Status, editeTime, true, jobRequest.JobClass,
		ServerCode, jobRequest.NameSpace, jobRequest.Code,
	)

	if err == nil {
		logger.Info("更新作业成功：%s", code)
		return true, "更新成功", jobRequest
	} else {
		logger.Info("数据库更新失败:%v", err)
		return false, "保存失败", nil
	}
}

// 判断连接信息是否存在
func IsExistDatabase(connectname, namespace, currentType string) bool {
	db, err := GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
	}
	defer db.Close()

	var exists bool
	query := `SELECT EXISTS ( SELECT 1 FROM ioit.database_info WHERE connectname = $1 AND namespace = $2 AND databasetype != $3 AND databasetype = $4)`

	err = db.QueryRow(query, connectname, namespace, "EMySQL", currentType).Scan(&exists)
	if err != nil {
		logger.Info("数据库查询失败%v", err)
	}
	logger.Info("存在同名数据源校验:%v", exists)
	return exists
}

func IsUpdateExistDatabase(connectname, namespace, currentType, code string) bool {
	db, err := GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
	}
	defer db.Close()

	var exists bool
	query := `SELECT EXISTS ( SELECT 1 FROM ioit.database_info WHERE connectname = $1 AND namespace = $2 AND databasetype != $3 AND databasetype = $4 AND code != $5)`

	err = db.QueryRow(query, connectname, namespace, "EMySQL", currentType, code).Scan(&exists)
	if err != nil {
		logger.Info("数据库查询失败%v", err)
	}
	logger.Info("存在同名数据源校验:%v", exists)
	return exists
}

func IsEExistDatabase(connectname, namespace string) bool {
	db, err := GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
	}
	defer db.Close()

	var exists bool
	query := `SELECT EXISTS ( SELECT 1 FROM ioit.database_info WHERE connectname = $1 AND namespace = $2 AND databasetype = $3)`

	err = db.QueryRow(query, connectname, namespace, "EMySQL").Scan(&exists)
	if err != nil {
		logger.Info("数据库查询失败%v", err)
	}
	return exists
}

func IsUpdateEExistDatabase(connectname, namespace, code string) bool {
	db, err := GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
	}
	defer db.Close()

	var exists bool
	query := `SELECT EXISTS ( SELECT 1 FROM ioit.database_info WHERE connectname = $1 AND namespace = $2 AND databasetype = $3 AND code != $4)`

	err = db.QueryRow(query, connectname, namespace, "EMySQL", code).Scan(&exists)
	if err != nil {
		logger.Info("数据库查询失败%v", err)
	}
	return exists
}

// 获取连接信息
func GetDatabaseInfo(namespace, code, databasetype string) *vo.DatabaseInfoRequest {
	var databaseInfo vo.DatabaseInfoRequest

	err := GlobalGormDb.Table("ioit.database_info").Where("namespace = ? AND code = ? AND databasetype = ?", namespace, code, databasetype).First(&databaseInfo).Error

	if err != nil {
		logger.Info("查询连接信息失败%v", err)
	}

	return &databaseInfo
}

// 删除
func DeleteOriData(tableName, namespace, skNode, code string) {
	db, err := GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
	}
	defer db.Close()

	deleteJobQuery := fmt.Sprintf("DELETE FROM ioit.%s WHERE namespace = $1 AND code = $2", tableName)

	logger.Info("deleteJobQuery:%v", deleteJobQuery)
	_, err = db.Exec(deleteJobQuery, namespace, code)
	if err != nil {
		logger.Info("删除数据失败:%v", err)
	}
	logger.Info("删除数据成功")
}

// 插入
func InsertData(namespaceOfFront string, jobsImport *vo.CreateJobRequest, content, canvas, cron, period []byte) {
	db, err := GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
	}
	defer db.Close()

	addsql := `INSERT INTO ioit.job_info (
		namespace,		create_user,		s_node,
		code,			name,				describe,
		schedule,		schedule_details,	schedule_cycle,
		schedule_unit,	content,			cron_id,
		is_http,		canvas,				job_type,
		template,		id,					status,
		create_time,	edite_time,			is_auto_select_id, 
		job_class,      cron_detail,        period_detail) 
	VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24)`

	_, err = db.Exec(addsql,
		namespaceOfFront, jobsImport.CreateUse, jobsImport.SKNode, jobsImport.Code, jobsImport.Name,
		jobsImport.Describe, jobsImport.Schedule, jobsImport.ScheduleDetails, jobsImport.ScheduleCycle,
		jobsImport.ScheduleUnit, content, jobsImport.CronId, jobsImport.IsHttp, canvas, jobsImport.JobType,
		jobsImport.Template, jobsImport.Id, jobsImport.Status, jobsImport.CreateTime, jobsImport.EditeTime,
		jobsImport.IsAutoSelectId, jobsImport.JobClass, cron, period,
	)

	if err != nil {
		logger.Info("数据库操作失败：%v", err)
	}

}

func InsertDBData(namespaceOfFront string, v *vo.DatabaseInfoRequest) {
	db, err := GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
	}
	defer db.Close()

	updatedbsql := `INSERT INTO ioit.database_info (code, connectname, username, password, host, 
		port, namespace, databasetype, dbname, schemaname, tablename, dbpath, s_node,retry)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)`

	_, err = db.Exec(updatedbsql,
		v.Code, v.ConnectName, v.Username, v.Password, v.Host, v.Port, namespaceOfFront,
		v.DataBaseType, v.DbName, v.SchemaName, v.Tablename, v.DbPath, ServerCode,v.Retry,
	)
	if err != nil {
		logger.Info("数据库操作失败：%v", err)
	}
}

// 读取文件数据
func ReadFile(path string) (data string) {
	//打开文件
	open, err := os.Open(path)
	if err != nil {
		logger.Error("打开文件失败 %s", err.Error())
	}
	defer open.Close()
	file, err := ioutil.ReadAll(open)
	if err != nil {
		return
	}
	return string(file)
}

func ReadFileV2(path string) (error, string) {
	//打开文件
	open, err := os.Open(path)
	if err != nil {
		logger.Error("打开文件失败 %s", err.Error())
		return fmt.Errorf("打开文件失败 %s", err.Error()), ""
	}
	defer open.Close()
	file, err := ioutil.ReadAll(open)
	if err != nil {
		return fmt.Errorf("读取文件失败 %s", err.Error()), ""
	}
	return nil, string(file)
}

// 读取最后一行文件数据
func ReadLineRawFile(path string) (data string) {
	//打开文件
	file, err := os.Open(path)
	if err != nil {
		// fmt.Printf("打开文件失败 %s", err.Error())
	}
	defer file.Close()
	//创建一个Scanner对象
	scanner := bufio.NewScanner(file)

	var lastLine string
	for scanner.Scan() {
		lastLine = scanner.Text()

	}

	if err := scanner.Err(); err != nil {
		fmt.Println(err.Error())
		return
	}
	return lastLine
}

func WriteFile(filePath, data string) bool {
	//写文件
	file, error := os.Create(filePath)
	if error != nil {
		fmt.Println(error)
		return false
	}
	defer file.Close()
	//写入byte的slice数据
	_, err := file.Write([]byte(data))
	if err != nil {
		log.Fatal(err)
		return false
	}
	// log.Printf("Wrote %d bytes.", bytesWritten)
	return true
}

// 创建文件
func CreateFile(path string) {
	_, err1 := os.Stat(path)
	logger.Info("创建文件：%v", path)
	if err1 != nil {
		file, error := os.Create(path)
		if error != nil {
			fmt.Println(error)
		}
		defer file.Close()
	}
}

// 创建文件目录
func CreateDir(path string) bool {
	_, err1 := os.Stat(path)
	//存在返回错误
	if err1 != nil {
		if os.IsNotExist(err1) {
			//文件夹不存在就创建
			logger.Info("数据文件不存在,正在创建文件目录: %s", path)
			return Mkdir(path)
		} else {
			return false
		}
	} else {
		return true
	}
}

func Mkdir(path string) bool {
	err := os.MkdirAll(path, os.ModePerm)
	if err != nil {
		// logger.Error("创建文件失败: %s" + err.Error())
		return false
	} else {
		return true
	}

}

// 判断目录文件是否存在
// 存在 true
// 不存在 false
func PathExists(path string) bool {
	_, err := os.Stat(path)
	return !os.IsNotExist(err)
}

func IsUtf8(data []byte) bool {
	// 遍历字节切片中的每个字节
	for i := 0; i < len(data); {
		// 如果字节的最高位为 0，说明是单字节字符，直接跳过
		if data[i]&0x80 == 0x00 {
			i++
			continue
		} else {
			// 否则，根据字节的最高位连续的 1 的个数，判断该字符占用的字节数
			num := preNUm(data[i])
			// 如果字节数大于 2，说明是多字节字符
			if num > 2 {
				// 跳过第一个字节
				i++
				// 遍历后面的 num - 1 个字节，判断是否都以 10 开头
				for j := 0; j < num-1; j++ {
					// 如果不是以 10 开头，说明不是 UTF-8 编码，返回 false
					if data[i]&0xc0 != 0x80 {
						return false
					}
					i++
				}
			} else {
				// 否则，说明不是 UTF-8 编码，返回 false
				return false
			}
		}
	}
	// 如果遍历完所有字节都没有发现不符合 UTF-8 编码规则的情况，返回 true
	return true
}

// preNUm 函数用来计算一个字节的最高位连续的 1 的个数
// 参数 data 为要计算的字节
// 返回值为一个整数，表示最高位连续的 1 的个数
func preNUm(data byte) int {
	// 将字节转换为二进制字符串
	str := fmt.Sprintf("%b", data)
	var i int = 0
	// 遍历字符串中的每一位，如果是 1 就计数，如果是 0 就停止
	for i < len(str) {
		if str[i] != '1' {
			break
		}
		i++
	}
	return i
}

func CompressFolderToZip(folderPath, zipPath string) error {
	// 创建一个新的ZIP文件
	zipFile, err := os.Create(zipPath)
	if err != nil {
		return err
	}
	defer zipFile.Close()

	// 创建一个Writer来写入ZIP文件
	zipWriter := zip.NewWriter(zipFile)
	defer zipWriter.Close()

	// 遍历文件夹
	err = filepath.Walk(folderPath, func(filePath string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		// 获取文件在文件夹中的相对路径
		relPath, err := filepath.Rel(folderPath, filePath)
		if err != nil {
			return err
		}

		// 如果是文件夹，则在ZIP文件中创建相应的文件夹
		if info.IsDir() {
			_, err = zipWriter.Create(relPath + "/")
			if err != nil {
				return err
			}
		} else {
			// 如果是文件，则将文件内容写入到ZIP文件中
			file, err := os.Open(filePath)
			if err != nil {
				return err
			}
			defer file.Close()

			// 创建一个在ZIP文件中的新文件
			zipFile, err := zipWriter.Create(relPath)
			if err != nil {
				return err
			}

			// 将文件内容复制到ZIP文件中的新文件中
			_, err = io.Copy(zipFile, file)
			if err != nil {
				return err
			}
		}
		return nil
	})

	if err != nil {
		return err
	}

	fmt.Println("文件夹压缩为ZIP成功：", zipPath)
	return nil
}

// 删除文件目录
func RemoveFolder(folderPath string) bool {
	err := os.RemoveAll(folderPath)
	if err != nil {
		logger.Error("删除文件失败：%v", folderPath)
		return false
	}
	return true
}

func CopyFile(src, destFolder string) {
	// 源文件路径
	// src := "/path/to/source/file.txt"

	// 目标文件夹路径
	// destFolder := "/path/to/destination/folder"

	// 打开源文件
	srcFile, err := os.Open(src)
	if err != nil {
		panic(err)
	}
	defer srcFile.Close()

	// 创建目标文件
	destFile, err := os.Create(destFolder)
	if err != nil {
		panic(err)
	}
	defer destFile.Close()

	// 复制文件内容
	_, err = io.Copy(destFile, srcFile)
	if err != nil {
		panic(err)
	}
}

func UnzipFileToPath(zipFilePath, extractDir string) {

	// zipFilePath := "/home/hollysys/testdata/ceshi/job_peah3f30_test789.zip"
	// extractDir := "/home/hollysys/testdata/ceshi/gaosheng"
	zipFile, err := zip.OpenReader(zipFilePath)
	if err != nil {
		fmt.Println("打开 ZIP 文件出错:", err)
		return
	}
	defer zipFile.Close()

	// 创建目标目录
	err = os.MkdirAll(extractDir, os.ModePerm)
	if err != nil {
		fmt.Println("创建目标目录出错:", err)
		return
	}

	// 解压 ZIP 文件
	for _, file := range zipFile.File {
		// 构建解压后的文件路径
		extractedFilePath := filepath.Join(extractDir, file.Name)

		// 如果是目录，则创建对应的目录
		if file.FileInfo().IsDir() {
			os.MkdirAll(extractedFilePath, os.ModePerm)
			continue
		}

		// 创建解压后的文件
		extractedFile, err := os.Create(extractedFilePath)
		if err != nil {
			fmt.Println("创建解压后的文件出错:", err)
			return
		}
		defer extractedFile.Close()

		// 打开 ZIP 文件中的文件
		zipFile, err := file.Open()
		if err != nil {
			fmt.Println("打开 ZIP 文件中的文件出错:", err)
			return
		}
		defer zipFile.Close()

		// 将 ZIP 文件中的内容复制到解压后的文件中
		_, err = io.Copy(extractedFile, zipFile)
		if err != nil {
			fmt.Println("解压文件出错:", err)
			return
		}
	}

	fmt.Println("ZIP 文件解压成功")
}

// 复制文件目录下的所有文件
func CopyFilesToFolder(srcDir, dstDir string) error {
	err := filepath.Walk(srcDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		// 获取相对于源目录的路径
		relPath, err := filepath.Rel(srcDir, path)
		if err != nil {
			return err
		}
		// 创建目标文件路径
		dstPath := filepath.Join(dstDir, relPath)
		if info.IsDir() {
			// 如果是目录，创建目标目录
			err = os.MkdirAll(dstPath, info.Mode())
			if err != nil {
				return err
			}
		} else {
			// 如果是文件，复制文件内容
			err = copyFile(path, dstPath)
			if err != nil {
				return err
			}
		}

		return nil
	})

	return err
}

// 复制文件
func copyFile(srcPath, dstPath string) error {
	// 打开源文件
	srcFile, err := os.Open(srcPath)
	if err != nil {
		return fmt.Errorf("打开源文件出错: %v", err)
	}
	defer srcFile.Close()

	// 创建或打开目标文件
	dstFile, err := os.Create(dstPath)
	if err != nil {
		return fmt.Errorf("创建或打开目标文件出错: %v", err)
	}
	defer dstFile.Close()

	// 复制文件内容
	_, err = io.Copy(dstFile, srcFile)
	if err != nil {
		return fmt.Errorf("复制文件内容出错: %v", err)
	}

	return nil
}

func RemoveDuplicates(slice []string) []string {
	// 创建一个映射来记录已经出现过的字符串
	seen := make(map[string]bool)

	// 创建一个新的切片来存储去重后的结果
	result := []string{}

	// 遍历原始切片
	for _, str := range slice {
		// 如果字符串在映射中不存在，则将其添加到结果切片中，并将其标记为已出现
		if !seen[str] {
			result = append(result, str)
			seen[str] = true
		}
	}

	return result
}

func UploadFileCopy(uploadpathslice *vo.AttrsOfFileUpload, tempPath string, count int) int {
	for _, uploadFilePath := range uploadpathslice.UploadFilePaths {
		fmt.Println(uploadFilePath)
		uploadFolder := tempPath + "upload/"
		CreateDir(uploadFolder)
		count++
		filename := filepath.Base(uploadFilePath)
		// 文件复制
		CopyFile(uploadFilePath, uploadFolder+filename)
	}
	return count
}

func JudgeExt(fileExt string) bool {
	validExts := []string{".csv", ".txt", ".json", ".xml"}
	isValid := false
	for _, ext := range validExts {
		if ext == fileExt {
			isValid = true
			break
		}
	}
	return isValid
}

func ISSSUTF8(data []byte) bool {
	// 定义一个变量nBytes，用来记录多字节字符的字节数
	nBytes := 0

	// 遍历字节切片中的每个字节
	for _, b := range data {
		// 如果nBytes等于0，说明当前字节是一个单字节字符或者多字节字符的第一个字节
		if nBytes == 0 {
			// 如果当前字节与0x80进行与运算的结果不为0，说明当前字节是一个多字节字符的第一个字节
			if b&0x80 != 0 {
				// 从当前字节的最高位开始，连续的二进制位值为1的个数决定了该字符的编码位数，用nBytes记录这个数值
				for i := 7; i >= 0; i-- {
					if b&(1<<uint(i)) != 0 {
						nBytes++
					} else {
						break
					}
				}

				// 如果nBytes小于2或者大于6，说明该字符不是有效的UTF-8编码，返回false
				if nBytes < 2 || nBytes > 6 {
					return false
				}

				// 否则，将nBytes减1，表示剩余的字节数
				nBytes--
			}
			// 否则，说明当前字节是一个多字节字符的非第一个字节
		} else {
			// 如果当前字节与0xc0进行与运算的结果不等于0x80，说明当前字节不是以10开头，不符合UTF-8编码规则，返回false
			if b&0xc0 != 0x80 {
				return false
			}

			// 否则，将nBytes减1，表示剩余的字节数
			nBytes--
		}
	}

	// 遍历结束后，如果nBytes等于0，说明所有的字符都是有效的UTF-8编码，返回true
	return nBytes == 0
}

func IsHave(target string, str_array []string) bool {
	sort.Strings(str_array)
	index := sort.SearchStrings(str_array, target)
	//index的取值：0 ~ (len (str_array)-1)
	return index < len(str_array) && str_array[index] == target
}

func FindDataBaseTypeWithRe(content string) []string {
	var res []string
	// content, _ := ioutil.ReadFile(path)
	re_mysql := regexp.MustCompile(`\bmysql_\d{8}\b`)
	re_emysql := regexp.MustCompile(`\bemysql_\d{8}\b`)
	re_pg := regexp.MustCompile(`PostgreSQL_\d{8}`)
	re_sq := regexp.MustCompile(`SQLite_\d{8}`)
	re_ss := regexp.MustCompile(`SQLServer_\d{8}`)
	matches_mysql := re_mysql.FindAllString(string(content), -1)
	for _, v := range matches_mysql {
		s_new := "MySQL:" + v
		res = append(res, s_new)
	}
	matches_emysql := re_emysql.FindAllString(string(content), -1)
	for _, v := range matches_emysql {
		s_new := "EMySQL:" + v
		res = append(res, s_new)
	}
	matches_pg := re_pg.FindAllString(string(content), -1)
	for _, v := range matches_pg {
		s_new := "PostgreSQL:" + v
		res = append(res, s_new)
	}
	matches_sq := re_sq.FindAllString(string(content), -1)
	for _, v := range matches_sq {
		s_new := "SQLite:" + v
		res = append(res, s_new)
	}
	matches_ss := re_ss.FindAllString(string(content), -1)
	for _, v := range matches_ss {
		s_new := "SQLServer:" + v
		res = append(res, s_new)
	}
	return res
}

func FindUploadFilePathWithRe(content string) []string {
	// content, _ := ioutil.ReadFile(path)
	pattern := `"uploadFilePath":"([^"]+)",`
	reg := regexp.MustCompile(pattern)
	matches1 := reg.FindAllStringSubmatch(string(content), -1)
	// fmt.Println(matches1)
	var res []string
	for _, match := range matches1 {
		if len(match) > 1 {
			res = append(res, match[1])

		}
	}
	return res
}

func BuildLog(logSlice []vo.LogBody, project, node, level, content, serviceId, type1, dataVersion, jumpUrl string) []vo.LogBody {
	var log = vo.LogBody{
		Project:     project,
		Node:        node,
		Level:       level,
		Content:     content,
		ServiceId:   serviceId,
		Type:        type1,
		DataVersion: dataVersion,
		RecordTime:  strconv.Itoa(int(time.Now().UnixMilli())),
		JumpUrl:     jumpUrl,
	}
	logSlice = append(logSlice, log)
	return logSlice
}

func JsonToFile(path string, logSlice []vo.LogBody) {
	logData, err := json.Marshal(logSlice)
	if err != nil {

		fmt.Println("序列化Postgres配置文件出错")
	}
	WriteFile(path, string(logData))
}

func WriteArr(path string, arr_version []string) bool {
	file, err := os.Create(path)
	if err != nil {
		logger.Info("Failed to create file:%v", err)
		return false
	}
	defer file.Close()

	writer := bufio.NewWriter(file)
	for _, line := range arr_version {
		_, err := writer.WriteString(line + "\n")
		if err != nil {
			logger.Info("Failed to write to file:%v", err)
			return false
		}
	}

	err = writer.Flush()
	if err != nil {
		logger.Info("Failed to flush buffer:%v", err)
		return false
	}
	return true
}

func ReadArr(path string, arr_version []string) []string {
	file, err := os.Open(path)
	if err != nil {
		logger.Info("Failed to open file:%v", err)
		return nil
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)

	for scanner.Scan() {
		line := scanner.Text()
		arr_version = append(arr_version, line)
	}

	if err := scanner.Err(); err != nil {
		logger.Info("Failed to read file:%v", err)
		return nil
	}
	return arr_version
}

func ClearFolder(dir string) error {
	// 打开文件夹
	f, err := os.Open(dir)
	if err != nil {
		return err
	}
	defer f.Close()

	// 读取文件夹中的所有文件和子文件夹
	names, err := f.Readdirnames(-1)
	if err != nil {
		return err
	}

	// 删除每个文件和子文件夹
	for _, name := range names {
		err := os.RemoveAll(filepath.Join(dir, name))
		if err != nil {
			return err
		}
	}

	return nil
}

func RemoveSpace(strSlice []string) []string {
	logger.Info("原始切片为，%v", strSlice)

	for i := 1; i < len(strSlice); i++ {
		strSlice[i] = strings.TrimSpace(strSlice[i])
	}
	logger.Info("修改后的切片为，%v", strSlice)
	return strSlice
}

// 获取文件夹大小
func GetFolderSize(folderPath string) (int64, error) {
	var size int64

	err := filepath.Walk(folderPath, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if !info.IsDir() {
			size += info.Size()
		}
		return nil
	})

	if err != nil {
		return 0, err
	}

	return size, nil
}

// 获取作业文件
func GetJsonFiles(dir string) ([]string, error) {
	var files []string
	items, err := ioutil.ReadDir(dir)
	if err != nil {
		return nil, err
	}

	for _, item := range items {
		if !item.IsDir() && strings.HasPrefix(item.Name(), "job_") && strings.HasSuffix(item.Name(), ".json") {
			filePath := filepath.Join(dir, item.Name())
			files = append(files, filePath)
		}
	}
	return files, nil
}

// 判断目录下的文件是否存在
func FileExist(dir string) (bool, error) {
	filePath := filepath.Join(dir)

	info, err := os.Stat(filePath)
	if os.IsNotExist(err) {
		return false, nil
	}
	if err != nil {
		return false, err
	}
	return !info.IsDir(), nil
}

// 获取数据库配置文件
func GetAllJsonFiles(dir string) ([]string, error) {
	var files []string
	err := filepath.Walk(dir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		if !info.IsDir() && strings.HasSuffix(info.Name(), ".json") {
			files = append(files, path)
		}
		return nil
	})
	return files, err
}

func BackPublish(arr_version []string) {

	db, err := GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败:%v", err)
	}
	defer db.Close()

	CreateDir(constants.BackPath)
	removePath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp + constants.PORTALNAME
	// tempPath = /usr/local/hsm-os/data/hsm-io-it/data/temp/hsm_io_it/
	tempPath := removePath + constants.Hierarchy
	CreateDir(tempPath)
	existQuery := `SELECT EXISTS (SELECT 1 FROM ioit.job_info WHERE namespace = $1)`

	var exists bool
	err = db.QueryRow(existQuery, constants.PORTALNAME).Scan(&exists)
	if err != nil {
		logger.Info("数据库查询失败:%v", err)
	}

	if exists {
		query := `SELECT
				create_user, name, describe, schedule, schedule_details, schedule_cycle, schedule_unit, namespace, code, s_node,
				content, cron_id, is_http, canvas, job_type, job_class, template, id, status, create_time, edite_time, 
				is_auto_select_id, cron_detail, period_detail
			FROM ioit.job_info WHERE namespace = $1 AND is_auto_select_id = $2`

		rows, err := db.Query(query, constants.PORTALNAME, false)

		if err != nil {
			logger.Info("数据库查询失败:%v", err)
		}

		defer rows.Close()

		var jobs []vo.CreateJobRequest

		for rows.Next() {
			var job vo.CreateJobRequest
			var canvas []byte
			var content []byte
			var cronDetail []byte
			var periodDetail []byte
			if err := rows.Scan(&job.CreateUse, &job.Name, &job.Describe, &job.Schedule, &job.ScheduleDetails,
				&job.ScheduleCycle, &job.ScheduleUnit, &job.NameSpace, &job.Code, &job.SKNode, &content,
				&job.CronId, &job.IsHttp, &canvas, &job.JobType, &job.JobClass, &job.Template, &job.Id,
				&job.Status, &job.CreateTime, &job.EditeTime, &job.IsAutoSelectId, &cronDetail, &periodDetail); err != nil {
				logger.Info("数据库查询失败:%v", err)
			}
			err = json.Unmarshal(content, &job.Content)
			if err != nil {
				logger.Info("解析失败:%v", err)
			}
			err = json.Unmarshal(canvas, &job.Canvas)
			if err != nil {
				logger.Info("解析失败:%v", err)
			}
			err = json.Unmarshal(cronDetail, &job.CronDetail)
			if err != nil {
				logger.Info("查询作业状态失败%v", err)
			}
			err = json.Unmarshal(periodDetail, &job.PeriodDetail)
			if err != nil {
				logger.Info("查询作业状态失败%v", err)
			}
			jobs = append(jobs, job)
		}

		jobData, err := json.Marshal(jobs)
		if err != nil {
			logger.Info("解析失败:%v", err)
		}

		// 数据库连接信息处理
		dbquery := `SELECT
				code, connectname, username, password, host, port, namespace, databasetype,
				dbname, schemaname, tablename, dbpath, s_node
	 		FROM ioit.database_info WHERE namespace = $1 AND s_node = $2`

		var databaseInfoList []vo.DatabaseInfoRequest

		rows, err = db.Query(dbquery, constants.PORTALNAME, "publish")

		if err != nil {
			logger.Info("查询失败:%v", err)
			logger.Info("数据库查询失败:%v", err)
		}

		defer rows.Close()

		for rows.Next() {
			var databaseInfo vo.DatabaseInfoRequest
			if err := rows.Scan(&databaseInfo.Code, &databaseInfo.ConnectName, &databaseInfo.Username, &databaseInfo.Password,
				&databaseInfo.Host, &databaseInfo.Port, &databaseInfo.Namespace, &databaseInfo.DataBaseType, &databaseInfo.DbName,
				&databaseInfo.SchemaName, &databaseInfo.Tablename, &databaseInfo.DbPath, &databaseInfo.SKNode); err != nil {
				logger.Info("查询失败:%v", err)
				logger.Info("数据库查询失败:%v", err)
			}
			databaseInfoList = append(databaseInfoList, databaseInfo)
		}

		dbData, err := json.Marshal(databaseInfoList)
		if err != nil {
			logger.Info("数据库查询失败:%v", err)
		}

		// 文件上传
		// uploadFolder = /usr/loacl/hsm-os/data/hsm-io-it/data/temp/tempFile/upload/
		uploadFolder := tempPath + constants.PORTALNAME + constants.Hierarchy + "upload/"
		CreateDir(uploadFolder)
		// 文件复制
		jobFolderPath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Project + constants.PORTALNAME + constants.Hierarchy + "upload/"
		CopyFilesToFolder(jobFolderPath, uploadFolder)

		dataBasefolder := tempPath + constants.PORTALNAME + constants.Hierarchy + constants.DataBaseConfig
		CreateDir(dataBasefolder)
		WriteFile(dataBasefolder+"database"+constants.Suffix, string(dbData))
		// tempPath = /usr/loacl/hsm-os/data/hsm-io-it/data/temp/tempFile/namespace.json
		WriteFile(tempPath+constants.PORTALNAME+constants.JsonIdentifier, string(jobData))
		// tempPath = /usr/loacl/hsm-os/data/hsm-io-it/data/temp/tempFile/namespace.txt
	}

	sourceDir := removePath

	bak_version := arr_version[len(arr_version)-2]
	targzNameSlice := []string{constants.PORTALNAME, "0", constants.AppId, bak_version, constants.IsAll, constants.IsClear}
	targzName := strings.Join(targzNameSlice, constants.Pound) + constants.TarGz
	targetFile := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp + targzName
	baseDir := filepath.Base(sourceDir)
	logger.Info("baseDir is %v", baseDir)
	cmd := exec.Command("tar", "-czf", targetFile, "-C", filepath.Dir(sourceDir), baseDir)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	err = cmd.Run()
	if err != nil {
		logger.Info("err is %v", err)
		return
	}
	// 移动
	cmd1 := exec.Command("mv", targetFile, constants.BackPath)
	cmd1.Stdout = os.Stdout
	cmd1.Stderr = os.Stderr
	err = cmd1.Run()
	if err != nil {
		return
	}
	os.RemoveAll(removePath)
}
