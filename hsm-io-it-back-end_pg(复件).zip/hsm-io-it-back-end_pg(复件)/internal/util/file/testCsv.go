package main

import (
	"bufio"
	"bytes"
	"fmt"
	"io"
	"io/ioutil"

	"golang.org/x/net/html/charset"
	"golang.org/x/text/encoding"
	"golang.org/x/text/encoding/simplifiedchinese"
	"golang.org/x/text/transform"
)

func TestUTF81() {
	data, err := ioutil.ReadFile("D:/data/e2.csv")
	if err != nil {
		fmt.Println(err)
	}
	//判断是否是utf-8
	fmt.Println("isGBK:", isGBK(data))
	// 打印UTF8
	fmt.Println(string(data))

	// UTF8转GBK
	data, err = ioutil.ReadAll(transform.NewReader(bytes.NewBuffer(data), simplifiedchinese.GBK.NewEncoder()))
	if err != nil {
		fmt.Println(err)
	}
	// 打印GBK
	fmt.Println(string(data))
}

func determineEncodeing(r io.Reader) encoding.Encoding {
	peek, err := bufio.NewReader(r).Peek(1024)
	if err != nil {
		panic(err)
	}
	determineEncoding, _, _ := charset.DetermineEncoding(peek, "")
	return determineEncoding
}
