package main

import (
	"bytes"
	"fmt"
	"io/ioutil"

	"golang.org/x/text/encoding/simplifiedchinese"
	"golang.org/x/text/transform"
)

func isGBK1(data []byte) bool {
	length := len(data)
	var i int = 0
	for i < length {
		//fmt.Printf("for %x\n", data[i])
		if data[i] <= 0xff {
			//编码小于等于127,只有一个字节的编码，兼容ASCII吗
			i++
			continue
		} else {
			//大于127的使用双字节编码
			if data[i] >= 0x81 &&
				data[i] <= 0xfe &&
				data[i+1] >= 0x40 &&
				data[i+1] <= 0xfe &&
				data[i+1] != 0xf7 {
				i += 2
				continue
			} else {
				return false
			}
		}
	}
	return true
}

func isGBK(data []byte) bool {
	length := len(data)
	var i int = 0
	for i < length {
		if data[i] <= 0x7f {
			//编码0~127,只有一个字节的编码，兼容ASCII码
			i++
			continue
		} else {
			//大于127的使用双字节编码，落在gbk编码范围内的字符
			if data[i] >= 0x81 &&
				data[i] <= 0xfe &&
				data[i+1] >= 0x40 &&
				data[i+1] <= 0xfe &&
				data[i+1] != 0xf7 {
				i += 2
				continue
			} else {
				return false
			}
		}
	}
	return true
}

func preNUm(data byte) int {
	str := fmt.Sprintf("%b", data)
	var i int = 0
	for i < len(str) {
		if str[i] != '1' {
			break
		}
		i++
	}
	return i
}

func isUtf8(data []byte) bool {
	for i := 0; i < len(data); {
		if data[i]&0x80 == 0x00 {
			// 0XXX_XXXX
			i++
			continue
		} else if num := preNUm(data[i]); num > 2 {
			// 110X_XXXX 10XX_XXXX
			// 1110_XXXX 10XX_XXXX 10XX_XXXX
			// 1111_0XXX 10XX_XXXX 10XX_XXXX 10XX_XXXX
			// 1111_10XX 10XX_XXXX 10XX_XXXX 10XX_XXXX 10XX_XXXX
			// 1111_110X 10XX_XXXX 10XX_XXXX 10XX_XXXX 10XX_XXXX 10XX_XXXX
			// preNUm() 返回首个字节的8个bits中首个0bit前面1bit的个数，该数量也是该字符所使用的字节数
			i++
			for j := 0; j < num-1; j++ {
				//判断后面的 num - 1 个字节是不是都是10开头
				if data[i]&0xc0 != 0x80 {
					return false
				}
				i++
			}
		} else {
			//其他情况说明不是utf-8
			return false
		}
	}
	return true
}

func testUTF8() {
	data, err := ioutil.ReadFile("D:/data/test高盛1u.csv")
	if err != nil {
		fmt.Println(err)
	}
	//判断是否是utf-8

	fmt.Println("isUtf8:", isUtf8(data))
	fmt.Println("isGBK:", isGBK(data))
	fmt.Println("文件数据：", string(data))

	// UTF8转GBK
	data, err = ioutil.ReadAll(transform.NewReader(bytes.NewBuffer(data), simplifiedchinese.GBK.NewEncoder()))

	//fmt.Println("gbk:" + string(data))

	utf8Data, _ := simplifiedchinese.GBK.NewDecoder().Bytes(data) //将gbk再转换为utf-8

	fmt.Println("isGBK:", isGBK(utf8Data))

	if err != nil {
		fmt.Println(err)
	}

	fmt.Println("=======================================================")

	// 打印GBK
	fmt.Println(string(utf8Data))
}

func main() {

	str := "月色真美，风也温柔，233333333，~！@#"                                   //go字符串编码为utf-8
	fmt.Println("isGBK:", isGBK3([]byte(str)))                          //判断是否是gbk
	fmt.Println("before convert:", str)                                 //打印转换前的字符串
	fmt.Println("isUtf8:", isUtf8([]byte(str)))                         //判断是否是utf-8
	gbkData, _ := simplifiedchinese.GBK.NewEncoder().Bytes([]byte(str)) //使用官方库将utf-8转换为gbk
	fmt.Println("gbk直接打印会出现乱码:", string(gbkData))                       //乱码字符串
	fmt.Println("isGBK:", isGBK(gbkData))                               //判断是否是gbk
	utf8Data, _ := simplifiedchinese.GBK.NewDecoder().Bytes(gbkData)    //将gbk再转换为utf-8
	fmt.Println("isUtf8:", isUtf8(utf8Data))                            //判断是否是utf-8
	fmt.Println("after convert:", string(utf8Data))                     //打印转换前的字符串
}

func main11() {
	//读取文件数据判断文件是否为utf-8
	testUTF8()
}

func isGBK3(data []byte) bool {
	length := len(data)
	var i int = 0
	for i < length {
		if data[i] <= 0x7f {
			//编码0~127,只有一个字节的编码，兼容ASCII码
			i++
			continue
		} else {
			//大于127的使用双字节编码，落在gbk编码范围内的字符
			if data[i] >= 0x81 &&
				data[i] <= 0xfe &&
				data[i+1] >= 0x40 &&
				data[i+1] <= 0xfe &&
				data[i+1] != 0xf7 {
				i += 2
				continue
			} else {
				return false
			}
		}
	}
	return true
}
