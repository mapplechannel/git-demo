package service

import (
	"database/sql"
	"fmt"
	"hsm-io-it-back-end/internal/util"
	"hsm-io-it-back-end/internal/vo"
	"hsm-io-it-back-end/pkg/logger"
	"log"
	"strconv"
	"strings"
	"time"

	_ "github.com/lib/pq"
)

// 测试连接postgresql数据库
func ConnectSqlSerTest(pgInfoRequest *vo.DatabaseInfoRequest) (bool, string) {
	//组装连接参数
	userName := pgInfoRequest.Username
	password := pgInfoRequest.Password
	host := pgInfoRequest.Host
	port := pgInfoRequest.Port
	url := "server=" + host + ";user id=" + userName + ";password=" + password + ";port=" + port + ";"
	db, err := sql.Open("mssql", url)
	if err != nil {
		return false, "连接失败"
	}
	db.SetConnMaxIdleTime(time.Minute * 1)
	db.SetConnMaxLifetime(time.Minute * 1)
	db.SetMaxOpenConns(10)
	db.SetMaxIdleConns(10)
	err = db.Ping()

	defer db.Close()

	retry, _ := strconv.Atoi(pgInfoRequest.Retry)
	if err != nil {
		for i := retry; i > 0; i-- {
			err = db.Ping()
			if err == nil {
				break
			}
			time.Sleep(500 * time.Millisecond)
		}

		if err != nil {
			return false, "数据库连接失败"
		}
	}
	return true, "连接成功"
}

func connectToSQLserver(url string) (*sql.DB, error) {
	db, err := sql.Open("mssql", url)
	if err != nil {
		return nil, err
	}
	db.SetConnMaxIdleTime(time.Minute * 10)
	db.SetConnMaxLifetime(time.Minute * 10)
	db.SetMaxOpenConns(10)
	db.SetMaxIdleConns(10)
	err = db.Ping()
	if err != nil {
		return nil, err
	}
	logger.Info(" ->连接成功")
	return db, nil
}

func AddConnectSqlSer(pgInfoRequest *vo.DatabaseInfoRequest) (bool, string) {

	flag := util.IsExistDatabase(pgInfoRequest.ConnectName, pgInfoRequest.Namespace, pgInfoRequest.DataBaseType)

	if flag {
		return false, "不能创建相同类型的同名数据源，请重新输入"
	}

	code := generateDataBaseCode(pgInfoRequest.DataBaseType)
	pgInfoRequest.Code = code

	dbPG, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, ""
	}
	defer dbPG.Close()

	addsql := `INSERT INTO ioit.database_info (
					code, namespace, connectname, username, password, host, port, 
					databasetype, s_node, dbname, schemaname, tablename, dbpath) 
				VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)`

	_, err = dbPG.Exec(addsql,
		pgInfoRequest.Code, pgInfoRequest.Namespace, pgInfoRequest.ConnectName,
		pgInfoRequest.Username, pgInfoRequest.Password, pgInfoRequest.Host,
		pgInfoRequest.Port, pgInfoRequest.DataBaseType, "unpublish", pgInfoRequest.DbName,
		pgInfoRequest.SchemaName, pgInfoRequest.Tablename, pgInfoRequest.DbPath)

	if err != nil {
		logger.Info("数据库插入失败:%v", err)
		return false, "数据库插入失败"
	}

	url := "server=" + pgInfoRequest.Host + ";user id=" + pgInfoRequest.Username + ";password=" + pgInfoRequest.Password + ";port=" + pgInfoRequest.Port + ";"

	db, err := connectToSQLserver(url)
	if err != nil {
		return false, "连接失败"
	}
	defer db.Close()
	return true, code
}

func UpdateConnectSqlSer(pgInfo *vo.DatabaseInfoRequest) (bool, string) {

	flag := util.IsUpdateExistDatabase(pgInfo.ConnectName, pgInfo.Namespace, pgInfo.DataBaseType, pgInfo.Code)

	if flag {
		return false, "不能创建相同类型的同名数据源，请重新编辑"
	}

	dbPG, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, "数据库连接失败"
	}
	defer dbPG.Close()

	updatesql := `UPDATE ioit.database_info SET connectname=$1,	username=$2, password=$3, host=$4, port=$5 WHERE namespace = $6 AND code = $7 `

	_, err = dbPG.Exec(updatesql,
		pgInfo.ConnectName, pgInfo.Username, pgInfo.Password, pgInfo.Host, pgInfo.Port, pgInfo.Namespace, pgInfo.Code)

	if err != nil {
		logger.Info("数据库连接更新失败")
		return false, "数据库连接更新失败"
	}

	logger.Info("数据库连接信息更新: %v", flag)

	return true, "更新成功"
}

// 获取查询某个ip上所有的数据库
func GetSqlSerDataBaseConnectList(dataBaseInfo *vo.DatabaseInfoRequest) (bool, []Database) {
	//组装连接参数
	userName := dataBaseInfo.Username
	password := dataBaseInfo.Password
	host := dataBaseInfo.Host
	port := dataBaseInfo.Port
	url := "server=" + host + ";user id=" + userName + ";password=" + password + ";port=" + port + ";"

	db, err := connectToSQLserver(url)

	if err != nil {
		return false, nil
	}
	defer db.Close()
	// 连接到指定的数据库
	rows, err := db.Query("SELECT name FROM sys.databases")
	if err != nil {
		return false, nil
	}
	defer rows.Close()
	// 读取数据库连接并构建响应
	var dataBases []Database
	// 遍历查询结果
	for rows.Next() {
		var dataBase Database
		if err := rows.Scan(&dataBase.Name); err != nil {
			return false, nil
		}

		dataBases = append(dataBases, dataBase)
	}
	return true, dataBases
}

// 查询某个数据库下所有表
func GetSqlSerTableList(sqlSerInfoRequest *vo.DatabaseInfoRequest) (bool, []TableAndType) {
	var tables []TableAndType
	// 读取数据库连接并构建响应
	db, err := getSqlSerConnect(sqlSerInfoRequest)

	if err != nil {
		return false, tables
	}
	defer db.Close()

	// 查询某个数据库下所有表
	query := "SELECT table_name,table_type FROM information_schema.tables WHERE table_type  IN ('BASE TABLE', 'VIEW')"
	rows, err := db.Query(query)
	if err != nil {
		return false, tables
	}
	defer rows.Close()
	// 遍历结果集
	for rows.Next() {
		var table TableAndType
		if err := rows.Scan(&table.Name, &table.Type); err != nil {
			return false, nil
		}
		tables = append(tables, table)
	}
	return true, tables
}
func getSqlSerConnect(sqlSerInfoRequest *vo.DatabaseInfoRequest) (*sql.DB, error) {
	//组装连接参数
	userName := sqlSerInfoRequest.Username
	password := sqlSerInfoRequest.Password
	host := sqlSerInfoRequest.Host
	port := sqlSerInfoRequest.Port
	dbname := sqlSerInfoRequest.DbName
	url := "server=" + host + ";user id=" + userName + ";password=" + password + ";port=" + port + ";database=" + dbname
	db, err := sql.Open("mssql", url)
	if err != nil {
		return nil, err
	}

	db.SetConnMaxIdleTime(time.Minute * 10)
	db.SetConnMaxLifetime(time.Minute * 10)
	db.SetMaxOpenConns(10)
	db.SetMaxIdleConns(10)
	return db, nil
}
func GetSqlSerTablesPrimary(sqlSerInfoRequest *vo.DatabaseInfoRequest) (bool, []string) {
	db, err := getSqlSerConnect(sqlSerInfoRequest)

	if err != nil {
		return false, nil
	}
	defer db.Close()
	// 查询当前表的所有字段
	query := fmt.Sprintf(`
       SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
       WHERE OBJECTPROPERTY(OBJECT_ID(CONSTRAINT_SCHEMA+'.'+CONSTRAINT_NAME), 'IsPrimaryKey') = 1 AND TABLE_NAME = '%s'`, sqlSerInfoRequest.Tablename)

	rows, err := db.Query(query)
	logger.Info("dbName is %v", sqlSerInfoRequest.DbName)
	if err != nil {
		return false, nil
	}
	defer rows.Close()

	// 封装所有字段信息
	var columns []string
	for rows.Next() {
		var column string
		if err := rows.Scan(&column); err != nil {
			return false, nil
		}
		columns = append(columns, column)
	}
	// 返回所有字段信息
	return true, columns
}

func GetSqlSerTableColumns(sqlSerInfoRequest *vo.DatabaseInfoRequest) (bool, []ColumnPG) {
	db, err := getSqlSerConnect(sqlSerInfoRequest)

	if err != nil {
		return false, nil
	}
	defer db.Close()

	query := fmt.Sprintf(`
       SELECT 
			c.name AS ColumnName,
			t.name AS DataType,
			p.value AS Comment
		FROM 
			sys.columns c
			INNER JOIN sys.types t ON c.user_type_id = t.user_type_id
			LEFT JOIN sys.extended_properties p ON c.object_id = p.major_id AND c.column_id = p.minor_id AND p.name = 'MS_Description'
		WHERE 
			c.object_id = OBJECT_ID('%s') `, sqlSerInfoRequest.Tablename)

	rows, err := db.Query(query)
	if err != nil {
		return false, nil
	}
	defer rows.Close()
	// 封装所有字段信息
	var columns []ColumnPG
	for rows.Next() {
		var colInfo ColumnPG
		err := rows.Scan(&colInfo.Name, &colInfo.Type, &colInfo.Comment)
		if err != nil {
			log.Fatal(err)
		}
		logger.Info("colInfo:%v", colInfo)
		columns = append(columns, colInfo)
	}
	return true, columns
}
func GetSqlSerTableData(sqlSerInfoRequest *vo.DatabaseInfoRequest) (bool, SearchResponse, string) {
	// 连接到指定的数据库
	res := SearchResponse{}

	db, err := getSqlSerConnect(sqlSerInfoRequest)

	if err != nil {
		return false, res, "查询失败"
	}
	defer db.Close()

	flag := ContainsComplexQuery(sqlSerInfoRequest.SQL)
	if flag {
		return false, res, "不支持复杂查询"
	}

	// 查询当前表的所有字段
	logger.Info("SQL:%v", sqlSerInfoRequest.SQL)
	rows, err := db.Query(sqlSerInfoRequest.SQL)
	if err != nil {
		logger.Info("err is :%v", err)
		msg := strings.TrimPrefix(err.Error(), "mssql: ")
		msg = strings.TrimSuffix(msg, "。")
		return false, res, msg
	}
	defer rows.Close()
	// 解析查询结果
	count := 0
	columns, _ := rows.Columns()
	// 获取列的数据类型
	columnTypes, _ := rows.ColumnTypes()
	var results []map[string]interface{}
	for rows.Next() {
		count++
		if count > 1000 {
			// return false, res, "支持预览1000条数据"
			logger.Info("支持预览1000条数据")
			break
		}
		values := make([]interface{}, len(columns))
		valuePtrs := make([]interface{}, len(columns))
		for i := range columns {
			valuePtrs[i] = &values[i]
		}
		err = rows.Scan(valuePtrs...)
		if err != nil {
			continue
		}
		rowData := make(map[string]interface{})
		for i, col := range columns {
			val := valuePtrs[i].(*interface{})
			if *val != nil {
				// 根据列的数据类型进行特定格式的处理
				switch columnTypes[i].DatabaseTypeName() {
				case "DATE":
					if dateVal, ok := (*val).(time.Time); ok {
						rowData[col] = dateVal.Format("2006-01-02")
					} else {
						rowData[col] = *val
					}
				case "TIME":
					if timeVal, ok := (*val).(time.Time); ok {
						rowData[col] = timeVal.Format("15:04:05")
					} else {
						rowData[col] = *val
					}
				case "DATETIME":
					if datetimeVal, ok := (*val).(time.Time); ok {
						rowData[col] = datetimeVal.Format("2006-01-02 15:04:05")
					} else {
						rowData[col] = *val
					}
				default:
					rowData[col] = *val
				}
			} else {
				rowData[col] = nil
			}
		}
		results = append(results, rowData)
	}

	// 将查询结果转化为原始数据格式
	for _, row := range results {
		for key, val := range row {
			switch v := val.(type) {
			case []byte:
				row[key] = string(v)
			case time.Time:
				row[key] = v.Format("2006-01-02 15:04:05.000")
			case bool:
				if v {
					row[key] = 1
				} else {
					row[key] = 0
				}
			default:
				logger.Info("case is default")
			}
		}
	}
	res.List = results
	res.Cols = columns

	sqlTableColumn := fmt.Sprintf(`
       SELECT 
			c.name AS column_name,
			p.value AS column_comment
		FROM 
			sys.columns c
			INNER JOIN sys.types t ON c.user_type_id = t.user_type_id
			LEFT JOIN sys.extended_properties p ON c.object_id = p.major_id AND c.column_id = p.minor_id AND p.name = 'MS_Description'
		WHERE 
			c.object_id = OBJECT_ID('%s')`, sqlSerInfoRequest.Tablename)
	rowsCom, err := db.Query(sqlTableColumn)
	if err != nil {
		fmt.Println(err)
	}
	defer rowsCom.Close()

	var tableColumns []tableColumn

	for rowsCom.Next() {
		var column tableColumn
		err = rowsCom.Scan(
			&column.ColumnName,
			&column.ColumnComment)

		if err != nil {
			fmt.Printf("query table column scan error, detail is [%v]\n", err.Error())
			continue
		}

		tableColumns = append(tableColumns, column)
	}
	res.ColsInfo = tableColumns

	return true, res, "查询成功"
}

// 获取数据库连接
func GetDataBaseConnectList(namespaceVo *vo.DatabaseInfoRequest) (bool, []vo.DatabaseInfoRequest) {
	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, nil
	}
	defer db.Close()

	query := `SELECT 
					code, connectname, username, dbpath, dbname, host, port, password, schemaname, tablename, databasetype, retry 
			FROM ioit.database_info WHERE namespace = $1 AND databasetype != $2`

	rows, err := db.Query(query, namespaceVo.Namespace, "EMySQL")

	if err != nil {
		logger.Info("查询错误%v", err)
		return false, nil
	}

	defer rows.Close()

	var infos []vo.DatabaseInfoRequest

	logger.Info("查询结束")

	for rows.Next() {
		var info vo.DatabaseInfoRequest
		err = rows.Scan(&info.Code, &info.ConnectName, &info.Username,
			&info.DbPath, &info.DbName, &info.Host, &info.Port, &info.Password, &info.SchemaName, &info.Tablename, &info.DataBaseType, &info.Retry)
		if err != nil {
			logger.Info("查询错误%v", err)
			return false, nil
		}
		infos = append(infos, info)
	}

	return true, infos
}
