package u8kingdee

import (
	"hsm-io-it-back-end/pkg/logger"
	"net/http"

	"github.com/gin-gonic/gin"

	"fmt"

	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

// u8*******************************
func SaveU8TaskCenter(c *gin.Context) {
	var task U8TaskCenter
	if err := c.ShouldBindJSON(&task); err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	db, err := ConnectPg()

	if err != nil {
		logger.Info("err is :%v", err)
	}

	if err := db.Create(&task).Error; err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to save task"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Data saved successfully"})
}

func SaveU8Department(c *gin.Context) {
	var task U8Department
	if err := c.ShouldBindJSON(&task); err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	db, err := ConnectPg()

	if err != nil {
		logger.Info("err is :%v", err)
	}

	if err := db.Create(&task).Error; err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to save task"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Data saved successfully"})
}

func SaveU8Supplier(c *gin.Context) {
	var task U8Supplier
	if err := c.ShouldBindJSON(&task); err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	db, err := ConnectPg()

	if err != nil {
		logger.Info("err is :%v", err)
	}

	if err := db.Create(&task).Error; err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to save task"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Data saved successfully"})
}

func SaveU8Unit(c *gin.Context) {
	var task U8Unit
	if err := c.ShouldBindJSON(&task); err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	db, err := ConnectPg()

	if err != nil {
		logger.Info("err is :%v", err)
	}

	if err := db.Create(&task).Error; err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to save task"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Data saved successfully"})
}

func SaveU8CustomerData(c *gin.Context) {
	var task U8CustomerData
	if err := c.ShouldBindJSON(&task); err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	db, err := ConnectPg()

	if err != nil {
		logger.Info("err is :%v", err)
	}

	if err := db.Create(&task).Error; err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to save task"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Data saved successfully"})
}

func SaveU8Person(c *gin.Context) {
	var task U8Person
	if err := c.ShouldBindJSON(&task); err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	db, err := ConnectPg()

	if err != nil {
		logger.Info("err is :%v", err)
	}

	if err := db.Create(&task).Error; err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to save task"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Data saved successfully"})
}

func SaveU8ProductionOrder(c *gin.Context) {
	var task U8ProductionOrder
	if err := c.ShouldBindJSON(&task); err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	db, err := ConnectPg()

	if err != nil {
		logger.Info("err is :%v", err)
	}

	if err := db.Create(&task).Error; err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to save task"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Data saved successfully"})
}

func SaveU8Material(c *gin.Context) {
	var task U8Material
	if err := c.ShouldBindJSON(&task); err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	db, err := ConnectPg()

	if err != nil {
		logger.Info("err is :%v", err)
	}

	if err := db.Create(&task).Error; err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to save task"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Data saved successfully"})
}

func SaveU8MaterialBOM(c *gin.Context) {
	var task U8MaterialBOM
	if err := c.ShouldBindJSON(&task); err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	db, err := ConnectPg()

	if err != nil {
		logger.Info("err is :%v", err)
	}

	if err := db.Create(&task).Error; err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to save task"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Data saved successfully"})
}

// kingdee*******************************
func SaveKingdeeDepartment(c *gin.Context) {
	var task KingdeeDepartment
	if err := c.ShouldBindJSON(&task); err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	db, err := ConnectPg()

	if err != nil {
		logger.Info("err is :%v", err)
	}

	if err := db.Create(&task).Error; err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to save task"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Data saved successfully"})
}

func SaveKingdeeWorkCenter(c *gin.Context) {
	var task KingdeeWorkCenter
	if err := c.ShouldBindJSON(&task); err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	db, err := ConnectPg()

	if err != nil {
		logger.Info("err is :%v", err)
	}

	if err := db.Create(&task).Error; err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to save task"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Data saved successfully"})
}

func SaveKingdeeSupplier(c *gin.Context) {
	var task KingdeeSupplier
	if err := c.ShouldBindJSON(&task); err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	db, err := ConnectPg()

	if err != nil {
		logger.Info("err is :%v", err)
	}

	if err := db.Create(&task).Error; err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to save task"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Data saved successfully"})
}

func SaveKingdeePlanOrder(c *gin.Context) {
	var task KingdeePlanOrder
	if err := c.ShouldBindJSON(&task); err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	db, err := ConnectPg()

	if err != nil {
		logger.Info("err is :%v", err)
	}

	if err := db.Create(&task).Error; err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to save task"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Data saved successfully"})
}

func SaveKingdeeUnit(c *gin.Context) {
	var task KingdeeUnit
	if err := c.ShouldBindJSON(&task); err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	db, err := ConnectPg()

	if err != nil {
		logger.Info("err is :%v", err)
	}

	if err := db.Create(&task).Error; err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to save task"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Data saved successfully"})
}

func SaveKingdeeCustomer(c *gin.Context) {
	var task KingdeeCustomer
	if err := c.ShouldBindJSON(&task); err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	db, err := ConnectPg()

	if err != nil {
		logger.Info("err is :%v", err)
	}

	if err := db.Create(&task).Error; err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to save task"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Data saved successfully"})
}

func SaveKingdeeProductionOrder(c *gin.Context) {
	var task KingdeeProductionOrder
	if err := c.ShouldBindJSON(&task); err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	db, err := ConnectPg()

	if err != nil {
		logger.Info("err is :%v", err)
	}

	if err := db.Create(&task).Error; err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to save task"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Data saved successfully"})
}

func SaveKingdeeMaterial(c *gin.Context) {
	var task KingdeeMaterial
	if err := c.ShouldBindJSON(&task); err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	db, err := ConnectPg()

	if err != nil {
		logger.Info("err is :%v", err)
	}

	if err := db.Create(&task).Error; err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to save task"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Data saved successfully"})
}

func SaveKingdeeBOM(c *gin.Context) {
	var task KingdeeBOM
	if err := c.ShouldBindJSON(&task); err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	db, err := ConnectPg()

	if err != nil {
		logger.Info("err is :%v", err)
	}

	if err := db.Create(&task).Error; err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to save task"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Data saved successfully"})
}

func SaveKingdeeEmployee(c *gin.Context) {
	var task KingdeeEmployee
	if err := c.ShouldBindJSON(&task); err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	db, err := ConnectPg()

	if err != nil {
		logger.Info("err is :%v", err)
	}

	if err := db.Create(&task).Error; err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to save task"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Data saved successfully"})
}

// 产品入库*******************************
func SaveU8ProductIn(c *gin.Context) {
	var task U8ProductIn
	if err := c.ShouldBindJSON(&task); err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	getLinkInfo()
	connStr := fmt.Sprintf("host=%s user=%s password=%s dbname=%s port=%d sslmode=disable search_path=%s", databaseInfo.Host, databaseInfo.User, databaseInfo.Password, "u8", databaseInfo.Port, "public")
	db, err := gorm.Open(postgres.Open(connStr), &gorm.Config{})
	if err != nil {
		logger.Info("err is:%v", err)
	}
	logger.Info("task:%v", task)
	if err := db.Create(&task).Error; err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to save task"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Data saved successfully"})
}

func SaveKingdeeProductIn(c *gin.Context) {
	var task KingdeeProductIn
	if err := c.ShouldBindJSON(&task); err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	getLinkInfo()
	connStr := fmt.Sprintf("host=%s user=%s password=%s dbname=%s port=%d sslmode=disable search_path=%s", databaseInfo.Host, databaseInfo.User, databaseInfo.Password, "kingdee", databaseInfo.Port, "public")
	db, err := gorm.Open(postgres.Open(connStr), &gorm.Config{})
	if err != nil {
		logger.Info("err is:%v", err)
	}

	if err := db.Create(&task).Error; err != nil {
		logger.Info("err is :%v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to save task"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Data saved successfully"})
}
