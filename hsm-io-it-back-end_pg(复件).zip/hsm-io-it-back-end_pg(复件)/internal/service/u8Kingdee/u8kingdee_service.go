package u8kingdee

import (
	"encoding/json"
	"fmt"
	"hsm-io-it-back-end/config"
	"hsm-io-it-back-end/internal/constants"
	"hsm-io-it-back-end/pkg/logger"
	"io/ioutil"

	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

type DatabaseInfo struct {
	Host     string `json:"host"`
	Port     int    `json:"port"`
	User     string `json:"user"`
	Password string `json:"password"`
	DBName   string `json:"dbname"`
	Schema   string `json:"schema"`
}

// 数据库连接对象
var databaseInfo DatabaseInfo

// 获取数据库连接
func getLinkInfo() {
	// 读取 JSON 文件
	path := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.ProjectTemplate + "u8kingdeedbs.json"
	data, err := ioutil.ReadFile(path)
	if err != nil {
		fmt.Println("无法读取 JSON 文件:", err)
		return
	}

	// 解析 JSON 数据
	if err := json.Unmarshal(data, &databaseInfo); err != nil {
		fmt.Println("无法解析 JSON 数据:", err)
		return
	}
}

// MySQL连接信息
func ConnectPg() (*gorm.DB, error) {
	getLinkInfo()
	// 构建连接字符串
	connStr := fmt.Sprintf("host=%s user=%s password=%s dbname=%s port=%d sslmode=disable search_path=%s", databaseInfo.Host, databaseInfo.User, databaseInfo.Password, databaseInfo.DBName, databaseInfo.Port, databaseInfo.Schema)

	db, err := gorm.Open(postgres.Open(connStr), &gorm.Config{})
	// 连接数据库

	if err != nil {
		logger.Info("err is:%v", err)
		return nil, err
	}

	// 返回数据库连接对象
	return db, nil
}

func MigrateTables(db *gorm.DB) error {
	// Migrate the U8TaskCenter table
	// if err := db.AutoMigrate(&U8TaskCenter{}); err != nil {
	// 	return err
	// }

	// // Migrate the U8Department table
	// if err := db.AutoMigrate(&U8Department{}); err != nil {
	// 	return err
	// }

	// // Migrate the U8Supplier table
	// if err := db.AutoMigrate(&U8Supplier{}); err != nil {
	// 	return err
	// }

	// // Migrate the U8Unit table
	// if err := db.AutoMigrate(&U8Unit{}); err != nil {
	// 	return err
	// }

	// // Migrate the U8CustomerData table
	// if err := db.AutoMigrate(&U8CustomerData{}); err != nil {
	// 	return err
	// }

	// // Migrate the U8Person table
	// if err := db.AutoMigrate(&U8Person{}); err != nil {
	// 	return err
	// }

	// // Migrate the U8ProductionOrder table
	// if err := db.AutoMigrate(&U8ProductionOrder{}); err != nil {
	// 	return err
	// }

	// // Migrate the U8Material table
	// if err := db.AutoMigrate(&U8Material{}); err != nil {
	// 	return err
	// }

	// // Migrate the U8MaterialBOM table
	// if err := db.AutoMigrate(&U8MaterialBOM{}); err != nil {
	// 	return err
	// }

	// // Migrate the KingdeeDepartment table
	// if err := db.AutoMigrate(&KingdeeDepartment{}); err != nil {
	// 	return err
	// }

	// // Migrate the KingdeeWorkCenter table
	// if err := db.AutoMigrate(&KingdeeWorkCenter{}); err != nil {
	// 	return err
	// }

	// // Migrate the KingdeeSupplier table
	// if err := db.AutoMigrate(&KingdeeSupplier{}); err != nil {
	// 	return err
	// }

	// // Migrate the KingdeePlanOrder table
	// if err := db.AutoMigrate(&KingdeePlanOrder{}); err != nil {
	// 	return err
	// }

	// // Migrate the KingdeeUnit table
	// if err := db.AutoMigrate(&KingdeeUnit{}); err != nil {
	// 	return err
	// }

	// // Migrate the KingdeeCustomer table
	// if err := db.AutoMigrate(&KingdeeCustomer{}); err != nil {
	// 	return err
	// }

	// // Migrate the KingdeeProductionOrder table
	// if err := db.AutoMigrate(&KingdeeProductionOrder{}); err != nil {
	// 	return err
	// }

	// // Migrate the KingdeeMaterial table
	// if err := db.AutoMigrate(&KingdeeMaterial{}); err != nil {
	// 	return err
	// }

	// Migrate the KingdeeBOM table
	if err := db.AutoMigrate(&U8ProductIn{}); err != nil {
		return err
	}

	if err := db.AutoMigrate(&KingdeeProductIn{}); err != nil {
		return err
	}

	// Migrate the KingdeeEmployee table
	// if err := db.AutoMigrate(&KingdeeEmployee{}); err != nil {
	// 	return err
	// }

	return nil
}
