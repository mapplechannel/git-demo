CREATE DATABASE u8;
CREATE DATABASE kingdee;

DROP TABLE IF EXISTS "public"."kingdee_product_ins";
CREATE TABLE "public"."kingdee_product_ins" (
  "f_material_id" text COLLATE "pg_catalog"."default",
  "f_owner_id" text COLLATE "pg_catalog"."default",
  "f_keeper_id" text COLLATE "pg_catalog"."default",
  "f_unit_id" text COLLATE "pg_catalog"."default",
  "f_owner_type_id" text COLLATE "pg_catalog"."default",
  "f_keeper_type_id" text COLLATE "pg_catalog"."default",
  "f_base_unit_id" text COLLATE "pg_catalog"."default",
  "f_in_stock_type" text COLLATE "pg_catalog"."default",
  "f_mo_bill_no" text COLLATE "pg_catalog"."default",
  "f_stock_status_id" text COLLATE "pg_catalog"."default",
  "f_stock_id" text COLLATE "pg_catalog"."default"
)
;
ALTER TABLE "public"."kingdee_product_ins" OWNER TO "postgres";

DROP TABLE IF EXISTS "public"."u8_product_ins";
CREATE TABLE "public"."u8_product_ins" (
  "date" text COLLATE "pg_catalog"."default",
  "department_code" text COLLATE "pg_catalog"."default",
  "warehouse_name" text COLLATE "pg_catalog"."default",
  "maker" text COLLATE "pg_catalog"."default",
  "business_type" text COLLATE "pg_catalog"."default",
  "department_name" text COLLATE "pg_catalog"."default",
  "code" text COLLATE "pg_catalog"."default",
  "receive_name" text COLLATE "pg_catalog"."default",
  "receive_code" text COLLATE "pg_catalog"."default",
  "audit_date" text COLLATE "pg_catalog"."default",
  "warehouse_code" text COLLATE "pg_catalog"."default",
  "handler" text COLLATE "pg_catalog"."default"
)
;
ALTER TABLE "public"."u8_product_ins" OWNER TO "postgres";

-- ----------------------------
-- Table structure for kingdee_boms
-- ----------------------------
CREATE SCHEMA u8kingdee;

DROP TABLE IF EXISTS "u8kingdee"."kingdee_boms";
CREATE TABLE "u8kingdee"."kingdee_boms" (
  "f_create_org_id" text COLLATE "pg_catalog"."default",
  "f_material_id" text COLLATE "pg_catalog"."default",
  "f_bom_category" text COLLATE "pg_catalog"."default",
  "f_bom_use" text COLLATE "pg_catalog"."default",
  "f_is_base_unit" bool,
  "f_is_system_set" bool,
  "f_name" text COLLATE "pg_catalog"."default",
  "f_precision" int8,
  "f_unit_id" text COLLATE "pg_catalog"."default",
  "f_material_id_child" text COLLATE "pg_catalog"."default",
  "f_issue_type" text COLLATE "pg_catalog"."default",
  "f_owner_type_id" text COLLATE "pg_catalog"."default",
  "f_dosage_type" text COLLATE "pg_catalog"."default",
  "f_unit_id_lot" text COLLATE "pg_catalog"."default",
  "f_material_id_lot_based" text COLLATE "pg_catalog"."default",
  "f_coby_type" text COLLATE "pg_catalog"."default",
  "f_material_id_coby" text COLLATE "pg_catalog"."default"
)
;
ALTER TABLE "u8kingdee"."kingdee_boms" OWNER TO "postgres";

-- ----------------------------
-- Table structure for kingdee_customers
-- ----------------------------
DROP TABLE IF EXISTS "u8kingdee"."kingdee_customers";
CREATE TABLE "u8kingdee"."kingdee_customers" (
  "f_trading_curr_id" text COLLATE "pg_catalog"."default",
  "f_name" text COLLATE "pg_catalog"."default",
  "f_create_org_id" text COLLATE "pg_catalog"."default"
)
;
ALTER TABLE "u8kingdee"."kingdee_customers" OWNER TO "postgres";

-- ----------------------------
-- Table structure for kingdee_departments
-- ----------------------------
DROP TABLE IF EXISTS "u8kingdee"."kingdee_departments";
CREATE TABLE "u8kingdee"."kingdee_departments" (
  "f_use_org_id" text COLLATE "pg_catalog"."default",
  "f_create_org_id" text COLLATE "pg_catalog"."default",
  "f_name" text COLLATE "pg_catalog"."default"
)
;
ALTER TABLE "u8kingdee"."kingdee_departments" OWNER TO "postgres";

-- ----------------------------
-- Table structure for kingdee_employees
-- ----------------------------
DROP TABLE IF EXISTS "u8kingdee"."kingdee_employees";
CREATE TABLE "u8kingdee"."kingdee_employees" (
  "f_staff_number" text COLLATE "pg_catalog"."default",
  "f_create_org_id" text COLLATE "pg_catalog"."default",
  "f_join_date" text COLLATE "pg_catalog"."default",
  "f_use_org_id" text COLLATE "pg_catalog"."default",
  "f_name" text COLLATE "pg_catalog"."default"
)
;
ALTER TABLE "u8kingdee"."kingdee_employees" OWNER TO "postgres";

-- ----------------------------
-- Table structure for kingdee_materials
-- ----------------------------
DROP TABLE IF EXISTS "u8kingdee"."kingdee_materials";
CREATE TABLE "u8kingdee"."kingdee_materials" (
  "f_creator_id" text COLLATE "pg_catalog"."default",
  "f_ext_var" text COLLATE "pg_catalog"."default",
  "f_old_number" text COLLATE "pg_catalog"."default",
  "f_description" text COLLATE "pg_catalog"."default",
  "f_material_group" text COLLATE "pg_catalog"."default",
  "f_base_property" text COLLATE "pg_catalog"."default",
  "f_material_src" text COLLATE "pg_catalog"."default",
  "f_specification" text COLLATE "pg_catalog"."default",
  "fplm_material_id" text COLLATE "pg_catalog"."default",
  "f_number" text COLLATE "pg_catalog"."default",
  "f_eqp_cls_id" text COLLATE "pg_catalog"."default"
)
;
ALTER TABLE "u8kingdee"."kingdee_materials" OWNER TO "postgres";

-- ----------------------------
-- Table structure for kingdee_plan_orders
-- ----------------------------
DROP TABLE IF EXISTS "u8kingdee"."kingdee_plan_orders";
CREATE TABLE "u8kingdee"."kingdee_plan_orders" (
  "f_material_id" text COLLATE "pg_catalog"."default",
  "f_in_stock_org_id" text COLLATE "pg_catalog"."default",
  "f_demand_org_id" text COLLATE "pg_catalog"."default",
  "f_plan_start_date" text COLLATE "pg_catalog"."default",
  "f_supply_org_id" text COLLATE "pg_catalog"."default"
)
;
ALTER TABLE "u8kingdee"."kingdee_plan_orders" OWNER TO "postgres";

-- ----------------------------
-- Table structure for kingdee_production_orders
-- ----------------------------
DROP TABLE IF EXISTS "u8kingdee"."kingdee_production_orders";
CREATE TABLE "u8kingdee"."kingdee_production_orders" (
  "f_prd_org_id" text COLLATE "pg_catalog"."default",
  "f_owner_type_id" text COLLATE "pg_catalog"."default",
  "f_bill_type" text COLLATE "pg_catalog"."default",
  "f_date" text COLLATE "pg_catalog"."default",
  "fppbom_type" text COLLATE "pg_catalog"."default"
)
;
ALTER TABLE "u8kingdee"."kingdee_production_orders" OWNER TO "postgres";

-- ----------------------------
-- Table structure for kingdee_suppliers
-- ----------------------------
DROP TABLE IF EXISTS "u8kingdee"."kingdee_suppliers";
CREATE TABLE "u8kingdee"."kingdee_suppliers" (
  "f_loc_address" text COLLATE "pg_catalog"."default",
  "f_loc_name" text COLLATE "pg_catalog"."default",
  "f_loc_mobile" text COLLATE "pg_catalog"."default",
  "f_loc_new_contact" text COLLATE "pg_catalog"."default"
)
;
ALTER TABLE "u8kingdee"."kingdee_suppliers" OWNER TO "postgres";

-- ----------------------------
-- Table structure for kingdee_units
-- ----------------------------
DROP TABLE IF EXISTS "u8kingdee"."kingdee_units";
CREATE TABLE "u8kingdee"."kingdee_units" (
  "f_number" text COLLATE "pg_catalog"."default",
  "f_current_unit" text COLLATE "pg_catalog"."default",
  "f_old_number" text COLLATE "pg_catalog"."default",
  "f_document_status" text COLLATE "pg_catalog"."default",
  "f_is_base_unit" bool,
  "f_is_system_set" bool,
  "f_name" text COLLATE "pg_catalog"."default",
  "f_precision" int8
)
;
ALTER TABLE "u8kingdee"."kingdee_units" OWNER TO "postgres";

-- ----------------------------
-- Table structure for kingdee_work_centers
-- ----------------------------
DROP TABLE IF EXISTS "u8kingdee"."kingdee_work_centers";
CREATE TABLE "u8kingdee"."kingdee_work_centers" (
  "f_use_org_id" text COLLATE "pg_catalog"."default",
  "f_effect_date" text COLLATE "pg_catalog"."default",
  "f_name" text COLLATE "pg_catalog"."default",
  "f_create_org_id" text COLLATE "pg_catalog"."default",
  "f_opt_ctrl_code_id" text COLLATE "pg_catalog"."default",
  "f_dept_id" text COLLATE "pg_catalog"."default",
  "f_expire_date" text COLLATE "pg_catalog"."default"
)
;
ALTER TABLE "u8kingdee"."kingdee_work_centers" OWNER TO "postgres";

-- ----------------------------
-- Table structure for u8_customer_data
-- ----------------------------
DROP TABLE IF EXISTS "u8kingdee"."u8_customer_data";
CREATE TABLE "u8kingdee"."u8_customer_data" (
  "abbr_name" text COLLATE "pg_catalog"."default",
  "name" text COLLATE "pg_catalog"."default",
  "domain_code" text COLLATE "pg_catalog"."default",
  "code" text COLLATE "pg_catalog"."default",
  "industry" text COLLATE "pg_catalog"."default",
  "contact" text COLLATE "pg_catalog"."default",
  "sort_code" text COLLATE "pg_catalog"."default",
  "mobile" int8
)
;
ALTER TABLE "u8kingdee"."u8_customer_data" OWNER TO "postgres";

-- ----------------------------
-- Table structure for u8_departments
-- ----------------------------
DROP TABLE IF EXISTS "u8kingdee"."u8_departments";
CREATE TABLE "u8kingdee"."u8_departments" (
  "rank" int8,
  "name" text COLLATE "pg_catalog"."default",
  "code" text COLLATE "pg_catalog"."default",
  "end_flag" int8
)
;
ALTER TABLE "u8kingdee"."u8_departments" OWNER TO "postgres";

-- ----------------------------
-- Table structure for u8_material_boms
-- ----------------------------
DROP TABLE IF EXISTS "u8kingdee"."u8_material_boms";
CREATE TABLE "u8kingdee"."u8_material_boms" (
  "cinv_name" text COLLATE "pg_catalog"."default",
  "create_user" text COLLATE "pg_catalog"."default",
  "parentscrap" text COLLATE "pg_catalog"."default",
  "version_desc" text COLLATE "pg_catalog"."default",
  "bom_type" text COLLATE "pg_catalog"."default",
  "version_eff_date" text COLLATE "pg_catalog"."default",
  "cinv_c_name" text COLLATE "pg_catalog"."default",
  "bom_id" text COLLATE "pg_catalog"."default",
  "cinv_c_code" text COLLATE "pg_catalog"."default"
)
;
ALTER TABLE "u8kingdee"."u8_material_boms" OWNER TO "postgres";

-- ----------------------------
-- Table structure for u8_materials
-- ----------------------------
DROP TABLE IF EXISTS "u8kingdee"."u8_materials";
CREATE TABLE "u8kingdee"."u8_materials" (
  "recursive_flag" text COLLATE "pg_catalog"."default",
  "wh_code" text COLLATE "pg_catalog"."default",
  "cinv_code" text COLLATE "pg_catalog"."default",
  "cinv_name" text COLLATE "pg_catalog"."default",
  "optional_flag" text COLLATE "pg_catalog"."default",
  "cwh_name" text COLLATE "pg_catalog"."default",
  "op_component_id" text COLLATE "pg_catalog"."default",
  "product_type" text COLLATE "pg_catalog"."default",
  "draw_dept_code" text COLLATE "pg_catalog"."default",
  "cdep_name" text COLLATE "pg_catalog"."default",
  "bom_id" text COLLATE "pg_catalog"."default"
)
;
ALTER TABLE "u8kingdee"."u8_materials" OWNER TO "postgres";

-- ----------------------------
-- Table structure for u8_people
-- ----------------------------
DROP TABLE IF EXISTS "u8kingdee"."u8_people";
CREATE TABLE "u8kingdee"."u8_people" (
  "person_grade_no" text COLLATE "pg_catalog"."default",
  "department_no" text COLLATE "pg_catalog"."default",
  "month" int8,
  "salary_grade_no" text COLLATE "pg_catalog"."default",
  "year" int8,
  "person_name" text COLLATE "pg_catalog"."default",
  "person_no" text COLLATE "pg_catalog"."default"
)
;
ALTER TABLE "u8kingdee"."u8_people" OWNER TO "postgres";

-- ----------------------------
-- Table structure for u8_production_orders
-- ----------------------------
DROP TABLE IF EXISTS "u8kingdee"."u8_production_orders";
CREATE TABLE "u8kingdee"."u8_production_orders" (
  "code" text COLLATE "pg_catalog"."default",
  "name" text COLLATE "pg_catalog"."default",
  "pk_org" text COLLATE "pg_catalog"."default",
  "operator_type" text COLLATE "pg_catalog"."default"
)
;
ALTER TABLE "u8kingdee"."u8_production_orders" OWNER TO "postgres";

-- ----------------------------
-- Table structure for u8_suppliers
-- ----------------------------
DROP TABLE IF EXISTS "u8kingdee"."u8_suppliers";
CREATE TABLE "u8kingdee"."u8_suppliers" (
  "bank_acc_number" int8,
  "abbr_name" text COLLATE "pg_catalog"."default",
  "name" text COLLATE "pg_catalog"."default",
  "bank_open" text COLLATE "pg_catalog"."default",
  "code" text COLLATE "pg_catalog"."default",
  "sort_code" text COLLATE "pg_catalog"."default"
)
;
ALTER TABLE "u8kingdee"."u8_suppliers" OWNER TO "postgres";

-- ----------------------------
-- Table structure for u8_task_centers
-- ----------------------------
DROP TABLE IF EXISTS "u8kingdee"."u8_task_centers";
CREATE TABLE "u8kingdee"."u8_task_centers" (
  "vrow_no" text COLLATE "pg_catalog"."default",
  "cbwr_ast_unit_id" text COLLATE "pg_catalog"."default",
  "cbwr_unit_id" text COLLATE "pg_catalog"."default",
  "nbwr_ast_num" numeric,
  "nbwr_num" numeric,
  "cb_dept_vid" text COLLATE "pg_catalog"."default",
  "cb_wk_id" text COLLATE "pg_catalog"."default",
  "cb_team_id" text COLLATE "pg_catalog"."default",
  "c_activity_id" text COLLATE "pg_catalog"."default",
  "d_task_date" text COLLATE "pg_catalog"."default",
  "n_stand_num" numeric,
  "n_act_num" numeric
)
;
ALTER TABLE "u8kingdee"."u8_task_centers" OWNER TO "postgres";

-- ----------------------------
-- Table structure for u8_units
-- ----------------------------
DROP TABLE IF EXISTS "u8kingdee"."u8_units";
CREATE TABLE "u8kingdee"."u8_units" (
  "group_code" text COLLATE "pg_catalog"."default",
  "name" text COLLATE "pg_catalog"."default",
  "main_flag" int8,
  "code" text COLLATE "pg_catalog"."default"
)
;
ALTER TABLE "u8kingdee"."u8_units" OWNER TO "postgres";