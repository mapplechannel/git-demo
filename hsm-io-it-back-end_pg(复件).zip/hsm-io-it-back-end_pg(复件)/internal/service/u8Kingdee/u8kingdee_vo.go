package u8kingdee

type U8TaskCenter struct {
	VrowNo        string  `json:"vrowno"`
	CbwrAstUnitId string  `json:"cbwrastunitid"`
	CbwrUnitId    string  `json:"cbwrunitid"`
	NbwrAstNum    float64 `json:"nbwrastnum"`
	NbwrNum       float64 `json:"nbwrnum"`
	CbDeptVid     string  `json:"cbdeptvid"`
	CbWkId        string  `json:"cbwkid"`
	CbTeamId      string  `json:"cbteamid"`
	CActivityId   string  `json:"cactivityid"`
	DTaskDate     string  `json:"dtaskdate"`
	NStandNum     float64 `json:"nstandnum"`
	NActNum       float64 `json:"nactnum"`
}

type U8Department struct {
	Rank    int    `json:"rank"`
	Name    string `json:"name"`
	Code    string `json:"code"`
	EndFlag int    `json:"endflag"`
}

type U8Supplier struct {
	BankAccNumber int64  `json:"bank_acc_number"`
	AbbrName      string `json:"abbrname"`
	Name          string `json:"name"`
	BankOpen      string `json:"bank_open"`
	Code          string `json:"code"`
	SortCode      string `json:"sort_code"`
}

type U8Unit struct {
	GroupCode string `json:"group_code"`
	Name      string `json:"name"`
	MainFlag  int    `json:"main_flag"`
	Code      string `json:"code"`
}

type U8CustomerData struct {
	AbbrName   string `json:"abbrname"`
	Name       string `json:"name"`
	DomainCode string `json:"domain_code"`
	Code       string `json:"code"`
	Industry   string `json:"industry"`
	Contact    string `json:"contact"`
	SortCode   string `json:"sort_code"`
	Mobile     int64  `json:"mobile"`
}

type U8Person struct {
	PersonGradeNo string `json:"persongradeno"`
	DepartmentNo  string `json:"departmentno"`
	Month         int    `json:"month"`
	SalaryGradeNo string `json:"salarygradeno"`
	Year          int    `json:"year"`
	PersonName    string `json:"personname"`
	PersonNo      string `json:"personno"`
}

type U8ProductionOrder struct {
	Code         string `json:"code"`
	Name         string `json:"name"`
	PkOrg        string `json:"pk_org"`
	OperatorType string `json:"operatorType"`
}

type U8Material struct {
	RecursiveFlag string `json:"recursiveflag"`
	WhCode        string `json:"whcode"`
	CinvCode      string `json:"cinvcode"`
	CinvName      string `json:"cinvname"`
	OptionalFlag  string `json:"optionalflag"`
	CwhName       string `json:"cwhname"`
	OpComponentId string `json:"opcomponentid"`
	ProductType   string `json:"producttype"`
	DrawDeptCode  string `json:"drawdeptcode"`
	CdepName      string `json:"cdepname"`
	BomId         string `json:"bomid"`
}

type U8MaterialBOM struct {
	CinvName       string `json:"cinvname"`
	CreateUser     string `json:"createuser"`
	Parentscrap    string `json:"parentscrap"`
	VersionDesc    string `json:"versiondesc"`
	BomType        string `json:"bomtype"`
	VersionEffDate string `json:"versioneffdate"`
	CinvCName      string `json:"cinvcname"`
	BomId          string `json:"bomid"`
	CinvCCode      string `json:"cinvccode"`
}

// kingdee
type KingdeeDepartment struct {
	FUseOrgId    string `json:"fuseorgid"`
	FCreateOrgId string `json:"fcreateorgid"`
	FName        string `json:"fname"`
}

type KingdeeWorkCenter struct {
	FUseOrgId      string `json:"fuseorgid"`
	FEffectDate    string `json:"feffectdate"`
	FName          string `json:"fname"`
	FCreateOrgId   string `json:"fcreateorgid"`
	FOptCtrlCodeID string `json:"foptctrlcodeid"`
	FDeptID        string `json:"fdeptid"`
	FExpireDate    string `json:"fexpiredate"`
}

type KingdeeSupplier struct {
	FLocAddress    string `json:"flocaddress"`
	FLocName       string `json:"flocname"`
	FLocMobile     string `json:"flocmobile"`
	FLocNewContact string `json:"flocnewcontact"`
}

type KingdeePlanOrder struct {
	FMaterialId    string `json:"fmaterialid"`
	FInStockOrgId  string `json:"finstockorgid"`
	FDemandOrgId   string `json:"fdemandorgid"`
	FPlanStartDate string `json:"fplanstartdate"`
	FSupplyOrgId   string `json:"fsupplyorgid"`
}

type KingdeeUnit struct {
	FNumber         string `json:"fnumber"`
	FCurrentUnit    string `json:"fcurrentunit"`
	FOldNumber      string `json:"foldnumber"`
	FDocumentStatus string `json:"fdocumentstatus"`
	FIsBaseUnit     bool   `json:"fisbaseunit"`
	FIsSystemSet    bool   `json:"fisystemset"`
	FName           string `json:"fname"`
	FPrecision      int    `json:"fprecision"`
}

type KingdeeCustomer struct {
	FTradingCurrId string `json:"ftradingcurrid"`
	FName          string `json:"fname"`
	FCreateOrgId   string `json:"fcreateorgid"`
}

type KingdeeProductionOrder struct {
	FPrdOrgId    string `json:"fprdorgid"`
	FOwnerTypeId string `json:"fownertypeid"`
	FBillType    string `json:"fbilltype"`
	FDate        string `json:"fdate"`
	FPPBOMType   string `json:"fppbomtype"`
}

type KingdeeMaterial struct {
	FCreatorId     string `json:"fcreatorid"`
	FExtVar        string `json:"fextvar"`
	FOldNumber     string `json:"foldnumber"`
	FDescription   string `json:"fdescription"`
	FMaterialGroup string `json:"fmaterialgroup"`
	FBaseProperty  string `json:"fbaseproperty"`
	FMaterialSRC   string `json:"fmaterialsrc"`
	FSpecification string `json:"fspecification"`
	FPLMMaterialId string `json:"fplmmaterialid"`
	FNumber        string `json:"fnumber"`
	FEqpClsID      string `json:"feqpclsid"`
}

type KingdeeBOM struct {
	FCreateOrgId        string `json:"fcreateorgid"`
	FMaterialId         string `json:"fmaterialid"`
	FBomCategory        string `json:"fbomcategory"`
	FBomUse             string `json:"fbomuse"`
	FIsBaseUnit         bool   `json:"fisbaseunit"`
	FIsSystemSet        bool   `json:"fisystemset"`
	FName               string `json:"fname"`
	FPrecision          int    `json:"fprecision"`
	FUnitId             string `json:"funitid"`
	FMaterialIdChild    string `json:"fmaterialidchild"`
	FIssueType          string `json:"fissuetype"`
	FOwnerTypeId        string `json:"fownertypeid"`
	FDosageType         string `json:"fdosagetype"`
	FUnitIdLot          string `json:"funitidlot"`
	FMaterialIdLotBased string `json:"fmaterialidlotbased"`
	FCobyType           string `json:"fcobytype"`
	FMaterialIdCoby     string `json:"fmaterialidcoby"`
}

type KingdeeEmployee struct {
	FStaffNumber string `json:"fstaffnumber"`
	FCreateOrgId string `json:"fcreateorgid"`
	FJoinDate    string `json:"fjoindate"`
	FUseOrgId    string `json:"fuseorgid"`
	FName        string `json:"fname"`
}

// 产品入库
type U8ProductIn struct {
	Date           string `json:"date"`
	DepartmentCode string `json:"departmentcode"`
	WarehouseName  string `json:"warehousename"`
	Maker          string `json:"maker"`
	BusinessType   string `json:"businesstype"`
	DepartmentName string `json:"departmentname"`
	Code           string `json:"code"`
	ReceiveName    string `json:"receivename"`
	ReceiveCode    string `json:"receivecode"`
	AuditDate      string `json:"auditdate"`
	WarehouseCode  string `json:"warehousecode"`
	Handler        string `json:"handler"`
}

type KingdeeProductIn struct {
	FMaterialId    string `json:"fmaterialid"`
	FOwnerId       string `json:"fownerid"`
	FKeeperId      string `json:"fkeeperid"`
	FUnitID        string `json:"funitid"`
	FOwnerTypeId   string `json:"fownertypeid"`
	FKeeperTypeId  string `json:"fkeepertypeid"`
	FBaseUnitId    string `json:"fbaseunitid"`
	FInStockType   string `json:"finstocktype"`
	FMoBillNo      string `json:"fmobillno"`
	FStockStatusId string `json:"fstockstatusid"`
	FStockId       string `json:"fstockid"`
}
