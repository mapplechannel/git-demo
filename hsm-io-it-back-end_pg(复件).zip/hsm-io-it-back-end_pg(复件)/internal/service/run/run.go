package run

import (
	"context"
	"encoding/json"
	"fmt"
	"runtime/debug"
	"sync"
	"time"

	_ "hsm-io-it-back-end/pkg/benthos/public/components/all"
	"hsm-io-it-back-end/pkg/logger"

	"hsm-io-it-back-end/pkg/benthos/public/service"
)

var ChanResult = make(chan string)

var m sync.Mutex
var codeJob string
var nameSpace string

func ExecuteJob(code, yaml string) bool {
	defer func() {
		if msg := recover(); msg != nil {
			logger.Error("ExecuteJob recover with msg:%v", msg)
			logger.Error("ExecuteJob debug.Stack:%s", string(debug.Stack()))
		}
	}()
	// m.Lock()

	codeJob = code

	// 定义通道变量，用于解决code未被缓存的问题
	isStore := make(chan bool)

	// 每次调度都会产生一个流，判断当流已经存在时，先停止当前流
	// _, ok := streamMap_corn.Load(code)
	// if ok {
	// 	logger.Info("进入停止逻辑")
	// 	Stop_corn(code)
	// }

	exceuteBenthos(code, yaml, isStore)

	<-isStore
	// logger.Info("corn调度取出的通道值为，%v", v)

	// m.Unlock()
	return true
}

type TestOutput struct{}

func (b *TestOutput) Connect(ctx context.Context) error {
	return nil
}

// var DataMap sync.Map

func (b *TestOutput) Write(ctx context.Context, msg *service.Message) error {
	content, err := msg.AsBytes()
	if err != nil {
		return err
	}

	fmt.Println("数据：", string(content))
	return nil
}

func (b *TestOutput) Close(ctx context.Context) error {
	return nil
}

var streamMap sync.Map

var streamMap_corn sync.Map

// func exceuteBenthos(code, namespace, yaml string) {
func exceuteBenthos(code, yaml string, isStore chan<- bool) {

	panicOnErr := func(err error) {
		if err != nil {
			logger.Info("err is :%v", err)
		}
	}

	err := service.RegisterOutput(
		"test_stdout", service.NewConfigSpec(),
		func(conf *service.ParsedConfig, mgr *service.Resources) (out service.Output, maxInFlight int, err error) {
			return &TestOutput{}, 1, nil
		})

	if err != nil {
		panic(err)
	}

	configSpec := service.NewConfigSpec()

	constructor := func(conf *service.ParsedConfig, mgr *service.Resources) (service.Processor, error) {
		return newReverseProcessor(mgr.Logger(), mgr.Metrics()), nil
	}

	err = service.RegisterProcessor("mes_json", configSpec, constructor)
	if err != nil {
		panic(err)
	}

	builder := service.NewStreamBuilder()
	err = builder.SetYAML(yaml)

	panicOnErr(err)
	// Build a stream with our configured components.
	stream, err := builder.Build()

	panicOnErr(err)
	// 修改停止时流没有结束的bug，1.先将流保存下来
	streamMap_corn.Store(code, stream)

	// 这行发生panic了，logger框架不支持打印此map? 请排查
	// logger.Info("streamMap_corn:%v", streamMap_corn)

	go func() {
		isStore <- true
	}()

	logger.Info("start run")

	err = stream.Run(context.Background())

	panicOnErr(err)

	// var wg sync.WaitGroup
	// wg.Add(1)
	// go func() {
	// 	defer wg.Done()
	// 	panicOnErr(stream.Run(context.Background()))
	// }()
	// wg.Wait()

}

// 修改停止时流没有结束的bug，2.删除流
func Stop_corn(code string) {

	value, ok := streamMap_corn.Load(code)
	if !ok {
		logger.Info("%s作业不存在", code)
		return
	}
	stream := value.(*service.Stream)
	streamMap_corn.Delete(code)
	stream.StopWithin(time.Second * 1)
	// logger.Info("streamMap_corn:%v", streamMap_corn)
	logger.Info("%s作业已停止", code)
}

func ExceuteHttpBenthos(code, yaml string, isStore chan<- bool) {
	panicOnErr := func(err error) {
		if err != nil {
			logger.Info("err is :%v", err)
		}
	}
	err := service.RegisterOutput(
		"test_stdout", service.NewConfigSpec(),
		func(conf *service.ParsedConfig, mgr *service.Resources) (out service.Output, maxInFlight int, err error) {
			return &TestOutput{}, 1, nil
		})
	if err != nil {
		panic(err)
	}

	configSpec := service.NewConfigSpec()

	constructor := func(conf *service.ParsedConfig, mgr *service.Resources) (service.Processor, error) {
		return newReverseProcessor(mgr.Logger(), mgr.Metrics()), nil
	}

	err = service.RegisterProcessor("mes_json", configSpec, constructor)
	if err != nil {
		panic(err)
	}

	builder := service.NewStreamBuilder()
	err = builder.SetYAML(yaml)
	panicOnErr(err)
	// Build a stream with our configured components.
	stream, err := builder.Build()
	panicOnErr(err)
	streamMap.Store(code, stream)

	go func() {
		isStore <- true
	}()
	// And run it, blocking until it gracefully terminates once the generate
	// input has generated a message and it has flushed through the stream.
	logger.Info("benthos开始执行")
	err = stream.Run(context.Background())
	panicOnErr(err)
}

func Stop(code string) {

	value, ok := streamMap.Load(code)
	if !ok {
		logger.Info("%s作业不存在", code)
		return
	}
	stream := value.(*service.Stream)
	stream.StopWithin(time.Second * 1)
	streamMap.Delete(code)
	logger.Info("%s作业已停止", code)
}

// *****************************mes_json***********************
type reverseProcessor struct {
	logger *service.Logger
}

func newReverseProcessor(logger *service.Logger, metrics *service.Metrics) *reverseProcessor {
	// The logger and metrics components will already be labelled with the
	// identifier of this component within a config.
	return &reverseProcessor{
		logger: logger,
	}
}

func (r *reverseProcessor) Process(ctx context.Context, m *service.Message) (service.MessageBatch, error) {
	bytesContent, err := m.AsBytes()
	if err != nil {
		return nil, err
	}
	fmt.Println("process")
	newBytes := processBytes(bytesContent)

	m.SetBytes(newBytes)
	return []*service.Message{m}, nil
}

func (r *reverseProcessor) Close(ctx context.Context) error {
	return nil
}

func processBytes(data []byte) []byte {
	// 定义一个空的interface{}变量
	var result interface{}

	// 将字节流反序列化为interface{}类型的数据
	err := json.Unmarshal(data, &result)
	if err != nil {
		return nil
	}
	fmt.Println("ProcessMap")

	// 调用processMap方法处理数据
	ProcessMap(result)
	newBytes, _ := json.Marshal(result)
	if err != nil {
		return nil
	}
	return newBytes
}

func ProcessMap(data interface{}) {

	switch v := data.(type) {
	case map[string]interface{}:
		for key, value := range v {
			if attrs, ok := value.(map[string]interface{}); ok {
				if nilValue, exists := attrs["-nil"]; exists {
					if va, ok := nilValue.(bool); ok && va {fmt.Println(va) 
						v[key] = nil
					} else {if _, textExists := attrs["#text"]; textExists {v[key] = attrs["#text"]}}
				} else {ProcessMap(value)}
			} else {ProcessMap(value)}}
	case []interface{}:
		for _, item := range v {
			ProcessMap(item)
		}
	default:
		logger.Info("case is fault")
	}
}
