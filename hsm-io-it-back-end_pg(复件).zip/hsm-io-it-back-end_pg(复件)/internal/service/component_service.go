package service

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"hsm-io-it-back-end/config"
	"hsm-io-it-back-end/internal/constants"
	"hsm-io-it-back-end/internal/util"
	"hsm-io-it-back-end/internal/vo"
	"hsm-io-it-back-end/pkg/benthos/public/service"
	"hsm-io-it-back-end/pkg/logger"
	"hsm-io-it-back-end/response"
	"html/template"
	"io"
	"io/ioutil"
	"log"
	"math/rand"
	"net"
	"path/filepath"
	"reflect"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"
	"unicode/utf8"

	_ "github.com/go-sql-driver/mysql"
	"github.com/pkg/sftp"
	"golang.org/x/crypto/ssh"

	"encoding/csv"
	"encoding/json"
	"os"
)

// ftp连接客户端
var ftpConect *sftp.Client

type Database struct {
	Name string `json:"name"`
}

type Table struct {
	Name string `json:"name"`
}
type TableAndType struct {
	Name string `json:"name"`
	Type string `json:"type"`
}
type Column struct {
	Name    string `json:"name"`
	Type    string `json:"type"`
	Comment string `json:"comment"`
}

type ColumnPG struct {
	Name    string         `json:"name"`
	Type    string         `json:"type"`
	Comment sql.NullString `json:"comment"`
}
type tableColumn struct {
	ColumnName    string         `json:"column_name"`    // 字段名称
	ColumnComment sql.NullString `json:"column_comment"` // 字段注释
}

type tableColumnSL struct {
	ColumnName    string `json:"column_name"`    // 字段名称
	ColumnComment string `json:"column_comment"` // 字段注释
}

type SearchMySQLResponse struct {
	Cols     []string                 `json:"cols"`      // 查询后的行
	ColsInfo []tableColumn            `json:"cols_info"` // 行信息
	List     []map[string]interface{} `json:"list"`      // 查询后的数据
}

type FileInfo struct {
	Name       string `json:"name"`
	Type       string `json:"type"`
	Size       int64  `json:"size"`
	ParentPath string `json:"parentPath"`
}

// 生成数据库连接信息编码
func generateMysqlCode() string {
	rand.Seed(time.Now().UnixNano())
	code := "mysql_"
	for i := 0; i < 8; i++ {
		code += fmt.Sprintf("%d", rand.Intn(10))
	}
	return code
}

// 测试连接mysql数据库
func ConnectMysqlTest(mysqlInfoRequest *vo.DatabaseInfoRequest) (bool, string) {
	//组装连接参数
	userName := mysqlInfoRequest.Username
	password := mysqlInfoRequest.Password
	host := mysqlInfoRequest.Host
	port := mysqlInfoRequest.Port
	url := userName + ":" + password + "@tcp(" + host + ":" + port + ")/"

	db, err := sql.Open("mysql", url)
	if err != nil {
		return false, "连接失败"
	}

	// 关闭连接
	defer db.Close()

	db.SetConnMaxIdleTime(time.Minute * 1)
	db.SetConnMaxLifetime(time.Minute * 1)
	db.SetMaxOpenConns(10)
	db.SetMaxIdleConns(10)
	err = db.Ping()

	retry, _ := strconv.Atoi(mysqlInfoRequest.Retry)
	if err != nil {
		for i := retry; i > 0; i-- {
			err = db.Ping()
			if err == nil {
				break
			}
			time.Sleep(500 * time.Millisecond)
		}

		if err != nil {
			return false, "数据库连接失败"
		}
	}
	logger.Info("连接成功")
	return true, "连接成功"
}

func AddConenctMySql(mysqlInfoRequest *vo.DatabaseInfoRequest) (bool, string) {

	flag := util.IsExistDatabase(mysqlInfoRequest.ConnectName, mysqlInfoRequest.Namespace, "MySQL")

	if flag {
		return false, "不能创建相同类型的同名数据源，请重新输入"
	}

	code := generateMysqlCode()
	mysqlInfoRequest.Code = code

	dbPG, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, ""
	}
	defer dbPG.Close()

	addsql := `INSERT INTO ioit.database_info (
					code, namespace, connectname, username, password, host, port, 
					databasetype, s_node, dbname, schemaname, tablename, dbpath,retry) 
			VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)`

	_, err = dbPG.Exec(addsql,
		mysqlInfoRequest.Code, mysqlInfoRequest.Namespace, mysqlInfoRequest.ConnectName,
		mysqlInfoRequest.Username, mysqlInfoRequest.Password, mysqlInfoRequest.Host,
		mysqlInfoRequest.Port, "MySQL", "unpublish", mysqlInfoRequest.DbName,
		mysqlInfoRequest.SchemaName, mysqlInfoRequest.Tablename, mysqlInfoRequest.DbPath, mysqlInfoRequest.Retry)

	if err != nil {
		logger.Info("数据库插入失败:%v", err)
		return false, "数据库插入失败"
	}

	url := mysqlInfoRequest.Username + ":" + mysqlInfoRequest.Password + "@tcp(" + mysqlInfoRequest.Host + ":" + mysqlInfoRequest.Port + ")/"

	db, err := sql.Open("mysql", url)
	if err != nil {
		return false, "连接失败"
	}
	db.SetConnMaxIdleTime(time.Minute * 10)
	db.SetConnMaxLifetime(time.Minute * 10)
	db.SetMaxOpenConns(10)
	db.SetMaxIdleConns(10)
	err = db.Ping()
	if err != nil {
		logger.Error(err)
		return false, "连接失败"
	}
	logger.Info("连接成功")
	defer db.Close()
	return true, code
}

type MysqlResponseInfo struct {
	Code         string `json:"code"`
	Namespace    string `json:"namespace"`
	ConnectName  string `json:"connectname"`
	Username     string `json:"username"`
	Password     string `json:"password"`
	Host         string `json:"host"`
	Port         string `json:"port"`
	DataBaseType string `json:"databasetype"`
	Retry        int    `json:"retry"`
}

// 获取数据库连接
func GetConnectInfo(mysqlListInfo *vo.DatabaseInfoRequest) (bool, []MysqlResponseInfo) {

	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, nil
	}
	defer db.Close()

	query := `SELECT 
					code, namespace, connectname, username, 
					password, host, port, databasetype, retry 
			FROM ioit.database_info WHERE namespace = $1 AND databasetype = MySQL`

	rows, err := db.Query(query, mysqlListInfo.Namespace)

	if err != nil {
		return false, nil
	}

	defer rows.Close()

	var infos []MysqlResponseInfo

	for rows.Next() {
		var info MysqlResponseInfo
		err = rows.Scan(&info.Code, &info.Namespace, &info.ConnectName,
			&info.Username, &info.Password, &info.Host, &info.Port, &info.DataBaseType, &info.Retry)
		if err != nil {
			return false, nil
		}
		infos = append(infos, info)
	}

	return true, infos
}

// 更新数据库连接
func UpdateConnect(mysqlInfo *vo.DatabaseInfoRequest) (bool, string) {

	flag := util.IsUpdateExistDatabase(mysqlInfo.ConnectName, mysqlInfo.Namespace, mysqlInfo.DataBaseType, mysqlInfo.Code)

	if flag {
		return false, "不能创建相同类型的同名数据源，请重新编辑"
	}

	dbPG, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, "数据库连接失败"
	}
	defer dbPG.Close()

	updatesql := `UPDATE ioit.database_info SET 
					connectname=$1,	username=$2, password=$3, host=$4, port=$5, retry=$6
				WHERE namespace = $7 AND code = $8 `

	_, err = dbPG.Exec(updatesql,
		mysqlInfo.ConnectName, mysqlInfo.Username, mysqlInfo.Password, mysqlInfo.Host, mysqlInfo.Port,
		mysqlInfo.Retry, mysqlInfo.Namespace, mysqlInfo.Code)

	if err != nil {
		logger.Info("数据库连接更新失败%v", err)
		return false, "数据库连接更新失败"
	}

	logger.Info("数据库连接信息更新: %v", flag)

	return true, "更新成功"
}

func GetConenctMySql(mysqlInfoRequest *vo.DatabaseInfoRequest) (bool, []Database) {
	// 组装连接参数
	userName := mysqlInfoRequest.Username
	password := mysqlInfoRequest.Password
	host := mysqlInfoRequest.Host
	port := mysqlInfoRequest.Port
	url := userName + ":" + password + "@tcp(" + host + ":" + port + ")/"

	db, err := sql.Open("mysql", url)
	if err != nil {
		return false, nil
	}
	db.SetConnMaxIdleTime(time.Minute * 10)
	db.SetConnMaxLifetime(time.Minute * 10)
	db.SetMaxOpenConns(10)
	db.SetMaxIdleConns(10)

	err = db.Ping()
	if err != nil {
		logger.Error(err)
		return false, nil
	}
	logger.Info("连接成功")

	defer db.Close()

	rows, err := db.Query("SHOW DATABASES")
	if err != nil {
		return false, nil
	}
	defer rows.Close()
	// 封装所有数据库信息
	var databases []Database
	for rows.Next() {
		var database Database
		if err := rows.Scan(&database.Name); err != nil {
			return false, nil
		}
		databases = append(databases, database)
	}
	return true, databases
}

func connectToMySQL(url string) (*sql.DB, error) {
	db, err := sql.Open("mysql", url)
	if err != nil {
		fmt.Println(err)
		return nil, err
	}
	db.SetConnMaxIdleTime(time.Minute * 10)
	db.SetConnMaxLifetime(time.Minute * 10)
	db.SetMaxOpenConns(10)
	db.SetMaxIdleConns(10)

	err = db.Ping()
	if err != nil {
		logger.Error(err)
		return nil, err
	}
	fmt.Println("连接成功")
	logger.Info(" ->连接成功")

	return db, nil
}

func GetTable(mysqlInfoRequest *vo.DatabaseInfoRequest) (bool, []TableAndType, string) {
	userName := mysqlInfoRequest.Username
	password := mysqlInfoRequest.Password
	host := mysqlInfoRequest.Host
	port := mysqlInfoRequest.Port
	url := userName + ":" + password + "@tcp(" + host + ":" + port + ")/"

	db, err := connectToMySQL(url)
	if err != nil {
		return false, nil, "数据库连接错误，请重试"
	}

	defer db.Close()

	// 连接到指定的数据库
	_, err1 := db.Exec("USE " + mysqlInfoRequest.DbName)
	if err1 != nil {
		return false, nil, "连接指定数据库错误，请重试"
	}

	// 查询所有表
	rows, err := db.Query("SHOW FULL TABLES")
	if err != nil {
		return false, nil, "查询数据库表错误"
	}
	defer rows.Close()
	// 封装所有表信息
	var tables []TableAndType
	for rows.Next() {
		var table TableAndType
		if err := rows.Scan(&table.Name, &table.Type); err != nil {
			return false, nil, "查询表信息错误"
		}

		tables = append(tables, table)
	}
	return true, tables, "查询表信息成功"
}

func GetTablePrimary(mysqlInfoRequest *vo.DatabaseInfoRequest) (bool, []string) {
	userName := mysqlInfoRequest.Username
	password := mysqlInfoRequest.Password
	host := mysqlInfoRequest.Host
	port := mysqlInfoRequest.Port
	url := userName + ":" + password + "@tcp(" + host + ":" + port + ")/"

	db, err := connectToMySQL(url)
	if err != nil {
		return false, nil
	}

	defer db.Close()

	// 连接到指定的数据库
	_, err1 := db.Exec("USE " + mysqlInfoRequest.DbName)
	if err1 != nil {
		return false, nil
	}
	// 查询当前表的所有字段
	rows, err := db.Query(fmt.Sprintf("SELECT column_name FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE WHERE table_name='%s' AND constraint_name='PRIMARY'", mysqlInfoRequest.Tablename))
	if err != nil {
		return false, nil
	}
	defer rows.Close()

	// 封装所有字段信息
	var columns []string
	for rows.Next() {
		var column string
		if err := rows.Scan(&column); err != nil {
			return false, nil
		}
		columns = append(columns, column)
	}
	// 返回所有字段信息
	return true, columns
}

func GetTableColumns(mysqlInfoRequest *vo.DatabaseInfoRequest) (bool, []Column) {
	userName := mysqlInfoRequest.Username
	password := mysqlInfoRequest.Password
	host := mysqlInfoRequest.Host
	port := mysqlInfoRequest.Port
	url := userName + ":" + password + "@tcp(" + host + ":" + port + ")/"

	db, err := connectToMySQL(url)
	if err != nil {
		return false, nil
	}
	defer db.Close()

	// 连接到指定的数据库
	_, err1 := db.Exec("USE " + mysqlInfoRequest.DbName)
	if err1 != nil {
		return false, nil
	}
	// 查询当前表的所有字段
	rows, err := db.Query(
		fmt.Sprintf("SELECT COLUMN_NAME,COLUMN_TYPE,COLUMN_COMMENT FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '%s' AND TABLE_NAME = '%s'",
			mysqlInfoRequest.DbName, mysqlInfoRequest.Tablename))

	if err != nil {
		return false, nil
	}
	defer rows.Close()
	// 封装所有字段信息
	var columns []Column
	for rows.Next() {
		var column Column
		if err := rows.Scan(&column.Name, &column.Type, &column.Comment); err != nil {
			return false, nil
		}
		columns = append(columns, column)
	}
	for i, v := range columns {
		if v.Type == "bit(1)" {
			columns[i].Name = "bin(" + columns[i].Name + ")"
		}
	}
	// 返回所有字段信息
	return true, columns
}
func GetTableData(mysqlInfoRequest *vo.DatabaseInfoRequest) (bool, SearchMySQLResponse, string) {
	res := SearchMySQLResponse{}

	userName := mysqlInfoRequest.Username
	password := mysqlInfoRequest.Password
	host := mysqlInfoRequest.Host
	port := mysqlInfoRequest.Port
	url := userName + ":" + password + "@tcp(" + host + ":" + port + ")/"

	db, err := connectToMySQL(url)
	if err != nil {
		return false, res, "查询失败"
	}

	defer db.Close()

	flag := ContainsComplexQuery(mysqlInfoRequest.SQL)
	if flag {
		return false, res, "不支持复杂查询"
	}
	// if err != nil {
	// 	return false, res, err.Error()
	// }

	// 连接到指定的数据库
	_, err1 := db.Exec("USE " + mysqlInfoRequest.DbName)
	if err1 != nil {
		return false, res, "查询失败"
	}
	// 查询当前表的所有字段
	rows, err := db.Query(mysqlInfoRequest.SQL)
	if err != nil {
		logger.Info("err is:%v", err)
		if isUnknowColumnMysql(err) {
			return false, res, errToCN(err)
		}
		return false, res, "查询失败"
	}
	defer rows.Close()

	count := 0
	columnTypes, _ := rows.ColumnTypes()

	// 解析查询结果
	columns, _ := rows.Columns()
	var results []map[string]interface{}
	for rows.Next() {
		count++
		if count > 1000 {
			// return false, res, "支持预览1000条数据"
			logger.Info("支持预览1000条数据")
			break
		}
		values := make([]interface{}, len(columns))
		valuePtrs := make([]interface{}, len(columns))
		for i := range columns {
			valuePtrs[i] = &values[i]
		}
		err = rows.Scan(valuePtrs...)
		if err != nil {
			continue
		}
		rowData := make(map[string]interface{})
		for i, col := range columns {
			val := valuePtrs[i].(*interface{})

			if *val == nil {
				rowData[col] = nil
				continue
			}

			if ToString(*val) == "" {
				rowData[col] = ""
				continue
			}

			switch columnTypes[i].DatabaseTypeName() {
			case "INT":
				v := ToString(*val)
				if v == "" {
					rowData[col] = nil
				} else {
					intv, _ := strconv.Atoi(v)
					rowData[col] = intv
				}

			case "FLOAT", "DOUBLE":
				if ToString(*val) == "" {
					rowData[col] = nil
				} else {
					floatv, _ := strconv.ParseFloat(ToString(*val), 64)
					rowData[col] = floatv
				}
			// case "DOUBLE":
			// 	if ToString(*val) == "" {
			// 		rowData[col] = nil
			// 	} else {
			// 		floatv, _ := strconv.ParseFloat(ToString(*val), 64)
			// 		rowData[col] = floatv
			// 	}
			default:
				rowData[col] = ToString(*val)
			}

		}
		results = append(results, rowData)
	}
	res.List = results
	res.Cols = columns
	sqlTableColumn := fmt.Sprintf("SELECT `COLUMN_NAME`, `COLUMN_COMMENT` FROM `information_schema`.`columns` WHERE `table_schema`= '%s' AND `table_name`= '%s' ORDER BY `ORDINAL_POSITION` ASC",
		mysqlInfoRequest.DbName, mysqlInfoRequest.Tablename)
	rowsCom, err := db.Query(sqlTableColumn)
	if err != nil {
		fmt.Println(err)
	}
	defer rowsCom.Close()

	var tableColumns []tableColumn

	for rowsCom.Next() {
		var column tableColumn
		err = rowsCom.Scan(
			&column.ColumnName,
			&column.ColumnComment)

		if err != nil {
			fmt.Printf("query table column scan error, detail is [%v]\n", err.Error())
			continue
		}

		tableColumns = append(tableColumns, column)
	}

	res.ColsInfo = tableColumns

	return true, res, "查询成功"
}

func isUnknowColumnMysql(err error) bool {
	return strings.Contains(err.Error(), "Unknown column")
}

func errToCN(err error) string {
	re := regexp.MustCompile(`Unknown column '(\w+)' in 'field list'`)
	matcher := re.FindStringSubmatch(err.Error())
	if len(matcher) == 2 {
		columnName := matcher[1]
		return fmt.Sprintf("查询的字段 '%s' 不存在", columnName)
	}
	return "查询时发生未知错误"
}

// func formatValue(val interface{}) interface{} {
// 	switch val.(type) {
// 	case time.Time:
// 		t := val.(time.Time)
// 		if t.IsZero() {
// 			return nil
// 		}
// 		switch t.Format("2006-01-02 15:04:05") {
// 		case "0000-00-00 00:00:00":
// 			return nil
// 		case "0001-01-01 00:00:00":
// 			return nil
// 		default:
// 			return t.Format("2006-01-02 15:04:05")
// 		}
// 	case []byte:
// 		str := string(val.([]byte))
// 		if str == "" {
// 			return nil
// 		} else {
// 			return str
// 		}
// 	case int:
// 		v, _ := strconv.Atoi(strconv.FormatInt(int64(val.(int32)), 10))
// 		return v
// 	default:
// 		return val
// 	}
// }

func ToString(i interface{}) string {
	v, _ := ToStringE(i)
	return v
}

// ToStringE casts an interface to a string type.
func ToStringE(i interface{}) (string, error) {
	i = indirectToStringerOrError(i)

	switch s := i.(type) {
	case string:
		return s, nil
	case bool:
		return strconv.FormatBool(s), nil
	case float64:
		return strconv.FormatFloat(s, 'f', -1, 64), nil
	case float32:
		return strconv.FormatFloat(float64(s), 'f', -1, 32), nil
	case int:
		return strconv.Itoa(s), nil
	case int64:
		return strconv.FormatInt(s, 10), nil
	case int32:
		return strconv.Itoa(int(s)), nil
	case int16:
		return strconv.FormatInt(int64(s), 10), nil
	case int8:
		return strconv.FormatInt(int64(s), 10), nil
	case uint:
		return strconv.FormatUint(uint64(s), 10), nil
	case uint64:
		return strconv.FormatUint(uint64(s), 10), nil
	case uint32:
		return strconv.FormatUint(uint64(s), 10), nil
	case uint16:
		return strconv.FormatUint(uint64(s), 10), nil
	case uint8:
		return strconv.FormatUint(uint64(s), 10), nil
	case []byte:
		return string(s), nil
	case template.HTML:
		return string(s), nil
	case template.URL:
		return string(s), nil
	case template.JS:
		return string(s), nil
	case template.CSS:
		return string(s), nil
	case template.HTMLAttr:
		return string(s), nil
	case nil:
		return "", nil
	case fmt.Stringer:
		return s.String(), nil
	case error:
		return s.Error(), nil
	default:
		return "", fmt.Errorf("unable to cast %#v of type %T to string", i, i)
	}
}

// From html/template/content.go
// Copyright 2011 The Go Authors. All rights reserved.
// indirectToStringerOrError returns the value, after dereferencing as many times
// as necessary to reach the base type (or nil) or an implementation of fmt.Stringer
// or error,
func indirectToStringerOrError(a interface{}) interface{} {
	if a == nil {
		return nil
	}

	var errorType = reflect.TypeOf((*error)(nil)).Elem()
	var fmtStringerType = reflect.TypeOf((*fmt.Stringer)(nil)).Elem()

	v := reflect.ValueOf(a)
	for !v.Type().Implements(fmtStringerType) && !v.Type().Implements(errorType) && v.Kind() == reflect.Ptr && !v.IsNil() {
		v = v.Elem()
	}
	return v.Interface()
}

// lushuai

var SftpInfo vo.SftpInfo

func NewSshClient(sftpInfo vo.SftpInfo) (*ssh.Client, error) {
	config := &ssh.ClientConfig{
		User: sftpInfo.User,
		Auth: []ssh.AuthMethod{
			ssh.Password(sftpInfo.Password),
		},
		HostKeyCallback: ssh.InsecureIgnoreHostKey(),
	}
	addr := sftpInfo.Host + ":" + sftpInfo.Port
	client, err := ssh.Dial("tcp", addr, config)
	if err != nil {
		return nil, err
	}
	return client, nil
}

func NewSftpClient(sshClient *ssh.Client) (*sftp.Client, error) {
	client, err := sftp.NewClient(sshClient)
	if err != nil {
		return nil, err
	}
	return client, nil
}

func CloseClient(sshClient *ssh.Client, sftpClient *sftp.Client) error {
	if sftpClient != nil {
		err := sftpClient.Close()
		if err != nil {
			return err
		}
	}
	if sshClient != nil {
		err := sshClient.Close()
		if err != nil {
			return err
		}
	}
	return nil
}

// 自动重连
func AutoRetry(re int, info vo.SftpInfo) (*ssh.Client, error) {
	sshClient, err := NewSshClient(info)
	if sshClient == nil {
		for i := re; i > 0; i-- {
			startTime := time.Now()
			println(i)
			sshClient, err = NewSshClient(info)
			if sshClient != nil {
				return sshClient, nil
			}
			if time.Since(startTime) > 3*time.Second {
				return nil, errors.New("连接超时")
			}
		}

		if err != nil {
			return nil, errors.New("ssh客户端创建失败")
		}
	}
	return sshClient, nil
}

func GetCatalog(files []os.FileInfo, sftpPath vo.SftpPath) (result []FileInfo) {
	for _, file := range files {
		name := file.Name()
		var fileType string
		var size int64
		if len(name) > 60 {
			continue
		}
		if file.IsDir() {
			name += string(filepath.Separator)
			fileType = "folder"
		} else {
			ext := filepath.Ext(name)
			size = file.Size()
			if ext == ".csv" || ext == ".txt" {
				if size > 10*1024*1024 {
					continue
				}
			}

			if ext == ".xml" || ext == ".json" {
				if size > 1024*1024 {
					continue
				}
			}

			if ext == ".csv" {
				fileType = "csv"
			} else if ext == ".txt" {
				fileType = "txt"
			} else if ext == ".json" {
				fileType = "json"
			} else if ext == ".xml" {
				fileType = "xml"
			} else {
				continue
			}

		}
		// size := file.Size() / 1024 // 获取文件大小（字节）
		//modTime := file.ModTime() // 获取文件修改时间（时间戳）
		result = append(result, FileInfo{
			Name: name,
			Type: fileType,
			Size: size,
			//ModTime:    modTime,
			ParentPath: sftpPath.Path,
		})
	}
	return result

}

type CSVD struct {
	Cols []string                 `json:"cols"`
	List []map[string]interface{} `json:"list"`
}

func ReadSftpCSV(file *sftp.File) (CSVD, error) {

	reader := csv.NewReader(file)

	var csvd CSVD

	head, err := reader.Read()
	if err != nil {
		return CSVD{}, err
	}
	csvd.Cols = head

	var count int

	for {
		record, err := reader.Read()
		if err == io.EOF {
			break
		}
		if err != nil {
			return CSVD{}, err
		}

		row := make(map[string]interface{})

		for i, field := range record {
			row[csvd.Cols[i]] = field
		}

		csvd.List = append(csvd.List, row)

		count++

		if count == 1000 {
			break
		}
	}

	return csvd, nil
}

func ReadSftpTxt(file *sftp.File) (string, error) {
	fileInfo, err := file.Stat()
	if err != nil {
		return "", err
	}

	fileSize := fileInfo.Size()
	const limit = 1024 * 1024

	var readSize int64

	if fileSize > limit {
		readSize = limit
	} else {
		readSize = fileSize
	}

	buffer := make([]byte, readSize)

	n, err := file.Read(buffer)
	if err != nil {
		return "", err
	}

	for !utf8.Valid(buffer[:n]) {
		n--
		if n <= 0 {
			return "", errors.New("Invalid UTF-8 encoding")
		}
	}

	rs := []rune(string(buffer[:n]))

	return string(rs), nil
}

func ReadSftpXml(file *sftp.File) (string, error) {
	fInfo, err := file.Stat()
	if err != nil {
		return "", err
	}

	fileSize := fInfo.Size()
	const limit = 1024 * 1024

	var readSize int64

	if fileSize > limit {
		readSize = limit
	} else {
		readSize = fileSize
	}

	buffer := make([]byte, readSize)

	n, err := file.Read(buffer)
	if err != nil {
		return "", err
	}

	for !utf8.Valid(buffer[:n]) {
		n--
		if n <= 0 {
			return "", errors.New("Invalid UTF-8 encoding")
		}
	}

	rs := []rune(string(buffer[:n]))

	return string(rs), nil
}

func ReadSftpJson(file *sftp.File) (interface{}, error) {

	decoder := json.NewDecoder(file)

	var data interface{}

	err := decoder.Decode(&data)

	if err != nil {
		return nil, err
	}

	return data, nil
}

func ReadCSV(CsvTxtInfo *vo.CsvTxtInfo) (CSVD, error) {
	filePath := CsvTxtInfo.Path

	file, err := os.Open(filePath)
	if err != nil {
		return CSVD{}, err
	}
	defer file.Close()

	reader := csv.NewReader(file)

	var csvd CSVD

	head, err := reader.Read()
	if err != nil {
		return CSVD{}, err
	}

	csvd.Cols = head

	var count int

	for {
		record, err := reader.Read()
		if err == io.EOF {
			break
		}
		if err != nil {
			return CSVD{}, err
		}

		row := make(map[string]interface{})

		for i, field := range record {
			row[csvd.Cols[i]] = field
		}

		csvd.List = append(csvd.List, row)

		count++

		if count == 1000 {
			break
		}
	}

	return csvd, nil
}

func ReadTxt(CsvTxtInfo *vo.CsvTxtInfo) (string, error) {
	fileInfo, err := os.Stat(CsvTxtInfo.Path)
	if err != nil {
		return "", err
	}
	fileSize := fileInfo.Size()

	const limit = 1024 * 1024

	var readSize int64

	if fileSize > limit {
		readSize = limit
	} else {
		readSize = fileSize
	}

	file, err := os.Open(CsvTxtInfo.Path)
	if err != nil {
		return "", err
	}
	defer file.Close()

	buffer := make([]byte, readSize)

	n, err := file.Read(buffer)
	if err != nil {
		return "", err
	}

	for !utf8.Valid(buffer[:n]) {
		n--
		if n <= 0 {
			return "", errors.New("Invalid UTF-8 encoding")
		}
	}

	rs := []rune(string(buffer[:n]))

	return string(rs), nil
}

func ReadJson(CsvTxtInfo *vo.CsvTxtInfo) (interface{}, error) {
	file, err := os.Open(CsvTxtInfo.Path)
	if err != nil {
		return "", err
	}
	defer file.Close()

	decoder := json.NewDecoder(file)

	var data interface{}

	err = decoder.Decode(&data)
	if err != nil {
		return "", err
	}

	return data, nil
}

func ReadXml(CsvTxtInfo *vo.CsvTxtInfo) (string, error) {
	data, err := ioutil.ReadFile(CsvTxtInfo.Path)
	if err != nil {
		return "", err
	}
	return string(data), nil
}

// lushuai over

// zhaoying

// 数据库连接信息
type Mode struct {
	Name string `json:"name"`
}

type SearchResponse struct {
	Cols     []string                 `json:"cols"`      // 查询后的行
	ColsInfo []tableColumn            `json:"cols_info"` // 行信息
	List     []map[string]interface{} `json:"list"`      // 查询后的数据
}

type SearchResponseSL struct {
	Cols     []string                 `json:"cols"`      // 查询后的行
	ColsInfo []tableColumnSL          `json:"cols_info"` // 行信息
	List     []map[string]interface{} `json:"list"`      // 查询后的数据
}

func connectToPosrGreSQL(url string) (*sql.DB, error) {
	db, err := sql.Open("postgres", url)
	if err != nil {
		return nil, err
	}
	db.SetConnMaxIdleTime(time.Minute * 10)
	db.SetConnMaxLifetime(time.Minute * 10)
	db.SetMaxOpenConns(10)
	db.SetMaxIdleConns(10)

	err = db.Ping()
	if err != nil {
		logger.Error(err)
		// logger.Error(url + " ->连接失败")
		return nil, err
	}
	logger.Info(" ->连接成功")

	return db, nil
}

// 测试连接postgresql数据库
func ConnectPGTest(pgInfoRequest *vo.DatabaseInfoRequest) (bool, string) {
	//组装连接参数
	userName := pgInfoRequest.Username
	password := pgInfoRequest.Password
	host := pgInfoRequest.Host
	port := pgInfoRequest.Port
	url := "host=" + host + " port=" + port + " user=" + userName + " password=" + password + " sslmode=disable"

	db, err := connectToPosrGreSQL(url)
	if err != nil {
		return false, "数据库连接失败"
	}

	defer db.Close()

	return true, "数据库连接成功"
}

func AddConnectPG(pgInfoRequest *vo.DatabaseInfoRequest) (bool, string) {

	flag := util.IsExistDatabase(pgInfoRequest.ConnectName, pgInfoRequest.Namespace, pgInfoRequest.DataBaseType)

	if flag {
		return false, "不能创建相同类型的同名数据源，请重新输入"
	}

	code := generateDataBaseCode(pgInfoRequest.DataBaseType)
	pgInfoRequest.Code = code

	dbPG, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, ""
	}
	defer dbPG.Close()

	addsql := `INSERT INTO ioit.database_info (
					code, namespace, connectname, username, password, host, port, 
					databasetype, s_node, dbname, schemaname, tablename, dbpath,retry) 
			VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)`

	_, err = dbPG.Exec(addsql,
		pgInfoRequest.Code, pgInfoRequest.Namespace, pgInfoRequest.ConnectName,
		pgInfoRequest.Username, pgInfoRequest.Password, pgInfoRequest.Host,
		pgInfoRequest.Port, pgInfoRequest.DataBaseType, "unpublish", pgInfoRequest.DbName,
		pgInfoRequest.SchemaName, pgInfoRequest.Tablename, pgInfoRequest.DbPath, pgInfoRequest.Retry)
	if err != nil {
		logger.Info("数据库插入失败:%v", err)
		return false, "数据库插入失败"
	}

	url := "host=" + pgInfoRequest.Host + " port=" + pgInfoRequest.Port + " user=" + pgInfoRequest.Username + " password=" + pgInfoRequest.Password + " sslmode=disable"

	db, err := connectToPosrGreSQL(url)
	if err != nil {
		return false, "连接失败"
	}

	defer db.Close()
	return true, code
}

// 删除作业
func UpdateConnectPG(pgInfo *vo.DatabaseInfoRequest) (bool, string) {

	flag := util.IsUpdateExistDatabase(pgInfo.ConnectName, pgInfo.Namespace, pgInfo.DataBaseType, pgInfo.Code)

	if flag {
		return false, "不能创建相同类型的同名数据源，请重新编辑"
	}

	dbPG, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, "数据库连接失败"
	}
	defer dbPG.Close()

	updatesql := `UPDATE ioit.database_info SET connectname=$1,	username=$2, password=$3, host=$4, port=$5, retry=$6 WHERE namespace = $7 AND code = $8 `

	_, err = dbPG.Exec(updatesql,
		pgInfo.ConnectName, pgInfo.Username, pgInfo.Password, pgInfo.Host, pgInfo.Port, pgInfo.Retry, pgInfo.Namespace, pgInfo.Code)

	if err != nil {
		logger.Info("数据库连接更新失败:%v", err)
		return false, "数据库连接更新失败"
	}

	logger.Info("数据库连接信息更新: %v", flag)

	return true, "更新成功"
}

// 生成数据库连接信息编码
func generateDataBaseCode(database string) string {
	rand.Seed(time.Now().UnixNano())
	code := database + "_"
	for i := 0; i < 8; i++ {
		code += fmt.Sprintf("%d", rand.Intn(10))
	}
	return code
}

// 获取数据库连接
func GetPGConnectList(projecName *vo.DatabaseInfoRequest) (bool, []vo.DatabaseInfoRequest) {
	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, nil
	}
	defer db.Close()

	query := `SELECT 
					code, connectname, username, dbname, host, port, password, schemaname, tablename, databasetype, retry 
			FROM ioit.database_info WHERE namespace = $1 AND databasetype = Postgres`

	rows, err := db.Query(query, projecName.Namespace)

	if err != nil {
		return false, nil
	}

	defer rows.Close()

	var infos []vo.DatabaseInfoRequest

	for rows.Next() {
		var info vo.DatabaseInfoRequest
		err = rows.Scan(&info.Code, &info.ConnectName, &info.Username,
			&info.DbName, &info.Host, &info.Port, &info.Password, &info.SchemaName, &info.Tablename, &info.DataBaseType, &info.Retry)
		if err != nil {
			return false, nil
		}
		infos = append(infos, info)
	}

	return true, infos
}

// 获取查询某个ip上所有的数据库
func GetPGDataBaseConnectList(dataBaseInfo *vo.DatabaseInfoRequest) (bool, []Database, int) {
	//组装连接参数
	userName := dataBaseInfo.Username
	password := dataBaseInfo.Password
	host := dataBaseInfo.Host
	port := dataBaseInfo.Port
	url := "host=" + host + " port=" + port + " user=" + userName + " password=" + password + " sslmode=disable"
	db, err := connectToPosrGreSQL(url)
	if err != nil {
		return false, nil, response.DATABASE_CONNECT_FAILED
	}

	defer db.Close()

	// 连接到指定的数据库
	rows, err := db.Query("SELECT datname FROM pg_database  WHERE datistemplate = false")
	if err != nil {
		return false, nil, response.DBTABLELIST_GETFAILED
	}
	defer rows.Close()
	// 读取数据库连接并构建响应
	var dataBases []Database
	// 遍历查询结果
	for rows.Next() {
		var dataBase Database
		if err := rows.Scan(&dataBase.Name); err != nil {
			return false, nil, response.DBTABLELIST_GETFAILED
		}

		dataBases = append(dataBases, dataBase)
	}
	return true, dataBases, 0
}

func GetPGModeList(databaseInfo *vo.DatabaseInfoRequest) (bool, []Mode) {
	// func GetPGModeList(databaseName string) (bool, []Mode) {
	userName := databaseInfo.Username
	password := databaseInfo.Password
	host := databaseInfo.Host
	port := databaseInfo.Port
	url := "host=" + host + " port=" + port + " user=" + userName + " password=" + password + " dbname=" + databaseInfo.DbName + " sslmode=disable"
	db, err := connectToPosrGreSQL(url)
	if err != nil {
		return false, nil
	}

	defer db.Close()
	// 读取数据库连接并构建响应
	var modes []Mode
	// 连接到指定的数据库模型
	rows, err := db.Query(fmt.Sprintf("SELECT schema_name FROM information_schema.schemata WHERE catalog_name ='%s'", databaseInfo.DbName))

	if err != nil {
		return false, nil
	}
	defer rows.Close()
	// 遍历查询结果
	for rows.Next() {
		var mode Mode
		if err := rows.Scan(&mode.Name); err != nil {
			return false, nil
		}
		modes = append(modes, mode)
	}
	logger.Info("GetPGModeList_modes:%v", modes)
	return true, modes
}

// 获取查询某个ip上所有的数据库
func GetPGTableList(pgInfoRequest *vo.DatabaseInfoRequest) (bool, []TableAndType) {
	// 读取数据库连接并构建响应
	db, err := getPGConnect(pgInfoRequest)
	if err != nil {
		return false, nil
	}

	defer db.Close()
	var tables []TableAndType
	// 查询某个数据库下某个模式的所有表
	query := fmt.Sprintf("SELECT table_name,table_type FROM information_schema.tables WHERE table_schema = '%s'", pgInfoRequest.SchemaName)
	rows, err := db.Query(query)
	if err != nil {
		return false, tables
	}
	defer rows.Close()
	// 遍历结果集
	for rows.Next() {
		var table TableAndType
		if err := rows.Scan(&table.Name, &table.Type); err != nil {
			return false, nil
		}
		tables = append(tables, table)
	}
	return true, tables
}
func GetPGTablesPrimary(modeName string, tableName string, pgInfoRequest *vo.DatabaseInfoRequest) (bool, []string) {
	db, err := getPGConnect(pgInfoRequest)
	if err != nil {
		return false, nil
	}

	defer db.Close()

	// 查询当前表的所有字段
	query := fmt.Sprintf(`
       SELECT a.attname AS column_name
        FROM pg_constraint AS c
        JOIN pg_class AS t ON c.conrelid = t.oid
        JOIN pg_attribute AS a ON a.attnum = ANY(c.conkey) AND a.attrelid = t.oid
        JOIN pg_namespace AS n ON n.oid = t.relnamespace
        WHERE c.contype = 'p'
            AND n.nspname = '%s'
            AND t.relname = '%s'`, modeName, tableName)

	rows, err := db.Query(query)
	logger.Info("modeName:%v + tableName:%v", modeName, tableName)
	if err != nil {
		return false, nil
	}
	defer rows.Close()

	// 封装所有字段信息
	var columns []string
	for rows.Next() {
		var column string
		if err := rows.Scan(&column); err != nil {
			return false, nil
		}
		columns = append(columns, column)
	}
	// 返回所有字段信息
	return true, columns
}
func getPGConnect(pgInfoRequest *vo.DatabaseInfoRequest) (*sql.DB, error) {
	//组装连接参数
	userName := pgInfoRequest.Username
	password := pgInfoRequest.Password
	host := pgInfoRequest.Host
	port := pgInfoRequest.Port
	dbname := pgInfoRequest.DbName
	url := "host=" + host + " port=" + port + " user=" + userName + " password=" + password + " dbname=" + dbname + " sslmode=disable"
	// logger.Info("url is %v", url)
	db, err := sql.Open("postgres", url)
	if err != nil {
		return nil, err
	}

	db.SetConnMaxIdleTime(time.Minute * 10)
	db.SetConnMaxLifetime(time.Minute * 10)
	db.SetMaxOpenConns(10)
	db.SetMaxIdleConns(10)

	return db, nil
}

func GetPGTableColumns(modeName string, tableName string, pgInfoRequest *vo.DatabaseInfoRequest) (bool, []ColumnPG) {
	db, err := getPGConnect(pgInfoRequest)
	if err != nil {
		return false, nil
	}

	defer db.Close()

	query := fmt.Sprintf(`
       SELECT column_name, data_type, col_description(a.attrelid, a.attnum) AS description
		FROM information_schema.columns c
		JOIN pg_attribute a ON c.column_name = a.attname
		JOIN pg_class t ON a.attrelid = t.oid AND c.table_name = t.relname
		JOIN pg_namespace n ON t.relnamespace = n.oid AND c.table_schema = n.nspname
		WHERE c.table_schema ='%s' AND c.table_name = '%s'
		ORDER BY a.attnum`, modeName, tableName)

	rows, err := db.Query(query)
	if err != nil {
		return false, nil
	}
	defer rows.Close()
	// 封装所有字段信息
	var columns []ColumnPG
	for rows.Next() {
		var colInfo ColumnPG
		err := rows.Scan(&colInfo.Name, &colInfo.Type, &colInfo.Comment)
		if err != nil {
			log.Fatal(err)
		}

		// logger.Info("colInfo:%v", colInfo)
		columns = append(columns, colInfo)
	}
	// logger.Info("所有的字段信息为：%v", columns)
	for i := range columns {
		if columns[i].Type == "character varying" {
			columns[i].Type = "varchar"
		}
	}

	return true, columns
}
func GetPGTableData(modeName, tableName, SQL string, pgInfoRequest *vo.DatabaseInfoRequest) (bool, string, SearchResponse) {
	// 连接到指定的数据库
	res := SearchResponse{}

	db, err := getPGConnect(pgInfoRequest)
	if err != nil {
		return false, "数据库连接失败", res
	}

	defer db.Close()

	flag := ContainsComplexQuery(pgInfoRequest.SQL)
	if flag {
		return false, "不支持复杂查询", res
	}

	// 查询当前表的所有字段
	logger.Info("SQL:%v", SQL)
	rows, err := db.Query(SQL)
	// logger.Info("rows:%v", rows)
	if err != nil {
		logger.Info("err is:%v", err)
		if isDoesNotExist(err) {
			return false, errToCNPG(err), res
		}
		return false, "执行SQL语句失败", res
	}
	defer rows.Close()

	// 解析查询结果
	columns, _ := rows.Columns()
	// 获取列的数据类型
	columnTypes, _ := rows.ColumnTypes()
	count := 0
	var results []map[string]interface{}
	for rows.Next() {
		count++
		if count > 1000 {
			// return false, res, "支持预览1000条数据"
			logger.Info("支持预览1000条数据")
			break
		}
		values := make([]interface{}, len(columns))
		valuePtrs := make([]interface{}, len(columns))
		for i := range columns {
			valuePtrs[i] = &values[i]
		}
		err = rows.Scan(valuePtrs...)
		if err != nil {
			continue
		}
		rowData := make(map[string]interface{})
		for i, col := range columns {
			val := valuePtrs[i].(*interface{})
			// logger.Info("columnTypes[i].DatabaseTypeName():%v", columnTypes[i].DatabaseTypeName())
			// logger.Info("columnTypes[i].ScanType():%v", columnTypes[i].ScanType())
			// 根据列类型转换值
			switch columnTypes[i].DatabaseTypeName() {
			case "DATE":
				if t, ok := (*val).(time.Time); ok {
					rowData[col] = t.Format("2006-01-02")
				} else {
					rowData[col] = nil
				}
			case "TIME":
				if t, ok := (*val).(time.Time); ok {
					rowData[col] = t.Format("15:04:05")
				} else {
					rowData[col] = nil
				}
			case "TIMESTAMP":
				if t, ok := (*val).(time.Time); ok {
					rowData[col] = t.Format("2006-01-02 15:04:05")
				} else {
					rowData[col] = nil
				}
			default:
				if *val == nil {
					rowData[col] = nil
				} else {
					rowData[col] = *val
				}
			}
		}
		results = append(results, rowData)
	}
	res.List = results
	res.Cols = columns

	sqlTableColumn := fmt.Sprintf(`
       SELECT a.attname as column_name, d.description as column_comment
						   FROM pg_attribute a 
						   LEFT JOIN pg_class c ON a.attrelid = c.oid 
						   LEFT JOIN pg_namespace n ON c.relnamespace = n.oid 
						   LEFT JOIN pg_description d ON (c.oid = d.objoid AND a.attnum = d.objsubid) 
						   WHERE c.relname = '%s' AND n.nspname = '%s' AND a.attnum > 0`, tableName, modeName)
	rowsCom, err := db.Query(sqlTableColumn)
	if err != nil {
		fmt.Println(err)
	}
	defer rowsCom.Close()

	var tableColumns []tableColumn

	for rowsCom.Next() {
		var column tableColumn
		err = rowsCom.Scan(
			&column.ColumnName,
			&column.ColumnComment)

		if err != nil {
			fmt.Printf("query table column scan error, detail is [%v]\n", err.Error())
			continue
		}

		tableColumns = append(tableColumns, column)
	}
	// logger.Info("tableColumns:%v", tableColumns)
	res.ColsInfo = tableColumns

	return true, "查询成功", res
}

func isDoesNotExist(err error) bool {
	return strings.Contains(err.Error(), "column") && strings.Contains(err.Error(), "does not exist")
}

func errToCNPG(err error) string {
	re := regexp.MustCompile(`column "(\w+)" does not exist`)
	matcher := re.FindStringSubmatch(err.Error())
	if len(matcher) == 2 {
		columnName := matcher[1]
		return fmt.Sprintf("查询的字段 '%s' 不存在", columnName)
	}
	return "查询时发生未知错误"
}

func Validate(re_express *vo.ValidateRegexp) (bool, string) {
	_, err := regexp.Compile(re_express.ValidateRegexpExpress)
	if err != nil {
		return false, "正则表达式不合法"
	}
	return true, re_express.ValidateRegexpExpress
}

// 端口检验
func ExistPort(batchPort *vo.Port) (bool, int, string) {
	port := batchPort.BatchPort
	logger.Info("配置的端口为：%v", port)
	//拼接地址
	address := ":" + port
	//监听端口是否被占用
	listener, err1 := net.Listen("tcp", address)
	if err1 != nil {
		return false, response.PORT_IS_OCCUPIED, "端口<" + port + ">被占用"
	}
	//关闭占用资源
	defer listener.Close()
	return true, 0, port
}

var streamMap_dis sync.Map

func ReturnData(yaml *vo.Yaml) (bool, interface{}) {
	// 定义通道变量用于保证streamMap中的存储到yaml
	isStore := make(chan bool)

	// 执行yaml
	ExecYaml(yaml.BenthosYaml, isStore)

	v := <-isStore
	logger.Info("数据预览取出的通道值为，%v", v)

	// 只有取到通道值才执行，代表yaml执行完毕
	if v {
		value, ok := streamMap_dis.Load(yaml.BenthosYaml)
		if !ok {
			logger.Info("yaml处理错误")
			return false, "yaml处理错误"
		}
		stream := value.(*service.Stream)
		stream.StopWithin(time.Second * 1)
		streamMap_dis.Delete(yaml.BenthosYaml)
		logger.Info("数据预览yaml已停止")
	}

	// 读取数据预览结果
	dataPath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + config.ConfigAll.FILE.BenthosData + constants.DATAPREVIEW
	data := util.ReadFile(dataPath)
	// logger.Info("data:%v", data)
	if data == "[]" {
		logger.Info("yaml:%v", yaml.Fields)
		return true, yaml.Fields
	} else {
		return true, data
	}
}

// 运行yaml，返回预览数据
func ExecYaml(yaml string, isStore chan<- bool) {
	panicOnErr := func(err error) {
		if err != nil {
			panic(err)
		}
	}

	// 创建流处理器
	builder := service.NewStreamBuilder()

	// 设置yaml
	err := builder.SetYAML(yaml)
	panicOnErr(err)
	stream, err := builder.Build()

	// 存储当前yaml记录
	streamMap_dis.Store(yaml, stream)

	go func() {
		isStore <- true
	}()

	panicOnErr(err)
	err = stream.Run(context.Background())
	panicOnErr(err)
}

func ValidateQuery(db *sql.DB, query, dbType, dbName, modeName, tableName string, InfoRequest *vo.DatabaseInfoRequest) error {
	tableName, err := ExtractTableName(query)
	if err != nil {
		logger.Error("get table name err is:%v")
	}

	logger.Info("tableName is%v", tableName)

	columns, err := GetTableColumnsForCheck(db, dbType, "public", "MaterialAlter", InfoRequest)
	if err != nil {
		logger.Error("get columns name err is:%v")
	}

	if err := CheckQueryFields(query, columns); err != nil {
		logger.Error("check fields err is:%v")
		return err
	}

	if ContainsComplexQuery(query) {
		return fmt.Errorf("不支持复杂查询")
	}
	return nil
}

func ExtractTableName(query string) (string, error) {
	re := regexp.MustCompile(`(?i)from\s+([a-zA-Z_][a-zA-Z0-9_]*)`)
	matches := re.FindStringSubmatch(query)
	if len(matches) < 2 {
		return "", fmt.Errorf("无法从查询语句中提取表名")
	}
	return matches[1], nil
}

func GetTableColumnsForCheck(db *sql.DB, dbType, modeName, tableName string, InfoRequest *vo.DatabaseInfoRequest) ([]string, error) {
	var res []string
	switch dbType {
	case "postgres":
		flag, columns := GetPGTableColumns(modeName, tableName, InfoRequest)
		if flag {
			for i := range columns {
				res = append(res, columns[i].Name)
			}
		}
	case "mysql":
		flag, columns := GetTableColumns(InfoRequest)
		if flag {
			for i := range columns {
				res = append(res, columns[i].Name)
			}
		}
	case "sqlserver":
		flag, columns := GetSqlSerTableColumns(InfoRequest)
		if flag {
			for i := range columns {
				res = append(res, columns[i].Name)
			}
		}
	case "sqlite3":
		flag, columns := GetSqliteTableColumns(InfoRequest)
		if flag {
			for i := range columns {
				res = append(res, columns[i].Name)
			}
		}
	default:
		logger.Info("不支持的数据库类型")
	}

	logger.Info("columns is :%v", res)
	return res, nil
}

func CheckQueryFields(Query string, columns []string) error {
	re := regexp.MustCompile(`(?i)select\s+(.*?)\s+from`)
	matches := re.FindStringSubmatch(Query)
	if len(matches) < 2 {
		return fmt.Errorf("查询语句不正确")
	}
	fields := strings.Split(matches[1], ",")
	logger.Info("fields is :%v", fields)
	if fields[0] == "*" {
		return nil
	}
	for _, field := range fields {
		field = strings.TrimSpace(field)
		field = strings.ToLower(field)
		found := false
		for _, column := range columns {
			if field == column {
				found = true
				break
			}

		}
		if !found {
			return fmt.Errorf("查询的字段 %s 不存在", field)
		}
	}
	return nil
}

func ContainsComplexQuery(query string) bool {
	complexPatterns := []string{
		`(?i)\border\s+by\b`,
		`(?i)\bgroup\s+by\b`,
		`(?i)\bin\s+\(`,
		`(?i)\bjoin\b`,
		`(?i)\bhaving\b`,
	}
	query = strings.ToLower(query)
	for _, pattern := range complexPatterns {
		match, _ := regexp.MatchString(pattern, query)
		if match {
			return true
		}
	}
	return false
}
