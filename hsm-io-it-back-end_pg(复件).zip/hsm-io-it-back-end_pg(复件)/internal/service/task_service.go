package service

import (
	"bytes"
	"encoding/json"
	"fmt"
	"hsm-io-it-back-end/config"
	"hsm-io-it-back-end/internal/constants"
	"hsm-io-it-back-end/internal/service/run"
	"hsm-io-it-back-end/internal/util"
	"hsm-io-it-back-end/internal/vo"
	"hsm-io-it-back-end/pkg/logger"
	"hsm-io-it-back-end/response"
	"io/ioutil"
	"net/http"
	"os"
	"regexp"
	"strconv"
	"time"
)

// 开始作业
func StartJob(jobCanvasRequest *vo.JobKeyInfo) (bool, int, string) {
	jobCanvasRequest.SKNode = util.ServerCode

	// 判断作业是否存在
	job := util.GetJobDetailsInfo(jobCanvasRequest.NameSpace, jobCanvasRequest.Code, jobCanvasRequest.SKNode)
	if job == nil {
		return false, response.DATABASE_READ_FAILED, ""
	}

	if job.Schedule == "2" {
		if job.PeriodDetail.EndType == "endDate" {
			isOverTime := CompareEndDate(job)
			if !isOverTime {
				return false, response.OVER_TIME, ""
			}
		}
	} else {
		if job.Schedule == "cron" {
			if job.CronDetail.EndType == "endDate" {
				isOverTime := CompareEndDate(job)
				if !isOverTime {
					return false, response.OVER_TIME, ""
				}
			}
		}
	}

	benthosYaml := job.Content.BenthosYaml

	intervalRegexp := regexp.MustCompile(`(?m)(interval:\s*)([^\n]+)`)
	countRegexp := regexp.MustCompile(`(?m)(count:\s*\d+)`)
	if jobCanvasRequest.NameSpace == constants.PORTALNAME {
		// 如果为cron，将interval修改为cron表达式，去掉count
		if job.Schedule == "cron" {
			// benthosYaml = intervalRegexp.ReplaceAllString(benthosYaml, `$1"`+"TZ=Asia/Shanghai "+job.ScheduleDetails+`"`)
			benthosYaml = intervalRegexp.ReplaceAllString(benthosYaml, `$1"`+job.ScheduleDetails+`"`)
			benthosYaml = countRegexp.ReplaceAllString(benthosYaml, ``)
		} else {
			if job.Schedule == "2" {
				// 如果为period，且有执行次数，将interval修改为cron表达式，修改count
				if job.PeriodDetail.EndType == "times" {
					benthosYaml = intervalRegexp.ReplaceAllString(benthosYaml, `$1"`+job.ScheduleDetails+`"`)
					count := strconv.Itoa(job.PeriodDetail.Times)
					benthosYaml = countRegexp.ReplaceAllString(benthosYaml, `count: `+count)
				} else {
					// 如果为period，且为无限期，将interval修改为cron表达式，去掉count
					// 如果为period，且有截止日期，将interval修改为cron表达式，去掉count
					if job.PeriodDetail.EndType == "endless" || job.PeriodDetail.EndType == "endDate" {
						benthosYaml = intervalRegexp.ReplaceAllString(benthosYaml, `$1"`+job.ScheduleDetails+`"`)
						benthosYaml = countRegexp.ReplaceAllString(benthosYaml, ``)
					}
				}
			}
		}
	}

	logger.Info("benthosYaml is %v", benthosYaml)
	// 判断是否为数据同步
	isDataSync := StartDataSync(job)

	if isDataSync {
		return true, 0, "作业<" + job.Name + ">启动成功"
	}

	UpsertJobNode(job)
	if GetHsmTemplate() == "double-integ-manifest" {
		if job.JobType == "realtime" {
			// 保证另一个节点能ping通的情况下
			jobNode := FindSNodeBynameAndCode(job)
			if jobNode.StartNode == "e1" {
				if SendReqToHealth("s1") {
					SendRepForRT(job, "s1", "startRT")
				}
			}
			if jobNode.StopNode == "s1" {
				if SendReqToHealth("e1") {
					SendRepForRT(job, "e1", "startRT")
				}
			}
		}
	}

	logger.Info("启动的作业为:%v", job.Code)

	isStore := make(chan bool)

	// if job.IsHttp {
	startDate, err := time.Parse("2006-01-02 15:04:05", job.CronDetail.EffectiveDate)
	if err != nil {
		logger.Info("parse effectiveDate error:%v", err)
	}

	tarTime := time.Date(startDate.Year(), startDate.Month(), startDate.Day(), startDate.Hour(), startDate.Minute(), startDate.Second(), 0, time.Local)

	duration := time.Until(tarTime)
	logger.Info("duration:%v", duration)
	if duration <= 0 {
		logger.Info("time is in the past")
	}
	time.AfterFunc(duration, func() { go run.ExceuteHttpBenthos(jobCanvasRequest.Code, benthosYaml, isStore) })

	// 如果有结束时间，则启动一个协程去停止
	if (job.CronDetail.EndDate != "endless" && job.CronDetail.EndDate != "") ||
		(job.PeriodDetail.EndDate != "endless" && job.PeriodDetail.EndDate != "") {
		StopRoutine(job)
	}

	if job.PeriodDetail.EndType == "times" {
		StopRoutine(job)
	}

	if job.Schedule == "once" {
		StopOnceRoutine(job)
	}

	job.Status = 1
	_, msg, _ := util.UpdateJob(job)
	logger.Info("UpdateJob msg: %v", msg)
	return true, 0, "作业<" + job.Name + ">启动成功"
}

func StartDataSync(job *vo.CreateJobRequest) bool {
	nodeList, ok := job.Canvas["nodeList"].([]interface{})
	if !ok {
		logger.Info("nodelist is not a array")
	}

	var canvasDetail []vo.SyncNodeData

	for _, node := range nodeList {
		nodeJson, err := json.Marshal(node)
		if err != nil {
			logger.Info("json marshal error :%v", err)
		}
		var canvasD vo.SyncNodeData
		if err := json.Unmarshal(nodeJson, &canvasD); err != nil {
			logger.Info("json unmarshal error:%v", err)
		}
		canvasDetail = append(canvasDetail, canvasD)
	}

	for i := range canvasDetail {
		if canvasDetail[i].NodeMark == "data-async" {
			if canvasDetail[i].Attrs.DataAsyncType == "multiple" {
				// 执行数据迁移任务
				// 组装参数
				taruser := canvasDetail[i].Attrs.FormItem.Target.LinkInfo.Username
				tarpass := canvasDetail[i].Attrs.FormItem.Target.LinkInfo.Password
				tarhost := canvasDetail[i].Attrs.FormItem.Target.LinkInfo.Host
				tarport := canvasDetail[i].Attrs.FormItem.Target.LinkInfo.Port
				tardbname := canvasDetail[i].Attrs.FormItem.Target.Database
				targetDSN := fmt.Sprintf(`user=%s password=%s dbname=%s host=%s port=%s sslmode=disable`, taruser, tarpass, tardbname, tarhost, tarport)

				souuser := canvasDetail[i].Attrs.FormItem.Source.LinkInfo.Username
				soupass := canvasDetail[i].Attrs.FormItem.Source.LinkInfo.Password
				souhost := canvasDetail[i].Attrs.FormItem.Source.LinkInfo.Host
				souport := canvasDetail[i].Attrs.FormItem.Source.LinkInfo.Port
				soudbname := canvasDetail[i].Attrs.FormItem.Source.Database
				sougetDSN := fmt.Sprintf(`user=%s password=%s dbname=%s host=%s port=%s sslmode=disable`, souuser, soupass, soudbname, souhost, souport)
				schema := canvasDetail[i].Attrs.FormItem.Source.Module
				tables := canvasDetail[i].Attrs.FormItem.Source.Tables
				views := canvasDetail[i].Attrs.FormItem.Source.Views

				dbinfo := vo.DBInfo{
					TargetDSN:    targetDSN,
					SourceDSN:    sougetDSN,
					TargetDBType: "postgres",
					SourceDBType: "postgres",
					Tables:       tables,
					Views:        views,
					Schema:       schema,
				}

				if sougetDSN == targetDSN {
					logger.Info("相等的dsn")
					return true
				}

				for i := range dbinfo.Tables {
					SyncPTOPTable(dbinfo, dbinfo.Tables[i])
				}

				for i := range dbinfo.Views {
					SyncPTOPView(dbinfo, dbinfo.Views[i])
				}
				return true
			}
			return false
		}
	}
	return false
}

func CompareEndDate(job *vo.CreateJobRequest) bool {
	var endDate time.Time
	var err error
	if job.Schedule == "2" {
		if job.PeriodDetail.EndType == "endDate" {
			endDate, err = time.Parse("2006-01-02 15:04:05", job.PeriodDetail.EndDate)
		}
	} else {
		if job.Schedule == "cron" {
			if job.CronDetail.EndType == "endDate" {
				endDate, err = time.Parse("2006-01-02 15:04:05", job.CronDetail.EndDate)
			}
		}
	}
	if err != nil {
		logger.Info("parse effectiveDate error:%v", err)
	}
	tarTime := time.Date(endDate.Year(), endDate.Month(), endDate.Day(), endDate.Hour(), endDate.Minute(), endDate.Second(), 0, time.Local)

	duration := time.Until(tarTime)
	logger.Info("距离停止时间还需:%v", duration)
	if duration <= 0 {
		return false
	}
	return true
}

func StopRoutine(job *vo.CreateJobRequest) {
	// 如果是周期调度有次数限制，计算完成时间，启动协程停止任务
	if job.Schedule == "2" {
		if job.PeriodDetail.EndType == "times" {
			startDate, err := time.Parse("2006-01-02 15:04:05", job.CronDetail.EffectiveDate)
			if err != nil {
				logger.Info("parse effectiveDate error:%v", err)
			}

			tarTime := time.Date(startDate.Year(), startDate.Month(), startDate.Day(), startDate.Hour(), startDate.Minute(), startDate.Second(), 0, time.Local)

			duration := time.Until(tarTime)
			logger.Info("duration:%v", duration)

			var secondInte int
			cycle := job.PeriodDetail.ScheduleCycle
			switch job.PeriodDetail.ScheduleUnit {
			case "second":
				secondInte = cycle
			case "minute":
				secondInte = cycle * 60
			case "hour":
				secondInte = cycle * 3600
			default:
				logger.Info("default")
			}

			if duration <= 0 {
				logger.Info("time is in the past")
				duration = time.Duration((job.PeriodDetail.Times-1)*secondInte+3) * time.Second
			} else {
				logger.Info("time is on the future")
				duration = duration + time.Duration((job.PeriodDetail.Times-1)*secondInte+3)*time.Second
			}

			logger.Info("距离停止时间还需:%v", duration)

			go func() {
				<-time.After(duration)
				run.Stop(job.Code)
				job.Status = 0
				util.UpdateJob(job)
			}()
			return
		}
	}

	// 如果是有停止时间的任务，启动协程停止任务
	var endDate time.Time
	var err error
	if job.Schedule == "2" {
		endDate, err = time.Parse("2006-01-02 15:04:05", job.PeriodDetail.EndDate)
	} else {
		if job.Schedule == "cron" {
			endDate, err = time.Parse("2006-01-02 15:04:05", job.CronDetail.EndDate)
		}
	}
	if err != nil {
		logger.Info("parse effectiveDate error:%v", err)
	}
	tarTime := time.Date(endDate.Year(), endDate.Month(), endDate.Day(), endDate.Hour(), endDate.Minute(), endDate.Second(), 0, time.Local)

	duration := time.Until(tarTime)
	logger.Info("距离停止时间还需:%v", duration)

	go func() {
		<-time.After(duration)
		run.Stop(job.Code)
		job.Status = 0
		util.UpdateJob(job)
	}()
}

func StopOnceRoutine(job *vo.CreateJobRequest) {

	// 如果是一次性作业
	endDate, err := time.Parse("2006-01-02 15:04:05", job.CronDetail.EffectiveDate)

	if err != nil {
		logger.Info("parse effectiveDate error:%v", err)
	}
	tarTime := time.Date(endDate.Year(), endDate.Month(), endDate.Day(), endDate.Hour(), endDate.Minute(), endDate.Second(), 0, time.Local)

	duration := time.Until(tarTime)
	if duration < 0 {
		logger.Info("time is in the past")
		duration = time.Duration(3) * time.Second
	} else {
		duration = duration + time.Duration(3)*time.Second
	}

	// logger.Info("距离停止时间还需:%v", duration)

	go func() {
		<-time.After(duration)
		run.Stop(job.Code)
		job.Status = 0
		util.UpdateJob(job)
	}()
}

func SendReqToHealth(node string) bool {
	ip := node + constants.DomainName

	defer func() {
		if r := recover(); r != nil {
			logger.Info("Health check is error:%v", r)
		}
	}()
	url := constants.Http + ip + constants.AddressSplicingSymbols + config.ConfigAll.Port + "/api/hsm-io-it/health/check"

	logger.Info("url:%v", url)
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		logger.Info("Fail to send request:%v", err)
	}
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil || resp.StatusCode != http.StatusOK {
		logger.Info("Failed to make request:%v", err)
		return false
	} else {
		defer resp.Body.Close()

		body, err := ioutil.ReadAll(resp.Body)
		logger.Info("response body is:%v", string(body))
		if err != nil {
			logger.Info("Failed to read response body:%v", err)
		}

		if string(body) == "alive" {
			logger.Info("Master is alive")
		}
		return true
	}
}

func StartRealTimeJob(job *vo.CreateJobRequest) {
	logger.Info("启动另一个节点的实时作业")
	isStore := make(chan bool)
	go run.ExceuteHttpBenthos(job.Code, job.Content.BenthosYaml, isStore)
	v := <-isStore
	logger.Info("取出的通道值为，%v", v)
}

func StopRealTimeJob(job *vo.CreateJobRequest) {
	logger.Info("停止另一个节点的作业")
	run.Stop(job.Code)
}

func UpsertJobNode(job *vo.CreateJobRequest) {
	jobNode := vo.JobNode{
		NameSpace: job.NameSpace,
		Code:      job.Code,
		StartNode: util.ServerCode,
		StopNode:  util.ServerCode,
	}
	err := util.GlobalGormDb.Table("ioit.job_nodes").
		Where("namespace = ? AND code = ?", job.NameSpace, job.Code).
		Assign(vo.JobNode{StartNode: util.ServerCode, StopNode: util.ServerCode}).
		FirstOrCreate(&jobNode).Error
	if err != nil {
		logger.Info("更新job_nodes失败:%v", err)
	}
}

func FindSNodeBynameAndCode(job *vo.CreateJobRequest) vo.JobNode {
	var jobNode vo.JobNode
	err := util.GlobalGormDb.Table("ioit.job_nodes").
		Select("startnode, stopnode").
		Where("namespace = ? AND code = ?", job.NameSpace, job.Code).
		First(&jobNode).Error
	if err != nil {
		logger.Info("查询job_nodes失败:%v", err)
	}
	return jobNode
}

func GetHsmTemplate() string {
	hsmTemplate := os.Getenv("HSM_TEMPLATE")
	return hsmTemplate
}

func SendRepForRT(job *vo.CreateJobRequest, node, action string) (bool, int, string) {
	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, response.DATABASE_CONNECT_FAILED, ""
	}
	defer db.Close()
	requestBody, err := json.Marshal(job)
	if err != nil {
		logger.Info("Fail to mapping:%v", err)
		return false, response.JSON_SERIALIZATION_FAILED, ""
	}

	ip := node + constants.DomainName

	req, err := http.NewRequest("POST", constants.Http+ip+":6120/api/hsm-io-it/job/"+action, bytes.NewBuffer(requestBody))
	if err != nil {
		logger.Info("Fail to send request:%v", err)
		return false, response.HTTP_SEND_FAILED, ""
	}
	req.Header.Set("Content-Type", "application/json")
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		logger.Info("Failed to excute job:%v", err)
		return false, response.HTTP_SEND_FAILED, ""
	} else {
		defer resp.Body.Close()
		if resp.StatusCode != http.StatusOK {
			logger.Info("Failed to excute job:%v", err)
			return false, response.HTTP_SEND_FAILED, ""
		}
		body, err := ioutil.ReadAll(resp.Body)
		if err != nil {
			logger.Info("Failed to excute job:%v", err)
			return false, response.HTTP_SEND_FAILED, ""
		}
		logger.Info("body:%v", string(body))
	}
	return true, 0, ""
}

// 供调度系统执行调度
func ExcuteJob(jobCanvasRequest *vo.JobKeyInfo) (bool, int, string) {
	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, response.DATABASE_CONNECT_FAILED, ""
	}
	defer db.Close()

	logger.Info("jobCanvasRequest:%v", jobCanvasRequest)

	jobCanvasRequest.SKNode = util.ServerCode
	// 判断作业是否存在
	job := util.GetJobDetailsInfo(jobCanvasRequest.NameSpace, jobCanvasRequest.Code, jobCanvasRequest.SKNode)
	if job == nil {
		return false, response.DATABASE_READ_FAILED, ""
	}

	nodeList, ok := job.Canvas["nodeList"].([]interface{})
	if !ok {
		logger.Info("nodelist is not a array")
	}

	var canvasDetail []vo.SyncNodeData

	for _, node := range nodeList {
		nodeJson, err := json.Marshal(node)
		if err != nil {
			logger.Info("json marshal error :%v", err)
		}
		var canvasD vo.SyncNodeData
		if err := json.Unmarshal(nodeJson, &canvasD); err != nil {
			logger.Info("json unmarshal error:%v", err)
		}
		canvasDetail = append(canvasDetail, canvasD)
	}

	for i := range canvasDetail {
		if canvasDetail[i].NodeMark == "data-async" {
			if canvasDetail[i].Attrs.DataAsyncType == "multiple" {
				// 执行数据迁移任务
				// 组装参数
				taruser := canvasDetail[i].Attrs.FormItem.Target.LinkInfo.Username
				tarpass := canvasDetail[i].Attrs.FormItem.Target.LinkInfo.Password
				tarhost := canvasDetail[i].Attrs.FormItem.Target.LinkInfo.Host
				tarport := canvasDetail[i].Attrs.FormItem.Target.LinkInfo.Port
				tardbname := canvasDetail[i].Attrs.FormItem.Target.Database
				targetDSN := fmt.Sprintf(`user=%s password=%s dbname=%s host=%s port=%s sslmode=disable`, taruser, tarpass, tardbname, tarhost, tarport)

				souuser := canvasDetail[i].Attrs.FormItem.Source.LinkInfo.Username
				soupass := canvasDetail[i].Attrs.FormItem.Source.LinkInfo.Password
				souhost := canvasDetail[i].Attrs.FormItem.Source.LinkInfo.Host
				souport := canvasDetail[i].Attrs.FormItem.Source.LinkInfo.Port
				soudbname := canvasDetail[i].Attrs.FormItem.Source.Database
				sougetDSN := fmt.Sprintf(`user=%s password=%s dbname=%s host=%s port=%s sslmode=disable`, souuser, soupass, soudbname, souhost, souport)
				schema := canvasDetail[i].Attrs.FormItem.Source.Module
				tables := canvasDetail[i].Attrs.FormItem.Source.Tables
				views := canvasDetail[i].Attrs.FormItem.Source.Views

				dbinfo := vo.DBInfo{
					TargetDSN:    targetDSN,
					SourceDSN:    sougetDSN,
					TargetDBType: "postgres",
					SourceDBType: "postgres",
					Tables:       tables,
					Views:        views,
					Schema:       schema,
				}

				if sougetDSN == targetDSN {
					logger.Info("相等的dsn")
					return true, 0, "启动成功"
				}

				// logger.Info("dbinfo is:%v", dbinfo)

				for i := range dbinfo.Tables {
					SyncPTOPTable(dbinfo, dbinfo.Tables[i])
				}

				for i := range dbinfo.Views {
					SyncPTOPView(dbinfo, dbinfo.Views[i])
				}
				return true, 0, "启动成功"
			}
		}
	}

	logger.Info("启动的作业为:%v", job.Code)

	executeInfo := util.ExecuteInfo{
		Code:        job.Code,
		BenthosYaml: job.Content.BenthosYaml,
	}
	util.JobQuene.Add(executeInfo)
	logger.Info("len of queue is :%v", util.JobQuene.Size())

	return true, 0, "启动成功"
}

// 停止作业
func StopJob(jobCanvasRequest *vo.JobKeyInfo) (bool, int, string) {
	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, response.DATABASE_CONNECT_FAILED, ""
	}
	defer db.Close()

	jobCanvasRequest.SKNode = util.ServerCode
	// 判断作业是否存在
	job := util.GetJobDetailsInfo(jobCanvasRequest.NameSpace, jobCanvasRequest.Code, jobCanvasRequest.SKNode)
	if job == nil {
		return false, response.DATABASE_READ_FAILED, ""
	}

	UpsertJobNode(job)
	if GetHsmTemplate() == "double-integ-manifest" {
		// if job.JobType == "realtime" {
		jobNode := FindSNodeBynameAndCode(job)
		if jobNode.StopNode == "e1" {
			if SendReqToHealth("s1") {
				SendRepForRT(job, "s1", "stopRT")
			}
		}
		if jobNode.StopNode == "s1" {
			if SendReqToHealth("e1") {
				SendRepForRT(job, "e1", "stopRT")
			}
		}
		// }
	}

	run.Stop(jobCanvasRequest.Code)

	job.CronId = constants.EmptyContent
	job.Status = 0
	flag, msg, _ := util.UpdateJob(job)
	logger.Info("停止作业成功:%s", msg)

	if flag {
		return true, 0, "作业<" + job.Name + ">停止成功"
	} else {
		return false, response.STOP_JOB_FAILED, ""
	}
}

func SendReqToAnotherNode(jobCanvasRequest *vo.CreateJobRequest) (bool, int, string) {
	jobkey := vo.JobKeyInfo{
		NameSpace: jobCanvasRequest.NameSpace,
		Code:      jobCanvasRequest.Code,
		SKNode:    jobCanvasRequest.SKNode,
	}
	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, response.DATABASE_CONNECT_FAILED, ""
	}
	defer db.Close()
	requestBody, err := json.Marshal(jobkey)
	if err != nil {
		logger.Info("Fail to mapping:%v", err)
		return false, response.JSON_SERIALIZATION_FAILED, ""
	}

	ip := jobCanvasRequest.SKNode + constants.DomainName

	req, err := http.NewRequest("POST", constants.Http+ip+":6120/api/hsm-io-it/job/stop", bytes.NewBuffer(requestBody))
	if err != nil {
		logger.Info("Fail to send request:%v", err)
		return false, response.HTTP_SEND_FAILED, ""
	}
	req.Header.Set("Content-Type", "application/json")
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		logger.Info("Failed to excute job:%v", err)
		return false, response.HTTP_SEND_FAILED, ""
	} else {
		defer resp.Body.Close()
		if resp.StatusCode != http.StatusOK {
			logger.Info("Failed to excute job:%v", err)
			return false, response.HTTP_SEND_FAILED, ""
		}
		body, err := ioutil.ReadAll(resp.Body)
		if err != nil {
			logger.Info("Failed to excute job:%v", err)
			return false, response.HTTP_SEND_FAILED, ""
		}
		logger.Info("body:%v", string(body))
	}
	return true, 0, "停止启动"
}
