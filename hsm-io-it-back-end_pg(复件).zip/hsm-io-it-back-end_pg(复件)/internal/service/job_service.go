package service

import (
	"bytes"
	"encoding/json"
	"fmt"
	"hsm-io-it-back-end/config"
	"hsm-io-it-back-end/internal/constants"
	"hsm-io-it-back-end/internal/service/run"
	"hsm-io-it-back-end/internal/service/sap"
	"hsm-io-it-back-end/internal/util"
	"hsm-io-it-back-end/internal/vo"
	"hsm-io-it-back-end/pkg/cron"
	"hsm-io-it-back-end/pkg/logger"
	"hsm-io-it-back-end/response"
	"io/ioutil"
	"math/rand"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/clbanning/mxj/v2"
	"github.com/gin-gonic/gin"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

type JobInfo struct {
	Code           string `json:"code"`
	Id             string `json:"id"`
	Name           string `json:"name"`
	Status         int    `json:"status"`
	CreateTime     string `json:"create_time"`
	EditeTime      string `json:"edite_time"`
	CreateUse      string `json:"create_user"`
	Describe       string `json:"describe"`
	IsAutoSelectId bool   `json:"isAutoSelectId"`
	SKNode         string `json:"s_node"`
	JobType        string `json:"job_type"`
	JobClass       string `json:"job_class"`
}

type NodeTree struct {
	Id       string                `json:"id"`
	Name     string                `json:"name"`
	Ip       string                `json:"ip"`
	Children []vo.CreateJobRequest `json:"children"`
}

var globalMap sync.Map

// 查询作业详情
func GetJobInfo(getJobRequest *vo.JobKeyInfo) (bool, *vo.CreateJobRequest, string) {

	getJobRequest.SKNode = util.ServerCode

	job := util.GetJobDetailsInfo(getJobRequest.NameSpace, getJobRequest.Code, getJobRequest.SKNode)
	if job == nil {
		return false, nil, "查询数据为空"
	} else {
		return true, job, "查询成功"
	}
}

func GetJobData(getJobRequest *vo.JobKeyInfo) (bool, string) {
	namespace := getJobRequest.NameSpace
	code := getJobRequest.Code
	//判断文件是否存在
	jobPath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + config.ConfigAll.BenthosData + namespace + constants.Hierarchy + code + constants.Suffix
	fileData := util.ReadLineRawFile(jobPath)
	if fileData == "" {
		return false, "null"
	}
	return true, fileData
}

func GetJobLog(getJobRequest *vo.JobKeyInfo) (bool, string) {

	code := getJobRequest.Code
	//判断文件是否存在
	jobPath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + config.ConfigAll.BenthosLogs + code + constants.Suffix
	fileData := util.ReadLineRawFile(jobPath)
	if fileData == "" {
		return false, "null"
	}
	return true, fileData
}

// 导出作业
func ExportJob(getJobRequest *vo.JobKeyInfo, c *gin.Context, databaseslice *vo.AttrsOfDatabase, uploadpathslice *vo.AttrsOfFileUpload) (bool, int, string) {
	logger.Info("databaseslice.EDatabaseAndCodes:%v", databaseslice.EDatabaseAndCodes)
	code := getJobRequest.Code
	namespace := getJobRequest.NameSpace

	removePath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp + code + constants.Hierarchy
	// tempPath = /usr/local/hsm-os/data/hsm-io-it/data/temp/job_Xxx/tempFile/
	tempPath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp + code + constants.Hierarchy + "tempFlie" + constants.Hierarchy
	tempPathZip := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp + code + constants.Hierarchy + code + constants.Zip
	util.CreateDir(tempPath)

	// 判断任务是否存在
	job := util.GetJobDetailsInfo(namespace, code, util.ServerCode)
	if job == nil {
		return false, response.DATABASE_READ_FAILED, ""
	}

	// 查询主数据，其实就是job
	fileName := namespace + constants.At + code
	jobData, err := json.Marshal(job)
	if err != nil {
		return false, response.JSON_SERIALIZATION_FAILED, ""
	}
	// logger.Info("导出数据为：" + string(jobData))

	namespacePath := tempPath + namespace + constants.Suffix
	// tempPath = /usr/local/hsm-os/data/hsm-io-it/data/temp/job_Xxx/tempFile/namespace.json
	util.WriteFile(namespacePath, string(jobData))

	logger.Info("*********************databaseslice:%v", databaseslice)
	logger.Info("*********************uploadpathslice:%v", uploadpathslice)

	var dataconut int
	var upcount int

	var databaseInfoList []vo.DatabaseInfoRequest

	s_txt := namespace + constants.Suffix

	dupslice := util.RemoveDuplicates(databaseslice.DatabaseAndCodes)

	logger.Info("dupslice%v", dupslice)
	logger.Info("len of dupslice:%v", len(dupslice))
	if len(dupslice) != 0 {
		for _, databasetype := range dupslice {
			sqlValue := strings.Split(databasetype, constants.AddressSplicingSymbols)
			sqlType := sqlValue[0]
			sqlCode := sqlValue[1]
			logger.Info("类型：%v", sqlType)
			logger.Info("code：%v", sqlCode)
			dataconut++
			databaseInfo := util.GetDatabaseInfo(namespace, sqlCode, sqlType)
			databaseInfoList = append(databaseInfoList, *databaseInfo)
		}
	}

	logger.Info("len of databaseslice.EDatabaseAndCodes:%v", len(databaseslice.EDatabaseAndCodes))
	if len(databaseslice.EDatabaseAndCodes) != 0 {
		for _, databasetype := range databaseslice.EDatabaseAndCodes {
			logger.Info("databasetype:%v", databasetype)
			dataconut++
			databaseInfo := util.GetDatabaseInfo(namespace, databasetype, "EMySQL")
			databaseInfoList = append(databaseInfoList, *databaseInfo)
		}
	}

	dbData, err := json.Marshal(databaseInfoList)
	if err != nil {
		return false, response.JSON_SERIALIZATION_FAILED, ""
	}

	// tempPath = /usr/local/hsm-os/data/hsm-io-it/data/temp/job_Xxx/tempFile/databaseconfig/database.json
	dataBasefolder := tempPath + constants.DataBaseConfig
	util.CreateDir(dataBasefolder)
	util.WriteFile(dataBasefolder+"database"+constants.Suffix, string(dbData))

	upcount = util.UploadFileCopy(uploadpathslice, tempPath, upcount)

	logger.Info("datacount%v", dataconut)
	if dataconut != 0 {
		s_txt = s_txt + constants.AtDatabaseConfig
	}

	if upcount != 0 {
		s_txt = s_txt + constants.AtUpload
	}

	// tempPath = /usr/local/hsm-os/data/hsm-io-it/data/temp/job_Xxx/tempFile/namespace@job_xxx.txt
	// tempPath = /usr/local/hsm-os/data/hsm-io-it/data/temp/job_Xxx/tempFile/databaseconfig/database.json
	// tempPath = /usr/local/hsm-os/data/hsm-io-it/data/temp/job_Xxx/tempFile/namespace.json
	util.WriteFile(tempPath+fileName+constants.TxtIdentifier, s_txt+constants.AtJob)

	err = util.CompressFolderToZip(tempPath, tempPathZip)
	if err != nil {
		return false, response.COMPRESS_FAILED, ""
	}
	encodedFileName := makeEncodedFileName(fileName + constants.Zip)
	logger.Info("文件名：%v", encodedFileName)
	c.Header("Content-Type", "application/octet-stream")
	c.Header("Content-Disposition", fmt.Sprintf("attachment; filename=%s", encodedFileName))
	c.Header("Content-Transfer-Encoding", "binary")
	c.File(tempPathZip)
	err = os.RemoveAll(removePath)
	if err != nil {
		return false, response.DELETE_FILE_FAILED, ""
	}
	return true, 0, "作业导出成功"
}

func ExportBatchJob(projectRequest *vo.JobKeyInfo, c *gin.Context) (bool, int, string) {
	namespace := projectRequest.NameSpace

	existQuery := `SELECT EXISTS (SELECT 1 FROM ioit.job_info WHERE namespace = $1)`

	var exists bool
	err := util.GlobalGormDb.Raw(existQuery, namespace).Scan(&exists).Error
	if err != nil {
		logger.Info("数据库操作失败%v", err)
		return false, response.DATABASE_OPERATION_FAILED, ""
	}

	removePath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp
	// tempPath = /usr/loacl/hsm-os/data/hsm-io-it/data/temp/tempFile/
	tempPath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp + "tempFlie" + constants.Hierarchy
	tempPathZip := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp + namespace + constants.Zip
	util.CreateDir(tempPath)

	if exists {
		var jobs []vo.CreateJobRequest
		err = util.GlobalGormDb.Table("ioit.job_info").Where("namespace = ?", namespace).Find(&jobs).Error

		if err != nil {
			logger.Info("数据库操作失败%v", err)
			return false, response.DATABASE_OPERATION_FAILED, ""
		}

		jobData, err := json.Marshal(jobs)
		if err != nil {
			return false, response.JSON_SERIALIZATION_FAILED, ""
		}

		var databaseInfoList []vo.DatabaseInfoRequest

		err = util.GlobalGormDb.Table("ioit.database_info").Where("namespace = ?", namespace).Find(&databaseInfoList).Error

		if err != nil {
			logger.Info("查询失败:%v", err)
			return false, response.DATABASE_OPERATION_FAILED, "查询失败"
		}

		dbData, err := json.Marshal(databaseInfoList)
		if err != nil {
			return false, response.JSON_SERIALIZATION_FAILED, ""
		}

		// 文件上传
		// uploadFolder = /usr/loacl/hsm-os/data/hsm-io-it/data/temp/tempFile/upload/
		uploadFolder := tempPath + "upload/"
		util.CreateDir(uploadFolder)
		// 文件复制
		jobFolderPath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Project + namespace + constants.Hierarchy + "upload/"
		util.CopyFilesToFolder(jobFolderPath, uploadFolder)

		dataBasefolder := tempPath + namespace + constants.Hierarchy + constants.DataBaseConfig
		util.CreateDir(dataBasefolder)
		util.WriteFile(dataBasefolder+"database"+constants.Suffix, string(dbData))
		// tempPath = /usr/loacl/hsm-os/data/hsm-io-it/data/temp/tempFile/namespace.json
		util.WriteFile(tempPath+namespace+constants.JsonIdentifier, string(jobData))
		// tempPath = /usr/loacl/hsm-os/data/hsm-io-it/data/temp/tempFile/namespace.txt
		util.WriteFile(tempPath+namespace+constants.TxtIdentifier, namespace+constants.AtProject)
	} else {
		util.WriteFile(tempPath+namespace+constants.TxtIdentifier, namespace+constants.AtNull+constants.AtProject)
	}

	err = util.CompressFolderToZip(tempPath, tempPathZip)
	if err != nil {
		return false, response.COMPRESS_FAILED, ""
	}
	encodedFileName := makeEncodedFileName(namespace + constants.Zip)
	c.Header("Content-Type", "application/octet-stream")
	c.Header("Content-Disposition", fmt.Sprintf("attachment; filename=%s", encodedFileName))
	c.Header("Content-Transfer-Encoding", "binary")
	c.File(tempPathZip)
	err = os.RemoveAll(removePath)
	if err != nil {
		return false, response.DELETE_FILE_FAILED, ""
	}
	return true, 0, "项目导出成功"
}

func makeEncodedFileName(fileName string) string {
	encodedFileName := fileName
	if len(encodedFileName) > 0 {
		encodedFileName = url.PathEscape(encodedFileName)
	}
	return encodedFileName
}

// 删除项目
type DeleteProjectVo struct {
	Code   string `gorm:"column:code"`
	Status int    `gorm:"column:status"`
}

func DeleteProject(projectRequest *vo.JobKeyInfo) (bool, string) {
	var deleteProjectVo []DeleteProjectVo

	err := util.GlobalGormDb.Table("ioit.job_info").Select("code,status").Where("namespace = ?", projectRequest.NameSpace).Find(&deleteProjectVo).Error
	if err != nil {
		logger.Info("数据查询失败%v", err)
	}

	var codes []string
	var runningCodes []string

	for i := range deleteProjectVo {
		if deleteProjectVo[i].Status == 1 {
			runningCodes = append(runningCodes, deleteProjectVo[i].Code)
		}
		codes = append(codes, deleteProjectVo[i].Code)
	}

	logger.Info("codes:%v", codes)
	logger.Info("runningCodes:%v", runningCodes)

	// 停止正在运行的任务
	StopRunningJob(projectRequest.NameSpace, runningCodes)

	err = util.GlobalGormDb.Table("ioit.job_info").Where("namespace = ?", projectRequest.NameSpace).Delete(&vo.CreateJobRequest{}).Error
	if err != nil {
		logger.Info("数据删除失败%v", err)
		return false, "删除失败"
	}

	err = util.GlobalGormDb.Table("ioit.database_info").Where("namespace = ?", projectRequest.NameSpace).Delete(&vo.DatabaseInfoRequest{}).Error

	if err != nil {
		logger.Info("数据删除失败%v", err)
		return false, "删除失败"
	}

	//删除benthos下面的文件
	var jobname []string
	for i := range codes {
		jobname = append(jobname, codes[i]+constants.Suffix)
	}
	benthosLogPath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + config.ConfigAll.BenthosLogs
	logger.Info("benthosLogPath:%v", benthosLogPath)
	logger.Info("jobname:%v", jobname)
	DeleteFilesWithNames(benthosLogPath, jobname)
	logger.Info("删除日志文件完毕")
	return true, "删除成功"
}

// 导出项目
func ExportProject(namespace, filePath string) (int, string) {

	globalMap.Store(namespace, true)
	logger.Info("导出项目：%v 开始", namespace)
	logger.Info("项目路径:%v", filePath)
	tarName := filepath.Base(filePath)
	tempPathZip := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp + constants.Project
	//创建临时文件目录
	util.CreateDir(tempPathZip)

	resultPath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp + namespace + constants.Suffix

	existQuery := `SELECT EXISTS (SELECT 1 FROM ioit.job_info WHERE namespace = $1)`

	var exists bool
	err := util.GlobalGormDb.Raw(existQuery, namespace).Scan(&exists).Error
	if err != nil {
		logger.Info("数据库操作失败%v", err)
	}

	if exists {
		var jobs []vo.CreateJobRequest
		err = util.GlobalGormDb.Table("ioit.job_info").Where("namespace = ?", namespace).Find(&jobs).Error

		if err != nil {
			logger.Info("数据库操作失败%v", err)
		}

		jobData, err := json.Marshal(jobs)
		if err != nil {
			logger.Info("数据映射失败%v", err)
		}

		var databaseInfoList []vo.DatabaseInfoRequest

		err = util.GlobalGormDb.Table("ioit.database_info").Where("namespace = ?", namespace).Find(&databaseInfoList).Error

		if err != nil {
			logger.Info("查询失败:%v", err)
		}

		dbData, err := json.Marshal(databaseInfoList)
		logger.Info("jobData:%v", string(dbData))

		if err != nil {
			logger.Info("数据映射失败%v", err)
		}

		// 文件上传
		// uploadFolder = /usr/loacl/hsm-os/data/hsm-io-it/data/temp/tempFile/upload/
		jobFolderPath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Project + namespace + constants.Hierarchy + "upload/"

		if util.PathExists(jobFolderPath) {
			uploadFolder := tempPathZip + namespace + constants.Hierarchy + "upload/"
			util.CreateDir(uploadFolder)
			// 文件复制
			util.CopyFilesToFolder(jobFolderPath, uploadFolder)
		}

		dataBasefolder := tempPathZip + namespace + constants.Hierarchy + constants.DataBaseConfig
		util.CreateDir(dataBasefolder)
		util.WriteFile(dataBasefolder+"database"+constants.Suffix, string(dbData))
		util.WriteFile(tempPathZip+namespace+constants.JsonIdentifier, string(jobData))
		util.WriteFile(tempPathZip+namespace+constants.TxtIdentifier, "database")
	}

	//压缩文件
	logger.Info("开始打包项目：%v", namespace)
	cmd2 := exec.Command("tar", "-czvf", tarName, "project/")
	cmd2.Dir = constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp
	err2 := cmd2.Run()
	if err2 != nil {
		util.WriteFile(resultPath, "false")
		return 0, "失败"
	}
	util.WriteFile(resultPath, "80")
	//移动文件的位置
	sourceFile := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp + tarName
	fileDir := filepath.Dir(filePath)
	time.Sleep(1 * time.Second)
	flag1 := util.PathExists(fileDir)
	logger.Info("ENG文件目录是否存在:%v", flag1)
	if !flag1 {
		logger.Info("文件目录：%v不存在,IOIT创建", fileDir)
		util.ClearFolder(fileDir)
		// return 0, "失败"
	}
	logger.Info("sourceFile is %v", sourceFile)
	cmd3 := exec.Command("mv", sourceFile, filePath)
	output, err3 := cmd3.CombinedOutput()
	if err3 != nil {
		logger.Error("移动文件失败:%v", output)
		util.WriteFile(resultPath, "false")
		logger.Info("导出项目%v失败", namespace)
		// util.RemoveFolder(tempPathZip)
		return 0, "失败"
	}
	util.WriteFile(resultPath, "100")
	//删除临时文件夹
	// util.RemoveFolder(tempPathZip)
	logger.Info("导出项目：%v 成功", namespace)
	return 1, "成功"
}

// 取消导出项目
func CancelExportProject(namespace, filePath string) (int, string) {
	logger.Info("取消导出项目%v 开始", namespace)
	globalMap.Store(namespace, false)
	util.RemoveFolder(filePath)
	logger.Info("取消导出项目%v 成功", namespace)
	return 0, "成功"
}

// 导出项目结果查询
func ExportResult(namespace, filePath string) (int, string) {

	resultPath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp + namespace + constants.Suffix
	data := util.ReadFile(resultPath)
	value, ok := globalMap.Load(namespace)
	if ok {
		logger.Info("key: %v,value: %v", namespace, value)
		boolVal, boolOk := value.(bool)
		logger.Info("boolVal: %v,boolOk: %v", boolVal, boolOk)
		if boolOk {
			if !boolVal {
				globalMap.Delete(namespace)
				return 1, "50"
			}
		}
		if data == "100" {
			globalMap.Delete(namespace)
			return 2, data
		}
	}
	return 1, "60"
}

// 导入项目
func ImportProject(namespace, filePath string) (int, string) {

	logger.Info("开始导入项目%v", namespace)
	logger.Info("路径%v", filePath)
	nameFile := namespace + "_import"
	globalMap.Store(nameFile, true)

	fileFlag := util.PathExists(filePath)
	if !fileFlag {
		logger.Error("导入项目文件路径%v 不存在", filePath)
		return 0, "文件不存在！"
	}
	tarName := filepath.Base(filePath)
	tarPath := filepath.Dir(filePath)
	logger.Info("导入的文件目录：%v", tarPath)
	logger.Info("导入的文件目录：%v", tarName)

	fileNameVersion := strings.Split(tarName, "#")[3]
	logger.Info("文件版本为=============：%v", fileNameVersion)

	value, ok := globalMap.Load(nameFile)
	if ok {
		boolVal, boolOk := value.(bool)
		if boolOk {
			if !boolVal {
				logger.Info("取消导入操作1--> key: %v,value: %v", namespace, value)
				logger.Error("导入操作取消")
				return 0, "取消导入"
			}
		}
	}

	targetDir1 := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp
	if !util.PathExists(targetDir1) {
		util.CreateDir(targetDir1)
	}
	// 构建解压命令
	cmd := exec.Command("tar", "-zxvf", tarName, "-C", targetDir1)
	cmd.Dir = tarPath
	cmdOutput, err := cmd.CombinedOutput()
	if err != nil {
		logger.Error("解压错误:%v", string(cmdOutput))
		return 0, "取消导入"
	}
	logger.Info("Stdout:%v", string(cmdOutput))

	value, ok = globalMap.Load(nameFile)
	if ok {
		boolVal, boolOk := value.(bool)
		if boolOk {
			if !boolVal {
				logger.Info("取消导入操作2--> key: %v,value: %v", namespace, value)
				logger.Error("导入操作取消")
				return 0, "取消导入"
			}
		}
	}

	flagPath := targetDir1 + constants.Project + namespace + constants.TxtIdentifier
	uploadPath := targetDir1 + constants.Project + namespace + constants.Hierarchy + constants.UpLoad
	if !util.PathExists(flagPath) {
		return 1, "成功"
	}
	err, isDatabaseVersion := util.ReadFileV2(flagPath)
	if err != nil {
		logger.Error(err)
		return 0, "取消导入"
	}
	if isDatabaseVersion == "database" {
		//清空项目
		// 1. 删除原来的任务，通过namespace和s_node
		err = util.GlobalGormDb.Table("ioit.job_info").Where("namespace = ?", namespace).Delete(&vo.CreateJobRequest{}).Error
		if err != nil {
			logger.Info("删除数据失败:%v", err)
		}
		// 2. 删除原来的数据连接信息,通过namespace
		err = util.GlobalGormDb.Table("ioit.database_info").Where("namespace = ?", namespace).Delete(&vo.DatabaseInfoRequest{}).Error
		if err != nil {
			logger.Info("删除数据失败:%v", err)
		}

		// 解压后的目录
		jobPath := targetDir1 + constants.Project + namespace + constants.Suffix
		databasePath := targetDir1 + constants.Project + namespace + constants.Hierarchy + constants.DataBaseConfig

		var jobsImportList []vo.CreateJobRequest
		jobInfos := util.ReadFile(jobPath)
		if len(jobInfos) != 0 {
			if err := json.Unmarshal([]byte(jobInfos), &jobsImportList); err != nil {
				logger.Error("json反序列化出错:%v", err)
			}
		}

		for _, v := range jobsImportList {
			v.EditeTime = time.Now().Format("2006-01-02 15:04:05")
			v.Status = constants.ReadyJob
			v.SKNode = util.ServerCode
			err = util.GlobalGormDb.Table("ioit.job_info").Create(&v).Error

			if err != nil {
				logger.Info("数据库操作失败：%v", err)
			}
		}
		dbFlag := util.PathExists(databasePath)

		db, err := util.GetPgConn()
		if err != nil {
			logger.Info("数据库连接失败")
		}
		defer db.Close()

		if dbFlag {
			var databaseInfoList []vo.DatabaseInfoRequest
			databaseInfo := util.ReadFile(databasePath + "database.json")

			if len(databaseInfo) != 0 {
				if err := json.Unmarshal([]byte(databaseInfo), &databaseInfoList); err != nil {
					logger.Error("json反序列化出错:%v", err)
				}
			}

			for _, v := range databaseInfoList {
				if v.Retry == "" {
					v.Retry = "5"
				}
				err = util.GlobalGormDb.Table("ioit.database_info").Create(&v).Error
				if err != nil {
					logger.Info("数据库操作失败：%v", err)
				}
			}
		}
	} else {
		//项目升级
		logger.Info("开始升级项目 start:  %v", namespace)
		isUpgrade := ProjectUpgrade(fileNameVersion, namespace)
		logger.Info("开始升级项目 end:  %v", isUpgrade)
	}
	// 4. 文件上传
	// 上传文件
	namespaceUploadPath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Project + namespace + constants.Hierarchy + "upload"
	flag := util.PathExists(uploadPath)
	if flag {
		if !util.PathExists(namespaceUploadPath) {
			util.CreateDir(namespaceUploadPath)
		}
		// 如果存在，则复制子文件中的内容到项目指定目录下
		util.CopyFilesToFolder(uploadPath, namespaceUploadPath)
	}

	logger.Info("导入项目：%v 成功", namespace)
	return 1, "成功"
}

type OldCreateJobRequest struct {
	NameSpace       string                 `json:"namespace" binding:"required"` //工程名
	NickName        string                 `json:"nickName"`                     //用户名
	Node            int                    `json:"node"`                         //服务器节点
	ENG_node        string                 `json:"s_node" binding:"required"`    //服务器节点
	Code            string                 `json:"code"`                         //作业编号
	Name            string                 `json:"name" binding:"required"`      //作业名称
	Describe        string                 `json:"describe"`                     //作业描述
	Schedule        string                 `json:"schedule"`                     //调度类型
	ScheduleDetails string                 `json:"schedule_details"`             //corn表达式
	ScheduleCycle   string                 `json:"schedule_cycle"`               //调度周期
	ScheduleUnit    string                 `json:"schedule_unit"`                //调度类型
	Content         OldContent             `json:"content"`
	CronId          string                 `json:"cron_id"`
	IsHttp          bool                   `json:"is_http"`
	Canvas          map[string]interface{} `json:"canvas"`
	JobType         string                 `json:"job_type"`
	Template        string                 `json:"template"`
}

type OldJobInfo struct {
	Node           int    `json:"node"`
	Code           string `json:"code"`
	Id             string `json:"id"`
	Name           string `json:"name"`
	Status         int    `json:"status"`
	CreateTime     string `json:"create_time"`
	EditeTime      string `json:"edite_time"`
	CreateUse      string `json:"create_use"`
	Describe       string `json:"describe"`
	IsAutoSelectId bool   `json:"isAutoSelectId"`
	ENG_node       string `json:"s_node"`
	JobType        string `json:"job_type"`
}

type OldContent struct {
	BenthosYaml      string                   `json:"benthos_yaml"`
	BenthosComponent map[string]interface{}   `json:"benthos_componnet"`
	NodeYamlMap      map[string]interface{}   `json:"node_yaml_map"`
	NodeDataMap      map[string]interface{}   `json:"node_data_map"`
	CanvasParamMap   []map[string]interface{} `json:"canvas_param"`
}

func ProjectUpgrade(version, namespace string) bool {
	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
	}
	defer db.Close()

	// 1.找到主文件和子文件，进行数据匹配，然后插入，保留原始的数据结构
	targzPath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp + constants.Project
	mainData := util.ReadFile(targzPath + namespace + constants.Suffix)
	var jobs []OldJobInfo
	if err := json.Unmarshal([]byte(mainData), &jobs); err != nil {
		logger.Error(err)
	}

	subData := util.ReadFile(targzPath + namespace + constants.Hierarchy)
	var subJobs []OldCreateJobRequest
	if err := json.Unmarshal([]byte(subData), &subJobs); err != nil {
		logger.Error(err)
	}

	// 插入job信息
	for _, m := range jobs {
		for _, s := range subJobs {
			if m.Code == s.Code {
				addsql := `INSERT INTO ioit.job_info (
					namespace,		create_user,		s_node,
					code,			name,				describe,
					schedule,		schedule_details,	schedule_cycle,
					schedule_unit,	content,			cron_id,
					is_http,		canvas,				job_type,
					template,		id,					status,
					create_time,	edite_time,			is_auto_select_id, job_class) 
				VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22)`

				m.EditeTime = time.Now().Format("2006-01-02 15:04:05")
				m.Status = constants.ReadyJob
				m.ENG_node = util.ServerCode

				content, errs := json.Marshal(s.Content)
				if errs != nil {
					fmt.Println("json marshal error:", errs)
				}

				canvas, errs := json.Marshal(s.Canvas)
				if errs != nil {
					fmt.Println("json marshal error:", errs)
				}

				_, err := db.Exec(addsql,
					namespace, m.CreateUse, util.ServerCode, m.Code, m.Name,
					s.Describe, s.Schedule, s.ScheduleDetails, s.ScheduleCycle,
					s.ScheduleUnit, content, s.CronId, s.IsHttp, canvas, m.JobType,
					s.Template, m.Id, m.Status, m.CreateTime, m.EditeTime,
					m.IsAutoSelectId, "")

				if err != nil {
					logger.Info("数据库操作失败：%v", err)
				}

			}
		}
	}
	// 2.找到所有的数据库文件，进行数据插入，如果是0.4版本，只找databaseinfo.json
	// 判断是否存在mysql信息
	exists, _ := util.FileExist(targzPath + namespace + constants.Hierarchy + constants.DataBaseInfo + constants.Suffix)
	var dbInfos []vo.DatabaseInfoRequest
	if exists {
		mysqlData := util.ReadFile(targzPath + namespace + constants.Hierarchy + constants.DataBaseInfo + constants.Suffix)
		var mysqlInfo []vo.DatabaseInfoRequest
		if err := json.Unmarshal([]byte(mysqlData), &mysqlInfo); err != nil {
			logger.Error(err)
		}
		// 插入数据
		for i := range mysqlInfo {
			mysqlInfo[i].DataBaseType = "MySQL"
		}
		dbInfos = append(dbInfos, mysqlInfo...)
	}
	// 判断databaseconfig下面的所有数据库配置文件
	if util.PathExists(targzPath + namespace + constants.Hierarchy + constants.DataBaseConfig) {
		dbFiles, _ := util.GetAllJsonFiles(targzPath + namespace + constants.Hierarchy + constants.DataBaseConfig)
		for _, v := range dbFiles {
			dbdata := util.ReadFile(v)
			var dblist []vo.DatabaseInfoRequest
			if err := json.Unmarshal([]byte(dbdata), &dblist); err != nil {
				logger.Error(err)
			}
			// 判断数据库类型
			if filepath.Base(v) == "data_base_info.json" {
				for i := range dblist {
					dblist[i].DataBaseType = "EMySQL"
				}
			}
			if filepath.Base(v) == "SQLite.json" {
				for i := range dblist {
					dblist[i].DataBaseType = "SQLite"
				}
			}
			if filepath.Base(v) == "Postgres.json" {
				for i := range dblist {
					dblist[i].DataBaseType = "Postgres"
				}
			}
			if filepath.Base(v) == "SQLServer.json" {
				for i := range dblist {
					dblist[i].DataBaseType = "SQLServer"
				}
			}

			// 插入数据
			dbInfos = append(dbInfos, dblist...)
		}
	}
	// 判断是否有电子厂的数据库连接
	if util.PathExists(targzPath + namespace + constants.Hierarchy + constants.MESData) {
		dbdata := util.ReadFile(targzPath + namespace + constants.Hierarchy + constants.MESData + constants.DataBaseInfo + constants.Suffix)
		var meslist []vo.DatabaseInfoRequest
		if err := json.Unmarshal([]byte(dbdata), &meslist); err != nil {
			logger.Error(err)
		}
		// 插入数据
		for i := range meslist {
			meslist[i].DataBaseType = "EMySQL"
		}
		dbInfos = append(dbInfos, meslist...)

	}

	adddbsql := `INSERT INTO ioit.database_info (code, connectname, username, password, host, 
		port, namespace, databasetype, dbname, schemaname, tablename, dbpath, s_node)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)`

	for _, v := range dbInfos {
		_, err = db.Exec(adddbsql,
			v.Code, v.ConnectName, v.Username, v.Password, v.Host, v.Port, namespace,
			v.DataBaseType, v.DbName, v.SchemaName, v.Tablename, v.DbPath, util.ServerCode)
		if err != nil {
			logger.Info("数据库操作失败：%v", err)
		}
	}

	return true
}

type StopRunningJobVo struct {
	IsHttp   bool   `gorm:"column:is_http"`
	CronId   string `gorm:"column:cron_id"`
	Schedule string `gorm:"column:schedule"`
}

func StopRunningJob(namespace string, codes []string) bool {

	logger.Info("开始停止 %v 的作业", namespace)

	for _, code := range codes {
		var stopRunningJobVo StopRunningJobVo
		err := util.GlobalGormDb.Table("ioit.job_info").Select("is_http, schedule, cron_id").Where("namespace = ? AND code = ?", namespace, code).First(&stopRunningJobVo).Error
		if err != nil {
			logger.Info("数据查询失败%v", err)
		}

		logger.Info("isHttp:%v", stopRunningJobVo.IsHttp)

		if stopRunningJobVo.IsHttp {
			run.Stop(code)
			logger.Info("项目%v作业%v停止成功", namespace, code)
		} else {
			if stopRunningJobVo.Schedule == constants.Period_schedule {
				if stopRunningJobVo.CronId == constants.EmptyContent {
					logger.Info("项目%v作业%v停止成功,CronId为空", namespace, code)
					continue
				}
				cronIdInt, err1 := strconv.Atoi(stopRunningJobVo.CronId)
				if err1 != nil {
					logger.Error("类型转换失败", err1)
				}
				logger.Error("cornId:------->", cronIdInt)
				cron.DeleteCron(cronIdInt)
				logger.Info("项目%v作业%v停止成功", namespace, code)
			}
		}
	}
	return true
}

// 取消导入项目
func CancelImportProject(namespace, filePath string) (int, string) {

	nameFile := namespace + "_import"
	globalMap.Store(nameFile, false)
	logger.Info("取消导入项目%v 成功", namespace)
	return 1, "成功"
}

// 导入查询
func ImportResult(namespace, filePath string) (int, string) {
	// targetDir := "/usr/local/hsm-os/data/hsm-io-it/data/project/"
	nameFile := namespace + "_import"
	// projectFile := targetDir + namespace + constants.Suffix
	// logger.Info("导入项目目录：%v", projectFile)
	value, ok := globalMap.Load(nameFile)
	if ok {

		boolVal, boolOk := value.(bool)
		// logger.Info("boolVal: %v,boolOk: %v", boolVal, boolOk)
		if boolOk {
			if !boolVal {
				logger.Info("导出接口查询：导出失败---> key: %v,value: %v", namespace, value)
				globalMap.Delete(nameFile)
				return 1, "50"
			}
			if boolVal {
				logger.Info("导出接口查询：导出成功---> key: %v,value: %v", namespace, value)
				globalMap.Delete(nameFile)
				return 2, "成功"
			}
		}
	}
	return 2, "成功"
}

// 添加作业
func AddJob(jobRequest *vo.CreateJobRequest) (bool, int, string, *JobInfo) {
	var code string
	if jobRequest.NameSpace != constants.PORTALNAME {
		code = generateCode()
	} else {
		code = jobRequest.Code
	}

	jobRequest.Code = code
	jobRequest.Id = code
	jobRequest.IsAutoSelectId = true
	createTime := time.Now().Format("2006-01-02 15:04:05")

	// 作业模板插入**************
	templateName := jobRequest.Template
	if templateName != "" {
		canvasInfo := sap.ResloveParten(templateName)

		logger.Info("canvasInfo%v", canvasInfo)

		canvasMap := map[string]interface{}{
			"lineList": canvasInfo.LineList,
			"nodeList": canvasInfo.NodeList,
		}

		if jobRequest.JobType == "realtime" {
			jobRequest.Canvas = canvasMap
		}
	}

	jobRequest.SKNode = util.ServerCode

	logger.Info("ScheduleType:%v", jobRequest.PeriodDetail)
	logger.Info("jobRequest:%v", jobRequest)

	if jobRequest.Schedule == "2" {
		var secondInte int
		cycle := jobRequest.PeriodDetail.ScheduleCycle
		switch jobRequest.PeriodDetail.ScheduleUnit {
		case "second":
			secondInte = cycle
		case "minute":
			secondInte = cycle * 60
		case "hour":
			secondInte = cycle * 3600
		default:
			logger.Info("default")
		}
		second := strconv.Itoa(secondInte)
		jobRequest.ScheduleDetails = "@every " + second + "s"
	}

	if jobRequest.Schedule == "cron" {
		jobRequest.ScheduleDetails = GenerateCronExp(jobRequest)
	}

	logger.Info("jobRequest.ScheduleType is:%v", jobRequest.ScheduleDetails)

	jobRequest.CreateTime = time.Now().Format("2006-01-02 15:04:05")
	jobRequest.EditeTime = time.Now().Format("2006-01-02 15:04:05")
	jobRequest.Status = 0

	if jobRequest.Canvas == nil {
		logger.Info("jobRequest.cavas:%v", jobRequest.Canvas)
		jobRequest.Canvas = map[string]interface{}{}
	}

	if jobRequest.NameSpace != constants.PORTALNAME && jobRequest.Schedule == "2" {
		if jobRequest.CronDetail.EffectiveDate == "" {
			jobRequest.CronDetail.EffectiveDate = time.Now().Format("2006-01-02 15:04:05")
		}

		if jobRequest.PeriodDetail.EffectiveDate == "" {
			jobRequest.PeriodDetail.EffectiveDate = time.Now().Format("2006-01-02 15:04:05")
		}

		if jobRequest.PeriodDetail.EndType == "" {
			jobRequest.PeriodDetail.EndType = "endless"
		}
	}

	util.GlobalGormDb.Table("ioit.job_info").Create(jobRequest)

	var jobInfo JobInfo
	jobInfo.Code = jobRequest.Code
	jobInfo.CreateTime = createTime
	jobInfo.CreateUse = jobRequest.CreateUse
	jobInfo.Describe = jobRequest.Describe
	jobInfo.EditeTime = createTime
	jobInfo.Id = jobRequest.Id
	jobInfo.IsAutoSelectId = jobRequest.IsAutoSelectId
	jobInfo.JobType = jobRequest.JobType
	jobInfo.Name = jobRequest.Name
	jobInfo.SKNode = jobRequest.SKNode
	jobInfo.Status = jobRequest.Status
	jobInfo.JobClass = jobRequest.JobClass

	logger.Info("添加作业成功：%s", code)
	return true, 0, jobRequest.Name, &jobInfo
}

func CheckCode(namespace, code string) bool {
	var codes []string
	err := util.GlobalGormDb.Table("ioit.job_info").Select("code").Where("namespace = ?", namespace).Find(&codes).Error
	if err != nil {
		logger.Info("select exist code failed:%v", err)
	}

	logger.Info("codes:%v", codes)
	for _, v := range codes {
		if v == code {
			return false
		}
	}
	return true
}

// 保存作业
func SaveJob(jobRequest *vo.CreateJobRequest) (bool, string, int) {
	flag, _, _, code := UpdateJob(jobRequest)
	if flag {
		return true, "作业保存成功", code
	} else {
		return false, "作业保存失败", code
	}
}

func UpdateJob(jobRequest *vo.CreateJobRequest) (bool, string, *vo.CreateJobRequest, int) {

	code := jobRequest.Code
	namespace := jobRequest.NameSpace
	skNode := jobRequest.SKNode
	editeTime := time.Now().Format("2006-01-02 15:04:05")

	logger.Info("ScheduleType:%v", jobRequest.PeriodDetail)
	if jobRequest.Schedule == "2" {
		var secondInte int
		cycle := jobRequest.PeriodDetail.ScheduleCycle
		switch jobRequest.PeriodDetail.ScheduleUnit {
		case "second":
			secondInte = cycle
		case "minute":
			secondInte = cycle * 60
		case "hour":
			secondInte = cycle * 3600
		default:
			logger.Info("default")
		}
		second := strconv.Itoa(secondInte)
		jobRequest.ScheduleDetails = "@every " + second + "s"
	}

	if jobRequest.Schedule == "cron" {
		jobRequest.ScheduleDetails = GenerateCronExp(jobRequest)
	}

	// 判断是否正在运行的作业
	jobInfo := util.GetJobDetailsInfo(namespace, code, skNode)
	if jobInfo.Status == 1 {
		return false, "作业正在运行中，不允许修改", nil, response.RUNNING_JOB_NOT_OP
	}

	if jobRequest.NameSpace != constants.PORTALNAME && jobRequest.Schedule == "2" {
		if jobRequest.CronDetail.EffectiveDate == "" {
			jobRequest.CronDetail.EffectiveDate = time.Now().Format("2006-01-02 15:04:05")
		}

		if jobRequest.PeriodDetail.EndType == "" {
			jobRequest.PeriodDetail.EndType = "endless"
		}
	}

	jobRequest.Id = jobRequest.Code
	jobRequest.Status = 0
	jobRequest.EditeTime = editeTime
	jobRequest.IsAutoSelectId = true
	err := util.GlobalGormDb.Table("ioit.job_info").Where("namespace = ? AND code = ?", jobRequest.NameSpace, jobRequest.Code).Updates(jobRequest).Error

	if err == nil {
		logger.Info("更新作业成功：%s", code)
		return true, "编辑作业<" + jobRequest.Name + ">成功", jobRequest, 0
	} else {
		logger.Info("数据库更新失败:%v", err)
		return false, "保存失败", nil, response.DATABASE_UPDATE_FAILED
	}
}

type JobName struct {
	Name string `gorm:"column:name"`
}

func CheckName(namespace, skNode, name, code string) bool {

	var names []string
	err := util.GlobalGormDb.Table("ioit.job_info").Select("name").Where("namespace = ? AND code != ?", namespace, code).Find(&names).Error
	if err != nil {
		logger.Info("Update Fail to connect pg:%v", err)
	}

	logger.Info("names:%v", names)
	for _, v := range names {
		if v == name {
			return true
		}
	}
	return false
}

// 删除作业
func DeleteJob(deleteJobRequest *vo.JobKeyInfo) (bool, int, string) {
	code := deleteJobRequest.Code
	namespace := deleteJobRequest.NameSpace
	nodeRes := util.GetNodeServer()
	skNode := nodeRes[1]
	deleteJobRequest.SKNode = skNode

	logger.Info("deleteJobRequest:%v", deleteJobRequest)

	jobInfo := util.GetJobDetailsInfo(namespace, code, skNode)
	if jobInfo == nil {
		return false, response.GET_INFO_FAILED, ""
	}

	if jobInfo.Status == 1 {
		return false, response.RUNNING_JOB_NOT_OP, ""
	}

	logger.Info("deleteJobRequest:%v", deleteJobRequest)

	err := util.GlobalGormDb.Table("ioit.job_info").Where("namespace = ? AND code = ?", namespace, code).Delete(&vo.CreateJobRequest{}).Error
	if err != nil {
		logger.Info("delete failed:%v", err)
		return false, response.DATABASE_OPERATION_FAILED, ""
	}

	//删除运行日志
	benthosLog := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + config.ConfigAll.FILE.BenthosLogs + code + constants.Suffix
	logFlag := util.PathExists(benthosLog)
	if logFlag {
		error := os.Remove(benthosLog)
		logger.Info("删除日志文件%v", error)
	}

	if err == nil {
		logger.Info("删除作业成功：%s", code)
		return true, 0, "删除作业<" + jobInfo.Name + ">成功"
	} else {
		logger.Info("数据库作业删除失败:%v", err)
		return false, response.DELETE_FAILED, ""
	}
}

// 查询作业
func GetJobList(getJobRequest *vo.JobListReq) (bool, []NodeTree, string) {
	logger.Info("namespace:%v", getJobRequest.NameSpace)

	var jobs []vo.CreateJobRequest

	var err1 error
	if getJobRequest.NameSpace != constants.PORTALNAME {
		getJobRequest.JobClass = ""
	}

	if getJobRequest.JobClass == "" {
		err1 = util.GlobalGormDb.Table("ioit.job_info").Where("namespace = ?", getJobRequest.NameSpace).Find(&jobs).Error
	} else {
		err1 = util.GlobalGormDb.Table("ioit.job_info").Where("namespace = ? AND job_class = ?", getJobRequest.NameSpace, getJobRequest.JobClass).Find(&jobs).Error
	}

	if err1 != nil {
		logger.Info("数据库连接失败:%v", err1)
		return false, nil, "作业列表查询失败"
	}

	configSlice := util.GetNodeServer()
	result := []NodeTree{
		{
			Id:   configSlice[1],
			Name: configSlice[2],
			Ip:   configSlice[0],
		},
	}

	var resJobs []vo.CreateJobRequest
	for i := range jobs {
		resJobs = append(resJobs, jobs[i])
	}

	sort.Sort(JobInfoSlice(resJobs))
	if getJobRequest.NameSpace != constants.PORTALNAME {
		result[0].Id = "e1"
	}
	result[0].Children = resJobs

	return true, result, "作业列表查询成功"
}

func generateCode() string {
	rand.Seed(time.Now().UnixNano())

	const letters = "abcdefghijklmnopqrstuvwxyz0123456789"
	const prefix = "job_"
	code := prefix
	code += string(letters[rand.Intn(26)]) // 第二位为小写字母
	for i := 0; i < 7; i++ {
		code += string(letters[rand.Intn(len(letters))])
	}
	return code
}

// ENG 发布订阅
func Search(jobContent *vo.GetJobContent) (bool, []JobInfo) {
	logger.Info("jobContent:%v", jobContent)

	query := `SELECT 
				create_user, name, describe, job_type, id, status, create_time, 
				edite_time, is_auto_select_id, status, s_node, job_class
 			FROM ioit.job_info WHERE namespace = $1`

	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, nil
	}
	defer db.Close()

	rows, err := db.Query(query, jobContent.Namespace)

	if err != nil {
		logger.Info("数据库连接失败:%v", err)
		return false, nil
	}

	defer rows.Close()

	var jobs []JobInfo

	for rows.Next() {
		var job JobInfo
		if err := rows.Scan(&job.CreateUse, &job.Name, &job.Describe, &job.JobType,
			&job.Id, &job.Status, &job.CreateTime, &job.EditeTime,
			&job.IsAutoSelectId, &job.Status, &job.SKNode, &job.JobClass); err != nil {
			logger.Info("数据库连接失败:%v", err)
			return false, nil
		}
		jobs = append(jobs, job)
	}

	content := jobContent.Content

	matchedJob := make([]JobInfo, 0)
	for _, p := range jobs {
		if strings.Contains(p.Name, content) {
			logger.Info("查询数据作业成功，内容为:%v", p.Id)
			matchedJob = append(matchedJob, p)
		}
	}
	logger.Info("查询数据作业成功，内容为:%v", matchedJob)

	// 发送ENG查找数据

	type MenuData struct {
		ActiveNodeId string   `json:"activeNodeId"`
		Id           string   `json:"id"`
		ParentIdArr  []string `json:"parentIdArr"`
	}

	type subReq struct {
		ModifyTime   int64  `json:"modifyTime"`
		RelativePath string `json:"relativePath"`
		Desc         string `json:"desc"`
		AppData      string `json:"appData"`
		EventType    string `json:"type"`
		MenuData     string `json:"menuData"`
	}

	type findReq struct {
		From        string   `json:"from"`
		Target      string   `json:"target"`
		ContentType string   `json:"type"`
		SessionId   string   `json:"sessionId"`
		Data        []subReq `json:"data"`
	}

	ip := util.ServerCode + constants.DomainName

	subRes := make([]subReq, 0)
	for i := range matchedJob {
		if i <= 300 {
			data := subReq{
				ModifyTime:   time.Now().UnixMilli(),
				RelativePath: matchedJob[i].Name,
				Desc:         matchedJob[i].Describe,
				EventType:    "project-tree-model-check-success",
			}

			menuData := MenuData{
				Id:          matchedJob[i].Id,
				ParentIdArr: []string{"hsm-io-it", "e1"},
			}

			jsonS, err := json.Marshal(menuData)

			if err != nil {
				logger.Info("err is :%v", err)
			}

			data.MenuData = string(jsonS)
			subRes = append(subRes, data)
		}
	}

	logger.Info("subRes:%v", subRes)

	request := findReq{
		From:        "hsm-io-it",
		Target:      "hsm-eng-back-end",
		ContentType: "find",
		SessionId:   jobContent.SessionId,
		Data:        subRes,
	}

	requestBody, err := json.Marshal(request)
	if err != nil {
		logger.Info("请求体解析错误:%v", err)
	}

	logger.Info("requestBody:%v", string(requestBody))
	req, err := http.NewRequest("POST", constants.Http+ip+":7082/eng/v1/msg/send", bytes.NewBuffer(requestBody))
	if err != nil {
		logger.Info("Fail to send request")
	}

	req.Header.Set("Content-Type", "application/json")
	client := &http.Client{Timeout: 60 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		logger.Info("Fail to do request")
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		logger.Info("Executor returned non-OK")
	} else {
		body, _ := ioutil.ReadAll(resp.Body)
		logger.Info("body:%v", string(body))
	}
	return true, matchedJob
}

// 作业分类管理***********************
type JobCataReq struct {
	NameSpace  string `json:"namespace"`
	SKNode     string `json:"s_node"`
	CataCode   string `json:"cl_code"`
	CataName   string `json:"cg_name"`
	CataParent string `json:"cg_parent"`
	Describe   string `json:"cg_describe"`
}

type JobCataNode struct {
	CataCode string         `json:"cl_code"`
	CataName string         `json:"cg_name"`
	Describe string         `json:"cg_describe"`
	Children []*JobCataNode `json:"children"`
}

func generateCateCode() string {
	rand.Seed(time.Now().UnixNano())

	const letters = "abcdefghijklmnopqrstuvwxyz0123456789"
	const prefix = "cate_"
	code := prefix
	code += string(letters[rand.Intn(26)])
	for i := 0; i < 7; i++ {
		code += string(letters[rand.Intn(len(letters))])
	}
	return code
}

func AddJobCata(jobCataReq *JobCataReq) (bool, int, string, string) {
	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, response.DATABASE_CONNECT_FAILED, "", ""
	}
	defer db.Close()

	logger.Info("jobCataReq:%v", jobCataReq)

	jobCataReq.SKNode = util.ServerCode
	cateCode := generateCateCode()
	jobCataReq.CataCode = cateCode

	flag := CheckCateName(jobCataReq.CataName)
	if flag {
		return false, response.CATENAME_ALREADY_EXIST, "", ""
	}

	var parentName string

	if jobCataReq.CataParent != "" {

		err = db.QueryRow("SELECT cg_name FROM ioit.job_cata WHERE namespace = $1 AND cl_code = $2",
			jobCataReq.NameSpace, jobCataReq.CataParent).Scan(&parentName)
		if err != nil {
			logger.Info("数据库更新失败:%v", err)
			return false, response.DATABASE_READ_FAILED, "", ""
		}
	}

	logger.Info("parentName:%v", parentName)

	addQuery := `INSERT INTO ioit.job_cata (cl_code, cg_name, namespace, s_node, cg_parent, cg_describe) values ($1,$2,$3,$4,$5,$6)`

	_, err = db.Exec(addQuery, jobCataReq.CataCode, jobCataReq.CataName, jobCataReq.NameSpace,
		util.ServerCode, parentName, jobCataReq.Describe)

	if err != nil {
		logger.Info("数据库插入失败%v", err)
		return false, response.DATABASE_OPERATION_FAILED, "", ""
	}
	return true, 0, cateCode, jobCataReq.CataName
}

func CheckCateName(name string) bool {
	db, err := util.GetPgConn()

	if err != nil {
		logger.Info("Update Fail to connect pg:%v", err)
	}

	query := `SELECT cg_name FROM ioit.job_cata`

	rows, err := db.Query(query)
	if err != nil {
		logger.Info("Update Fail to connect pg:%v", err)
	}
	defer rows.Close()

	var names []string
	for rows.Next() {
		var name string
		if err := rows.Scan(&name); err != nil {
			logger.Info("Update Fail to connect pg:%v", err)
		}
		names = append(names, name)
	}
	logger.Info("names:%v", names)
	for _, v := range names {
		if v == name {
			return true
		}
	}
	return false
}

func EditJobCata(jobCataReq *JobCataReq) (bool, int, string) {

	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, response.DATABASE_CONNECT_FAILED, ""
	}
	defer db.Close()

	var exist bool

	query := `SELECT 1 FROM ioit.job_cata WHERE namespace = $1 AND cg_name = $2 AND cl_code != $3`

	err = db.QueryRow(query, jobCataReq.NameSpace, jobCataReq.CataName, jobCataReq.CataCode).Scan(&exist)
	if err != nil {
		logger.Info("数据库查询失败%v", err)
	}
	if exist {
		return false, response.ALREADY_EXIST, ""
	}

	var oldName string

	queryName := `SELECT cg_name FROM ioit.job_cata WHERE namespace = $1 AND cl_code = $2`

	err = db.QueryRow(queryName, jobCataReq.NameSpace, jobCataReq.CataCode).Scan(&oldName)
	if err != nil {
		logger.Info("数据库查询失败%v", err)
	}
	logger.Info("oldName:%v", oldName)

	updatesql := `UPDATE ioit.job_cata SET cg_name=$1, cg_describe=$2 WHERE namespace = $3 AND cl_code = $4`

	_, err = db.Exec(updatesql, jobCataReq.CataName, jobCataReq.Describe,
		jobCataReq.NameSpace, jobCataReq.CataCode)

	if err != nil {
		logger.Info("数据库更新失败:%v", err)
		return false, response.DATABASE_UPDATE_FAILED, ""
	}

	updatesubsql := `UPDATE ioit.job_cata SET cg_parent = $1 WHERE namespace = $2 AND cg_parent = $3`

	_, err = db.Exec(updatesubsql, jobCataReq.CataName, jobCataReq.NameSpace, oldName)

	if err != nil {
		logger.Info("数据库更新失败:%v", err)
		return false, response.DATABASE_UPDATE_FAILED, ""
	}
	return true, 0, jobCataReq.CataName
}

type JobCata struct {
	ClCode   string `gorm:"column:cl_code"`
	CgName   string `gorm:"column:cg_name"`
	CgParent string `gorm:"column:cg_parent"`
}

type JobInfoClass struct {
	JobClass string `gorm:"column:job_class"`
}

func DeleteJobCata(namespace, cl_code string) (bool, int, string) {
	dsn := config.ConfigAll.Postgres.Url + " dbname=" + config.ConfigAll.Postgres.DbName

	db, err := gorm.Open(postgres.Open(dsn), &gorm.Config{})
	if err != nil {
		logger.Info("数据库连接失败")
		return false, response.DATABASE_CONNECT_FAILED, ""
	}

	sqlDb, _ := db.DB()
	defer sqlDb.Close()

	var count int64

	if err := db.Table("ioit.job_info").Where("job_class = ? ", cl_code).Count(&count).Error; err != nil {
		logger.Info("数据库更新失败:%v", err)
		return false, response.DATABASE_READ_FAILED, ""
	}

	if count > 0 {
		logger.Info("count:%v", count)
		return false, response.CATE_EXIST_JOB, ""
	}

	var jobCata JobCata
	if err := db.Table("ioit.job_cata").Where("cl_code = ?", cl_code).First(&jobCata).Error; err != nil {
		if err == gorm.ErrRecordNotFound {
			logger.Info("err:%v", err)
			return false, response.DATABASE_OPERATION_FAILED, ""
		}
		logger.Info("err:%v", err)
		return false, response.DATABASE_OPERATION_FAILED, ""
	}

	if err := db.Table("ioit.job_cata").Where("cg_parent = ?", jobCata.CgName).Count(&count).Error; err != nil {
		logger.Info("err:%v", err)
		return false, response.DATABASE_OPERATION_FAILED, ""
	}
	if count > 0 {
		logger.Info("count:%v", count)
		return false, response.CATE_EXIST_SUB, ""
	}

	if err := db.Table("ioit.job_cata").Where("cl_code = ?", cl_code).Delete(&JobCata{}).Error; err != nil {
		logger.Info("err:%v", err)
		return false, response.DATABASE_OPERATION_FAILED, ""
	}
	return true, 0, jobCata.CgName
}

func BuildTree(parentName string) *JobCataNode {
	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
	}
	defer db.Close()

	query := `SELECT cg_name, cl_code, cg_describe FROM ioit.job_cata WHERE cg_parent = $1`

	rows, err := db.Query(query, parentName)

	if err != nil {
		logger.Info("数据库查询失败%v", err)
	}

	defer rows.Close()

	root := &JobCataNode{CataName: parentName}

	for rows.Next() {
		var name string
		var code string
		var describe string
		if err := rows.Scan(&name, &code, &describe); err != nil {
			logger.Info("数据库查询失败%v", err)
		}
		child := BuildTree(name)
		child.CataCode = code
		child.Describe = describe
		root.Children = append(root.Children, child)
	}
	return root
}

func XmlToMap(xml string) (map[string]any, error, string) {
	logger.Info("xml:%v", xml)
	newS := strings.Replace(xml, "UTF-16", "UTF-8", -1)
	root, err := mxj.NewMapXml([]byte(newS), true)
	if err != nil {
		logger.Info("err:%v", err)
		return nil, err, "XML解析错误，请查看数据是否合法"
	}
	logger.Info("root:%v", root)
	return map[string]any(root), nil, ""
}

func TestHttpConn(reqBody *vo.TestConnReq) (*http.Response, []byte) {

	logger.Info("reqBody.Data:%v", reqBody.Data)
	requestBody, _ := json.Marshal(reqBody.Data)

	logger.Info("reqBody:%v", string(requestBody))

	req, err := http.NewRequest(reqBody.Method, reqBody.Url, bytes.NewBuffer(requestBody))
	if err != nil {
		logger.Info("Fail to send request:%v", err)
	}

	for i := range reqBody.Headers {
		req.Header.Add(reqBody.Headers[i].Key, reqBody.Headers[i].Value)
	}

	for i := range reqBody.Auth {
		req.Header.Add(reqBody.Auth[i].Key, reqBody.Auth[i].Value)
	}
	logger.Info("req.Header:%v", req.Header)

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		logger.Info("Fail to send request:%v", err)
		return resp, nil
	}
	defer resp.Body.Close()

	logger.Info("resp.StatusCode:%v", resp.StatusCode)

	if resp.StatusCode != http.StatusOK {
		logger.Info("Fail to send request:%v", err)
		return resp, nil
	}

	respbody, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		logger.Info("Fail to send request:%v", err)
		return resp, respbody
	}

	return resp, respbody
}
