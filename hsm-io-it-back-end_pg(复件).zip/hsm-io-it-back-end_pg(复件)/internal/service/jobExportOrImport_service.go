package service

import (
	"archive/zip"
	"database/sql"
	"encoding/json"
	"fmt"
	"hsm-io-it-back-end/config"
	"hsm-io-it-back-end/internal/constants"
	"hsm-io-it-back-end/internal/util"
	"hsm-io-it-back-end/internal/vo"
	"hsm-io-it-back-end/pkg/logger"
	"hsm-io-it-back-end/response"
	"io/ioutil"
	"log"
	"mime/multipart"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
)

// 校验作业文件及导入名称是否重复
func ImportJobCheck(file *multipart.FileHeader, c *gin.Context) (bool, bool, string) {
	namespaceOfFront := c.PostForm("namespace")
	//上传到文件到临时文件夹中
	tempPath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp
	//压缩包的名称
	filename := filepath.Base(file.Filename)
	logger.Info("Jobname: %v", filename)
	// 临时文件路径+文件名称
	uploadPath := filepath.Join(tempPath, filename)
	if err := c.SaveUploadedFile(file, uploadPath); err != nil {
		return false, false, "保存上传的zip压缩包失败"
	}
	//校验zip压缩包
	flag1, flag2, result := CheckZip1(filename, uploadPath, namespaceOfFront)
	if !flag1 {
		os.RemoveAll(uploadPath)
		return flag1, flag2, result
	}
	namespace := result
	//校验zip压缩包没问题后，再解压：压缩文件至temp/namespac及作业name、code是否存在
	flag11, flag22, message := UnzipFileAndCheckJob1(uploadPath, namespaceOfFront, namespace)
	return flag11, flag22, message
}

func CheckZip1(filename, uploadPath, namespaceOfFront string) (bool, bool, string) {
	var namespace string
	zipFile, err := zip.OpenReader(uploadPath)
	if err != nil {
		return false, false, "获取文件失败，请检查上传文件"
	}
	defer zipFile.Close()
	// 查找指定的.txt文件,遍历ZIP文件中的所有文件
	var txtFileExists bool
	var flieNames []string
	for _, file := range zipFile.File {
		// 判断文件名是否以".txt"结尾，且不在文件夹datebaseConfig内
		if !strings.Contains(file.Name, constants.Slash) && strings.HasSuffix(file.Name, constants.TxtIdentifier) {
			// 判断文件名是否以".txt"结尾
			if strings.HasSuffix(file.Name, constants.Txt) {
				// 打开文件
				logger.Info("fileName:%v", file.Name)
				txtFile, err := file.Open()
				if err != nil {
					return false, false, "获取文件失败，请检查上传文件"
				}
				defer txtFile.Close()
				// 读取文件内容
				content, err := ioutil.ReadAll(txtFile)
				if err != nil {
					log.Fatal(err)
				}
				// 将文件内容以@分割放入切片中
				flieNames = strings.Split(string(content), constants.At)
				logger.Info("标志文件内容:%v", flieNames)
				// 如果文件内容为空，则给出提示
				if len(flieNames) == 0 {
					return false, false, "导入失败，检验文件被损坏"
				}
				txtFileExists = true
				break
			}
		}
	}
	// len(flieNames)
	// 如果没有找到.txt文件，则进行提醒
	logger.Info("len(flieNames)" + strconv.Itoa(len(flieNames)))
	if len(flieNames) < 1 {
		return false, false, "导入失败，检验文件被损坏"
	}
	JobOrProject := flieNames[len(flieNames)-1]
	logger.Info("JobOrProject:%v", JobOrProject)
	JobOrProject = strings.TrimSpace(JobOrProject)
	if !txtFileExists {
		return false, false, "导入失败，检验文件被损坏"
	} else {
		logger.Info("导入标志:%v", flieNames[len(flieNames)-1])
		logger.Info("JobOrProject:%v", len(JobOrProject))

		if len(JobOrProject) != 1 {
			return false, false, "导入失败，检验文件被损坏"
		}
		if JobOrProject != constants.ExportJob {
			return false, false, "请导入作业文件"
		}
		// 判断切片names中除了最后一个文件外的其他文件是否存在于ZIP包中
		logger.Info("flieNames:%v", flieNames)
		for _, name := range flieNames[:len(flieNames)-1] {
			found := false
			for _, file := range zipFile.File {
				if strings.HasSuffix(file.Name, name) || strings.HasPrefix(file.Name, name+constants.Slash) {
					found = true
					break
				}
			}
			if !found {
				return false, false, "导入失败，检验文件被损坏"
			}
		}
		namespace = strings.TrimRight(flieNames[0], constants.Suffix)
	}
	return true, true, namespace
}

func UnzipFileAndCheckJob1(uploadPath, namespaceOfFront, namespace string) (bool, bool, string) {
	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, false, "数据库连接失败"
	}
	defer db.Close()

	tempNamespacePath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp + namespaceOfFront
	//解压文件
	// tempNamespacePath = /usr/local/hsm-os/data/hsm-io-it/data/temp/namespaceFront/
	util.UnzipFileToPath(uploadPath, tempNamespacePath)
	//解压后的临时路径下的文件，找到主文件修改其名称
	logger.Info("namespace " + namespace + "   namespaceOfFront: " + namespaceOfFront)
	tempNamespaceFile := tempNamespacePath + constants.Hierarchy + namespace + constants.Suffix
	logger.Info("临时文件：tempNamespaceFile:%v", tempNamespaceFile)
	var jobsImport vo.CreateJobRequest
	mainFileContent := util.ReadFile(tempNamespaceFile)
	if len(mainFileContent) != 0 {
		if err := json.Unmarshal([]byte(mainFileContent), &jobsImport); err != nil {
			os.RemoveAll(tempNamespacePath)
			return false, false, "导入失败，读取文件 " + tempNamespaceFile + " 中json反序列化出错"
		}
	} else {
		os.RemoveAll(tempNamespacePath)
		return false, false, "导入失败，读取文件 " + tempNamespaceFile + " 内容为空，请检查"
	}
	// logger.Info("jobsImport:%v", jobsImport)
	logger.Info("code:%v", jobsImport.Code)
	//读取项目的主文件
	query := `SELECT status FROM ioit.job_info WHERE namespace = $1 AND code = $2`

	var status int
	err = db.QueryRow(query, namespaceOfFront, jobsImport.Code).Scan(&status)

	if err != nil {
		if err == sql.ErrNoRows {
			return true, true, "数据校验成功"
		}
		logger.Info("数据库查询错误:%v", err)
		return false, false, "数据库查询错误"
	}

	if status == 1 {
		logger.Info(jobsImport.Code + "作业正在运行中，不允许导入,作业状态：" + "1")
		os.RemoveAll(tempNamespacePath)
		return false, false, "作业正在运行中，不允许导入"
	} else {
		return false, true, "作业编号: " + jobsImport.Code + " 已存在，是否覆盖？"
	}
}

// 读取zip文件中的txt文件数据
func ReadZipFile(zipPath string) []string {
	zipFile, err := zip.OpenReader(zipPath)
	if err != nil {
		logger.Error("读取zip文件失败: %v", err)
	}
	defer zipFile.Close()
	var fileDatas []string
	for _, file := range zipFile.File {
		// 判断文件名是否以".txt"结尾，且不在文件夹datebaseConfig内
		if !strings.Contains(file.Name, constants.Slash) && strings.HasSuffix(file.Name, constants.TxtIdentifier) {
			// 判断文件名是否以".txt"结尾
			if strings.HasSuffix(file.Name, constants.Txt) {
				// 打开文件
				logger.Info("fileName:%v", file.Name)
				txtFile, err := file.Open()
				if err != nil {
					logger.Error("导入失败,读取zip压缩包中 " + file.Name + "失败")
				}
				defer txtFile.Close()
				// 读取文件内容
				content, err := ioutil.ReadAll(txtFile)
				if err != nil {
					log.Fatal(err)
				}
				// 将文件内容以@分割放入切片中
				fileDatas = strings.Split(string(content), constants.At)
				break
			}
		}
	}
	return fileDatas
}

func ImportJob1(file *multipart.FileHeader, c *gin.Context) (bool, *vo.CreateJobRequest, int, string) {
	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, nil, response.DATABASE_CONNECT_FAILED, ""
	}
	defer db.Close()

	namespaceOfFront := c.PostForm("namespace")
	nickName := c.PostForm("create_user")
	//上传到文件到临时文件夹中
	// tempPath := /usr/local/hsm-os/data/hsm-io-it/data/temp
	tempPath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp
	//压缩包的名称
	filename := filepath.Base(file.Filename)
	logger.Info("Jobname: %v", filename)
	// 临时文件路径+文件名称
	// uploadPath := /usr/local/hsm-os/data/hsm-io-it/data/temp/xxxx.zip
	uploadPath := filepath.Join(tempPath, filename)
	if err := c.SaveUploadedFile(file, uploadPath); err != nil {
		return false, nil, response.SAVE_FILE_FAILED, ""
	}
	// tempNamespace := /usr/local/hsm-os/data/hsm-io-it/data/temp/namespacefront/
	tempNamespace := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp + namespaceOfFront
	util.UnzipFileToPath(uploadPath, tempNamespace)
	fileDatas := ReadZipFile(uploadPath)

	//导入中的文件中的namespace
	fileNamespace := fileDatas[0]
	fileNamespace = strings.TrimRight(fileNamespace, constants.Suffix)
	logger.Info("fileNamespace: %v", fileNamespace)
	logger.Info("namespaceOfFront: %v", namespaceOfFront)
	var jobsImport vo.CreateJobRequest
	// 文件解压位置
	// tempNamespace := /usr/local/hsm-os/data/hsm-io-it/data/temp/namespacefront/

	jobInfo := util.ReadFile(tempNamespace + constants.Hierarchy + fileNamespace + constants.Suffix)
	if len(jobInfo) != 0 {
		if err := json.Unmarshal([]byte(jobInfo), &jobsImport); err != nil {
			logger.Error("json反序列化出错")
			return false, nil, response.JSON_SERIALIZATION_FAILED, ""
		}
	} else {
		return false, nil, response.CONTENT_EMPTY, ""
	}

	jobsImport.EditeTime = time.Now().Format("2006-01-02 15:04:05")
	jobsImport.Status = constants.ReadyJob
	jobsImport.CreateUse = nickName

	// 获取当前节点
	res := util.GetNodeServer()
	s_node := res[1]
	jobsImport.SKNode = s_node

	content, errs := json.Marshal(jobsImport.Content)
	if errs != nil {
		fmt.Println("json marshal error:", errs)
	}

	canvas, errs := json.Marshal(jobsImport.Canvas)
	if errs != nil {
		fmt.Println("json marshal error:", errs)
	}

	cron, errs := json.Marshal(jobsImport.CronDetail)
	if errs != nil {
		fmt.Println("json marshal error:", errs)
	}

	period, errs := json.Marshal(jobsImport.PeriodDetail)
	if errs != nil {
		fmt.Println("json marshal error:", errs)
	}

	if jobsImport.NameSpace == namespaceOfFront {
		util.DeleteOriData("job_info", jobsImport.NameSpace, jobsImport.SKNode, jobsImport.Code)
	} else {
		util.DeleteOriData("job_info", namespaceOfFront, jobsImport.SKNode, jobsImport.Code)
	}

	util.InsertData(namespaceOfFront, &jobsImport, content, canvas, cron, period)

	// tempNamespace := /usr/local/hsm-os/data/hsm-io-it/data/temp/namespacefront/
	databaseConfigFileTemp := tempNamespace + constants.Hierarchy + constants.DataBaseConfig
	dbFlag := util.PathExists(databaseConfigFileTemp)
	if dbFlag {
		var databaseInfoList []vo.DatabaseInfoRequest
		databaseInfo := util.ReadFile(databaseConfigFileTemp + constants.Hierarchy + "database.json")
		if len(databaseInfo) != 0 {
			if err := json.Unmarshal([]byte(databaseInfo), &databaseInfoList); err != nil {
				logger.Error("json反序列化出错")
				return false, nil, response.JSON_SERIALIZATION_FAILED, ""
			}
		} else {
			return false, nil, response.CONTENT_EMPTY, ""
		}

		for _, v := range databaseInfoList {

			if jobsImport.NameSpace == namespaceOfFront {
				util.DeleteOriData("database_info", v.Namespace, v.SKNode, v.Code)
			} else {
				util.DeleteOriData("database_info", namespaceOfFront, v.SKNode, v.Code)
			}

			util.InsertDBData(namespaceOfFront, &v)
		}
	}

	// 上传文件
	tempUploadFile := tempNamespace + constants.Hierarchy + constants.UpLoad
	namespaceUploadPath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Project + namespaceOfFront + constants.Hierarchy + "upload"
	flag := util.PathExists(tempUploadFile)
	logger.Info("是否包含上传的临时文件，upload: %v", flag)
	if flag {
		// 如果存在，则复制子文件中的内容到项目指定目录下
		util.CopyFilesToFolder(tempUploadFile, namespaceUploadPath)
		logger.Info("复制上传的临时文件：upload")
	}

	// 删除导入的zip文件
	os.Remove(uploadPath)
	// 删除临时文件夹
	os.RemoveAll(tempNamespace)
	return true, &jobsImport, 0, "作业导入成功"
}

// 批量导入作业校验
func ImportBatchCheckJobs1(file *multipart.FileHeader, c *gin.Context) (bool, bool, string) {

	logger.Info("开始校验批量作业")
	namespaceOfFront := c.PostForm("namespace")
	//上传到文件到临时文件夹中
	tempPath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp
	//压缩包的名称
	filename := filepath.Base(file.Filename)
	logger.Info("filename %v", filename)
	// 临时文件路径+文件名称
	uploadPath := filepath.Join(tempPath, filename)
	if err := c.SaveUploadedFile(file, uploadPath); err != nil {
		os.RemoveAll(uploadPath)
		return false, false, "保存上传的zip压缩包失败"
	}
	// var jobsImport JobInfoImport
	flag1, flag2, result := CheckBatchZip1(filename, uploadPath, namespaceOfFront)
	os.RemoveAll(uploadPath)
	return flag1, flag2, result
}

func CheckBatchZip1(filename, uploadPath, namespaceOfFront string) (bool, bool, string) {

	zipFile, err := zip.OpenReader(uploadPath)
	if err != nil {
		return false, false, "导入失败，读取上传的zip压缩包 " + filename + "失败"
	}
	defer zipFile.Close()
	// 查找指定的.txt文件,遍历ZIP文件中的所有文件
	var txtFileExists bool
	var zipFlieNames []string
	var txtContent string
	for _, file := range zipFile.File {
		// 判断文件名是否以".txt"结尾，且不在文件夹datebaseConfig内
		if !strings.Contains(file.Name, constants.Slash) && strings.HasSuffix(file.Name, constants.Txt) {
			// 打开文件
			logger.Info("fileName:%v", file.Name)
			txtFile, err := file.Open()
			if err != nil {
				return false, false, "导入失败，读取zip压缩包中 " + file.Name + "失败"
			}
			defer txtFile.Close()

			// 读取文件内容
			content, err := ioutil.ReadAll(txtFile)
			if err != nil {
				log.Fatal(err)
			}
			// 将文件内容以@分割放入切片中
			zipFlieNames = strings.Split(string(content), constants.At)
			// 如果文件内容为空，则给出提示
			if len(zipFlieNames) == 0 {
				return false, false, "导入失败，上传的zip包中.txt的文件内容为空，请检查"
			} else {
				// 输出切片内容
				txtContent = string(content)
			}
			txtFileExists = true
			break
		}
	}
	if len(zipFlieNames) < 1 {
		return false, false, "导入失败，文件被损坏请检查"
	}

	projectFlag := zipFlieNames[len(zipFlieNames)-1]
	// 如果没有找到.txt文件，则进行提醒
	if !txtFileExists {
		return false, false, "导入失败，文件被损坏请检查"
	} else {
		// 判断目标文件是否存在于ZIP包中，根据获取到的txt文件内容查找指定目录下是否存在这些文件
		logger.Info("导入项目标志:%v", projectFlag)
		if projectFlag != constants.ExportProject {
			return false, false, "导入失败，上传文件不合法，请检查"
		}
		var flieNames []string
		if !strings.Contains(txtContent, constants.ExportNull) {
			flieNames = append(flieNames, zipFlieNames[0]+constants.Suffix)
			flieNames = append(flieNames, zipFlieNames[0])
			for _, name := range flieNames {
				found := false
				for _, file := range zipFile.File {
					if strings.HasSuffix(file.Name, name) || strings.HasPrefix(file.Name, name+constants.Slash) {
						found = true
						break
					}
				}
				if !found {
					logger.Info("导入失败,上传的zip包中 %v 的文件/文件夹不存在，请检查", name)
					return false, false, "导入失败，上传文件不合法，请检查"
				}
			}
		}
		// 判断是否有正在执行的作业
		db, err := util.GetPgConn()
		if err != nil {
			logger.Info("数据库连接失败")
			return false, false, "数据库连接失败"
		}
		defer db.Close()

		query := `SELECT EXISTS (SELECT 1 FROM ioit.job_info WHERE namespace = $1 AND status = 1)`

		var exists bool

		err = db.QueryRow(query, namespaceOfFront).Scan(&exists)

		if err != nil {
			if err == sql.ErrNoRows {
				return true, true, "数据校验成功"
			}
			logger.Info("数据库查询错误:%v", err)
			return false, false, "数据库查询错误"
		}

		if exists {
			logger.Info("项目：" + namespaceOfFront + "，有正在运行的作业，请停止后再操作")
			return false, false, "项目：" + namespaceOfFront + "，有正在运行的作业，请停止后再操作"
		}
	}
	return true, true, "数据校验成功"
}

func ImportBatchJobs1(file *multipart.FileHeader, c *gin.Context) (bool, bool, int, string) {
	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, false, response.DATABASE_CONNECT_FAILED, "数据库连接失败"
	}
	defer db.Close()

	namespaceOfFront := c.PostForm("namespace")
	nickName := c.PostForm("create_user")

	logger.Info("开始导入批量作业")
	//上传到文件到临时文件夹中
	// tempPath = /usr/local/hsm-os/data/hsm-io-it/data/temp
	tempPath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp
	//压缩包的名称
	filename := filepath.Base(file.Filename)
	logger.Info("上传文件： %v", filename)
	// 临时文件路径+文件名称
	uploadPath := filepath.Join(tempPath, filename)
	if err := c.SaveUploadedFile(file, uploadPath); err != nil {
		return false, false, response.SAVE_FILE_FAILED, ""
	}
	// uploadPath = /usr/local/hsm-os/data/hsm-io-it/data/temp/xxxx.zip
	// tempNamespacePath = /usr/local/hsm-os/data/hsm-io-it/data/temp/namespaceFront
	tempNamespacePath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp + namespaceOfFront
	util.UnzipFileToPath(uploadPath, tempNamespacePath)
	logger.Info("将上传文件解压至： %v", tempNamespacePath)
	fileDatas := ReadZipFile(uploadPath)
	//导入中的文件中的namespace
	batchNamespace := fileDatas[0]
	batchNamespace = strings.TrimRight(batchNamespace, constants.Suffix)
	logger.Info("namespaceOfFront %v", namespaceOfFront)
	logger.Info("namespaceOfFile: %v", batchNamespace)

	var txtContent string
	// 获取导入的项目作业运行情况 start
	query := `SELECT EXISTS (SELECT 1 FROM ioit.job_info WHERE namespace = $1 AND status = 1)`

	var exists bool

	err = db.QueryRow(query, namespaceOfFront).Scan(&exists)

	if err != nil {
		logger.Info("数据库查询错误:%v", err)
		return false, false, response.DATABASE_READ_FAILED, "数据库查询错误"
	}

	if exists {
		logger.Info("项目：" + namespaceOfFront + "，有正在运行的作业，请停止后再操作")
		return false, false, response.RUNNING_JOB_NOT_OP, ""
	}
	// 获取导入的项目作业运行情况 end
	// tempNamespacePath = /usr/local/hsm-os/data/hsm-io-it/data/temp/namespaceFront
	files, err := ioutil.ReadDir(tempNamespacePath)
	if err != nil {
		log.Fatal(err)
	}
	for _, file := range files {
		if !strings.Contains(file.Name(), constants.Slash) && strings.HasSuffix(file.Name(), constants.Txt) {
			filePath := filepath.Join(tempNamespacePath, file.Name())
			content, err := ioutil.ReadFile(filePath)
			if err != nil {
				log.Println(err)
				continue
			}
			txtContent = string(content)
		}
	}
	if !strings.Contains(txtContent, constants.ExportNull) {
		//说明是非空项目， 将文件内容以@分割放入切片中
		flieNames := strings.Split(txtContent, constants.At)
		logger.Info("flieNames %v", flieNames)
		logger.Info("batchNamespace: %v", batchNamespace)

		// 更新任务数据
		var jobsImportList []vo.CreateJobRequest
		// 文件解压位置
		// tempNamespacePath = /usr/local/hsm-os/data/hsm-io-it/data/temp/namespaceFront
		jobInfos := util.ReadFile(tempNamespacePath + constants.Hierarchy + batchNamespace + constants.Suffix)
		if len(jobInfos) != 0 {
			if err := json.Unmarshal([]byte(jobInfos), &jobsImportList); err != nil {
				logger.Error("json反序列化出错")
				return false, false, response.JSON_SERIALIZATION_FAILED, ""
			}
		} else {
			return false, false, response.CONTENT_EMPTY, ""
		}

		res := util.GetNodeServer()
		s_node := res[1]

		for _, v := range jobsImportList {

			v.EditeTime = time.Now().Format("2006-01-02 15:04:05")
			v.Status = constants.ReadyJob
			v.CreateUse = nickName
			v.SKNode = s_node

			content, errs := json.Marshal(v.Content)
			if errs != nil {
				fmt.Println("json marshal error:", errs)
			}

			canvas, errs := json.Marshal(v.Canvas)
			if errs != nil {
				fmt.Println("json marshal error:", errs)
			}

			cron, errs := json.Marshal(v.CronDetail)
			if errs != nil {
				fmt.Println("json marshal error:", errs)
			}

			period, errs := json.Marshal(v.PeriodDetail)
			if errs != nil {
				fmt.Println("json marshal error:", errs)
			}

			if v.NameSpace == namespaceOfFront {
				util.DeleteOriData("job_info", v.NameSpace, v.SKNode, v.Code)
			} else {
				util.DeleteOriData("job_info", namespaceOfFront, v.SKNode, v.Code)
			}
			util.InsertData(namespaceOfFront, &v, content, canvas,cron,period)
		}
		// 更新数据库连接
		// tempNamespacePath = /usr/local/hsm-os/data/hsm-io-it/data/temp/namespaceFront
		databaseConfigFileTemp := tempNamespacePath + constants.Hierarchy + batchNamespace + constants.Hierarchy + constants.DataBaseConfig
		dbFlag := util.PathExists(databaseConfigFileTemp)
		if dbFlag {
			var databaseInfoList []vo.DatabaseInfoRequest
			databaseInfo := util.ReadFile(databaseConfigFileTemp + constants.Hierarchy + "database.json")
			if len(databaseInfo) != 0 {
				if err := json.Unmarshal([]byte(databaseInfo), &databaseInfoList); err != nil {
					logger.Error("json反序列化出错")
					return false, false, response.JSON_SERIALIZATION_FAILED, ""
				}
			} else {
				return false, false, response.CONTENT_EMPTY, ""
			}

			logger.Info("databaseInfoList:%v", len(databaseInfoList))
			for _, v := range databaseInfoList {
				if v.Namespace == namespaceOfFront {
					util.DeleteOriData("database_info", v.Namespace, v.SKNode, v.Code)
				} else {
					util.DeleteOriData("database_info", namespaceOfFront, v.SKNode, v.Code)
				}

				util.InsertDBData(namespaceOfFront, &v)
			}
		}
	}

	// 上传文件
	// tempNamespacePath = /usr/local/hsm-os/data/hsm-io-it/data/temp/namespaceFront
	tempUploadFile := tempNamespacePath + constants.Hierarchy + batchNamespace + constants.Hierarchy + constants.UpLoad
	namespaceUploadPath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Project + namespaceOfFront + constants.Hierarchy + "upload"
	flag := util.PathExists(tempUploadFile)
	logger.Info("是否包含上传的临时文件，upload: %v", flag)
	if flag {
		// 如果存在，则复制子文件中的内容到项目指定目录下
		util.CopyFilesToFolder(tempUploadFile, namespaceUploadPath)
		logger.Info("复制上传的临时文件：upload")
	}

	//取消导入
	os.RemoveAll(uploadPath)
	os.RemoveAll(constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp + namespaceOfFront)
	return true, true, 0, "项目导入成功"

}
