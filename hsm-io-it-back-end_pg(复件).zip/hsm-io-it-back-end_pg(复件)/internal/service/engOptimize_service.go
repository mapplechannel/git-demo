package service

import (
	"hsm-io-it-back-end/internal/constants"
	"hsm-io-it-back-end/internal/util"
	"hsm-io-it-back-end/internal/vo"
	"hsm-io-it-back-end/pkg/logger"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"
)

// ****************************ENG优化***********************************
func DefaultName(getJobRequest *vo.JobKeyInfo) (bool, string) {

	query := `SELECT name FROM ioit.job_info WHERE namespace = $1`

	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, "数据库连接失败"
	}
	defer db.Close()

	rows, err := db.Query(query, getJobRequest.NameSpace)

	if err != nil {
		return false, "查询失败"
	}

	defer rows.Close()

	var jobs []JobInfo

	for rows.Next() {
		var job JobInfo
		if err := rows.Scan(&job.Name); err != nil {
			return false, "查询失败"
		}
		jobs = append(jobs, job)
	}

	if len(jobs) == 0 {
		return true, constants.NewJob
	}

	logger.Info("jobs:%v", jobs)

	var name_slice []string
	for _, v := range jobs {
		if strings.HasPrefix(v.Name, constants.NewJob) {
			name_slice = append(name_slice, v.Name)
		}
	}

	logger.Info("name_slice: %v", name_slice)
	flag := util.IsHave(constants.NewJob, name_slice)
	if !flag {
		return true, constants.NewJob
	} else {
		name_slice = DeleteSlice(name_slice, constants.NewJob)
	}

	nums := []int{}
	result := ""
	if len(name_slice) == 0 {
		result = constants.NewJob1
	} else {
		for _, str := range name_slice {
			str = strings.TrimPrefix(str, constants.NewJob)
			num, err := strconv.Atoi(str)
			if err == nil {
				nums = append(nums, num)
			}
		}

		sort.Ints(nums)

		nums = RemoveDuplicates(nums)

		// 取消新建作业a
		nums = removeZeros(nums)

		logger.Info("nums: %v", nums)
		for i, num := range nums {
			if i == 0 {
				if num != 1 {
					result = constants.NewJob1
					break
				} else {
					continue
				}
			}

			if num != nums[i-1]+1 {
				result = constants.NewJob + strconv.Itoa(nums[i-1]+1)
				break
			}
		}

		// 当作业中“新建作业”，其他的作业名称中不包含数字时
		if len(nums) == 0 {
			result = constants.NewJob1
		}
		if result == constants.EmptyContent {
			result = constants.NewJob + strconv.Itoa(nums[len(nums)-1]+1)
		}

	}
	return true, result
}

func removeZeros(arr []int) []int {
	result := []int{}

	for _, v := range arr {
		if v != 0 {
			result = append(result, v)
		}
	}

	return result
}

func DeleteSlice(s []string, elem string) []string {
	r := make([]string, 0, len(s))
	for _, v := range s {
		if v != elem {
			r = append(r, v)
		}
	}
	return r
}

func RemoveDuplicates(slice []int) []int {
	seen := make(map[int]bool)
	unique := []int{}

	for _, num := range slice {
		if !seen[num] {
			seen[num] = true
			unique = append(unique, num)
		}
	}

	return unique
}

type JobInfoSlice []vo.CreateJobRequest

func (s JobInfoSlice) Len() int {
	return len(s)
}

func (s JobInfoSlice) Less(i, j int) bool {
	t1, _ := time.Parse("2006-01-02 15:04:05", s[i].EditeTime)
	t2, _ := time.Parse("2006-01-02 15:04:05", s[j].EditeTime)
	return t1.After(t2)
}

func (s JobInfoSlice) Swap(i, j int) {
	s[i], s[j] = s[j], s[i]
}

func UpdateJob_ENG(jobRequest *vo.CreateJobRequest) (bool, string, *vo.CreateJobRequest) {

	code := jobRequest.Code
	namespace := jobRequest.NameSpace
	skNode := jobRequest.SKNode
	editeTime := time.Now().Format("2006-01-02 15:04:05")

	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, "数据库连接失败", nil
	}
	defer db.Close()

	// 判断是否正在运行的作业
	jobInfo := util.GetJobDetailsInfo(namespace, code, skNode)
	if jobInfo.Status == 1 {
		return false, "作业正在运行中，不允许修改", nil
	}

	updatesql := `UPDATE ioit.job_info 
						SET name=$1, edite_time=$2, is_auto_select_id=$3
						WHERE namespace = $4 AND code = $5`

	_, err = db.Exec(updatesql,
		jobRequest.Name, editeTime, true, jobRequest.NameSpace, jobRequest.Code,
	)

	jobRequest.EditeTime = editeTime
	if err == nil {
		logger.Info("更新作业成功：%s", code)
		return true, "编辑作业<" + jobRequest.Name + ">成功", jobRequest
	} else {
		logger.Info("数据库更新失败:%v", err)
		return false, "保存失败", nil
	}
}

func DeleteFilesWithNames(dir string, filenames []string) error {
	logger.Info("filenames: %v", filenames)
	err := filepath.Walk(dir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if !info.IsDir() {
			// 获取文件名
			filename := info.Name()
			logger.Info("filename: %v", filename)
			// 检查文件名是否匹配要删除的文件名
			for _, name := range filenames {
				if filename == name {
					logger.Info("Deleting file: %v", path)
					err := os.Remove(path)
					if err != nil {
						logger.Error("Error deleting file: %v", err)
					}
					break
				}
			}
		}
		return nil
	})
	return err
}
