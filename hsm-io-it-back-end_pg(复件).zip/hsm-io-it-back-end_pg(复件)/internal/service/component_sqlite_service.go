package service

import (
	"database/sql"
	"fmt"
	"hsm-io-it-back-end/internal/util"
	"hsm-io-it-back-end/internal/vo"
	"hsm-io-it-back-end/pkg/logger"
	"log"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"time"

	_ "github.com/mattn/go-sqlite3"
)

// 测试连接postgresql数据库
func ConnectSqliteTest(sqliteInfoReq *vo.DatabaseInfoRequest) (bool, string) {
	//组装连接参数
	dbPath := sqliteInfoReq.DbPath
	dbName := sqliteInfoReq.DbName + ".db"
	// 根据路径和文件名拼接完整的数据库文件路径
	dbFile := filepath.Join(dbPath, dbName)
	logger.Info("dbFile: %v", dbFile)
	// 检查数据库文件是否存在
	if _, err := os.Stat(dbFile); os.IsNotExist(err) {
		logger.Info("数据库文件 %s 不存在\n", dbFile)
		return false, "数据库文件不存在"
	} else {
		// 连接SQLite数据库
		db, err := sql.Open("sqlite3", dbFile)
		if err != nil {
			logger.Info("连接数据库 %s 失败：%s\n", dbFile, err.Error())
			return false, "连接数据库失败"
		} else {
			// 测试数据库连接是否成功
			db.SetConnMaxIdleTime(time.Minute * 10)
			db.SetConnMaxLifetime(time.Minute * 10)
			db.SetMaxOpenConns(10)
			db.SetMaxIdleConns(10)
			err = db.Ping()
			defer db.Close()
			if err != nil {
				retry, _ := strconv.Atoi(sqliteInfoReq.Retry)
				if err != nil {
					for i := retry; i > 0; i-- {
						err = db.Ping()
						if err == nil {
							break
						}
						time.Sleep(500 * time.Millisecond)
					}

					if err != nil {
						return false, "数据库连接失败"
					}
				}
			} else {
				logger.Info("连接数据库 %s 成功\n", dbFile)
			}

		}
	}
	return true, "连接成功"
}

func AddConnectSqlite(sqliteInfoeq *vo.DatabaseInfoRequest) (bool, string) {

	flag := util.IsExistDatabase(sqliteInfoeq.ConnectName, sqliteInfoeq.Namespace, sqliteInfoeq.DataBaseType)

	if flag {
		return false, "不能创建相同类型的同名数据源，请重新输入"
	}

	code := generateDataBaseCode(sqliteInfoeq.DataBaseType)
	sqliteInfoeq.Code = code

	dbPG, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, ""
	}
	defer dbPG.Close()

	addsql := `INSERT INTO ioit.database_info (
			code, namespace, connectname, username, password, host, port, 
			databasetype, s_node, dbname, schemaname, tablename, dbpath) 
	VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)`

	_, err = dbPG.Exec(addsql,
		sqliteInfoeq.Code, sqliteInfoeq.Namespace, sqliteInfoeq.ConnectName,
		sqliteInfoeq.Username, sqliteInfoeq.Password, sqliteInfoeq.Host,
		sqliteInfoeq.Port, sqliteInfoeq.DataBaseType, "unpublish", sqliteInfoeq.DbName,
		sqliteInfoeq.SchemaName, sqliteInfoeq.Tablename, sqliteInfoeq.DbPath)

	if err != nil {
		logger.Info("数据库插入失败:%v", err)
		return false, "数据库插入失败"
	}

	dbFile := filepath.Join(sqliteInfoeq.DbPath, sqliteInfoeq.DbName)
	logger.Info("dbFIle:%v", dbFile)

	// 连接SQLite数据库
	db, err := sql.Open("sqlite3", dbFile)
	if err != nil {
		return false, code
	}
	db.SetConnMaxIdleTime(time.Minute * 10)
	db.SetConnMaxLifetime(time.Minute * 10)
	db.SetMaxOpenConns(10)
	db.SetMaxIdleConns(10)
	err = db.Ping()
	if err != nil {
		return false, "连接失败"
	}
	defer db.Close()
	return true, code
}

// 更新连接
func UpdateConnectSqlite(sqliteInfo *vo.DatabaseInfoRequest) (bool, string) {

	flag := util.IsUpdateExistDatabase(sqliteInfo.ConnectName, sqliteInfo.Namespace, sqliteInfo.DataBaseType, sqliteInfo.Code)

	if flag {
		return false, "不能创建相同类型的同名数据源，请重新编辑"
	}

	dbPG, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, "数据库连接失败"
	}
	defer dbPG.Close()

	updatesql := `UPDATE ioit.database_info SET connectname=$1,	dbpath=$2, dbname=$3 WHERE namespace = $4 AND code = $5 `

	_, err = dbPG.Exec(updatesql,
		sqliteInfo.ConnectName, sqliteInfo.DbPath, sqliteInfo.DbName, sqliteInfo.Namespace, sqliteInfo.Code)

	if err != nil {
		logger.Info("数据库连接更新失败")
		return false, "数据库连接更新失败"
	}

	logger.Info("数据库连接信息更新: %v", flag)

	return true, "更新成功"
}

// 获取查询某个ip上所有的数据库
func GetSqliteDataBaseConnectList(sqliteInfoReq *vo.DatabaseInfoRequest) (bool, []Database) {
	//组装连接参数
	dbPath := sqliteInfoReq.DbPath
	dbName := sqliteInfoReq.DbName

	// 根据路径和文件名拼接完整的数据库文件路径
	dbFile := filepath.Join(dbPath, dbName)
	db, err := connectToSQLite(dbFile)
	if err != nil {
		return false, nil
	}
	defer db.Close()
	// 读取数据库连接并构建响应
	var dataBases []Database
	// 创建一个新的Database对象，并设置Name字段为dbName
	dbInfo := Database{Name: dbName}
	dataBases = append(dataBases, dbInfo)
	return true, dataBases
}

func connectToSQLite(dbFile string) (*sql.DB, error) {
	logger.Info("dbFile:%v", dbFile)
	db, err := sql.Open("sqlite3", dbFile+".db")
	if err != nil {
		return nil, err
	}
	db.SetConnMaxIdleTime(time.Minute * 10)
	db.SetConnMaxLifetime(time.Minute * 10)
	db.SetMaxOpenConns(10)
	db.SetMaxIdleConns(10)

	err = db.Ping()
	if err != nil {
		return nil, err
	}

	return db, nil
}

// 查询某个数据库下所有表
func GetSqliteTableList(dataBaseInfoReq *vo.DatabaseInfoRequest) (bool, []TableAndType) {
	var tables []TableAndType

	dbPath := dataBaseInfoReq.DbPath
	dbName := dataBaseInfoReq.DbName

	// 根据路径和文件名拼接完整的数据库文件路径
	dbFile := filepath.Join(dbPath, dbName)
	db, err := connectToSQLite(dbFile)
	if err != nil {
		return false, nil
	}
	defer db.Close()

	// 查询某个数据库下所有表
	query := "SELECT name,type FROM sqlite_master WHERE type IN ('table', 'view')"
	rows, err := db.Query(query)
	if err != nil {
		return false, tables
	}
	defer rows.Close()
	// 遍历结果集
	for rows.Next() {
		var table TableAndType
		if err := rows.Scan(&table.Name, &table.Type); err != nil {
			return false, nil
		}
		tables = append(tables, table)
	}

	logger.Info("data:%v", tables)
	return true, tables
}

func GetSqliteTablesPrimary(dataBaseInfoReq *vo.DatabaseInfoRequest) (bool, []string) {
	query := fmt.Sprintf(`PRAGMA table_info(%s)`, dataBaseInfoReq.Tablename)
	logger.Info("query:%v", query)

	dbPath := dataBaseInfoReq.DbPath
	dbName := dataBaseInfoReq.DbName

	// 根据路径和文件名拼接完整的数据库文件路径
	dbFile := filepath.Join(dbPath, dbName)
	db, err := connectToSQLite(dbFile)
	if err != nil {
		return false, nil
	}
	defer db.Close()

	rows, err := db.Query(query)
	if err != nil {
		return false, nil
	}
	defer rows.Close()
	// 遍历结果集，找到主键列
	var primaryKeys []string
	for rows.Next() {
		var cid int
		var columnName string
		var dataType string
		var notNull int
		var defaultValue sql.NullString
		var primaryKey int

		err = rows.Scan(&cid, &columnName, &dataType, &notNull, &defaultValue, &primaryKey)
		if err != nil {
			return false, nil
		}
		// 如果该列是主键列，则将其添加至主键列表
		if primaryKey > 0 {
			primaryKeys = append(primaryKeys, columnName)
		}
	}
	// 返回主键字段信息
	return true, primaryKeys
}

func GetSqliteTableColumns(dataBaseInfoReq *vo.DatabaseInfoRequest) (bool, []ColumnPG) {

	query := fmt.Sprintf(`SELECT name, type FROM pragma_table_info('%s')`, dataBaseInfoReq.Tablename)
	logger.Info("query-11111:%v", query)

	dbPath := dataBaseInfoReq.DbPath
	dbName := dataBaseInfoReq.DbName

	// 根据路径和文件名拼接完整的数据库文件路径
	dbFile := filepath.Join(dbPath, dbName)
	db, err := connectToSQLite(dbFile)
	if err != nil {
		return false, nil
	}
	defer db.Close()

	rows, err := db.Query(query)
	if err != nil {
		return false, nil
	}
	defer rows.Close()
	// 封装所有字段信息
	var columns []ColumnPG
	for rows.Next() {
		var colInfo ColumnPG
		err := rows.Scan(&colInfo.Name, &colInfo.Type)
		if err != nil {
			log.Fatal(err)
		}
		columns = append(columns, colInfo)
	}
	return true, columns
}
func GetSqliteTableData(dataBaseInfoReq *vo.DatabaseInfoRequest) (bool, SearchResponseSL, string) {
	// 连接到指定的数据库
	res := SearchResponseSL{}

	dbPath := dataBaseInfoReq.DbPath
	dbName := dataBaseInfoReq.DbName

	// 根据路径和文件名拼接完整的数据库文件路径
	dbFile := filepath.Join(dbPath, dbName)
	db, err := connectToSQLite(dbFile)
	if err != nil {
		return false, res, "查询失败"
	}
	defer db.Close()

	flag := ContainsComplexQuery(dataBaseInfoReq.SQL)
	if flag {
		return false, res, "不支持复杂查询"
	}

	// 查询当前表的所有字段
	logger.Info("SQL:%v", dataBaseInfoReq.SQL)
	rows, err := db.Query(dataBaseInfoReq.SQL)
	if err != nil {
		logger.Info("err is:%v", err)
		if isNoSuchSQLite(err) {
			return false, res, serrToCNSqlite(err)
		}
		return false, res, "查询失败"
	}
	defer rows.Close()
	// 解析查询结果
	count := 0
	columns, _ := rows.Columns()
	var results []map[string]interface{}
	for rows.Next() {
		count++
		if count > 1000 {
			// return false, res, "支持预览1000条数据"
			logger.Info("支持预览1000条数据")
			break
		}
		values := make([]interface{}, len(columns))
		valuePtrs := make([]interface{}, len(columns))
		for i := range columns {
			valuePtrs[i] = &values[i]
		}
		err = rows.Scan(valuePtrs...)
		if err != nil {
			continue
		}
		rowData := make(map[string]interface{})
		for i, col := range columns {
			val := values[i]
			switch v := val.(type) {
			case time.Time:
				// 处理日期时间类型
				if v.IsZero() {
					rowData[col] = nil
				} else if v.Hour() == 0 && v.Minute() == 0 && v.Second() == 0 {
					// 只有日期，格式化为'YYYY-MM-DD'
					rowData[col] = v.Format("2006-01-02")
				} else if v.Year() == 1 && v.Month() == 1 && v.Day() == 1 {
					// 只有时间，格式化为'HH:MM:SS'
					rowData[col] = v.Format("15:04:05")
				} else {
					// 日期时间，格式化为'YYYY-MM-DD HH:MM:SS'
					rowData[col] = v.Format("2006-01-02 15:04:05")
				}
			case nil:
				// 处理NULL值
				rowData[col] = nil
			default:
				// 其他类型直接赋值
				rowData[col] = val
			}
		}
		results = append(results, rowData)
	}
	res.List = results
	res.Cols = columns
	sqlTableColumn := fmt.Sprintf(`SELECT name, type FROM pragma_table_info('%s')`, dataBaseInfoReq.Tablename)
	rowsCom, err := db.Query(sqlTableColumn)
	if err != nil {
		fmt.Println(err)
	}
	defer rowsCom.Close()

	var tableColumns []tableColumnSL

	for rowsCom.Next() {
		var column tableColumnSL
		err = rowsCom.Scan(
			&column.ColumnName,
			&column.ColumnComment)

		if err != nil {
			logger.Info("query table column scan error, detail is [%v]\n", err.Error())
			continue
		}

		tableColumns = append(tableColumns, column)
	}
	for i := range tableColumns {
		tableColumns[i].ColumnComment = ""
	}
	res.ColsInfo = tableColumns

	return true, res, "查询成功"
}

func isNoSuchSQLite(err error) bool {
	return strings.Contains(err.Error(), "no such column")
}

func serrToCNSqlite(err error) string {
	re := regexp.MustCompile(`no such column: (\w+)`)
	matcher := re.FindStringSubmatch(err.Error())
	if len(matcher) == 2 {
		columnName := matcher[1]
		return fmt.Sprintf("查询的字段 '%s' 不存在", columnName)
	}
	return "查询时发生未知错误"
}
