package service

import (
	"database/sql"
	"fmt"
	"hsm-io-it-back-end/internal/util"
	"hsm-io-it-back-end/internal/vo"
	"hsm-io-it-back-end/pkg/logger"
	"hsm-io-it-back-end/response"
	"reflect"
	"regexp"
	"strings"

	"gorm.io/driver/mysql"
	"gorm.io/driver/postgres"

	"gorm.io/driver/sqlserver"
	"gorm.io/gorm"
)

type Config struct {
	Mainkeys []KeyPair `json:"mainkeys"`
}

type KeyPair struct {
	Source string `json:"source"`
	Target string `json:"target"`
}

type CompareRequest struct {
	Config          Config                   `json:"config"`
	SourceData      []map[string]interface{} `json:"sourceData"`
	TargetData      []map[string]interface{} `json:"targetData"`
	Fields          []KeyPair                `json:"fields"`
	SourceFieldData []map[string]interface{} `json:"sourceFieldData"`
	TargetFieldData []map[string]interface{} `json:"targetFieldData"`
}

type CompareResult struct {
	Source []map[string]interface{} `json:"source"`
	Target []map[string]interface{} `json:"target"`
}

func CompareHandler(req CompareRequest) *CompareResult {
	sourceResults, identicalPairs := CompareData(req.Config.Mainkeys, req.SourceData, req.TargetData)
	targetResults := CompareDataExcludingIdentical(req.Config.Mainkeys, req.TargetData, req.SourceData, identicalPairs)

	for _, res := range sourceResults {
		if res["flag"] == "Identical" {
			CompareFields(req.Fields, req.SourceFieldData, req.TargetFieldData, res)
		}
	}

	result := CompareResult{
		Source: sourceResults,
		Target: targetResults,
	}
	return &result
}

func CompareData(mainKeys []KeyPair, sourceData, targetData []map[string]interface{}) ([]map[string]interface{}, []map[string]interface{}) {
	results := []map[string]interface{}{}
	identicalPairs := []map[string]interface{}{}

	for _, s := range sourceData {
		flag := "Added"
		for _, t := range targetData {
			matched := true
			for _, key := range mainKeys {
				if s[key.Source] != t[key.Target] {
					matched = false
					break
				}
			}
			if matched {
				flag = "Identical"
				identicalPairs = append(identicalPairs, t)
				break
			}
		}
		result := make(map[string]interface{})
		for k, v := range s {
			result[k] = v
		}
		result["flag"] = flag
		results = append(results, result)
	}
	return results, identicalPairs
}

func CompareDataExcludingIdentical(mainKeys []KeyPair, sourceData, targetData []map[string]interface{}, identicalPairs []map[string]interface{}) []map[string]interface{} {
	results := []map[string]interface{}{}

	for _, s := range sourceData {
		flag := "Removed"
		for _, t := range targetData {
			matched := true
			for _, key := range mainKeys {
				if s[key.Source] != t[key.Target] {
					matched = false
					break
				}
			}
			if matched {
				flag = "Identical"
				break
			}
		}
		alreadyIdentical := false
		for _, pair := range identicalPairs {
			pairMatched := true
			for _, key := range mainKeys {
				if s[key.Source] != pair[key.Target] {
					pairMatched = false
					break
				}
			}
			if pairMatched {
				alreadyIdentical = true
				break
			}
		}
		if alreadyIdentical {
			continue
		}
		result := make(map[string]interface{})
		for k, v := range s {
			result[k] = v
		}
		result["flag"] = flag
		results = append(results, result)
	}
	return results
}

func CompareFields(fields []KeyPair, sourceFieldData, targetFieldData []map[string]interface{}, result map[string]interface{}) {
	for _, field := range fields {
		sourceValue := sourceFieldData[0][field.Source]
		targetValue := targetFieldData[0][field.Target]
		if !reflect.DeepEqual(sourceValue, targetValue) {
			result["flag"] = "Changed"
			break
		}
	}
}

// 组件查询*************************
type Category struct {
	Label    string         `json:"label"`
	ID       string         `json:"id"`
	Value    string         `json:"value"`
	Children []vo.Component `json:"children"`
}

func FetchCategories() ([]Category, int) {
	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败:%v", err)
		return nil, response.DATABASE_CONNECT_FAILED
	}
	defer db.Close()
	rows, err := db.Query("SELECT label, id, value FROM ioit.component_cata")
	if err != nil {
		logger.Info("数据库连接失败:%v", err)
		return nil, response.DATABASE_READ_FAILED
	}
	defer rows.Close()

	var categories []Category
	for rows.Next() {
		var label, id, value string
		if err := rows.Scan(&label, &id, &value); err != nil {
			logger.Info("数据库连接失败:%v", err)
			return nil, response.DATABASE_READ_FAILED
		}
		categories = append(categories, Category{Label: label, ID: id, Value: value})
	}
	return categories, 0
}

func FetchComponent(applicableType string) ([]vo.Component, error) {
	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败:%v", err)
		return nil, err
	}
	defer db.Close()

	var rows *sql.Rows
	var err1 error
	if applicableType == "" {
		rows, err1 = db.Query("SELECT label, value, node_type, node_mark, img, no_config_msg, node_data, cate_key,api_type FROM ioit.component")
	} else {
		rows, err1 = db.Query("SELECT label, value, node_type, node_mark, img, no_config_msg, node_data, cate_key,api_type FROM ioit.component WHERE applicable_type = $1 OR applicable_type = 'all'", applicableType)
	}
	if err1 != nil {
		logger.Info("数据库连接失败:%v", err1)
		return nil, err1
	}
	defer rows.Close()

	var components []vo.Component
	for rows.Next() {
		var component vo.Component
		var nodeData string
		if err := rows.Scan(&component.Label, &component.Value, &component.NodeType,
			&component.NodeMark, &component.Img, &component.NoConfigMsg, &nodeData, &component.CateKey, &component.ApiType); err != nil {
			logger.Info("数据库连接失败:%v", err)
			return nil, err
		}

		component.NodeData = nodeData
		components = append(components, component)
	}
	var res []vo.Component
	for i := range components {
		if components[i].Label != "XML解析" && components[i].Label != "文件系统" && components[i].Label != "文件数据转换" &&
			components[i].Label != "信息模型" && components[i].Label != "HiaBatch转信息模型" {
			res = append(res, components[i])
		}
	}

	var res1 []vo.Component

	for i := range res {
		if res[i].Label == "关系数据库" && res[i].NodeType == "output" {
			continue
		}
		res1 = append(res1, res[i])
	}

	return res1, nil
}

func GroupComponentsByCategory(components []vo.Component, categories []Category) []Category {
	for i := range categories {
		for _, component := range components {
			if component.CateKey == categories[i].ID {
				categories[i].Children = append(categories[i].Children, component)
			}
		}

	}
	return categories
}

func AddComponent(compoent *vo.Component) (bool, int) {
	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, response.DATABASE_CONNECT_FAILED
	}
	defer db.Close()

	regexPattern := `^[\p{Han}A-Za-z0-9]+$`
	re := regexp.MustCompile(regexPattern)
	if !re.MatchString(compoent.Label) {
		logger.Info("save label is :%v", compoent.Label)
		return false, response.CHECK_FAILED
	}

	var exists bool
	query := `SELECT EXISTS ( SELECT 1 FROM ioit.component WHERE label = $1)`
	err = db.QueryRow(query, compoent.Label).Scan(&exists)
	if err != nil {
		logger.Info("数据库查询失败%v", err)
	}

	if exists {
		return false, response.COMPONENT_ALREADY_EXIST
	}

	var applicableType string

	queryValue := `SELECT applicable_type FROM ioit.component WHERE value = $1`
	err = db.QueryRow(queryValue, compoent.Value).Scan(&applicableType)
	if err != nil {
		logger.Info("数据库查询失败%v", err)
	}
	logger.Info("applicableType:%v", applicableType)

	insert := `INSERT INTO ioit.component (label, value, node_type, node_mark, img, no_config_msg, node_data, cate_key, applicable_type,api_type) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`
	_, err = db.Exec(insert, compoent.Label, compoent.Value, compoent.NodeType, compoent.NodeMark, compoent.Img, compoent.NoConfigMsg, compoent.NodeData, compoent.CateKey, applicableType, compoent.ApiType)
	if err != nil {
		logger.Info("数据库连接失败:%v", err)
		return false, response.DATABASE_OPERATION_FAILED
	}
	return true, 0
}

func AddBusinessData(bdata *vo.BusinessDataReq) (bool, int) {
	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, response.DATABASE_CONNECT_FAILED
	}
	defer db.Close()

	insert := `INSERT INTO ioit.business_data (id, data) VALUES($1,$2)`
	_, err = db.Exec(insert, bdata.ID, bdata.Data)
	if err != nil {
		logger.Info("数据库连接失败:%v", err)
		return false, response.DATABASE_OPERATION_FAILED
	}
	return true, 0
}

func GetBusinessData(req *vo.BusinessDataReq) (string, int) {
	logger.Info("req.ID:%v", req.ID)
	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败:%v", err)
		return "", response.DATABASE_CONNECT_FAILED
	}
	defer db.Close()
	query := `SELECT data FROM ioit.business_data WHERE id = $1`
	if err != nil {
		logger.Info("数据库连接失败:%v", err)
		return "", response.DATABASE_READ_FAILED
	}

	var data string
	err = db.QueryRow(query, req.ID).Scan(&data)

	if err != nil {
		logger.Info("数据库连接失败:%v", err)
		return "", response.DATABASE_READ_FAILED
	}

	return data, 0
}

func connectDB(dsn, dbtype string) (*gorm.DB, error) {
	var dialector gorm.Dialector
	switch dbtype {
	case "mysql":
		dialector = mysql.Open(dsn)
	case "postgres":
		dialector = postgres.Open(dsn)
	case "sqlserver":
		dialector = sqlserver.Open(dsn)
	default:
		logger.Info("unsupported database type")
	}
	db, err := gorm.Open(dialector, &gorm.Config{})
	if err != nil {
		logger.Info("connect db error:%v", err)
	}
	return db, nil
}

func SyncPTOPTable(dbinfo vo.DBInfo, tablename string) error {
	sourceDB, err := connectDB(dbinfo.SourceDSN, dbinfo.SourceDBType)
	if err != nil {
		logger.Info("connect db error:%v", err)
	}

	targetDB, err := connectDB(dbinfo.TargetDSN, dbinfo.TargetDBType)
	if err != nil {
		logger.Info("connect db error:%v", err)
	}

	// 模式创建
	var shemaExists bool
	err = targetDB.Raw("SELECT EXISTS (SELECT 1 FROM information_schema.schemata WHERE schema_name = ?)", dbinfo.Schema).Scan(&shemaExists).Error
	if err != nil {
		logger.Info("check schema error:%v", err)
	}

	logger.Info("shemaExists is :%v", shemaExists)

	if !shemaExists {
		if err := targetDB.Exec(fmt.Sprintf("CREATE SCHEMA %s", dbinfo.Schema)).Error; err != nil {
			logger.Info("create schema error:%v", err)
		}
	}

	// 查询表格是否存在
	var exists bool
	err = targetDB.Raw("SELECT EXISTS (SELECT FROM information_schema.tables WHERE table_schema = ? AND table_name = ?)", dbinfo.Schema, tablename).Scan(&exists).Error
	if err != nil {
		logger.Info("failed to check table exists error:%v", err)
	}

	logger.Info("exist is :%v", exists)

	viewDefMap := map[string]string{}

	// 存在删除
	if exists {
		// 判断有无试图，有：copy
		views, err := FindViewsOnTable(targetDB, dbinfo.Schema, tablename)
		if err != nil {
			logger.Error("查询视图失败")
		}

		if len(views) > 0 {
			for _, viewname := range views {
				viewDefine, err := GetViewDefine(targetDB, dbinfo.Schema, viewname)
				if err != nil {
					logger.Error(err)
					continue
				}
				viewDefMap[viewname] = viewDefine
				logger.Info("viewname is:%v", viewname)
				//删除view
				if err := targetDB.Exec(fmt.Sprintf("DROP VIEW IF EXISTS %s", viewname)).Error; err != nil {
					logger.Error("delete view error:%v", err)
					continue
				}
			}
		}
		if err := targetDB.Exec(fmt.Sprintf("DROP TABLE %s.%s", dbinfo.Schema, tablename)).Error; err != nil {
			logger.Info("failed to delete error:%v", err)
		}
	}

	// 植入新的表格结构
	sourcesqldb, _ := sourceDB.DB()

	createSQL, err := getCreateTableSQL(sourcesqldb, dbinfo.Schema, tablename)
	if err != nil {
		logger.Info("create sql find error:%v", err)
	}

	logger.Info("createSQL is :%v", createSQL)

	if err := targetDB.Exec(createSQL).Error; err != nil {
		logger.Info("failed to create table:%v", err)
	}

	var data []map[string]interface{}

	batchSize := 5000
	offset := 0
	for {
		data = []map[string]interface{}{}
		if err := sourceDB.Table(fmt.Sprintf("%s.%s", dbinfo.Schema, tablename)).Offset(offset).Limit(batchSize).Find(&data).Error; err != nil {
			logger.Info("find source data error:%v", err)
		}

		if len(data) == 0 {
			break
		}

		if err := targetDB.Table(fmt.Sprintf("%s.%s", dbinfo.Schema, tablename)).Create(&data).Error; err != nil {
			logger.Info("insert data error:%v", err)
		}
		offset += batchSize
	}

	for viewname, viewDefine := range viewDefMap {
		if err := CreateView(targetDB, viewname, viewDefine); err != nil {
			logger.Error(err)
			continue
		}
	}

	return nil
}

func SyncPTOPView(dbinfo vo.DBInfo, viewname string) error {
	sourceDB, err := connectDB(dbinfo.SourceDSN, dbinfo.SourceDBType)
	if err != nil {
		logger.Info("connect db error:%v", err)
	}

	targetDB, err := connectDB(dbinfo.TargetDSN, dbinfo.TargetDBType)
	if err != nil {
		logger.Info("connect db error:%v", err)
	}

	// 模式创建
	var shemaExists bool
	err = targetDB.Raw("SELECT EXISTS (SELECT 1 FROM information_schema.schemata WHERE schema_name = ?)", dbinfo.Schema).Scan(&shemaExists).Error
	if err != nil {
		logger.Info("check schema error:%v", err)
	}

	logger.Info("shemaExists is :%v", shemaExists)

	if !shemaExists {
		if err := targetDB.Exec(fmt.Sprintf("CREATE SCHEMA %s", dbinfo.Schema)).Error; err != nil {
			logger.Info("create schema error:%v", err)
		}
	}

	// 查询视图是否存在
	var exists bool
	err = targetDB.Raw("SELECT EXISTS (SELECT 1 FROM information_schema.views WHERE table_schema = ? AND table_name = ?)", dbinfo.Schema, viewname).Scan(&exists).Error
	if err != nil {
		logger.Info("failed to check table exists error:%v", err)
	}

	logger.Info("exist is :%v", exists)

	// 存在删除
	if exists {
		if err := targetDB.Exec(fmt.Sprintf("DROP VIEW %s.%s", dbinfo.Schema, viewname)).Error; err != nil {
			logger.Info("failed to delete error:%v", err)
		}
	}

	var createViewSql string
	logger.Info("select view is:%v", fmt.Sprintf(`SELECT pg_get_viewdef('%s."%s"',true)`, dbinfo.Schema, viewname))
	if err = sourceDB.Raw(fmt.Sprintf(`SELECT pg_get_viewdef('%s."%s"',true)`, dbinfo.Schema, viewname)).Scan(&createViewSql).Error; err != nil {
		logger.Info("failed to select view error:%v", err)
	}

	logger.Info("create view is:%v", fmt.Sprintf(`CREATE VIEW '%s."%s"' AS "%s"`, dbinfo.Schema, viewname, createViewSql))
	if err := targetDB.Exec(fmt.Sprintf(`CREATE VIEW %s.%s AS %s`, dbinfo.Schema, viewname, createViewSql)).Error; err != nil {
		logger.Info("failed to create view error:%v", err)
	}
	return nil
}

func getCreateTableSQL(db *sql.DB, schema, tableName string) (string, error) {
	query := `CREATE 
	OR REPLACE FUNCTION show_create_table ( in_schema_name VARCHAR, in_table_name VARCHAR ) RETURNS TEXT LANGUAGE plpgsql VOLATILE AS $$ DECLARE-- the ddl we're building
	v_table_ddl TEXT;
-- data about the target table
v_table_oid INT;
v_table_type CHAR;
v_partition_key VARCHAR;
v_table_comment VARCHAR;
-- records for looping
v_column_record record;
v_constraint_record record;
v_index_record record;
v_column_comment_record record;
v_index_comment_record record;
v_constraint_comment_record record;
BEGIN-- grab the oid of the table; https://www.postgresql.org/docs/8.3/catalog-pg-class.html
	SELECT C
		.OID,
		C.relkind INTO v_table_oid,
		v_table_type 
	FROM
		pg_catalog.pg_class
		C LEFT JOIN pg_catalog.pg_namespace n ON n.OID = C.relnamespace 
	WHERE
		C.relkind IN ( 'r', 'p' ) 
		AND C.relname = in_table_name -- the table name
		
		AND n.nspname = in_schema_name;-- the schema
-- throw an error if table was not found
	IF
		( v_table_oid IS NULL ) THEN
			RAISE EXCEPTION 'table does not exist';
		
	END IF;
-- start the create definition
	v_table_ddl := 'CREATE TABLE ' || in_schema_name || '.' || in_table_name || ' (' || E'\n';
-- define all of the columns in the table; https://stackoverflow.com/a/8153081/3068233
	FOR v_column_record IN SELECT C
	.COLUMN_NAME,
	C.data_type,
	C.character_maximum_length,
	C.is_nullable,
	C.column_default 
	FROM
		information_schema.COLUMNS C 
	WHERE
		( table_schema, TABLE_NAME ) = ( in_schema_name, in_table_name ) 
	ORDER BY
		ordinal_position
		LOOP
		v_table_ddl := v_table_ddl || '  ' -- note: two char spacer to start, to indent the column
		|| '"' || v_column_record.COLUMN_NAME || '" ' || v_column_record.data_type ||
	CASE
			
			WHEN v_column_record.character_maximum_length IS NOT NULL THEN
			( '(' || v_column_record.character_maximum_length || ')' ) ELSE'' 
		END || ' ' ||
CASE
	
	WHEN v_column_record.is_nullable = 'NO' THEN
	'NOT NULL' ELSE'NULL' 
	END ||
CASE
	
	WHEN v_column_record.column_default IS NOT NULL THEN
	( ' DEFAULT ' || v_column_record.column_default ) ELSE'' 
	END || ',' || E'\n';

END LOOP;
-- define all the constraints in the; https://www.postgresql.org/docs/9.1/catalog-pg-constraint.html && https://dba.stackexchange.com/a/214877/75296
FOR v_constraint_record IN SELECT
con.conname AS CONSTRAINT_NAME,
con.contype AS constraint_type,
CASE
		
		WHEN con.contype = 'p' THEN
		1 -- primary key constraint
		
		WHEN con.contype = 'u' THEN
		2 -- unique constraint
		
		WHEN con.contype = 'f' THEN
		3 -- foreign key constraint
		
		WHEN con.contype = 'c' THEN
		4 ELSE 5 
	END AS type_rank,
	pg_get_constraintdef ( con.OID ) AS constraint_definition 
FROM
	pg_catalog.pg_constraint con
	JOIN pg_catalog.pg_class rel ON rel.OID = con.conrelid
	JOIN pg_catalog.pg_namespace nsp ON nsp.OID = connamespace 
WHERE
	nsp.nspname = in_schema_name 
	AND rel.relname = in_table_name 
ORDER BY
	type_rank
	LOOP
IF
	v_constraint_record.constraint_type = 'p' THEN
		v_table_ddl := v_table_ddl || '  ' || v_constraint_record.constraint_definition || ',' || E'\n';
	ELSE v_table_ddl := v_table_ddl || '  ' -- note: two char spacer to start, to indent the column
	|| 'CONSTRAINT' || ' ' || '"' || v_constraint_record.CONSTRAINT_NAME || '" ' || v_constraint_record.constraint_definition || ',' || E'\n';
	
END IF;

END LOOP;
-- drop the last comma before ending the create statement
v_table_ddl = substr( v_table_ddl, 0, LENGTH ( v_table_ddl ) - 1 ) || E'\n';
-- end the create definition
v_table_ddl := v_table_ddl || ')';
IF
	v_table_type = 'p' THEN
	SELECT
		pg_get_partkeydef ( v_table_oid ) INTO v_partition_key;
	IF
		v_partition_key IS NOT NULL THEN
			v_table_ddl := v_table_ddl || ' PARTITION BY ' || v_partition_key;
		
	END IF;
	
END IF;
v_table_ddl := v_table_ddl || ';' || E'\n';
-- suffix create statement with all of the indexes on the table
FOR v_index_record IN SELECT
regexp_replace( indexdef, ' "?' || schemaname || '"?\.', ' ' ) AS indexdef 
FROM
	pg_catalog.pg_indexes 
WHERE
	( schemaname, tablename ) = ( in_schema_name, in_table_name ) 
	AND indexname NOT IN (
	SELECT
		con.conname 
	FROM
		pg_catalog.pg_constraint con
		JOIN pg_catalog.pg_class rel ON rel.OID = con.conrelid
		JOIN pg_catalog.pg_namespace nsp ON nsp.OID = connamespace 
	WHERE
		nsp.nspname = in_schema_name 
		AND rel.relname = in_table_name 
	)
	LOOP
	v_table_ddl := v_table_ddl || v_index_record.indexdef || ';' || E'\n';

END LOOP;
-- comment on table
SELECT
	description INTO v_table_comment 
FROM
	pg_catalog.pg_description 
WHERE
	objoid = v_table_oid 
	AND objsubid = 0;
IF
	v_table_comment IS NOT NULL THEN
		v_table_ddl := v_table_ddl || 'COMMENT ON TABLE "' || in_table_name || '" IS ''' || REPLACE ( v_table_comment, '''', '''''' ) || ''';' || E'\n';
	
END IF;
-- comment on column
FOR v_column_comment_record IN SELECT
col.COLUMN_NAME,
d.description 
FROM
	information_schema.COLUMNS col
	JOIN pg_catalog.pg_class C ON C.relname = col.
	TABLE_NAME JOIN pg_catalog.pg_namespace nsp ON nsp.OID = C.relnamespace 
	AND col.table_schema = nsp.nspname
	JOIN pg_catalog.pg_description d ON d.objoid = C.OID 
	AND d.objsubid = col.ordinal_position 
WHERE
	C.OID = v_table_oid 
ORDER BY
	col.ordinal_position
	LOOP
	v_table_ddl := v_table_ddl || 'COMMENT ON COLUMN "' || in_table_name || '"."' || v_column_comment_record.COLUMN_NAME || '" IS ''' || REPLACE ( v_column_comment_record.description, '''', '''''' ) || ''';' || E'\n';

END LOOP;
-- comment on index
FOR v_index_comment_record IN SELECT C
.relname,
d.description 
FROM
	pg_catalog.pg_index idx
	JOIN pg_catalog.pg_class C ON idx.indexrelid = C.
	OID JOIN pg_catalog.pg_description d ON idx.indexrelid = d.objoid 
WHERE
	idx.indrelid = v_table_oid
	LOOP
	v_table_ddl := v_table_ddl || 'COMMENT ON INDEX "' || v_index_comment_record.relname || '" IS ''' || REPLACE ( v_index_comment_record.description, '''', '''''' ) || ''';' || E'\n';

END LOOP;
-- comment on constraint
FOR v_constraint_comment_record IN SELECT
con.conname,
pg_description.description 
FROM
	pg_catalog.pg_constraint con
	JOIN pg_catalog.pg_class rel ON rel.OID = con.conrelid
	JOIN pg_catalog.pg_namespace nsp ON nsp.OID = connamespace
	JOIN pg_catalog.pg_description ON pg_description.objoid = con.OID 
WHERE
	rel.OID = v_table_oid
	LOOP
	v_table_ddl := v_table_ddl || 'COMMENT ON CONSTRAINT "' || v_constraint_comment_record.conname || '" ON "' || in_table_name || '" IS ''' || REPLACE ( v_constraint_comment_record.description, '''', '''''' ) || ''';' || E'\n';

END LOOP;
-- return the ddl
RETURN v_table_ddl;

END $$;
`

	query2 := `SELECT
show_create_table ( $2, $1 );`

	res, err := db.Exec(query)
	if err != nil {
		logger.Error(err)
		return "", err
	}
	logger.Info("%v", res)

	var createSQL string
	err = db.QueryRow(query2, tableName, schema).Scan(&createSQL)
	if err != nil {
		return "", err
	}
	return createSQL, nil
}

func IsViewExists(db *gorm.DB, schema, tableName string) (bool, error) {
	var exists bool
	rawSql := `
	SELECT 
	  EXISTS (
		SELECT 1
		FROM information_schema.views
		WHERE table_schema = ?
		AND table_name = ?
	)`
	err := db.Raw(rawSql, schema, tableName).Row().Scan(&exists)
	if err != nil {
		return false, err
	}
	return exists, nil
}

func FindViewsOnTable(db *gorm.DB, schema, tableName string) ([]string, error) {
	var views []string
	query := `
	SELECT
DISTINCT
	v.OID :: REGCLASS AS VIEW 
FROM
	pg_depend AS d
	JOIN pg_rewrite AS r ON r.OID = d.objid
	JOIN pg_class AS v ON v.OID = r.ev_class 
WHERE
	v.relkind = 'v' 
	AND d.classid = 'pg_rewrite' :: REGCLASS 
	AND d.refclassid = 'pg_class' :: REGCLASS 
	AND d.deptype = 'n' 
	AND d.refobjid = ? :: REGCLASS
	`
	fullTableName := fmt.Sprintf("%s.%s", schema, tableName)
	err := db.Raw(query, fullTableName).Pluck("view", &views).Error

	return views, err

}

func BackUpView(db *gorm.DB, schema string, views []string) error {
	for _, viewname := range views {
		newViewName := "backup_" + viewname
		// 获取旧视图的def
		queryOldDef := `
		SELECT
		view_definition 
	FROM
		information_schema.views 
	WHERE
		table_schema = ? 
		AND TABLE_NAME = ?
		`
		var viewDef string
		db.Raw(queryOldDef, viewname).Scan(&viewDef)
		if viewDef == "" {
			logger.Error("未获取到视图定义")
		}
		createNewViewSql := fmt.Sprintf("CREATE VIEW %s.%s as %s", schema, newViewName, viewDef)
		if err := db.Exec(createNewViewSql).Error; err != nil {
			logger.Error("create")
		}

	}

	return nil
}

func GetViewDefine(db *gorm.DB, schema string, viewname string) (string, error) {
	logger.Info("viewname is:%v", viewname)
	if schema == "public" {
		viewname = schema + "." + viewname
	}
	viewname = strings.Split(viewname, ".")[1]
	// newViewName := "backup_" + viewname
	// 获取旧视图的def
	queryOldDef := `
		SELECT
		view_definition 
	FROM
		information_schema.views 
	WHERE
		table_schema = ? 
		AND TABLE_NAME = ?
		`
	var viewDef string
	db.Raw(queryOldDef, schema, viewname).Scan(&viewDef)
	if viewDef == "" {
		logger.Error("未获取到视图定义")
	}
	// createNewViewSql := fmt.Sprintf("CREATE VIEW %s.%s as %s", schema, newViewName, viewDef)
	// if err := db.Exec(createNewViewSql).Error; err != nil {
	// 	logger.Error("create")
	// }
	return viewDef, nil

}

func CreateView(db *gorm.DB, viewname, viewDef string) error {

	createNewViewSql := fmt.Sprintf("CREATE VIEW %s as %s", viewname, viewDef)
	if err := db.Exec(createNewViewSql).Error; err != nil {
		logger.Error("create view failed:%v", err)
	}

	return nil
}
