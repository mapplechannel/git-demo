package service

import (
	"database/sql"
	"fmt"
	"hsm-io-it-back-end/internal/util"
	"hsm-io-it-back-end/internal/vo"
	"hsm-io-it-back-end/pkg/logger"
	"html/template"
	"math/rand"
	"reflect"
	"strconv"
	"time"

	_ "github.com/go-sql-driver/mysql"
)

// 测试连接mysql数据库
func ConnectMysqlTest_MES(mysqlInfoRequest *vo.DatabaseInfoRequest) (bool, string) {
	//组装连接参数
	userName := mysqlInfoRequest.Username
	password := mysqlInfoRequest.Password
	host := mysqlInfoRequest.Host
	port := mysqlInfoRequest.Port
	url := userName + ":" + password + "@tcp(" + host + ":" + port + ")/"

	db, err := sql.Open("mysql", url)
	if err != nil {
		return false, "连接失败"
	}

	defer db.Close()

	db.SetConnMaxIdleTime(time.Minute * 1)
	db.SetConnMaxLifetime(time.Minute * 1)
	db.SetMaxOpenConns(10)
	db.SetMaxIdleConns(10)
	err = db.Ping()
	if err != nil {
		logger.Error(err)
		logger.Error(url + " ->连接失败")
		return false, "连接失败"
	}
	logger.Info(" ->连接成功")
	return true, "连接成功"
}

func GenerateECode() string {
	rand.Seed(time.Now().UnixNano())
	code := "emysql_"
	for i := 0; i < 8; i++ {
		code += fmt.Sprintf("%d", rand.Intn(10))
	}
	return code
}

func AddConenctMySql_MES(mysqlInfoRequest *vo.DatabaseInfoRequest) (bool, string) {

	flag := util.IsEExistDatabase(mysqlInfoRequest.ConnectName, mysqlInfoRequest.Namespace)

	if flag {
		return false, "不能创建相同类型的同名数据源，请重新输入"
	}

	code := GenerateECode()
	mysqlInfoRequest.Code = code

	dbPG, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, ""
	}
	defer dbPG.Close()

	addsql := `INSERT INTO ioit.database_info (
					code, namespace, connectname, username, password, host, port, 
					databasetype, s_node, dbname, schemaname, tablename, dbpath) 
				VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)`

	_, err = dbPG.Exec(addsql,
		mysqlInfoRequest.Code, mysqlInfoRequest.Namespace, mysqlInfoRequest.ConnectName,
		mysqlInfoRequest.Username, mysqlInfoRequest.Password, mysqlInfoRequest.Host,
		mysqlInfoRequest.Port, "EMySQL", util.ServerCode, mysqlInfoRequest.DbName,
		mysqlInfoRequest.SchemaName, mysqlInfoRequest.Tablename, mysqlInfoRequest.DbPath)

	if err != nil {
		logger.Info("数据库插入失败:%v", err)
		return false, "数据库插入失败"
	}

	url := mysqlInfoRequest.Username + ":" + mysqlInfoRequest.Password + "@tcp(" + mysqlInfoRequest.Host + ":" + mysqlInfoRequest.Port + ")/"

	db, err := sql.Open("mysql", url)
	if err != nil {
		fmt.Println(err)
		return false, "连接失败"
	}
	db.SetConnMaxIdleTime(time.Minute * 10)
	db.SetConnMaxLifetime(time.Minute * 10)
	db.SetMaxOpenConns(10)
	db.SetMaxIdleConns(10)
	err = db.Ping()
	if err != nil {
		logger.Error(err)
		return false, "连接失败"
	}
	logger.Info("连接成功")

	defer db.Close()
	return true, code
}

type MESResponseInfo struct {
	Code        string `json:"code"`
	JobCode     string `json:"jobcode"`
	ConnectName string `json:"connectname"`
	Namespace   string `json:"namespace"`
	Username    string `json:"username"`
	Password    string `json:"password"`
	Host        string `json:"host"`
	Port        string `json:"port"`
	DbName      string `json:"dbname"`
}

// 获取数据库连接
func GetConnectInfo_MES(mysqlListInfo *vo.DatabaseInfoRequest) (bool, []MESResponseInfo) {

	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, nil
	}
	defer db.Close()

	query := `SELECT 
					code, connectname, username, namespace,
					password, host, port, dbname 
			FROM ioit.database_info WHERE namespace = $1 AND databasetype = $2`

	rows, err := db.Query(query, mysqlListInfo.Namespace, "EMySQL")

	if err != nil {
		logger.Info("数据库连接失败%v", err)
		return false, nil
	}

	defer rows.Close()

	var infos []MESResponseInfo

	for rows.Next() {
		var info MESResponseInfo
		err = rows.Scan(&info.Code, &info.ConnectName,
			&info.Username, &info.Namespace, &info.Password, &info.Host, &info.Port, &info.DbName)
		if err != nil {
			logger.Info("数据库连接失败%v", err)
			return false, nil
		}
		infos = append(infos, info)
	}

	return true, infos
}

// 更新数据库连接
func UpdateConnect_MES(mysqlInfo *vo.DatabaseInfoRequest) (bool, string) {
	flag := util.IsUpdateEExistDatabase(mysqlInfo.ConnectName, mysqlInfo.Namespace, mysqlInfo.Code)

	if flag {
		return false, "不能创建相同类型的同名数据源，请重新编辑"
	}

	dbPG, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, "数据库连接失败"
	}
	defer dbPG.Close()

	updatesql := `UPDATE ioit.database_info SET 
					connectname=$1,	username=$2, password=$3, host=$4, port=$5, dbname=$6
				WHERE code = $7 `

	_, err = dbPG.Exec(updatesql,
		mysqlInfo.ConnectName, mysqlInfo.Username, mysqlInfo.Password, mysqlInfo.Host, mysqlInfo.Port, mysqlInfo.DbName, mysqlInfo.Code)

	if err != nil {
		logger.Info("数据库连接更新失败%v", err)
		return false, "数据库连接更新失败"
	}

	logger.Info("数据库连接信息更新: %v", flag)

	return true, "更新成功"
}

func GetConenctMySql_MES(mysqlInfoRequest *vo.DatabaseInfoRequest) (bool, []Database) {
	//组装连接参数
	userName := mysqlInfoRequest.Username
	password := mysqlInfoRequest.Password
	host := mysqlInfoRequest.Host
	port := mysqlInfoRequest.Port
	url := userName + ":" + password + "@tcp(" + host + ":" + port + ")/"

	db, err := sql.Open("mysql", url)
	if err != nil {
		return false, nil
	}
	db.SetConnMaxIdleTime(time.Minute * 10)
	db.SetConnMaxLifetime(time.Minute * 10)
	db.SetMaxOpenConns(10)
	db.SetMaxIdleConns(10)

	err = db.Ping()
	if err != nil {
		logger.Error(url + " ->连接失败")
		return false, nil
	}
	logger.Info(" ->连接成功")

	defer db.Close()

	rows, err := db.Query("SHOW DATABASES")
	if err != nil {
		return false, nil
	}
	defer rows.Close()
	// 封装所有数据库信息
	var databases []Database
	for rows.Next() {
		var database Database
		if err := rows.Scan(&database.Name); err != nil {
			return false, nil
		}
		databases = append(databases, database)
	}
	return true, databases
}

func GetTable_MES(mysqlInfoRequest *vo.DatabaseInfoRequest) (bool, []Table) {

	userName := mysqlInfoRequest.Username
	password := mysqlInfoRequest.Password
	host := mysqlInfoRequest.Host
	port := mysqlInfoRequest.Port
	url := userName + ":" + password + "@tcp(" + host + ":" + port + ")/"

	db, err := connectToMySQL(url)
	if err != nil {
		return false, nil
	}

	defer db.Close()

	// 连接到指定的数据库
	_, err1 := db.Exec("USE " + mysqlInfoRequest.DbName)
	if err1 != nil {
		return false, nil
	}

	// 查询所有表
	rows, err := db.Query("SHOW TABLES")
	if err != nil {
		return false, nil
	}
	defer rows.Close()
	// 封装所有表信息
	var tables []Table
	for rows.Next() {
		var table Table
		if err := rows.Scan(&table.Name); err != nil {
			return false, nil
		}

		tables = append(tables, table)
	}
	return true, tables
}

func GetTablePrimary_MES(mysqlInfoRequest *vo.DatabaseInfoRequest) (bool, []string) {
	userName := mysqlInfoRequest.Username
	password := mysqlInfoRequest.Password
	host := mysqlInfoRequest.Host
	port := mysqlInfoRequest.Port
	url := userName + ":" + password + "@tcp(" + host + ":" + port + ")/"

	db, err := connectToMySQL(url)
	if err != nil {
		return false, nil
	}

	defer db.Close()

	// 连接到指定的数据库
	_, err1 := db.Exec("USE " + mysqlInfoRequest.DbName)
	if err1 != nil {
		return false, nil
	}
	// 查询当前表的所有字段
	rows, err := db.Query(fmt.Sprintf("SELECT column_name FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE WHERE table_name='%s' AND constraint_name='PRIMARY'", mysqlInfoRequest.Tablename))
	if err != nil {
		return false, nil
	}
	defer rows.Close()

	// 封装所有字段信息
	var columns []string
	for rows.Next() {
		var column string
		if err := rows.Scan(&column); err != nil {
			return false, nil
		}
		columns = append(columns, column)
	}
	// 返回所有字段信息
	return true, columns
}

func GetTableColumns_MES(mysqlInfoRequest *vo.DatabaseInfoRequest) (bool, []Column) {
	userName := mysqlInfoRequest.Username
	password := mysqlInfoRequest.Password
	host := mysqlInfoRequest.Host
	port := mysqlInfoRequest.Port
	url := userName + ":" + password + "@tcp(" + host + ":" + port + ")/"

	db, err := connectToMySQL(url)
	if err != nil {
		return false, nil
	}
	defer db.Close()

	// 连接到指定的数据库
	_, err1 := db.Exec("USE " + mysqlInfoRequest.DbName)
	if err1 != nil {
		return false, nil
	}
	// 查询当前表的所有字段
	rows, err := db.Query(fmt.Sprintf("SELECT COLUMN_NAME,COLUMN_TYPE,COLUMN_COMMENT FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '%s' AND TABLE_NAME = '%s'", mysqlInfoRequest.DbName, mysqlInfoRequest.Tablename))
	if err != nil {
		return false, nil
	}
	defer rows.Close()
	// 封装所有字段信息
	var columns []Column
	for rows.Next() {
		var column Column
		if err := rows.Scan(&column.Name, &column.Type, &column.Comment); err != nil {
			return false, nil
		}
		columns = append(columns, column)
	}
	for i, v := range columns {
		if v.Type == "bit(1)" {
			columns[i].Name = "bin(" + columns[i].Name + ")"
		}
	}
	// 返回所有字段信息
	return true, columns
}

func GetTableData_MES(mysqlInfoRequest *vo.DatabaseInfoRequest) (bool, SearchMySQLResponse, string) {
	res := SearchMySQLResponse{}

	userName := mysqlInfoRequest.Username
	password := mysqlInfoRequest.Password
	host := mysqlInfoRequest.Host
	port := mysqlInfoRequest.Port
	url := userName + ":" + password + "@tcp(" + host + ":" + port + ")/"

	db, err := connectToMySQL(url)
	if err != nil {
		return false, res, "数据库连接失败"
	}

	defer db.Close()

	flag := ContainsComplexQuery(mysqlInfoRequest.SQL)
	if flag {
		return false, res, "不支持复杂查询"
	}

	_, err1 := db.Exec("USE " + mysqlInfoRequest.DbName)
	if err1 != nil {
		return false, res, "数据查询失败"
	}
	// 查询当前表的所有字段
	rows, err := db.Query(mysqlInfoRequest.SQL)
	if err != nil {
		logger.Info("err is:%v", err)
		if isUnknowColumnMysql(err) {
			return false, res, errToCN(err)
		}
		return false, res, "数据查询失败"
	}
	defer rows.Close()

	count := 0
	// 解析查询结果
	columns, _ := rows.Columns()
	columnTypes, _ := rows.ColumnTypes()
	var results []map[string]interface{}
	for rows.Next() {
		count++
		if count > 1000 {
			// return false, res, "支持预览1000条数据"
			logger.Info("支持预览1000条数据")
			break
		}
		values := make([]interface{}, len(columns))
		valuePtrs := make([]interface{}, len(columns))
		for i := range columns {
			valuePtrs[i] = &values[i]
		}
		err = rows.Scan(valuePtrs...)
		if err != nil {
			continue
		}
		rowData := make(map[string]interface{})
		for i, col := range columns {
			val := valuePtrs[i].(*interface{})

			if columnTypes[i].DatabaseTypeName() == "BIT" {
				if *val == nil {
					rowData[col] = nil
					continue
				}
				t := *val
				logger.Info(" is bit :%v", t)
				u8str := t.([]byte)
				rowData[col] = strconv.Itoa(int(u8str[0]))
			} else {
				if *val == nil {
					rowData[col] = nil
					continue
				}
				rowData[col] = ToString_MES(*val)
			}
		}
		results = append(results, rowData)
	}
	res.List = results
	res.Cols = columns
	sqlTableColumn := fmt.Sprintf("SELECT `COLUMN_NAME`, `COLUMN_COMMENT` FROM `information_schema`.`columns` WHERE `table_schema`= '%s' AND `table_name`= '%s' ORDER BY `ORDINAL_POSITION` ASC",
		mysqlInfoRequest.DbName, mysqlInfoRequest.Tablename)
	rowsCom, err := db.Query(sqlTableColumn)
	if err != nil {
		fmt.Println(err)
	}
	defer rowsCom.Close()

	var tableColumns []tableColumn

	for rowsCom.Next() {
		var column tableColumn
		err = rowsCom.Scan(
			&column.ColumnName,
			&column.ColumnComment)

		if err != nil {
			fmt.Printf("query table column scan error, detail is [%v]\n", err.Error())
			continue
		}

		tableColumns = append(tableColumns, column)
	}

	res.ColsInfo = tableColumns

	return true, res, "查询成功"
}

func ToString_MES(i interface{}) string {
	v, _ := ToStringE_MES(i)
	return v
}

// ToStringE casts an interface to a string type.
func ToStringE_MES(i interface{}) (string, error) {
	i = indirectToStringerOrError_MES(i)

	switch s := i.(type) {
	case string:
		return s, nil
	case bool:
		return strconv.FormatBool(s), nil
	case float64:
		return strconv.FormatFloat(s, 'f', -1, 64), nil
	case float32:
		return strconv.FormatFloat(float64(s), 'f', -1, 32), nil
	case int:
		return strconv.Itoa(s), nil
	case int64:
		return strconv.FormatInt(s, 10), nil
	case int32:
		return strconv.Itoa(int(s)), nil
	case int16:
		return strconv.FormatInt(int64(s), 10), nil
	case int8:
		return strconv.FormatInt(int64(s), 10), nil
	case uint:
		return strconv.FormatUint(uint64(s), 10), nil
	case uint64:
		return strconv.FormatUint(uint64(s), 10), nil
	case uint32:
		return strconv.FormatUint(uint64(s), 10), nil
	case uint16:
		return strconv.FormatUint(uint64(s), 10), nil
	case uint8:
		return strconv.FormatUint(uint64(s), 10), nil
	case []byte:
		return string(s), nil
	case template.HTML:
		return string(s), nil
	case template.URL:
		return string(s), nil
	case template.JS:
		return string(s), nil
	case template.CSS:
		return string(s), nil
	case template.HTMLAttr:
		return string(s), nil
	case nil:
		return "", nil
	case fmt.Stringer:
		return s.String(), nil
	case error:
		return s.Error(), nil
	default:
		return "", fmt.Errorf("unable to cast %#v of type %T to string", i, i)
	}
}

func indirectToStringerOrError_MES(a interface{}) interface{} {
	if a == nil {
		return nil
	}

	var errorType = reflect.TypeOf((*error)(nil)).Elem()
	var fmtStringerType = reflect.TypeOf((*fmt.Stringer)(nil)).Elem()

	v := reflect.ValueOf(a)
	for !v.Type().Implements(fmtStringerType) && !v.Type().Implements(errorType) && v.Kind() == reflect.Ptr && !v.IsNil() {
		v = v.Elem()
	}
	return v.Interface()
}
