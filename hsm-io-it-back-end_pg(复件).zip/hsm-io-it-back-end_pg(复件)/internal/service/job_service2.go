package service

import (
	"hsm-io-it-back-end/internal/util"
	"hsm-io-it-back-end/internal/vo"
	"hsm-io-it-back-end/pkg/logger"
)

type SchInfo struct {
	SchType     string `json:"schType"`
	SchExp      string `json:"schExp"`
	PeriodCount int    `json:"periodCount"`
}

func GetSchTypeForYaml(req *vo.JobKeyInfo) SchInfo {
	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
	}
	defer db.Close()
	job := util.GetJobDetailsInfo(req.NameSpace, req.Code, req.SKNode)
	if job == nil {
		logger.Info("查询数据为空")
	}

	schType := job.Schedule
	schExp := job.ScheduleDetails
	var periodCount int
	if schType == "2" {
		if job.PeriodDetail.EndType == "times" {
			periodCount = job.PeriodDetail.Times
		}
	}

	res := SchInfo{
		SchType:     schType,
		SchExp:      schExp,
		PeriodCount: periodCount,
	}
	return res
}
