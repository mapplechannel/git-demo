package service_test

import (
	"hsm-io-it-back-end/internal/service"
	"hsm-io-it-back-end/pkg/logger"
	"testing"
)

func TestGetJobList(t *testing.T) {
	xml := `"{<?xml version="1.0" encoding="UTF-16"?>
	<ns1:PostBatchAsyncOrdersnDet
		xmlns:ns1="http://172.26.15.30/api/erpapi/ERPWebService.asmx">
		<ns1:allList>
			<ns1:ErpOrderSnModel>
				<ns1:OrderNo>3200232214</ns1:OrderNo>
				<ns1:SnNo>111</ns1:SnNo>
			</ns1:ErpOrderSnModel>
		</ns1:allList>
	</ns1:PostBatchAsyncOrdersnDet>
	}"`
	data, _, _ := service.XmlToMap(xml)
	logger.Info("data:%v", data)
}
