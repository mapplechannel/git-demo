package service

import (
	"fmt"
	"hsm-io-it-back-end/internal/vo"
	"strings"
)

func GenerateCronExp(jobRequest *vo.CreateJobRequest) string {
	if jobRequest.CronDetail.Type == "day" {
		// 每天执行的cron
		effectiveDateArr := strings.Split(jobRequest.CronDetail.EffectiveDate, " ")
		timeArr := strings.Split(effectiveDateArr[1], ":")
		return fmt.Sprintf("%s %s %s * %s *", timeArr[2], timeArr[1], timeArr[0], jobRequest.CronDetail.ExecuteMonth)
	}
	if jobRequest.CronDetail.Type == "week" {
		// 每周执行的cron
		effectiveDateArr := strings.Split(jobRequest.CronDetail.EffectiveDate, " ")
		timeArr := strings.Split(effectiveDateArr[1], ":")
		return fmt.Sprintf("%s %s %s * %s %s", timeArr[2], timeArr[1], timeArr[0], jobRequest.CronDetail.ExecuteMonth, jobRequest.CronDetail.DayOfWeek)
	}
	if jobRequest.CronDetail.Type == "month" {
		// 每月执行的cron
		effectiveDateArr := strings.Split(jobRequest.CronDetail.EffectiveDate, " ")
		timeArr := strings.Split(effectiveDateArr[1], ":")
		return fmt.Sprintf("%s %s %s %s %s ?", timeArr[2], timeArr[1], timeArr[0], jobRequest.CronDetail.DayOfMonth, jobRequest.CronDetail.ExecuteMonth)
	}

	return ""
}
