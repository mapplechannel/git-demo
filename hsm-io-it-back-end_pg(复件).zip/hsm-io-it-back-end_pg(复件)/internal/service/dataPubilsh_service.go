package service

import (
	"encoding/json"
	"errors"
	"fmt"
	"hsm-io-it-back-end/config"
	"hsm-io-it-back-end/internal/constants"
	"hsm-io-it-back-end/internal/util"
	"hsm-io-it-back-end/internal/vo"
	"hsm-io-it-back-end/pkg/logger"
	"io/ioutil"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"gorm.io/gorm"
)

type JobInfoSlice_dataPublish []JobInfo

func (s JobInfoSlice_dataPublish) Len() int {
	return len(s)
}

func (s JobInfoSlice_dataPublish) Less(i, j int) bool {
	// 比较两个JobInfo的CreateTime字段，使用time.Parse()函数将字符串转换为time.Time类型
	t1, _ := time.Parse("2006-01-02 15:04:05", s[i].CreateTime)
	t2, _ := time.Parse("2006-01-02 15:04:05", s[j].CreateTime)
	// 使用After()方法判断哪个时间更晚
	return t1.After(t2)
}

func (s JobInfoSlice_dataPublish) Swap(i, j int) {
	s[i], s[j] = s[j], s[i]
}

var dataPublishRange []string
var returnDataRange []string

func GetJobTree(namespace string) (bool, []JobInfo, string) {

	query := `SELECT 
				create_user, name, describe, job_type, id, status, create_time, 
				edite_time, is_auto_select_id,status,code,job_class
 			FROM ioit.job_info WHERE namespace = $1`

	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, nil, "数据库连接失败"
	}
	defer db.Close()

	rows, err := db.Query(query, namespace)

	if err != nil {
		logger.Info("数据库连接失败:%v", err)
		return false, nil, "查询失败"
	}

	defer rows.Close()

	var jobs []JobInfo

	for rows.Next() {
		var job JobInfo
		// var createTime time.Time
		// var editeTime time.Time
		if err := rows.Scan(&job.CreateUse, &job.Name, &job.Describe, &job.JobType,
			&job.Id, &job.Status, &job.CreateTime, &job.EditeTime, &job.IsAutoSelectId,
			&job.Status, &job.Code, &job.JobClass); err != nil {
			logger.Info("数据库连接失败:%v", err)
			return false, nil, "查询失败"
		}
		// job.CreateTime = createTime.Format("2006-01-02 15:04:05")
		// job.EditeTime = editeTime.Format("2006-01-02 15:04:05")
		jobs = append(jobs, job)
	}
	sort.Sort(JobInfoSlice_dataPublish(jobs))
	return true, jobs, "查询成功"
}

// 编译进度
var compressProgress int

// 编译状态
var compressStatus string

// 数据发布版本号
var dataPublish_version string

// 记录数据发布的版本号
var arr_version []string

// 记录ENG数据发布的namespace
var eng_verison []string

type DataPublish struct {
	LenIndex int `gorm:"column:len_index"`
}

func UpdateLenIndex(newIndex int) error {
	var data DataPublish
	if err := util.GlobalGormDb.Table("ioit.data_publish").First(&data).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			data = DataPublish{LenIndex: newIndex}
			return util.GlobalGormDb.Table("ioit.data_publish").Create(&data).Error
		}
		return err
	}

	return util.GlobalGormDb.Table("ioit.data_publish").Where("len_index = ?", data.LenIndex).Update("len_index", newIndex).Error
}

func GetLenIndex() (int, error) {
	var data DataPublish
	if err := util.GlobalGormDb.Table("ioit.data_publish").First(&data).Error; err != nil {
		logger.Info("len_index is not found")
	}
	return data.LenIndex, nil
}

// 编译
func CompressTargz(namespace string, getDataPublishCompileRequest *vo.GetDataPublishCompileRequest) (bool, string) {

	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, "数据库连接失败"
	}
	defer db.Close()

	compressStatus = constants.UnderWayStatus
	version := getDataPublishCompileRequest.Version

	// 日志路径
	logBasePath := constants.LogPath + namespace + constants.Hierarchy
	util.CreateDir(logBasePath)
	// 创建当前版本的日志
	logPath := logBasePath + version + constants.Suffix
	util.CreateFile(logPath)

	var logSlice []vo.LogBody

	serverRangeSlice := getDataPublishCompileRequest.ServerRange
	var index []int

	// 找到IOIT应用的数据发布信息
	for i, v := range serverRangeSlice {
		if v.AppId == constants.AppId {
			index = append(index, i)
		}
	}

	// 判断是否为全选，是否为清空，拼接压缩包名称
	isClear := serverRangeSlice[index[0]].IsClear
	isAll := serverRangeSlice[index[0]].IsAll
	removePath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp + namespace
	sourceDir := removePath
	isAll_string := constants.IsAll
	isCleae_string := constants.IsClear
	if !isAll {
		isAll_string = constants.NotAll
	}
	if !isClear {
		isCleae_string = constants.NotClear
		logger.Info("修改同项目下的清空标识为notClear，%v", isCleae_string)
	}

	if len(eng_verison) != 0 && eng_verison[len(eng_verison)-1] != namespace {
		isCleae_string = constants.IsClear
		logger.Info("修改不同项目下的清空标识为isClear，%v", isCleae_string)
	}

	eng_verison = append(eng_verison, namespace)

	logger.Info("***************,%v", eng_verison)
	logger.Info("index:%v", index)

	// 创建数据库中的一条记录，告知所有应用发布应用包个数
	err = util.GlobalGormDb.Table("ioit.data_publish").AutoMigrate(&DataPublish{})
	if err != nil {
		logger.Info("err:%v", err)
	}
	err = UpdateLenIndex(len(index))
	if err != nil {
		logger.Info("err:%v", err)
	}

	for i := range index {
		// 获取数据发布传过来的数据
		serverId := serverRangeSlice[i].ServerId
		appId := serverRangeSlice[i].AppId
		dataRangeSlice := serverRangeSlice[i].DataRange

		logSlice = util.BuildLog(logSlice, namespace, serverId, "info", "准备编译", appId, "query", version, "")

		// tempPath = /usr/local/hsm-os/data/hsm-io-it/data/temp/namespace/
		tempPath := removePath + constants.Hierarchy
		util.CreateDir(tempPath)

		logContent := "临时数据准备完毕"
		logSlice = util.BuildLog(logSlice, namespace, serverId, "info", logContent, appId, "query", version, "")

		namespaceQuery := `SELECT EXISTS (SELECT 1 FROM ioit.job_info WHERE namespace = $1)`

		var exists bool

		err = db.QueryRow(namespaceQuery, namespace).Scan(&exists)
		logger.Info("临时数据准备完毕:%v", exists)
		if err != nil {
			logger.Info("数据库查询错误:%v", err)
			return false, "数据库查询错误"
		}

		logger.Info("namespace:%v", namespace)
		logger.Info("exists:%v", exists)

		if !exists {
			logContent = "发布数据不存在"
			logSlice = util.BuildLog(logSlice, namespace, serverId, "error", logContent, appId, "query", version, "")
			util.JsonToFile(logPath, logSlice)
			compressStatus = constants.FailedStatus
			return false, "发布数据不存在"
		}

		compressProgress = 20

		var jobInfoList []vo.CreateJobRequest
		var databaseInfoList []vo.DatabaseInfoRequest

		res := util.GetNodeServer()
		s_node := res[1]

		dataPublishRange = dataRangeSlice
		// 搜索数据库组件和文件上传组件
		var dataBaseTypeAndCode []string
		var uploadFilePath []string

		logger.Info("dataRangeSlice:%v", dataRangeSlice)
		for _, v := range dataRangeSlice {
			jobInfo := util.GetJobDetailsInfo(namespace, v, s_node)
			// 在子文件中找到数据库类型及其code
			jobInfo.IsAutoSelectId = false

			canvas, _ := json.Marshal(jobInfo.Canvas)
			dataBaseTypeAndCodeTemp := util.FindDataBaseTypeWithRe(string(canvas))
			dataBaseTypeAndCode = append(dataBaseTypeAndCode, dataBaseTypeAndCodeTemp...)

			// 在子文件中找到文件上传的文件路径
			uploadFilePathTemp := util.FindUploadFilePathWithRe(string(canvas))
			uploadFilePath = append(uploadFilePath, uploadFilePathTemp...)

			jobInfoList = append(jobInfoList, *jobInfo)
		}

		jobData, err := json.Marshal(jobInfoList)
		if err != nil {
			logger.Info("数据解析错误:%v", err)
			return false, ""
		}

		logger.Info("dataBaseTypeAndCode, %v", dataBaseTypeAndCode)
		logger.Info("uploadFilePath, %v", uploadFilePath)

		// job = /usr/local/hsm-os/data/hsm-io-it/data/temp/namespace/namespace.json
		util.WriteFile(tempPath+namespace+constants.JsonIdentifier, string(jobData))
		logContent = "任务数据准备完毕"
		logSlice = util.BuildLog(logSlice, namespace, serverId, "info", logContent, appId, "query", version, "")

		// 处理数据库连接
		dupslice := util.RemoveDuplicates(dataBaseTypeAndCode)

		for _, databasetype := range dupslice {
			sqlValue := strings.Split(databasetype, constants.AddressSplicingSymbols)
			sqlType := sqlValue[0]
			sqlCode := sqlValue[1]
			logger.Info("类型：%v", sqlType)
			logger.Info("code：%v", sqlCode)

			databaseInfo := util.GetDatabaseInfo(namespace, sqlCode, sqlType)
			databaseInfoList = append(databaseInfoList, *databaseInfo)
		}

		dbData, err := json.Marshal(databaseInfoList)
		if err != nil {
			logger.Info("序列化错误:%v", err)
			return false, "序列化错误"
		}

		// db = /usr/local/hsm-os/data/hsm-io-it/data/temp/namespace/databaseconfig/database.json
		dataBasefolder := tempPath + constants.DataBaseConfig
		util.CreateDir(dataBasefolder)
		util.WriteFile(dataBasefolder+"database"+constants.Suffix, string(dbData))
		logContent = "数据连接信息准备完毕"
		logSlice = util.BuildLog(logSlice, namespace, serverId, "info", logContent, appId, "query", version, "")

		// 找到upload下相关的上传文件
		for _, uploadFilePath := range uploadFilePath {
			logger.Info("uploadFilePath is %v", uploadFilePath)
			// tempPath = /usr/local/hsm-os/data/hsm-io-it/data/temp/namespace/upload/
			uploadFolder := tempPath + namespace + constants.Hierarchy + constants.UpLoad
			util.CreateDir(uploadFolder)
			filename := filepath.Base(uploadFilePath)
			util.CopyFile(uploadFilePath, uploadFolder+filename)
		}

		logContent = "文件上传组件数据准备完毕"
		logSlice = util.BuildLog(logSlice, namespace, serverId, "info", logContent, appId, "query", version, "")

		logContent = "所有数据准备完毕，开始压缩"
		logSlice = util.BuildLog(logSlice, namespace, serverId, "info", logContent, appId, "query", version, "")

		compressProgress = 50

		// 将要发布的作业code存入txt文件中
		// tempPath = /usr/local/hsm-os/data/hsm-io-it/data/temp/namespace/
		arr_file := tempPath + constants.ArrTxt
		flag := util.WriteArr(arr_file, dataPublishRange)
		logger.Info("发布数组文件写入成功：%v", flag)

		// 拼接压缩包名称
		targzNameSlice := []string{namespace, serverId, appId, version, isAll_string, isCleae_string}
		targzName := strings.Join(targzNameSlice, constants.Pound) + constants.TarGz
		logger.Info("压缩包名称为，%v", targzName)
		targetFile := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp + targzName
		baseDir := filepath.Base(sourceDir)

		// 执行压缩命令
		compressProgress = 70
		cmd := exec.Command("tar", "-czf", targetFile, "-C", filepath.Dir(sourceDir), baseDir)
		cmd.Stdout = os.Stdout
		cmd.Stderr = os.Stderr
		err = cmd.Run()
		if err != nil {
			logContent = "编译错误"
			logSlice = util.BuildLog(logSlice, namespace, serverId, "error", logContent, appId, "query", version, "")
			util.JsonToFile(logPath, logSlice)
			compressStatus = constants.FailedStatus
			return false, "压缩失败"
		}

		logContent = "编译完成"
		logSlice = util.BuildLog(logSlice, namespace, serverId, "info", logContent, appId, "query", version, "")

		compressProgress = 90
		util.CreateDir(constants.TARGZPATH)
		// 将压缩包移动至数据发布文件夹下
		cmd1 := exec.Command("mv", targetFile, constants.TARGZPATH)
		cmd1.Stdout = os.Stdout
		cmd1.Stderr = os.Stderr
		err = cmd1.Run()
		if err != nil {
			compressStatus = constants.FailedStatus
			return false, "移动文件失败"
		}
		os.RemoveAll(removePath)
		compressProgress = 100
		compressStatus = constants.SucceedStatus

		logContent = "编译压缩包上传至" + constants.TARGZPATH + "路径下"
		logSlice = util.BuildLog(logSlice, namespace, serverId, "info", logContent, appId, "query", version, "")

		util.JsonToFile(logPath, logSlice)
	}

	return true, "压缩成功"
}

// 获取进度
func GetProgress() int {
	return compressProgress
}

// 获取状态
func GetStatus() string {
	return compressStatus
}

func GetLog(namespace string, logRequest *vo.LogRequest) []vo.LogBody {
	version := logRequest.Version
	length := logRequest.Length
	logPath := constants.LogPath + namespace + constants.Hierarchy + version + constants.Suffix
	var logDataSlice []vo.LogBody

	// 解析log数据
	logData := util.ReadFile(logPath)
	if len(logData) != 0 {
		if err := json.Unmarshal([]byte(logData), &logDataSlice); err != nil {
			logger.Info("读取主文件错误:%v", err)
		}
	}

	logSumNum := len(logDataSlice)

	if length >= logSumNum || (compressStatus == constants.SucceedStatus) {
		return logDataSlice
	}

	if compressStatus != constants.SucceedStatus {
		return logDataSlice[logSumNum-length : logSumNum-1]
	}

	return nil
}

// 数据更新状态
var dataUpdateStatus int

// 记录数据发布ENG项目的切片
var por_name []string

// 数据更新/发布
func DataUpdate(namespace string, getDataPublishRequest *vo.GetDataPublishRequest) (bool, string) {

	var por_slice []string
	dataUpdateStatus = 0

	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败:%v", err)
	}
	defer db.Close()

	dataFilePath := getDataPublishRequest.DataFilePath

	dataFileName := filepath.Base(dataFilePath)
	nameSlice := strings.Split(dataFileName, constants.Pound)

	isClear := strings.Split(nameSlice[5], constants.DotDelimiter)[0]

	if len(por_name) == 0 {
		por_name = append(por_name, constants.V0)
	}
	por_name = append(por_name, namespace)

	logger.Info("**************por_name,%v", por_name)

	version := nameSlice[3]
	if len(arr_version) == 0 {
		arr_version = append(arr_version, constants.V0)
	}
	arr_version = append(arr_version, version)

	logger.Info("***********isClear%v", isClear)
	logger.Info("***********version%v", version)

	if namespace != nameSlice[0] {
		return false, "发布失败，未发现" + namespace + "的数据包"
	}

	// 数据备份************************start
	dataUpdateStatus = 41
	go util.BackPublish(arr_version)
	logger.Info("**************数据备份完成****************")
	// 数据备份************************end

	// 判断数据发布方式
	lenIndex, _ := GetLenIndex()
	logger.Info("index is :%v", lenIndex)
	if lenIndex != 1 {
		if util.ServerCode == "e1" {
			dataUpdateStatus = 100
			dataPublish_version = arr_version[len(arr_version)-1]
			return true, "s1进行"
		}
	}

	// 解压ENG压缩包，进行数据发布
	dataUpdateStatus = 43

	destinationDir := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp
	cmd2 := exec.Command("tar", "-xzf", dataFilePath, "-C", destinationDir)
	cmd2.Stdout = os.Stdout
	cmd2.Stderr = os.Stderr

	err = cmd2.Run()
	if err != nil {
		dataUpdateStatus = 99
		return false, "解压失败"
	}
	logger.Info("解压成功********************")

	// tempMainFile = /usr/local/hsm-os/data/hsm-io-it/data/temp/namespace/
	tempMainFile := destinationDir + namespace + constants.Hierarchy

	desTxt := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.TempDpt
	util.CreateDir(desTxt)
	cmd3 := exec.Command("tar", "-xzf", dataFilePath, "-C", desTxt)
	cmd3.Stdout = os.Stdout
	cmd3.Stderr = os.Stderr

	err = cmd3.Run()
	if err != nil {
		logger.Info("解压txt失败")
		return false, "解压失败"
	}
	logger.Info("解压txt成功********************")
	arr_file := desTxt + namespace + constants.Hierarchy + constants.ArrTxt
	por_slice = util.ReadArr(arr_file, por_slice)
	logger.Info("读取的txt切片为：%v", por_slice)

	if isClear == constants.IsClear {
		jobkey := util.FindStautsAndStop()
		for i := range jobkey {
			StopJob(&jobkey[i])
		}
		// 1. 删除原来的任务，通过namespace和s_node
		deleteJobQuery := `DELETE FROM ioit.job_info WHERE namespace = $1 AND is_auto_select_id = $2`

		_, err := db.Exec(deleteJobQuery, constants.PORTALNAME, false)
		if err != nil {
			logger.Info("删除数据失败:%v", err)
		}
		// 2. 删除原来的数据连接信息,通过namespace
		deleteDBQuery := `DELETE FROM ioit.database_info WHERE namespace = $1 AND = s_node = $2`

		_, err = db.Exec(deleteDBQuery, constants.PORTALNAME, "publish")
		if err != nil {
			logger.Info("删除数据失败:%v", err)
		}
		// 3. 插入新的任务
		var jobsImportList []vo.CreateJobRequest
		// tempMainFile = /usr/local/hsm-os/data/hsm-io-it/data/temp/namespace/
		jobInfos := util.ReadFile(tempMainFile + namespace + constants.Suffix)
		if len(jobInfos) != 0 {
			if err := json.Unmarshal([]byte(jobInfos), &jobsImportList); err != nil {
				logger.Error("json反序列化出错:%v", err)
			}
		}

		addsql := `INSERT INTO ioit.job_info (
			namespace,		create_user,		s_node,
			code,			name,				describe,
			schedule,		schedule_details,	schedule_cycle,
			schedule_unit,	content,			cron_id,
			is_http,		canvas,				job_type,
			template,		id,					status,
			create_time,	edite_time,			is_auto_select_id, 
			job_class,      cron_detail,        period_detail)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24)`

		for _, v := range jobsImportList {

			v.EditeTime = time.Now().Format("2006-01-02 15:04:05")
			v.Status = constants.ReadyJob
			v.SKNode = util.ServerCode

			content, errs := json.Marshal(v.Content)
			if errs != nil {
				fmt.Println("json marshal error:", errs)
			}

			canvas, errs := json.Marshal(v.Canvas)
			if errs != nil {
				fmt.Println("json marshal error:", errs)
			}

			cron, errs := json.Marshal(v.CronDetail)
			if errs != nil {
				fmt.Println("json marshal error:", errs)
			}

			period, errs := json.Marshal(v.PeriodDetail)
			if errs != nil {
				fmt.Println("json marshal error:", errs)
			}

			if v.JobClass == "" {
				v.JobClass = "cate_rootroot"
			}
			logger.Info("v.JobType:%v", v.JobType)

			if v.JobType == "" {
				v.JobType = "timing"
			}
			if v.JobType == "timing" {
				v.IsHttp = false
			}
			logger.Info("v.JobType:%v", v.JobType)

			_, err = db.Exec(addsql,
				constants.PORTALNAME, v.CreateUse, util.ServerCode, v.Code, v.Name,
				v.Describe, v.Schedule, v.ScheduleDetails, v.ScheduleCycle,
				v.ScheduleUnit, content, v.CronId, v.IsHttp, canvas, v.JobType,
				v.Template, v.Id, v.Status, v.CreateTime, v.EditeTime,
				false, v.JobClass, cron, period,
			)

			if err != nil {
				logger.Info("数据库操作失败：%v", err)
			}
		}
		// tempMainFile = /usr/local/hsm-os/data/hsm-io-it/data/temp/namespace/
		databaseConfigFileTemp := tempMainFile + constants.DataBaseConfig
		dbFlag := util.PathExists(databaseConfigFileTemp)
		if dbFlag {
			var databaseInfoList []vo.DatabaseInfoRequest
			databaseInfo := util.ReadFile(databaseConfigFileTemp + constants.Hierarchy + "database.json")
			if len(databaseInfo) != 0 {
				if err := json.Unmarshal([]byte(databaseInfo), &databaseInfoList); err != nil {
					logger.Error("json反序列化出错")
				}
			}

			updatedbsql := `INSERT INTO ioit.database_info (code, connectname, username, password, host,
							port, namespace, databasetype, dbname, schemaname, tablename, dbpath, s_node,retry)
							VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)`

			for _, v := range databaseInfoList {
				_, err = db.Exec(updatedbsql,
					v.Code, v.ConnectName, v.Username, v.Password, v.Host, v.Port, constants.PORTALNAME,
					v.DataBaseType, v.DbName, v.SchemaName, v.Tablename, v.DbPath, "publish", v.Retry)
				if err != nil {
					logger.Info("数据库操作失败：%v", err)
				}
			}
		}
	} else {
		var jobsImportList []vo.CreateJobRequest
		// tempMainFile = /usr/local/hsm-os/data/hsm-io-it/data/temp/namespace/
		jobInfos := util.ReadFile(tempMainFile + namespace + constants.Suffix)
		if len(jobInfos) != 0 {
			if err := json.Unmarshal([]byte(jobInfos), &jobsImportList); err != nil {
				logger.Error("json反序列化出错:%v", err)
			}
		}

		for i := range jobsImportList {
			flag := util.GetJobStatus(db, constants.PORTALNAME, jobsImportList[i].Code, util.ServerCode)
			if !flag {
				key := vo.JobKeyInfo{
					NameSpace: constants.PORTALNAME,
					Code:      jobsImportList[i].Code,
					SKNode:    util.ServerCode,
				}
				StopJob(&key)
			}
			// 1. 删除原来的任务，通过namespace和s_node
			deleteJobQuery := `DELETE FROM ioit.job_info WHERE namespace = $1 AND code = $2`

			logger.Info("deleteJobQuery:%v", deleteJobQuery)
			_, err = db.Exec(deleteJobQuery, constants.PORTALNAME, jobsImportList[i].Code)
			if err != nil {
				logger.Info("删除数据失败:%v", err)
			}
		}

		addsql := `INSERT INTO ioit.job_info (
			namespace,		create_user,		s_node,
			code,			name,				describe,
			schedule,		schedule_details,	schedule_cycle,
			schedule_unit,	content,			cron_id,
			is_http,		canvas,				job_type,
			template,		id,					status,
			create_time,	edite_time,			is_auto_select_id, 
			job_class,      cron_detail,        period_detail)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24)`

		for _, v := range jobsImportList {

			v.EditeTime = time.Now().Format("2006-01-02 15:04:05")
			v.Status = constants.ReadyJob
			v.SKNode = util.ServerCode
			v.Status = constants.ReadyJob

			content, errs := json.Marshal(v.Content)
			if errs != nil {
				fmt.Println("json marshal error:", errs)
			}

			canvas, errs := json.Marshal(v.Canvas)
			if errs != nil {
				fmt.Println("json marshal error:", errs)
			}

			cron, errs := json.Marshal(v.CronDetail)
			if errs != nil {
				fmt.Println("json marshal error:", errs)
			}

			period, errs := json.Marshal(v.PeriodDetail)
			if errs != nil {
				fmt.Println("json marshal error:", errs)
			}

			if v.JobClass == "" {
				v.JobClass = "cate_rootroot"
			}

			if v.JobType == "" {
				v.JobType = "timing"
			}

			if v.JobType == "timing" {
				v.IsHttp = false
			}

			_, err = db.Exec(addsql,
				constants.PORTALNAME, v.CreateUse, util.ServerCode, v.Code, v.Name,
				v.Describe, v.Schedule, v.ScheduleDetails, v.ScheduleCycle,
				v.ScheduleUnit, content, v.CronId, v.IsHttp, canvas, v.JobType,
				v.Template, v.Id, v.Status, v.CreateTime, v.EditeTime,
				false, v.JobClass, cron, period,
			)

			if err != nil {
				logger.Info("数据库操作失败：%v", err)
			}
		}
		// tempMainFile = /usr/local/hsm-os/data/hsm-io-it/data/temp/namespace/
		databaseConfigFileTemp := tempMainFile + constants.DataBaseConfig
		dbFlag := util.PathExists(databaseConfigFileTemp)
		if dbFlag {
			var databaseInfoList []vo.DatabaseInfoRequest
			databaseInfo := util.ReadFile(databaseConfigFileTemp + constants.Hierarchy + "database.json")
			if len(databaseInfo) != 0 {
				if err := json.Unmarshal([]byte(databaseInfo), &databaseInfoList); err != nil {
					logger.Error("json反序列化出错")
				}
			}

			for i := range databaseInfoList {
				// 2. 删除原来的数据连接信息,通过namespace
				deleteDBQuery := `DELETE FROM ioit.database_info WHERE namespace = $1 AND code = $2`

				_, err = db.Exec(deleteDBQuery, constants.PORTALNAME, databaseInfoList[i].Code)
				if err != nil {
					logger.Info("删除数据失败:%v", err)
				}
			}

			updatedbsql := `INSERT INTO ioit.database_info (code, connectname, username, password, host,
							port, namespace, databasetype, dbname, schemaname, tablename, dbpath, s_node,retry)
							VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)`

			for _, v := range databaseInfoList {
				_, err = db.Exec(updatedbsql,
					v.Code, v.ConnectName, v.Username, v.Password, v.Host, v.Port, constants.PORTALNAME,
					v.DataBaseType, v.DbName, v.SchemaName, v.Tablename, v.DbPath, "publish", v.Retry)
				if err != nil {
					logger.Info("数据库操作失败：%v", err)
				}
			}
		}
	}
	// 4. 文件上传
	tempUploadFile := tempMainFile + namespace + constants.Hierarchy + constants.UpLoad
	logger.Info("tempUploadFile:%v", tempUploadFile)
	namespaceUploadPath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Project + constants.PORTALNAME + constants.Hierarchy + "upload"

	flag := util.PathExists(tempUploadFile)
	if flag {
		flag1 := util.PathExists(namespaceUploadPath)
		if flag1 {
			util.CreateDir(namespaceUploadPath)
		}
		// 如果存在，则复制子文件中的内容到项目指定目录下
		util.CopyFilesToFolder(tempUploadFile, namespaceUploadPath)
	}
	logger.Info("文件上传成功")
	dataUpdateStatus = 100
	util.ClearFolder(destinationDir)

	dataPublish_version = arr_version[len(arr_version)-1]
	logger.Info("update ************ arr_version,%v", arr_version)
	logger.Info("版本更新完成********************")
	return true, ""
}

func GetDataUpdateStatus() (int, string) {
	return dataUpdateStatus, dataPublish_version
}

func PublishedRange(namespace string, getDataPublishCompileRequest *vo.GetDataPublishCompileRequest) (bool, string) {

	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
		return false, "数据库连接失败"
	}
	defer db.Close()

	if len(eng_verison) != 0 && eng_verison[len(eng_verison)-1] != namespace {
		returnDataRange = returnDataRange[:0]
	}

	serverRange := getDataPublishCompileRequest.ServerRange
	for i, v := range serverRange {
		if v.AppId == "hsm-io-it" {
			returnDataRange = append(returnDataRange, serverRange[i].DataRange...)
		}
	}

	returnDataRange = util.RemoveSpace(returnDataRange)

	for _, v := range returnDataRange {
		// 根据namespace，code修改发布结果
		query := `UPDATE ioit.job_info SET is_auto_select_id = $1 WHERE namespace = $2 AND code = $3`
		_, err := db.Exec(query, false, namespace, v)
		if err != nil {
			logger.Info("数据库更新失败:%v", err)
		}
	}
	return true, "发布成功"
}

func RollBack(namespace string) (bool, string, string) {

	bak_version := arr_version[len(arr_version)-2]

	lenIndex, _ := GetLenIndex()
	logger.Info("index is :%v", lenIndex)
	if lenIndex != 1 {
		if util.ServerCode == "e1" {
			arr_version = arr_version[:len(arr_version)-1]
			dataPublish_version = arr_version[len(arr_version)-1]
			return true, "s1进行", dataPublish_version
		}
	}

	go BackRollUp(bak_version)

	arr_version = arr_version[:len(arr_version)-1]
	dataPublish_version = arr_version[len(arr_version)-1]
	logger.Info("rollback ************ arr_version,%v", arr_version)
	return true, "数据回滚成功", dataPublish_version
}

func BackRollUp(bak_version string) {
	db, err := util.GetPgConn()
	if err != nil {
		logger.Info("数据库连接失败")
	}
	defer db.Close()

	fileNameSlice, _ := ioutil.ReadDir(constants.BackPath)
	var backupFileName string
	for _, v := range fileNameSlice {
		if strings.Contains(v.Name(), bak_version) {
			backupFileName = v.Name()
		}
	}

	destinationDir := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp
	cmd := exec.Command("tar", "-xzf", constants.BackPath+backupFileName, "-C", destinationDir)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr

	err = cmd.Run()
	if err != nil {
		logger.Info("解压失败 err is :%v", err)
		// return false, "解压失败", bak_version
	}

	res := util.GetNodeServer()
	s_node := res[1]
	// 解压的目录: /usr/local/hsm-os/data/hsm-io_it/data/temp/hsm-io-it/hsm-io-it.json
	// 将运行中的作业停止
	jobkey := util.FindStautsAndStop()
	for i := range jobkey {
		StopJob(&jobkey[i])
	}
	// 1. 删除原来的任务，通过namespace和s_node
	deleteJobQuery := `DELETE FROM ioit.job_info WHERE namespace = $1 AND is_auto_select_id = $2`

	_, err = db.Exec(deleteJobQuery, constants.PORTALNAME, false)
	if err != nil {
		logger.Info("删除数据失败:%v", err)
	}

	// 2. 删除原来的数据连接信息,通过namespace
	deleteDBQuery := `DELETE FROM ioit.database_info WHERE namespace = $1 AND s_node = $2`

	_, err = db.Exec(deleteDBQuery, constants.PORTALNAME, "publish")
	if err != nil {
		logger.Info("删除数据失败:%v", err)
	}
	// 3. 插入新的任务
	var jobsImportList []vo.CreateJobRequest
	// 解压的目录: /usr/local/hsm-os/data/hsm-io_it/data/temp/hsm-io-it/hsm-io-it.json
	jobInfos := util.ReadFile(destinationDir + constants.PORTALNAME + constants.Hierarchy + constants.PORTALNAME + constants.Suffix)
	if len(jobInfos) != 0 {
		if err := json.Unmarshal([]byte(jobInfos), &jobsImportList); err != nil {
			logger.Error("json反序列化出错:%v", err)
		}
	}

	addsql := `INSERT INTO ioit.job_info (
		namespace,		create_user,		s_node,
		code,			name,				describe,
		schedule,		schedule_details,	schedule_cycle,
		schedule_unit,	content,			cron_id,
		is_http,		canvas,				job_type,
		template,		id,					status,
		create_time,	edite_time,			is_auto_select_id, 
		job_class,      cron_detail,        period_detail)
	VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24)`

	for _, v := range jobsImportList {

		v.EditeTime = time.Now().Format("2006-01-02 15:04:05")
		v.Status = constants.ReadyJob
		v.SKNode = s_node

		content, errs := json.Marshal(v.Content)
		if errs != nil {
			fmt.Println("json marshal error:", errs)
		}

		canvas, errs := json.Marshal(v.Canvas)
		if errs != nil {
			fmt.Println("json marshal error:", errs)
		}

		cron, errs := json.Marshal(v.CronDetail)
		if errs != nil {
			fmt.Println("json marshal error:", errs)
		}

		period, errs := json.Marshal(v.PeriodDetail)
		if errs != nil {
			fmt.Println("json marshal error:", errs)
		}

		_, err = db.Exec(addsql,
			constants.PORTALNAME, v.CreateUse, util.ServerCode, v.Code, v.Name,
			v.Describe, v.Schedule, v.ScheduleDetails, v.ScheduleCycle,
			v.ScheduleUnit, content, v.CronId, v.IsHttp, canvas, v.JobType,
			v.Template, v.Id, v.Status, v.CreateTime, v.EditeTime,
			v.IsAutoSelectId, v.JobClass, cron, period,
		)

		if err != nil {
			logger.Info("数据库操作失败：%v", err)
		}
	}
	// tempMainFile = /usr/local/hsm-os/data/hsm-io-it/data/temp/namespace/
	databaseConfigFileTemp := destinationDir + constants.PORTALNAME + constants.Hierarchy + constants.PORTALNAME + constants.Hierarchy + constants.DataBaseConfig
	dbFlag := util.PathExists(databaseConfigFileTemp)
	if dbFlag {
		var databaseInfoList []vo.DatabaseInfoRequest
		databaseInfo := util.ReadFile(databaseConfigFileTemp + constants.Hierarchy + "database.json")
		if len(databaseInfo) != 0 {
			if err := json.Unmarshal([]byte(databaseInfo), &databaseInfoList); err != nil {
				logger.Error("json反序列化出错")
			}
		}

		updatedbsql := `INSERT INTO ioit.database_info (code, connectname, username, password, host, 
						port, namespace, databasetype, dbname, schemaname, tablename, dbpath, s_node,retry)
						VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)`

		for _, v := range databaseInfoList {
			_, err = db.Exec(updatedbsql,
				v.Code, v.ConnectName, v.Username, v.Password, v.Host, v.Port, constants.PORTALNAME,
				v.DataBaseType, v.DbName, v.SchemaName, v.Tablename, v.DbPath, "publish", v.Retry)
			if err != nil {
				logger.Info("数据库操作失败：%v", err)
			}
		}
	}
	// 4. 文件上传
	// 上传文件
	tempUploadFile := destinationDir + constants.PORTALNAME + constants.Hierarchy + constants.PORTALNAME + constants.Hierarchy + constants.UpLoad
	namespaceUploadPath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Project + constants.PORTALNAME + constants.Hierarchy + "upload"
	flag := util.PathExists(tempUploadFile)
	if flag {
		if !util.PathExists(namespaceUploadPath) {
			util.CreateDir(namespaceUploadPath)
		}
		// 如果存在，则复制子文件中的内容到项目指定目录下
		util.CopyFilesToFolder(tempUploadFile, namespaceUploadPath)
	}
	logger.Info("修改运行态数据成功")
	logger.Info("清空发布完成**************")

	os.RemoveAll(constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.Temp + constants.PORTALNAME)
}
