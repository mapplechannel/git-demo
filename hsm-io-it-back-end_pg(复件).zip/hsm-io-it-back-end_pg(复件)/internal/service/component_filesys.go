package service

import (
	"hsm-io-it-back-end/config"
	"hsm-io-it-back-end/internal/constants"
	"hsm-io-it-back-end/internal/util"
	"hsm-io-it-back-end/internal/vo"
	"hsm-io-it-back-end/pkg/logger"
	"mime/multipart"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
)

func FileUpload(c *gin.Context, file *multipart.FileHeader, namespace string) (string, string, bool) {
	src, err := file.Open()
	if err != nil {
		return constants.EmptyContent, "识别编码格式失败", false
	}
	defer src.Close()

	size := file.Size

	buffer := make([]byte, size)

	n, _ := src.Read(buffer)

	if !util.ISSSUTF8(buffer[:n]) {
		return constants.EmptyContent, "文件不是UTF-8编码", false
	}

	filename := filepath.Base(file.Filename)

	if len(filename) > 60 {
		return constants.EmptyContent, "文件导入错误：文件名长度超过60", false
	}

	logger.Info("上传的文件名字为：%v", filename)

	ext := filepath.Ext(filename)

	logger.Info("上传的文件扩展名字为：%v", ext)

	flag := util.JudgeExt(ext)

	if !flag {
		return constants.EmptyContent, "只支持CSV、TXT、JSON、XML格式文件", false
	}

	if ext == constants.XmlIdentifier || ext == constants.JsonIdentifier {
		if size > 1048576 {
			return constants.EmptyContent, "文件导入错误：大小超过1M", false
		}
	}

	if ext == constants.TxtIdentifier || ext == constants.CsvIdentifier {
		if size > 10*1048576 {
			return constants.EmptyContent, "文件导入错误：大小超过10M", false
		}
	}

	var projectFolderPath = constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + config.ConfigAll.FILE.Project + namespace + constants.Hierarchy + "upload" + constants.Hierarchy
	util.CreateDir(projectFolderPath)
	// var ComponentPath = projectFolderPath + constants.DataBaseInfo + constants.Suffix

	dst := filepath.Join(projectFolderPath, filename)

	sec := time.Now().Unix()

	if _, err := os.Stat(dst); err == nil {
		filename = strings.TrimSuffix(filename, ext) + constants.Underline + strconv.FormatInt(sec, 10) + ext
		dst = filepath.Join(projectFolderPath, filename)
	}

	err = c.SaveUploadedFile(file, dst)
	if err != nil {
		return constants.EmptyContent, "保存文件失败", false
	} else {
		return dst, "上传文件成功", true
	}
}

func SftpConnection(c *gin.Context) (string, bool) {
	err := c.ShouldBindJSON(&SftpInfo)
	if err != nil {
		return "数据验证错误", false
	}
	ip := SftpInfo.Host

	retry, _ := strconv.Atoi(SftpInfo.Retry)
	sshClient, err := NewSshClient(SftpInfo)
	if sshClient == nil {

		for i := retry; i > 0; i-- {

			println(i)

			sshClient, err = NewSshClient(SftpInfo)
			if sshClient != nil {
				break
			}
		}

		if err != nil {
			return "连接文件服务" + ip + "错误", false
		}
	}

	defer CloseClient(sshClient, nil)

	sftpClient, err := NewSftpClient(sshClient)
	if err != nil {
		return "连接文件服务" + ip + "错误", false
	}
	defer CloseClient(nil, sftpClient)
	return "服务器连接成功", true
}

func GetSftpFile(sftpPath *vo.SftpPath) (string, []FileInfo, bool) {
	ip := SftpInfo.Host
	sshClient, err := NewSshClient(SftpInfo)
	if err != nil {
		return "连接文件服务" + ip + "错误", nil, false
	}
	defer CloseClient(sshClient, nil)

	sftpClient, err := NewSftpClient(sshClient)
	if err != nil {
		return "连接文件服务" + ip + "错误", nil, false
	}
	defer CloseClient(nil, sftpClient)
	files, err := sftpClient.ReadDir(sftpPath.Path)
	if err != nil {
		return "获取文件信息失败", nil, false

	}

	result := GetCatalog(files, *sftpPath)

	if len(result) == 0 {
		return "当前文件目录内容为空", nil, false
	} else {
		return "文件信息获取成功", result, true
	}
}

func SftpReadFile(csvTxtInfo *vo.CsvTxtInfo) (string, bool, interface{}) {
	filename := filepath.Base(csvTxtInfo.Path)
	ext := filepath.Ext(filename)

	flag := util.JudgeExt(ext)
	if !flag {
		return "只支持CSV、TXT、JSON、XML格式文件", false, nil
	}

	ip := SftpInfo.Host

	sshClient, err := NewSshClient(SftpInfo)
	if err != nil {
		return "连接文件服务" + ip + "错误", false, nil
	}
	defer CloseClient(sshClient, nil)

	sftpClient, err := NewSftpClient(sshClient)
	if err != nil {
		return "连接文件服务" + ip + "错误", false, nil
	}
	defer CloseClient(nil, sftpClient)

	fileInfo, err := sftpClient.Stat(csvTxtInfo.Path)

	if err != nil {
		return "文件不存在", false, nil
	}

	filesize := fileInfo.Size()

	if filesize > 1024*1024*10 {
		return "文件超过10M，无法读取", false, nil
	}

	file, _ := sftpClient.Open(csvTxtInfo.Path)

	buf := make([]byte, filesize)
	n, _ := file.Read(buf)
	if !util.ISSSUTF8(buf[:n]) {
		return "文件不是UTF-8编码", false, nil
	}
	defer file.Close()

	file.Seek(0, 0)

	println(csvTxtInfo.Path)

	if ext == constants.CsvIdentifier {
		csvData, err := ReadSftpCSV(file)
		if err != nil || csvData.Cols == nil {
			return "文件内容不合法", false, nil
		}
		return "文件读取成功", true, csvData
	} else if ext == constants.TxtIdentifier {
		txtData, err := ReadSftpTxt(file)
		if err != nil || txtData == constants.EmptyContent {
			return "文件内容不合法", false, nil
		}
		return "文件读取成功", true, txtData
	} else if ext == constants.XmlIdentifier {
		xmlData, err := ReadSftpXml(file)
		if err != nil || xmlData == constants.EmptyContent {
			return "文件内容不合法", false, nil
		}
		return "文件读取成功", true, xmlData
	} else if ext == constants.JsonIdentifier {
		jsonData, err := ReadSftpJson(file)
		if err != nil || jsonData == nil {
			return "文件内容不合法", false, nil
		}
		return "文件读取成功", true, jsonData
	} else {
		return "文件类型判断错误", false, nil
	}

}

func GetLoadData(csvTxtInfo *vo.CsvTxtInfo) (string, bool, interface{}) {
	filename := filepath.Base(csvTxtInfo.Path)
	ext := filepath.Ext(filename)
	flag := util.JudgeExt(ext)
	if !flag {
		return "只支持CSV、TXT、JSON、XML格式文件", false, nil
	}

	if ext == constants.CsvIdentifier {
		csvData, err := ReadCSV(csvTxtInfo)
		if err != nil {
			if os.IsNotExist(err) {
				return "文件不存在", false, nil
			} else {
				return "文件内容不合法", false, nil
			}
		} else {
			return "文件读取成功", true, csvData
		}
	} else if ext == constants.TxtIdentifier {
		txtData, err := ReadTxt(csvTxtInfo)
		if err != nil {
			if os.IsNotExist(err) {
				return "文件不存在", false, nil
			}
		} else {
			if txtData == constants.EmptyContent {
				return "文件内容为空", false, nil
			} else {
				return "文件读取成功", true, txtData
			}
		}
	} else if ext == constants.JsonIdentifier {
		jsonData, err := ReadJson(csvTxtInfo)
		if err != nil {
			if os.IsNotExist(err) {
				return "文件不存在", false, nil
			} else {
				return "文件内容不合法", false, nil
			}
		} else {
			return "文件读取成功", true, jsonData
		}
	} else if ext == constants.XmlIdentifier {
		xmlData, err := ReadXml(csvTxtInfo)
		if err != nil {
			if os.IsNotExist(err) {
				return "文件不存在", false, nil
			} else {
				return "文件内容不合法", false, nil
			}
		} else {
			if xmlData == constants.EmptyContent {
				return "文件内容为空", false, nil
			} else {
				return "文件读取成功", true, xmlData
			}
		}
	}
	return "文件类型判断错误", false, nil
}
