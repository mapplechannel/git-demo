package sap

import (
	"encoding/json"
	"fmt"
	"hsm-io-it-back-end/config"
	"hsm-io-it-back-end/internal/constants"
	"hsm-io-it-back-end/internal/util"
	"hsm-io-it-back-end/internal/vo"
	"hsm-io-it-back-end/pkg/logger"

	"github.com/google/uuid"
)

// 实时作业模板
type TemplateItem struct {
	Label string `json:"label"`
	Type  string `json:"type"`
	Value string `json:"value"`
}

type Template struct {
	Suffix   string         `json:"suffix"`
	Template []TemplateItem `json:"template"`
}

func ResloveParten(templateName string) vo.NParten {
	partenPath := constants.HSM_OS_ROOT+config.ConfigAll.FILE.Path  + constants.ProjectTemplate + constants.ProjectSAPMESTemplate + templateName + constants.Suffix
	// partenPath := "bin/template/SAP_MES-Parten/SAP_MES_MATERIAL.json"
	fileData := util.ReadFile(partenPath)
	var data vo.NParten
	if err := json.Unmarshal([]byte(fileData), &data); err != nil {
		fmt.Println(err)
	}

	// 替换node节点
	for i := range data.NodeIDMap {
		uuid := uuid.New().String()
		data.NodeIDMap[i] = uuid
	}

	logger.Info("data.NodeIDMap:%v", data.NodeIDMap)
	lineList := data.LineList
	// 替换lineList结构
	for i := range lineList {
		lineList[i].ID = data.NodeIDMap[lineList[i].ID]
		lineList[i].Source.Cell = data.NodeIDMap[lineList[i].Source.Cell]
		lineList[i].Source.Port = data.NodeIDMap[lineList[i].Source.Port]
		lineList[i].Target.Cell = data.NodeIDMap[lineList[i].Target.Cell]
		lineList[i].Target.Port = data.NodeIDMap[lineList[i].Target.Port]
	}

	// 替换NodeList结构
	for i := range data.NodeList {
		data.NodeList[i].Id = data.NodeIDMap[data.NodeList[i].Id]
		ports := data.NodeList[i].Ports
		for i := range ports {
			ports[i].Id = data.NodeIDMap[ports[i].Id]
		}
	}

	// 替换新的UUIDS结构
	// var newPatren vo.NParten
	// newPatren.JobConfig = data.JobConfig
	// newPatren.NodeIDMap = data.NodeIDMap
	// newPatren.NodeList = data.NodeList
	// newLineData := make([]vo.NLineData, len(lineList))
	// for i := range lineList {
	// newLineData[i].Anchors = lineList[i].Anchors
	// newLineData[i].Target = lineList[i].Target
	// newLineData[i].Connector = lineList[i].Connector
	// newLineData[i].Source = lineList[i].Source
	// var mergedUUIDs []string
	// for _, uuidSlice := range lineList[i].UUIDs {
	// 	logger.Info("uuidSlice:%v", uuidSlice)
	// 	mergedUUIDs = append(mergedUUIDs, uuidSlice[0])
	// }

	// newLineData[i].UUIDs = mergedUUIDs
	// }
	// newPatren.LineList = newLineData

	return data
}

func GetTemplateInfo() []TemplateItem {
	partenPath := constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + constants.ProjectTemplate + constants.ProjectSAPMESTemplate + constants.Manifest + constants.JsonIdentifier

	fileData := util.ReadFile(partenPath)

	var template Template

	if err := json.Unmarshal([]byte(fileData), &template); err != nil {
		fmt.Println(err)
	}

	// logger.Info("模板信息为:%v", template)

	res := template.Template

	return res
}
