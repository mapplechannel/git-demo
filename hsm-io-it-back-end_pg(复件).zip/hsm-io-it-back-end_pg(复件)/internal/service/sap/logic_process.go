package sap

import (
	"bytes"
	"database/sql"
	"encoding/json"
	"fmt"
	"hsm-io-it-back-end/config"
	"hsm-io-it-back-end/internal/constants"
	"hsm-io-it-back-end/internal/util"
	"hsm-io-it-back-end/pkg/logger"
	"io/ioutil"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"github.com/clbanning/mxj/v2"
	_ "github.com/go-sql-driver/mysql"
)

type Configuration struct {
	StartProcess string          `json:"start_process"`
	Process      map[string]Flow `json:"process"`
}

type Flow struct {
	Interface     string            `json:"interface"`
	ArgMap        map[string]string `json:"arg_map"`
	PostCondition []Postcondition   `json:"postcondition,omitempty"`
	SendBody      bool              `json:"send_body,omitempty"`
	BodyType      string            `json:"body_type,omitempty"`
	PreCondition  []Precondition    `json:"precondition,omitempty"`
}

type Postcondition struct {
	Path   string   `json:"path"`
	Result bool     `json:"result"`
	Branch []string `json:"branch"`
}

type Precondition struct {
	Path   string      `json:"path"`
	Result interface{} `json:"result"`
}

type APIDetails struct {
	URL      string            `json:"url"`
	Type     string            `json:"type"`
	BodyArgs map[string]string `json:"body_arg,omitempty"`
	QueryArg map[string]string `json:"query_arg,omitempty"`
	GQL      GQLDatasource     `json:"gql,omitempty"`
}

type GQLDatasource struct {
	OperationName string                 `json:"operationName"`
	Query         string                 `json:"query"`
	Variables     map[string]interface{} `json:"variables"`
	ResultKey     string                 `json:"result_key"`
}

// 启动goroutine
func ObjectOrList(requestBody map[string]interface{}) {
	var processBody map[string]interface{}

	if val, ok := requestBody["process_map"].(map[string]interface{}); ok {
		processBody = val
	}

	config := ResolveAPIconfig(processBody)
	startProcess := config.StartProcess
	if config.Process[startProcess].BodyType != "" {
		ResolveProcess(requestBody)
		return
	}

	logger.Info("requestBody%v", requestBody)
	if val, ok := requestBody["data"].([]interface{}); ok {
		for _, v := range val {
			if SingleRequestBody, ok := v.(map[string]interface{}); ok {
				newRequestMap := make(map[string]interface{})
				newRequestMap["data"] = SingleRequestBody
				newRequestMap["process_map"] = processBody
				logger.Info("新的请求体为:%v", newRequestMap)
				ResolveProcess(newRequestMap)
			}
		}
	} else {
		if val, ok := requestBody["data"].(map[string]interface{}); ok {
			logger.Info("请求体是一个对象:%v", val)
			ResolveProcess(requestBody)
		}
	}
}

// 根据模板处理流程
func ResolveProcess(requestBody map[string]interface{}) bool {
	// 请求体拆分
	dataBody, processBody := SplitRequestBody(requestBody)

	// process绑定
	config := ResolveAPIconfig(processBody)

	// 开始流程
	startProcess := config.StartProcess
	logger.Info("startProcess:%v", startProcess)
	// 前置条件为空
	isSatisfiedPre := isSatisfiedPrecondition(config, startProcess, dataBody)
	if isSatisfiedPre {
		if config.Process[startProcess].BodyType != "" {
			logger.Info("config.Process[startProcess].BodyType:%v", config.Process[startProcess].BodyType)
			DealToMap(config, requestBody, startProcess)
		} else {
			if config.Process[startProcess].SendBody {
				logger.Info("config.Process[startProcess].SendBody:%v", config.Process[startProcess].SendBody)
				DealAllBody(config, requestBody, startProcess)
			} else {
				// 获取开始接口
				startInter := config.Process[startProcess]
				var isRepeat bool
				if len(startInter.Interface) >= 4 && startInter.Interface[len(startInter.Interface)-4:] == "_GQL" {
					SendGQL(config, &startInter, dataBody)
				} else {
					_, isRepeat = DealStart(config, &startInter, dataBody)
				}
				// 获取后置条件
				postConditionSlice := startInter.PostCondition
				logger.Info("postConditionSlice:%v", postConditionSlice)
				for i := range postConditionSlice {
					if isRepeat == postConditionSlice[i].Result {
						// 获取分支名称
						branch := postConditionSlice[i].Branch
						logger.Info("branch:%v", branch)
						for i := range branch {
							// 获取分支前置条件
							isSatisPre := isSatisfiedPrecondition(config, branch[i], dataBody)
							logger.Info("isSatisPre:%v", isSatisPre)
							if config.Process[branch[i]].BodyType != "" {
								DealToMap(config, requestBody, startProcess)
							} else {
								if isSatisPre {
									if config.Process[branch[i]].SendBody {
										// 传入所有参数
										DealAllBody(config, requestBody, branch[i])
									} else {
										// 获取参数
										partRequestMap := make(map[string]interface{}, 0)
										for _, v := range config.Process[branch[i]].ArgMap {
											flag, sVal := GetStringFieldOrDefault(dataBody, v)
											if flag {
												partRequestMap[v] = sVal
											}
										}
										logger.Info("searchRequestMap:%v", partRequestMap)

										DealPartBody(config, partRequestMap, branch[i])
									}
								}
							}
						}
					}
				}
			}
		}
	}
	return true
}

func isSatisfiedPrecondition(config *Configuration, flowName string, dataBody map[string]interface{}) bool {
	preCondition := config.Process[flowName].PreCondition
	for i := range preCondition {
		_, condition := GetStringFieldOrDefault(dataBody, preCondition[i].Path)
		res := fmt.Sprintf("%v", preCondition[i].Result)
		if condition != res {
			logger.Info("condition:%v", condition)
			logger.Info("res:%v", res)
			return false
		}
	}
	return true
}

func DealStart(config *Configuration, searchInter *Flow, dataBody map[string]interface{}) ([]byte, bool) {

	logger.Info("************处理开始接口************")
	argMap := searchInter.ArgMap

	// 获取查重请求体
	searchRequestMap := make(map[string]interface{}, 0)
	for _, v := range argMap {
		flag, sVal := GetStringFieldOrDefault(dataBody, v)
		if flag {
			searchRequestMap[v] = sVal
		}
	}

	logger.Info("searchRequestMap:%v", searchRequestMap)

	// 执行查重*************************************
	searchRequestBody, err := json.Marshal(searchRequestMap)
	if err != nil {
		logger.Info("Error marshalling JSON:%v", err)
	}

	// url获取
	interfaceName := searchInter.Interface

	searchUrl := GetAPIURL(interfaceName)

	// 发送 POST 请求，执行查重接口
	searchResp, err := http.Post(searchUrl, "application/json", bytes.NewBuffer(searchRequestBody))
	if err != nil {
		logger.Info("Error sending request:%v", err)
	}
	defer searchResp.Body.Close()

	// 读取响应体
	body, err := ioutil.ReadAll(searchResp.Body)
	if err != nil {
		logger.Info("Error reading response body:%v", err)
	}

	// 解析响应体
	var result map[string]interface{}
	err = json.Unmarshal(body, &result)
	if err != nil {
		logger.Info("Error parsing response body:%v", err)
	}
	// 解析查重结果
	var isRepeat bool

	if val, ok := result["data"]; ok {
		if data, ok := val.(bool); ok {
			isRepeat = data
		} else {
			logger.Info("Data字段类型不是bool")
		}
	} else {
		logger.Info("Data字段不存在")
	}

	logger.Info("执行后的查重结果为:%v", isRepeat)

	return searchRequestBody, isRepeat
}

func DealToMap(config *Configuration, requestBody map[string]interface{}, flowName string) {
	logger.Info("************处理xml************")
	notRepeatInter := config.Process[flowName]
	interfaceName := notRepeatInter.Interface
	notRepeatUrl := GetAPIURL(interfaceName)

	var buf string
	// 获取addURL
	if val, ok := requestBody["data"].([]interface{}); ok {
		for _, v := range val {
			if SingleRequestBody, ok := v.(map[string]interface{}); ok {
				body := ResolveXml(SingleRequestBody)
				buf += string(body)
			}
		}
	} else {
		if val, ok := requestBody["data"].(map[string]interface{}); ok {
			body := ResolveXml(val)
			buf += string(body)
		}
	}

	request := []byte(buf)

	logger.Info("merged:%v", buf)
	respAdd, err := http.Post(notRepeatUrl, "text/plain", bytes.NewBuffer(request))
	if err != nil {
		logger.Info("Error sending request:%v", err)
	}
	defer respAdd.Body.Close()
	// 不重复流程,执行添加接口
	logger.Info("************处理xml结束************")
}

func DealPartBody(config *Configuration, requestBody map[string]interface{}, flowName string) {
	logger.Info("************处理部分请求体接口************")
	// 获取addURL
	notRepeatInter := config.Process[flowName]
	interfaceName := notRepeatInter.Interface
	notRepeatUrl := GetAPIURL(interfaceName)
	// 不重复流程,执行添加接口
	notRepeatRequestBody, err := json.Marshal(requestBody)
	if err != nil {
		logger.Info("Error marshalling JSON:%v", err)
	}

	respAdd, err := http.Post(notRepeatUrl, "application/json", bytes.NewBuffer(notRepeatRequestBody))
	if err != nil {
		logger.Info("Error sending request:%v", err)
	}
	defer respAdd.Body.Close()

	logger.Info("************处理部分请求体接口结束************")
}

func DealAllBody(config *Configuration, requestBody map[string]interface{}, flowName string) {
	logger.Info("************处理全部请求体接口************")
	// 获取addURL
	repeatInter := config.Process[flowName]
	interfaceName := repeatInter.Interface
	repeatUrl := GetAPIURL(interfaceName)
	// 重复流程,执行其他接口
	repeatRequestBody, err := json.Marshal(requestBody)
	if err != nil {
		logger.Info("Error marshalling JSON:%v", err)
	}

	respAdd, err := http.Post(repeatUrl, "application/json", bytes.NewBuffer(repeatRequestBody))
	if err != nil {
		logger.Info("Error sending request:%v", err)
	}
	defer respAdd.Body.Close()

	logger.Info("************处理全部请求体接口结束************")
}

func SearchRepeatData(requestBody map[string]interface{}, dataType string) bool {
	logger.Info("*************执行查重************")
	logger.Info("查重的requestBody:%v", requestBody)

	var conditions []string

	for k, v := range requestBody {
		if k == "plant" {
			intV, err := strconv.Atoi(v.(string))
			if err != nil {
				logger.Info("int类型转换错误:%v", err)
			}
			v = intV
		}
		if k == "plnkn" {
			intV, err := strconv.Atoi(v.(string))
			if err != nil {
				logger.Info("int类型转换错误:%v", err)
			}
			v = intV
		}
		condition := fmt.Sprintf("%s = '%v'", k, v)
		conditions = append(conditions, condition)
	}

	conditionStr := strings.Join(conditions, " AND ")

	var tableName string

	switch dataType {
	case "material":
		tableName = "mes_mat_md"
	case "pbom":
		tableName = "mes_pbom"
	case "order":
		tableName = "mes_order_sap"
	case "process":
		tableName = "mes_processes_product_sap"
	case "porder":
		tableName = "mes_production_order_sap"
	case "flow":
		tableName = "mes_processes"
	default:
		logger.Info("没有匹配到指定数据库")
	}

	sql := fmt.Sprintf("SELECT COUNT(*) FROM %s WHERE %s", tableName, conditionStr)

	logger.Info("查重的sql语句为:%v", sql)

	// 连接数据库
	db, err := ConnectMySQL()
	if err != nil {
		logger.Info("数据库连接失败")
		return false
	}
	defer db.Close()

	var count int
	err = db.QueryRow(sql).Scan(&count)
	if err != nil {
		logger.Info("查重错误%v", err)
		return false
	}
	if count > 0 {
		return true
	} else {
		return false
	}
}

func AddData(requestBody map[string]interface{}, dataType string) bool {
	logger.Info("************执行添加************")
	var dataBody map[string]interface{}
	// 解析data数据
	if val, ok := requestBody["data"].(map[string]interface{}); ok {
		dataBody = val
	}

	logger.Info("数据类型为:%v", dataType)

	db, err := ConnectMySQL()
	if err != nil {
		logger.Info("数据库连接失败")
		return false
	}
	defer db.Close()

	var tableName string
	var fieldSlice []string
	var fieldIntSlice []string

	// 获取字段
	switch dataType {
	case "material":
		tableName = "mes_mat_md"
		fieldSlice = []string{"mat_code", "mat_type", "mat_desc", "mat_type_desc", "mat_group_code", "mat_group_name", "erp_unit", "standard", "model_number", "rounding_value"}
		fieldIntSlice = []string{"plant", "is_delete"}
		InsertTable(dataBody, fieldSlice, fieldIntSlice, tableName, dataType, db)
	case "sn":
		tableName = "mes_ordersn_details_sap"
		fieldSlice = []string{"order_no", "sn_no"}
		fieldIntSlice = []string{}
		InsertTable(dataBody, fieldSlice, fieldIntSlice, tableName, dataType, db)
	case "order":
		tableName = "mes_order_sap"
		fieldSlice = []string{"order_no", "cmd_time", "order_batch", "order_type", "mat_code", "order_num", "unit", "plan_starttime", "plan_endtime", "process_code", "pbom_code", "order_status"}
		fieldIntSlice = []string{"order_priority", "plant", "is_delete"}
		InsertTable(dataBody, fieldSlice, fieldIntSlice, tableName, dataType, db)
	case "flow":
		tableName = "mes_processes"
		fieldSlice = []string{"plnnr", "mat_code", "mat_des", "mat_details_code", "processes_des", "erp_update", "process_code"}
		fieldIntSlice = []string{"plant", "is_delete", "plnkn", "num", "erp_create_id", "erp_update_id"}
		InsertTable(dataBody, fieldSlice, fieldIntSlice, tableName, dataType, db)
	case "pbom":
		tableName = "mes_pbom"
		fieldSlice = []string{"mat_code", "mat_des", "pbom_version", "pbom_code", "standard", "mat_unit"}
		fieldIntSlice = []string{"plant", "is_delete"}
		InsertTable(dataBody, fieldSlice, fieldIntSlice, tableName, dataType, db)
		// subName = "pbom_details_models"
		// subTableName = "mes_pbom_details"
		// subFieldSlice = []string{"mat_code", "mat_des", "erp_code", "replace_group", "pbom_code", "standard", "mat_unit", "mat_num", "position_code", "merge_code"}
		// subFieldIntSlice = []string{"level", "is_delete"}
		SelectSubPbom(db, dataBody)
	case "process":
		tableName = "mes_processes_product_sap"
		fieldSlice = []string{"plnnr", "mat_code", "mat_des", "process_code", "process_des", "start_time", "end_time", "erp_update"}
		fieldIntSlice = []string{"plant", "is_delete", "erp_create_id", "erp_update_id"}
		InsertTable(dataBody, fieldSlice, fieldIntSlice, tableName, dataType, db)
		// subName = "erp_product_line_details_model"
		// subTableName = "mes_processes_product_sap_details"
		// subFieldSlice = []string{"plnnr", "mat_code", "mat_des", "mat_details_code", "processes_des", "labor_hour", "labor_hour_unit", "machine_hour", "machine_hour_unit", "labor_prepare_hour", "labor_prepare_hour_unit", "machine_prepare_hour", "machine_prepare_hour_unit", "erp_update", "start_time", "end_time", "process_code"}
		// subFieldIntSlice = []string{"plant", "is_delete", "erp_create_id", "erp_update_id", "plnkn", "num"}
		SelectSubProcess(db, dataBody)
	case "porder":
		tableName = "mes_production_order_sap"
		fieldSlice = []string{"order_no", "plan_num", "mat_code", "mat_des", "standard", "mat_unit"}
		fieldIntSlice = []string{"is_delete"}
		InsertTable(dataBody, fieldSlice, fieldIntSlice, tableName, dataType, db)
		// subName = "erp_production_order_details_model"
		// subTableName = "mes_production_order_sap_des"
		// subFieldSlice = []string{"order_no", "erp_code", "mat_desc_code", "mat_desc_name", "mat_num", "mat_unit", "standard", "process_code"}
		// subFieldIntSlice = []string{"is_delete"}
		SelectSubPorder(db, dataBody)
	default:
		logger.Info("没有匹配到字段")
	}

	return true
}

func DeleteData(requestBody map[string]interface{}, dataType string) bool {
	logger.Info("************执行删除************")

	var conditions []string

	for k, v := range requestBody {
		if k == "plant" {
			intV, err := strconv.Atoi(v.(string))
			if err != nil {
				logger.Info("int类型转换错误:%v", err)
			}
			v = intV
		}
		if k == "plnkn" {
			intV, err := strconv.Atoi(v.(string))
			if err != nil {
				logger.Info("int类型转换错误:%v", err)
			}
			v = intV
		}
		condition := fmt.Sprintf("%s = %v", k, v)
		conditions = append(conditions, condition)
	}

	conditionStr := strings.Join(conditions, " AND ")

	var tableName string

	switch dataType {
	case "material":
		tableName = "mes_mat_md"
	case "pbom":
		tableName = "mes_pbom"
	case "order":
		tableName = "mes_order_sap"
	case "process":
		tableName = "mes_processes_product_sap"
	case "porder":
		tableName = "mes_production_order_sap"
	case "flow":
		tableName = "mes_processes"
	default:
		logger.Info("没有匹配到指定数据库")
	}

	sql := fmt.Sprintf("UPDATE %s SET is_delete=1 WHERE %s", tableName, conditionStr)

	logger.Info("删除的sql语句为:%v", sql)

	// 连接数据库
	db, err := ConnectMySQL()
	if err != nil {
		logger.Info("数据库连接失败")
		return false
	}
	defer db.Close()

	_, err = db.Exec(sql)
	if err != nil {
		return false
	} else {
		return true
	}
}

func EditData(requestBody map[string]interface{}, dataType string) bool {
	logger.Info("************执行更新************")
	var tableName string
	var dataBody map[string]interface{}

	// 解析data数据
	if val, ok := requestBody["data"].(map[string]interface{}); ok {
		dataBody = val
	}

	logger.Info("数据类型为:%v", dataType)

	db, err := ConnectMySQL()
	if err != nil {
		logger.Info("数据库连接失败")
		return false
	}
	defer db.Close()

	// 获取字段
	switch dataType {
	case "material":
		tableName = "mes_mat_md"

		var rowMesPbom []string
		var valMesPbom []interface{}

		fieldSlice := []string{"mat_code", "mat_type", "mat_desc", "mat_type_desc", "mat_group_code", "mat_group_name", "erp_unit", "standard", "model_number", "rounding_value"}

		for i := range fieldSlice {
			rowMesPbom, valMesPbom = MappingHelper(dataBody, rowMesPbom, valMesPbom, fieldSlice[i])
		}

		fieldIntSlice := []string{"plant", "is_delete"}
		for i := range fieldIntSlice {
			rowMesPbom, valMesPbom = MappingIntHelper(dataBody, rowMesPbom, valMesPbom, fieldIntSlice[i])
		}

		var indexMatCode int
		var indexPlant int

		for i := range rowMesPbom {
			if rowMesPbom[i] == "mat_code" {
				indexMatCode = i
			}
			if rowMesPbom[i] == "plant" {
				indexPlant = i
			}
		}

		var setParams []string
		var setValues []interface{}

		for i := range rowMesPbom {
			if i != indexMatCode && i != indexPlant {
				setParams = append(setParams, fmt.Sprintf("%s = ?", rowMesPbom[i]))
			}
		}
		updateStatement := fmt.Sprintf("UPDATE %s SET %s", tableName, strings.Join(setParams, ", "))

		for i := range valMesPbom {
			if i != indexMatCode && i != indexPlant {
				setValues = append(setValues, valMesPbom[i])
			}
		}

		updateStatement += " WHERE mat_code = ? AND plant = ?"
		setValues = append(setValues, valMesPbom[indexMatCode], valMesPbom[indexPlant])
		// 执行更新操作
		_, err = db.Exec(updateStatement, setValues...)
		if err != nil {
			logger.Info("数据库更新失败%v", err)
		}
	case "order":
		tableName = "mes_order_sap"

		var rowMesPbom []string
		var valMesPbom []interface{}

		fieldSlice := []string{"order_no", "cmd_time", "order_batch", "order_type", "mat_code", "order_num", "unit", "plan_starttime", "plan_endtime", "process_code", "pbom_code", "order_status"}

		for i := range fieldSlice {
			rowMesPbom, valMesPbom = MappingHelper(dataBody, rowMesPbom, valMesPbom, fieldSlice[i])
		}

		fieldIntSlice := []string{"order_priority", "plant", "is_delete"}
		for i := range fieldIntSlice {
			rowMesPbom, valMesPbom = MappingIntHelper(dataBody, rowMesPbom, valMesPbom, fieldIntSlice[i])
		}

		var indexMatCode int
		var indexPlant int

		for i := range rowMesPbom {
			if rowMesPbom[i] == "order_no" {
				indexMatCode = i
			}
			if rowMesPbom[i] == "plant" {
				indexPlant = i
			}
		}

		var setParams []string
		var setValues []interface{}

		for i := range rowMesPbom {
			if i != indexMatCode && i != indexPlant {
				setParams = append(setParams, fmt.Sprintf("%s = ?", rowMesPbom[i]))
			}
		}
		updateStatement := fmt.Sprintf("UPDATE %s SET %s", tableName, strings.Join(setParams, ", "))

		for i := range valMesPbom {
			if i != indexMatCode && i != indexPlant {
				setValues = append(setValues, valMesPbom[i])
			}
		}

		updateStatement += " WHERE order_no = ? AND plant = ?"
		setValues = append(setValues, valMesPbom[indexMatCode], valMesPbom[indexPlant])
		// 执行更新操作
		_, err = db.Exec(updateStatement, setValues...)
		if err != nil {
			logger.Info("数据库更新失败%v", err)
		}
	case "flow":
		tableName = "mes_processes"

		var rowMesPbom []string
		var valMesPbom []interface{}

		fieldSlice := []string{"plnnr", "mat_code", "mat_des", "mat_details_code", "processes_des", "erp_update", "process_code"}
		fieldIntSlice := []string{"plant", "is_delete", "plnkn", "num", "erp_create_id", "erp_update_id"}

		for i := range fieldSlice {
			rowMesPbom, valMesPbom = MappingHelper(dataBody, rowMesPbom, valMesPbom, fieldSlice[i])
		}

		for i := range fieldIntSlice {
			rowMesPbom, valMesPbom = MappingIntHelper(dataBody, rowMesPbom, valMesPbom, fieldIntSlice[i])
		}
		rowMesPbom = append(rowMesPbom, "sort")
		valMesPbom = append(valMesPbom, 0)

		var indexPlnnr int
		var indexPlnkn int

		for i := range rowMesPbom {
			if rowMesPbom[i] == "plnnr" {
				indexPlnnr = i
			}
			if rowMesPbom[i] == "plnkn" {
				indexPlnkn = i
			}
		}

		var setParams []string
		var setValues []interface{}

		for i := range rowMesPbom {
			if i != indexPlnnr && i != indexPlnkn {
				setParams = append(setParams, fmt.Sprintf("%s = ?", rowMesPbom[i]))
			}
		}
		updateStatement := fmt.Sprintf("UPDATE %s SET %s", tableName, strings.Join(setParams, ", "))

		for i := range valMesPbom {
			if i != indexPlnnr && i != indexPlnkn {
				setValues = append(setValues, valMesPbom[i])
			}
		}

		updateStatement += " WHERE plnnr = ? AND plnkn = ?"
		setValues = append(setValues, valMesPbom[indexPlnnr], valMesPbom[indexPlnkn])
		// 执行更新操作
		_, err = db.Exec(updateStatement, setValues...)
		if err != nil {
			logger.Info("数据库更新失败%v", err)
		}
	case "pbom":
		var rowMesPbom []string
		var valMesPbom []interface{}

		fieldSlice := []string{"mat_code", "mat_des", "pbom_version", "pbom_code", "standard", "mat_unit"}

		for i := range fieldSlice {
			rowMesPbom, valMesPbom = MappingHelper(dataBody, rowMesPbom, valMesPbom, fieldSlice[i])
		}

		fieldIntSlice := []string{"plant", "is_delete"}
		for i := range fieldIntSlice {
			rowMesPbom, valMesPbom = MappingIntHelper(dataBody, rowMesPbom, valMesPbom, fieldIntSlice[i])
		}

		index := GetIndex(rowMesPbom)
		indexMatCode := index[0]
		indexPlant := index[1]
		indexPbomVersion := index[2]

		var setParams []string
		var setValues []interface{}

		for i := range rowMesPbom {
			if i != indexMatCode && i != indexPbomVersion && i != indexPlant {
				setParams = append(setParams, fmt.Sprintf("%s = ?", rowMesPbom[i]))
			}
		}
		updateStatement := fmt.Sprintf("UPDATE mes_pbom SET %s", strings.Join(setParams, ", "))

		for i := range valMesPbom {
			if i != indexMatCode && i != indexPbomVersion && i != indexPlant {
				setValues = append(setValues, valMesPbom[i])
			}
		}

		updateStatement += " WHERE mat_code = ? AND plant = ? AND pbom_version = ?"
		setValues = append(setValues, valMesPbom[indexMatCode], valMesPbom[indexPlant], valMesPbom[indexPbomVersion])
		// 执行更新操作
		_, err = db.Exec(updateStatement, setValues...)
		if err != nil {
			logger.Info("数据插入子表失败")
			logger.Info("sqlStatement是：%v", err)
			return false
		}
		logger.Info("主表更新完成")

		SelectSubPbom(db, dataBody)
	case "process":
		var rowMesPbom []string
		var valMesPbom []interface{}

		fieldSlice := []string{"plnnr", "mat_code", "mat_des", "process_code", "process_des", "start_time", "end_time", "erp_update"}

		for i := range fieldSlice {
			rowMesPbom, valMesPbom = MappingHelper(dataBody, rowMesPbom, valMesPbom, fieldSlice[i])
		}

		fieldIntSlice := []string{"plant", "is_delete", "erp_create_id", "erp_update_id"}
		for i := range fieldIntSlice {
			rowMesPbom, valMesPbom = MappingIntHelper(dataBody, rowMesPbom, valMesPbom, fieldIntSlice[i])
		}

		index := GetIndex(rowMesPbom)
		indexMatCode := index[0]
		indexPlant := index[1]

		var setParams []string
		var setValues []interface{}

		for i := range rowMesPbom {
			if i != indexMatCode && i != indexPlant {
				setParams = append(setParams, fmt.Sprintf("%s = ?", rowMesPbom[i]))
			}
		}
		updateStatement := fmt.Sprintf("UPDATE mes_processes_product_sap SET %s", strings.Join(setParams, ", "))

		for i := range valMesPbom {
			if i != indexMatCode && i != indexPlant {
				setValues = append(setValues, valMesPbom[i])
			}
		}

		updateStatement += " WHERE mat_code = ? AND plant = ? "
		setValues = append(setValues, valMesPbom[indexMatCode], valMesPbom[indexPlant])
		// 执行更新操作
		_, err = db.Exec(updateStatement, setValues...)
		if err != nil {
			logger.Info("数据插入主表失败")
			logger.Info("sqlStatement是：%v", err)
			return false
		}

		logger.Info("主表更新完成")

		SelectSubProcess(db, dataBody)
	case "porder":
		var rowMesPbom []string
		var valMesPbom []interface{}

		fieldSlice := []string{"order_no", "plan_num", "mat_code", "mat_des", "standard", "mat_unit"}

		for i := range fieldSlice {
			rowMesPbom, valMesPbom = MappingHelper(dataBody, rowMesPbom, valMesPbom, fieldSlice[i])
		}

		fieldIntSlice := []string{"is_delete"}
		for i := range fieldIntSlice {
			rowMesPbom, valMesPbom = MappingIntHelper(dataBody, rowMesPbom, valMesPbom, fieldIntSlice[i])
		}

		logger.Info("dataBody:%v", dataBody)
		index := GetIndex(rowMesPbom)
		indexOrderON := index[3]

		var setParams []string
		var setValues []interface{}

		for i := range rowMesPbom {
			if i != indexOrderON {
				setParams = append(setParams, fmt.Sprintf("%s = ?", rowMesPbom[i]))
			}
		}
		updateStatement := fmt.Sprintf("UPDATE mes_production_order_sap SET %s", strings.Join(setParams, ", "))

		for i := range valMesPbom {
			if i != indexOrderON {
				setValues = append(setValues, valMesPbom[i])
			}
		}

		updateStatement += " WHERE order_no = ? "
		setValues = append(setValues, valMesPbom[indexOrderON])
		// 执行更新操作
		_, err = db.Exec(updateStatement, setValues...)
		if err != nil {
			logger.Info("数据插入主表失败")
			logger.Info("sqlStatement是：%v", err)
			return false
		}

		logger.Info("主表更新完成")
		SelectSubPorder(db, dataBody)
	default:
		logger.Info("没有匹配到指定数据库")
	}
	return true
}

func StoreXml(body []byte) bool {
	var projectFolderPath = constants.HSM_OS_ROOT + config.ConfigAll.FILE.Path + "tempXML" + constants.Hierarchy
	filename := "sap"
	ext := ".xml"
	dst := filepath.Join(projectFolderPath, filename+ext)

	sec := time.Now().Unix()

	if _, err := os.Stat(dst); err == nil {
		filename = filename + constants.Underline + strconv.FormatInt(sec, 10) + ext
		dst = filepath.Join(projectFolderPath, filename)
	}
	util.CreateDir(projectFolderPath)
	flag := util.WriteFile(dst, string(body))
	return flag
}

func EditOrderStatus(requestBody map[string]interface{}) bool {

	logger.Info("requestBody:%v", requestBody)
	_, orderNo := GetStringFieldOrDefault(requestBody, "order_no")
	_, orderStatus := GetStringFieldOrDefault(requestBody, "order_status")
	flag, plantS := GetStringFieldOrDefault(requestBody, "plant")

	var plant int
	if flag {
		plant, _ = strconv.Atoi(plantS)
	}

	db, err := ConnectMySQL()
	if err != nil {
		logger.Info("数据库连接失败")
		return false
	}
	defer db.Close()

	updateStatement := fmt.Sprintf("UPDATE mes_order_sap SET order_status='%s' WHERE order_no='%s' AND plant=%d", orderStatus, orderNo, plant)

	logger.Info("updateStatement:%v", updateStatement)
	// 执行更新操作
	_, err = db.Exec(updateStatement)
	if err != nil {
		logger.Info("数据库更新失败%v", err)
	}

	return true
}

// 主表插入
func InsertTable(dataBody map[string]interface{}, fieldSlice, fieldIntSlice []string, tableName string, dataType string, db *sql.DB) {
	var rowMesPbom []string
	var valMesPbom []interface{}

	for i := range fieldSlice {
		rowMesPbom, valMesPbom = MappingHelper(dataBody, rowMesPbom, valMesPbom, fieldSlice[i])
	}

	for i := range fieldIntSlice {
		rowMesPbom, valMesPbom = MappingIntHelper(dataBody, rowMesPbom, valMesPbom, fieldIntSlice[i])
	}

	if dataType == "flow" {
		rowMesPbom = append(rowMesPbom, "sort")
		valMesPbom = append(valMesPbom, 0)
	}

	// 定义占位符
	placeholders := ProducePlaceholders(rowMesPbom)

	insertStatement := fmt.Sprintf("INSERT INTO %s (%s) VALUES (%s)", tableName, strings.Join(rowMesPbom, ", "), strings.Join(placeholders, ", "))
	_, err := db.Exec(insertStatement, valMesPbom...)
	if err != nil {
		logger.Info("数据插入失败")
		logger.Info("sqlStatement是：%v", err)
	}
}

// 子表插入
func InsertSubTable(dataBody map[string]interface{}, subName, subTableName string, fieldSlice, fieldIntSlice []string, db *sql.DB) {
	var rowValSlice []interface{}

	logger.Info("subName:%v", subName)

	if m, ok := dataBody[subName].(map[string]interface{}); ok {
		var rowMesPbomDetails []string
		var valMesPbomDetails []interface{}

		for i := range fieldSlice {
			rowMesPbomDetails, valMesPbomDetails = MappingHelper(m, rowMesPbomDetails, valMesPbomDetails, fieldSlice[i])
		}

		for i := range fieldIntSlice {
			rowMesPbomDetails, valMesPbomDetails = MappingIntHelper(m, rowMesPbomDetails, valMesPbomDetails, fieldIntSlice[i])
		}

		if subName == "erp_product_line_details_model" {
			rowMesPbomDetails = append(rowMesPbomDetails, "sort")
			valMesPbomDetails = append(valMesPbomDetails, 0)
		}

		rowValSlice = append(rowValSlice, rowMesPbomDetails, valMesPbomDetails)
	}

	if pbomDetails, ok := dataBody[subName].([]interface{}); ok {
		for _, v := range pbomDetails {
			if m, ok := v.(map[string]interface{}); ok {
				logger.Info("m:%v", m)
				var rowMesPbomDetails []string
				var valMesPbomDetails []interface{}

				for i := range fieldSlice {
					rowMesPbomDetails, valMesPbomDetails = MappingHelper(m, rowMesPbomDetails, valMesPbomDetails, fieldSlice[i])
				}

				for i := range fieldIntSlice {
					rowMesPbomDetails, valMesPbomDetails = MappingIntHelper(m, rowMesPbomDetails, valMesPbomDetails, fieldIntSlice[i])
				}

				if subName == "erp_product_line_details_model" {
					rowMesPbomDetails = append(rowMesPbomDetails, "sort")
					valMesPbomDetails = append(valMesPbomDetails, 0)
				}

				rowValSlice = append(rowValSlice, rowMesPbomDetails, valMesPbomDetails)
			}
		}
	}

	logger.Info("rowValSlice:%v", rowValSlice)

	// 使用索引每次取出两个元素
	for i := 0; i < len(rowValSlice); i += 2 {
		rowMesPbomDetails := rowValSlice[i].([]string)
		valMesPbomDetails := rowValSlice[i+1].([]interface{})
		placeholders := make([]string, len(rowMesPbomDetails))
		for i := 0; i < len(rowMesPbomDetails); i++ {
			placeholders[i] = "?"
		}

		insertStatement := fmt.Sprintf("INSERT INTO %s (%s) VALUES (%s)", subTableName, strings.Join(rowMesPbomDetails, ", "), strings.Join(placeholders, ", "))

		_, err := db.Exec(insertStatement, valMesPbomDetails...)
		if err != nil {
			logger.Info("数据插入子表失败")
			logger.Info("sqlStatement是：%v", err)
		}
	}
}

func ResolveXml(requestBody map[string]interface{}) []byte {
	xml, _ := mxj.Map(requestBody).Xml()
	newXml := strings.Replace(string(xml), "<doc>", "<data>", 1)
	res := strings.Replace(newXml, "</doc>", "</data>", 1)
	logger.Info("json转换为XML:%v", res)
	request := []byte(res)
	return request
}

// pbom子表更新
func EditeSubPbom(db *sql.DB, dataBody map[string]interface{}) {
	subName := "pbom_details_models"
	subFieldSlice := []string{"mat_code", "mat_des", "erp_code", "replace_group", "pbom_code", "standard", "mat_unit", "mat_num", "position_code", "merge_code"}
	subFieldIntSlice := []string{"level", "is_delete"}
	var rowValSlice []interface{}

	logger.Info("subName:%v", subName)

	if m, ok := dataBody[subName].(map[string]interface{}); ok {
		var rowMesPbomDetails []string
		var valMesPbomDetails []interface{}

		for i := range subFieldSlice {
			rowMesPbomDetails, valMesPbomDetails = MappingHelper(m, rowMesPbomDetails, valMesPbomDetails, subFieldSlice[i])
		}

		for i := range subFieldIntSlice {
			rowMesPbomDetails, valMesPbomDetails = MappingIntHelper(m, rowMesPbomDetails, valMesPbomDetails, subFieldIntSlice[i])
		}

		rowValSlice = append(rowValSlice, rowMesPbomDetails, valMesPbomDetails)
	}

	if pbomDetails, ok := dataBody[subName].([]interface{}); ok {
		for _, v := range pbomDetails {
			if m, ok := v.(map[string]interface{}); ok {
				logger.Info("m:%v", m)
				var rowMesPbomDetails []string
				var valMesPbomDetails []interface{}

				for i := range subFieldSlice {
					rowMesPbomDetails, valMesPbomDetails = MappingHelper(m, rowMesPbomDetails, valMesPbomDetails, subFieldSlice[i])
				}

				for i := range subFieldIntSlice {
					rowMesPbomDetails, valMesPbomDetails = MappingIntHelper(m, rowMesPbomDetails, valMesPbomDetails, subFieldIntSlice[i])
				}

				rowValSlice = append(rowValSlice, rowMesPbomDetails, valMesPbomDetails)
			}
		}
	}

	logger.Info("rowValSlice:%v", rowValSlice)

	// 使用索引每次取出两个元素
	for i := 0; i < len(rowValSlice); i += 2 {
		rowMesPbomDetails := rowValSlice[i].([]string)
		valMesPbomDetails := rowValSlice[i+1].([]interface{})

		var indexPbom int
		for i := range rowMesPbomDetails {
			if rowMesPbomDetails[i] == "pbom_code" {
				indexPbom = i
			}
		}

		var setParams []string
		var setValues []interface{}

		for i := range rowMesPbomDetails {
			if i != indexPbom {
				setParams = append(setParams, fmt.Sprintf("%s = ?", rowMesPbomDetails[i]))
			}
		}
		updateStatement := fmt.Sprintf("UPDATE mes_pbom_details SET %s", strings.Join(setParams, ", "))

		for i := range valMesPbomDetails {
			if i != indexPbom {
				setValues = append(setValues, valMesPbomDetails[i])
			}
		}

		updateStatement += " WHERE pbom_code = ? "
		setValues = append(setValues, valMesPbomDetails[indexPbom])
		// 执行更新操作
		_, err := db.Exec(updateStatement, setValues...)
		if err != nil {
			logger.Info("数据插入子表失败")
			logger.Info("sqlStatement是：%v", err)
		}
	}
}

// process子表更新
func EditeSubProcess(db *sql.DB, dataBody map[string]interface{}) {
	subName := "erp_product_line_details_model"
	subFieldSlice := []string{"plnnr", "mat_code", "mat_des", "mat_details_code", "processes_des", "labor_hour", "labor_hour_unit", "machine_hour", "machine_hour_unit", "labor_prepare_hour", "labor_prepare_hour_unit", "machine_prepare_hour", "machine_prepare_hour_unit", "erp_update", "start_time", "end_time", "process_code"}
	subFieldIntSlice := []string{"plant", "is_delete", "erp_create_id", "erp_update_id", "plnkn", "num"}

	var rowValSlice []interface{}
	if m, ok := dataBody[subName].(map[string]interface{}); ok {
		var rowMesPbomDetails []string
		var valMesPbomDetails []interface{}

		for i := range subFieldSlice {
			rowMesPbomDetails, valMesPbomDetails = MappingHelper(m, rowMesPbomDetails, valMesPbomDetails, subFieldSlice[i])
		}

		for i := range subFieldIntSlice {
			rowMesPbomDetails, valMesPbomDetails = MappingIntHelper(m, rowMesPbomDetails, valMesPbomDetails, subFieldIntSlice[i])
		}

		if subName == "erp_product_line_details_model" {
			rowMesPbomDetails = append(rowMesPbomDetails, "sort")
			valMesPbomDetails = append(valMesPbomDetails, 0)
		}

		rowValSlice = append(rowValSlice, rowMesPbomDetails, valMesPbomDetails)
	}

	if pbomDetails, ok := dataBody[subName].([]interface{}); ok {
		for _, v := range pbomDetails {
			if m, ok := v.(map[string]interface{}); ok {
				logger.Info("m:%v", m)
				var rowMesPbomDetails []string
				var valMesPbomDetails []interface{}

				for i := range subFieldSlice {
					rowMesPbomDetails, valMesPbomDetails = MappingHelper(m, rowMesPbomDetails, valMesPbomDetails, subFieldSlice[i])
				}

				for i := range subFieldIntSlice {
					rowMesPbomDetails, valMesPbomDetails = MappingIntHelper(m, rowMesPbomDetails, valMesPbomDetails, subFieldIntSlice[i])
				}

				if subName == "erp_product_line_details_model" {
					rowMesPbomDetails = append(rowMesPbomDetails, "sort")
					valMesPbomDetails = append(valMesPbomDetails, 0)
				}

				rowValSlice = append(rowValSlice, rowMesPbomDetails, valMesPbomDetails)
			}
		}
	}

	logger.Info("rowValSlice:%v", rowValSlice)

	// 使用索引每次取出两个元素
	for i := 0; i < len(rowValSlice); i += 2 {
		rowMesPbomDetails := rowValSlice[i].([]string)
		valMesPbomDetails := rowValSlice[i+1].([]interface{})

		var indexPlnnr int
		var indexPlnkn int
		for i := range rowMesPbomDetails {
			if rowMesPbomDetails[i] == "plnnr" {
				indexPlnnr = i
			}
			if rowMesPbomDetails[i] == "plnkn" {
				indexPlnkn = i
			}
		}

		var setParams []string
		var setValues []interface{}

		for i := range rowMesPbomDetails {
			if i != indexPlnnr && i != indexPlnkn {
				setParams = append(setParams, fmt.Sprintf("%s = ?", rowMesPbomDetails[i]))
			}
		}
		updateStatement := fmt.Sprintf("UPDATE mes_processes_product_sap_details SET %s", strings.Join(setParams, ", "))

		for i := range valMesPbomDetails {
			if i != indexPlnnr && i != indexPlnkn {
				setValues = append(setValues, valMesPbomDetails[i])
			}
		}

		updateStatement += " WHERE plnnr = ? AND plnkn = ? "
		setValues = append(setValues, valMesPbomDetails[indexPlnnr], valMesPbomDetails[indexPlnkn])
		// 执行更新操作
		_, err := db.Exec(updateStatement, setValues...)
		if err != nil {
			logger.Info("数据插入子表失败")
			logger.Info("sqlStatement是：%v", err)
		}
	}
}

// porder子表更新
func EditeSubPorder(db *sql.DB, dataBody map[string]interface{}) {
	subName := "erp_production_order_details_model"
	subFieldSlice := []string{"order_no", "erp_code", "mat_desc_code", "mat_desc_name", "mat_num", "mat_unit", "standard", "process_code"}
	subFieldIntSlice := []string{"is_delete"}

	var rowValSlice []interface{}
	if m, ok := dataBody[subName].(map[string]interface{}); ok {
		var rowMesPbomDetails []string
		var valMesPbomDetails []interface{}

		for i := range subFieldSlice {
			rowMesPbomDetails, valMesPbomDetails = MappingHelper(m, rowMesPbomDetails, valMesPbomDetails, subFieldSlice[i])
		}

		for i := range subFieldIntSlice {
			rowMesPbomDetails, valMesPbomDetails = MappingIntHelper(m, rowMesPbomDetails, valMesPbomDetails, subFieldIntSlice[i])
		}

		if subName == "erp_product_line_details_model" {
			rowMesPbomDetails = append(rowMesPbomDetails, "sort")
			valMesPbomDetails = append(valMesPbomDetails, 0)
		}

		rowValSlice = append(rowValSlice, rowMesPbomDetails, valMesPbomDetails)
	}

	if pbomDetails, ok := dataBody[subName].([]interface{}); ok {
		for _, v := range pbomDetails {
			if m, ok := v.(map[string]interface{}); ok {
				logger.Info("m:%v", m)
				var rowMesPbomDetails []string
				var valMesPbomDetails []interface{}

				for i := range subFieldSlice {
					rowMesPbomDetails, valMesPbomDetails = MappingHelper(m, rowMesPbomDetails, valMesPbomDetails, subFieldSlice[i])
				}

				for i := range subFieldIntSlice {
					rowMesPbomDetails, valMesPbomDetails = MappingIntHelper(m, rowMesPbomDetails, valMesPbomDetails, subFieldIntSlice[i])
				}

				if subName == "erp_product_line_details_model" {
					rowMesPbomDetails = append(rowMesPbomDetails, "sort")
					valMesPbomDetails = append(valMesPbomDetails, 0)
				}

				rowValSlice = append(rowValSlice, rowMesPbomDetails, valMesPbomDetails)
			}
		}
	}

	logger.Info("rowValSlice:%v", rowValSlice)

	// 使用索引每次取出两个元素
	for i := 0; i < len(rowValSlice); i += 2 {
		rowMesPbomDetails := rowValSlice[i].([]string)
		valMesPbomDetails := rowValSlice[i+1].([]interface{})

		var indexOrderNo int
		var indexErpCode int
		for i := range rowMesPbomDetails {
			if rowMesPbomDetails[i] == "order_no" {
				indexOrderNo = i
			}
			if rowMesPbomDetails[i] == "erp_code" {
				indexErpCode = i
			}
		}

		var setParams []string
		var setValues []interface{}

		for i := range rowMesPbomDetails {
			if i != indexOrderNo && i != indexErpCode {
				setParams = append(setParams, fmt.Sprintf("%s = ?", rowMesPbomDetails[i]))
			}
		}
		updateStatement := fmt.Sprintf("UPDATE mes_production_order_sap_des SET %s", strings.Join(setParams, ", "))

		for i := range valMesPbomDetails {
			if i != indexOrderNo && i != indexErpCode {
				setValues = append(setValues, valMesPbomDetails[i])
			}
		}

		updateStatement += " WHERE order_no = ? AND erp_code = ? "
		setValues = append(setValues, valMesPbomDetails[indexOrderNo], valMesPbomDetails[indexErpCode])
		// 执行更新操作
		_, err := db.Exec(updateStatement, setValues...)
		if err != nil {
			logger.Info("数据插入子表失败")
			logger.Info("sqlStatement是：%v", err)
		}
	}
}

// 是否存在字表的记录，存在更新，不存在，走插入
func SelectSubPbom(db *sql.DB, dataBody map[string]interface{}) {
	subName := "pbom_details_models"
	subFieldSlice := []string{"mat_code", "mat_des", "erp_code", "replace_group", "pbom_code", "standard", "mat_unit", "mat_num", "position_code", "merge_code"}
	subFieldIntSlice := []string{"level", "is_delete"}
	var rowValSlice []interface{}

	if m, ok := dataBody[subName].(map[string]interface{}); ok {
		var rowMesPbomDetails []string
		var valMesPbomDetails []interface{}

		for i := range subFieldSlice {
			rowMesPbomDetails, valMesPbomDetails = MappingHelper(m, rowMesPbomDetails, valMesPbomDetails, subFieldSlice[i])
		}

		for i := range subFieldIntSlice {
			rowMesPbomDetails, valMesPbomDetails = MappingIntHelper(m, rowMesPbomDetails, valMesPbomDetails, subFieldIntSlice[i])
		}

		rowValSlice = append(rowValSlice, rowMesPbomDetails, valMesPbomDetails)
	}

	if pbomDetails, ok := dataBody[subName].([]interface{}); ok {
		for _, v := range pbomDetails {
			if m, ok := v.(map[string]interface{}); ok {
				logger.Info("m:%v", m)
				var rowMesPbomDetails []string
				var valMesPbomDetails []interface{}

				for i := range subFieldSlice {
					rowMesPbomDetails, valMesPbomDetails = MappingHelper(m, rowMesPbomDetails, valMesPbomDetails, subFieldSlice[i])
				}

				for i := range subFieldIntSlice {
					rowMesPbomDetails, valMesPbomDetails = MappingIntHelper(m, rowMesPbomDetails, valMesPbomDetails, subFieldIntSlice[i])
				}

				rowValSlice = append(rowValSlice, rowMesPbomDetails, valMesPbomDetails)
			}
		}
	}

	logger.Info("rowValSlice:%v", rowValSlice)

	// 使用索引每次取出两个元素
	for i := 0; i < len(rowValSlice); i += 2 {
		rowMesPbomDetails := rowValSlice[i].([]string)
		valMesPbomDetails := rowValSlice[i+1].([]interface{})

		var indexPbom int
		for i := range rowMesPbomDetails {
			if rowMesPbomDetails[i] == "pbom_code" {
				indexPbom = i
			}
		}

		sql := fmt.Sprintf("SELECT COUNT(*) FROM mes_pbom_details WHERE pbom_code = '%s'", valMesPbomDetails[indexPbom])

		logger.Info("查重的sql语句为:%v", sql)

		var count int
		err := db.QueryRow(sql).Scan(&count)
		if err != nil {
			logger.Info("查重错误%v", err)
		}
		if count > 0 {
			var setParams []string
			var setValues []interface{}

			for i := range rowMesPbomDetails {
				if i != indexPbom {
					setParams = append(setParams, fmt.Sprintf("%s = ?", rowMesPbomDetails[i]))
				}
			}
			updateStatement := fmt.Sprintf("UPDATE mes_pbom_details SET %s", strings.Join(setParams, ", "))

			for i := range valMesPbomDetails {
				if i != indexPbom {
					setValues = append(setValues, valMesPbomDetails[i])
				}
			}

			updateStatement += " WHERE pbom_code = ? "
			setValues = append(setValues, valMesPbomDetails[indexPbom])
			// 执行更新操作
			_, err := db.Exec(updateStatement, setValues...)
			if err != nil {
				logger.Info("数据插入子表失败")
				logger.Info("sqlStatement是：%v", err)
			}
		} else {
			placeholders := make([]string, len(rowMesPbomDetails))
			for i := 0; i < len(rowMesPbomDetails); i++ {
				placeholders[i] = "?"
			}

			insertStatement := fmt.Sprintf("INSERT INTO %s (%s) VALUES (%s)", "mes_pbom_details", strings.Join(rowMesPbomDetails, ", "), strings.Join(placeholders, ", "))

			_, err := db.Exec(insertStatement, valMesPbomDetails...)
			if err != nil {
				logger.Info("数据插入子表失败")
				logger.Info("sqlStatement是：%v", err)
			}
		}
	}
}

func SelectSubProcess(db *sql.DB, dataBody map[string]interface{}) {
	subName := "erp_product_line_details_model"
	subFieldSlice := []string{"plnnr", "mat_code", "mat_des", "mat_details_code", "processes_des", "labor_hour", "labor_hour_unit", "machine_hour", "machine_hour_unit", "labor_prepare_hour", "labor_prepare_hour_unit", "machine_prepare_hour", "machine_prepare_hour_unit", "erp_update", "start_time", "end_time", "process_code"}
	subFieldIntSlice := []string{"plant", "is_delete", "erp_create_id", "erp_update_id", "plnkn", "num"}

	var rowValSlice []interface{}
	if m, ok := dataBody[subName].(map[string]interface{}); ok {
		var rowMesPbomDetails []string
		var valMesPbomDetails []interface{}

		for i := range subFieldSlice {
			rowMesPbomDetails, valMesPbomDetails = MappingHelper(m, rowMesPbomDetails, valMesPbomDetails, subFieldSlice[i])
		}

		for i := range subFieldIntSlice {
			rowMesPbomDetails, valMesPbomDetails = MappingIntHelper(m, rowMesPbomDetails, valMesPbomDetails, subFieldIntSlice[i])
		}

		if subName == "erp_product_line_details_model" {
			rowMesPbomDetails = append(rowMesPbomDetails, "sort")
			valMesPbomDetails = append(valMesPbomDetails, 0)
		}

		rowValSlice = append(rowValSlice, rowMesPbomDetails, valMesPbomDetails)
	}

	if pbomDetails, ok := dataBody[subName].([]interface{}); ok {
		for _, v := range pbomDetails {
			if m, ok := v.(map[string]interface{}); ok {
				logger.Info("m:%v", m)
				var rowMesPbomDetails []string
				var valMesPbomDetails []interface{}

				for i := range subFieldSlice {
					rowMesPbomDetails, valMesPbomDetails = MappingHelper(m, rowMesPbomDetails, valMesPbomDetails, subFieldSlice[i])
				}

				for i := range subFieldIntSlice {
					rowMesPbomDetails, valMesPbomDetails = MappingIntHelper(m, rowMesPbomDetails, valMesPbomDetails, subFieldIntSlice[i])
				}

				if subName == "erp_product_line_details_model" {
					rowMesPbomDetails = append(rowMesPbomDetails, "sort")
					valMesPbomDetails = append(valMesPbomDetails, 0)
				}

				rowValSlice = append(rowValSlice, rowMesPbomDetails, valMesPbomDetails)
			}
		}
	}

	logger.Info("rowValSlice:%v", rowValSlice)

	// 使用索引每次取出两个元素
	for i := 0; i < len(rowValSlice); i += 2 {
		rowMesPbomDetails := rowValSlice[i].([]string)
		valMesPbomDetails := rowValSlice[i+1].([]interface{})

		var indexPlnnr int
		var indexPlnkn int
		for i := range rowMesPbomDetails {
			if rowMesPbomDetails[i] == "plnnr" {
				indexPlnnr = i
			}
			if rowMesPbomDetails[i] == "plnkn" {
				indexPlnkn = i
			}
		}

		sql := fmt.Sprintf("SELECT COUNT(*) FROM mes_processes_product_sap_details WHERE plnnr = '%s' AND plnkn = '%d'", valMesPbomDetails[indexPlnnr], valMesPbomDetails[indexPlnkn])

		logger.Info("查重的sql语句为:%v", sql)

		var count int
		err := db.QueryRow(sql).Scan(&count)
		if err != nil {
			logger.Info("查重错误%v", err)
		}
		logger.Info("count%v", count)
		if count > 0 {
			// 更新
			var setParams []string
			var setValues []interface{}

			for i := range rowMesPbomDetails {
				if i != indexPlnnr && i != indexPlnkn {
					setParams = append(setParams, fmt.Sprintf("%s = ?", rowMesPbomDetails[i]))
				}
			}
			updateStatement := fmt.Sprintf("UPDATE mes_processes_product_sap_details SET %s", strings.Join(setParams, ", "))

			for i := range valMesPbomDetails {
				if i != indexPlnnr && i != indexPlnkn {
					setValues = append(setValues, valMesPbomDetails[i])
				}
			}

			updateStatement += " WHERE plnnr = ? AND plnkn = ? "
			setValues = append(setValues, valMesPbomDetails[indexPlnnr], valMesPbomDetails[indexPlnkn])
			// 执行更新操作
			_, err := db.Exec(updateStatement, setValues...)
			if err != nil {
				logger.Info("数据插入子表失败")
				logger.Info("sqlStatement是：%v", err)
			}
		} else {
			// 拆入
			placeholders := make([]string, len(rowMesPbomDetails))
			for i := 0; i < len(rowMesPbomDetails); i++ {
				placeholders[i] = "?"
			}

			insertStatement := fmt.Sprintf("INSERT INTO %s (%s) VALUES (%s)", "mes_processes_product_sap_details", strings.Join(rowMesPbomDetails, ", "), strings.Join(placeholders, ", "))

			_, err := db.Exec(insertStatement, valMesPbomDetails...)
			if err != nil {
				logger.Info("数据插入子表失败")
				logger.Info("sqlStatement是：%v", err)
			}
		}
	}
}

func SelectSubPorder(db *sql.DB, dataBody map[string]interface{}) {
	subName := "erp_production_order_details_model"
	subFieldSlice := []string{"order_no", "erp_code", "mat_desc_code", "mat_desc_name", "mat_num", "mat_unit", "standard", "process_code"}
	subFieldIntSlice := []string{"is_delete"}

	var rowValSlice []interface{}
	if m, ok := dataBody[subName].(map[string]interface{}); ok {
		var rowMesPbomDetails []string
		var valMesPbomDetails []interface{}

		for i := range subFieldSlice {
			rowMesPbomDetails, valMesPbomDetails = MappingHelper(m, rowMesPbomDetails, valMesPbomDetails, subFieldSlice[i])
		}

		for i := range subFieldIntSlice {
			rowMesPbomDetails, valMesPbomDetails = MappingIntHelper(m, rowMesPbomDetails, valMesPbomDetails, subFieldIntSlice[i])
		}

		if subName == "erp_product_line_details_model" {
			rowMesPbomDetails = append(rowMesPbomDetails, "sort")
			valMesPbomDetails = append(valMesPbomDetails, 0)
		}

		rowValSlice = append(rowValSlice, rowMesPbomDetails, valMesPbomDetails)
	}

	if pbomDetails, ok := dataBody[subName].([]interface{}); ok {
		for _, v := range pbomDetails {
			if m, ok := v.(map[string]interface{}); ok {
				logger.Info("m:%v", m)
				var rowMesPbomDetails []string
				var valMesPbomDetails []interface{}

				for i := range subFieldSlice {
					rowMesPbomDetails, valMesPbomDetails = MappingHelper(m, rowMesPbomDetails, valMesPbomDetails, subFieldSlice[i])
				}

				for i := range subFieldIntSlice {
					rowMesPbomDetails, valMesPbomDetails = MappingIntHelper(m, rowMesPbomDetails, valMesPbomDetails, subFieldIntSlice[i])
				}

				if subName == "erp_product_line_details_model" {
					rowMesPbomDetails = append(rowMesPbomDetails, "sort")
					valMesPbomDetails = append(valMesPbomDetails, 0)
				}

				rowValSlice = append(rowValSlice, rowMesPbomDetails, valMesPbomDetails)
			}
		}
	}

	logger.Info("rowValSlice:%v", rowValSlice)

	// 使用索引每次取出两个元素
	for i := 0; i < len(rowValSlice); i += 2 {
		rowMesPbomDetails := rowValSlice[i].([]string)
		valMesPbomDetails := rowValSlice[i+1].([]interface{})

		var indexOrderNo int
		var indexErpCode int
		for i := range rowMesPbomDetails {
			if rowMesPbomDetails[i] == "order_no" {
				indexOrderNo = i
			}
			if rowMesPbomDetails[i] == "erp_code" {
				indexErpCode = i
			}
		}

		sql := fmt.Sprintf("SELECT COUNT(*) FROM mes_production_order_sap_des WHERE order_no = '%s' AND erp_code = '%s'", valMesPbomDetails[indexOrderNo], valMesPbomDetails[indexErpCode])

		logger.Info("查重的sql语句为:%v", sql)

		var count int
		err := db.QueryRow(sql).Scan(&count)
		if err != nil {
			logger.Info("查重错误%v", err)
		}
		if count > 0 {
			// 更新
			var setParams []string
			var setValues []interface{}

			for i := range rowMesPbomDetails {
				if i != indexOrderNo && i != indexErpCode {
					setParams = append(setParams, fmt.Sprintf("%s = ?", rowMesPbomDetails[i]))
				}
			}
			updateStatement := fmt.Sprintf("UPDATE mes_production_order_sap_des SET %s", strings.Join(setParams, ", "))

			for i := range valMesPbomDetails {
				if i != indexOrderNo && i != indexErpCode {
					setValues = append(setValues, valMesPbomDetails[i])
				}
			}

			updateStatement += " WHERE order_no = ? AND erp_code = ? "
			setValues = append(setValues, valMesPbomDetails[indexOrderNo], valMesPbomDetails[indexErpCode])
			// 执行更新操作
			_, err := db.Exec(updateStatement, setValues...)
			if err != nil {
				logger.Info("数据插入子表失败")
				logger.Info("sqlStatement是：%v", err)
			}
		} else {
			// 拆入
			placeholders := make([]string, len(rowMesPbomDetails))
			for i := 0; i < len(rowMesPbomDetails); i++ {
				placeholders[i] = "?"
			}

			insertStatement := fmt.Sprintf("INSERT INTO %s (%s) VALUES (%s)", "mes_production_order_sap_des", strings.Join(rowMesPbomDetails, ", "), strings.Join(placeholders, ", "))

			_, err := db.Exec(insertStatement, valMesPbomDetails...)
			if err != nil {
				logger.Info("数据插入子表失败")
				logger.Info("sqlStatement是：%v", err)
			}
		}
	}
}
