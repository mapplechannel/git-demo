package sap

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"hsm-io-it-back-end/config"
	"hsm-io-it-back-end/internal/constants"
	"hsm-io-it-back-end/pkg/logger"
	"io/ioutil"
	"strconv"
	"strings"
	"unicode"

	"github.com/gin-gonic/gin"
	_ "github.com/go-sql-driver/mysql"
)

type DatabaseInfo struct {
	Host     string `json:"host"`
	Port     int    `json:"port"`
	User     string `json:"user"`
	Password string `json:"password"`
	DBName   string `json:"dbname"`
}

// 数据库连接对象
var databaseInfo DatabaseInfo

// 获取数据库连接
func getLinkInfo() {
	// 读取 JSON 文件
	path := constants.HSM_OS_ROOT+config.ConfigAll.FILE.Path  + constants.ProjectTemplate + "databaseinfo.json"
	data, err := ioutil.ReadFile(path)
	if err != nil {
		fmt.Println("无法读取 JSON 文件:", err)
		return
	}

	// 解析 JSON 数据
	if err := json.Unmarshal(data, &databaseInfo); err != nil {
		fmt.Println("无法解析 JSON 数据:", err)
		return
	}
}

// MySQL连接信息
func ConnectMySQL() (*sql.DB, error) {

	getLinkInfo()

	// 构建连接字符串
	connStr := fmt.Sprintf("%s:%s@tcp(%s:%d)/%s", databaseInfo.User, databaseInfo.Password, databaseInfo.Host, databaseInfo.Port, databaseInfo.DBName)

	// 连接数据库
	db, err := sql.Open("mysql", connStr)
	if err != nil {
		return nil, err
	}

	// 测试连接是否成功
	err = db.Ping()
	if err != nil {
		db.Close() // 关闭数据库连接
		return nil, err
	}

	// 返回数据库连接对象
	return db, nil
}

// 根据路径获取值
func GetValueByPath(data map[string]interface{}, path string) (interface{}, error) {
	// path := ToCamelCase(pathOld)
	// logger.Info(path)
	// 根据路径切割成多个字段
	fields := strings.Split(path, ".")
	// 遍历字段
	for _, field := range fields {
		// 检查字段是否存在
		val, ok := data[field]
		if !ok {
			return nil, fmt.Errorf("路径 %s 无效，字段 %s 不存在", path, field)
		}
		// 如果是最后一个字段，则返回值
		if _, ok := val.(map[string]interface{}); !ok {
			return val, nil
		}
		// 否则继续深入下一层
		data = val.(map[string]interface{})
	}
	// 如果路径为空，返回整个 JSON 数据
	return data, nil
}

// 大小驼峰转换
func ToCamelCase(underscore string) string {
	var result string
	for i, r := range underscore {
		if i > 0 && unicode.IsUpper(r) {
			result += "_"
		}
		result += string(unicode.ToLower(r))
	}
	return result
}

// 解析响应体
func ResolveRequestBody(c *gin.Context) map[string]interface{} {
	body, err := ioutil.ReadAll(c.Request.Body)
	if err != nil {
		logger.Info("请求体读取错误")
	}

	var requestBody map[string]interface{}

	// 解析 JSON 数据到 map[string]interface{} 中
	err = json.Unmarshal(body, &requestBody)
	if err != nil {
		logger.Info("请求体解析错误")
	}

	return requestBody
}

// 透传响应体解析
func PenetrateDataResolve(c *gin.Context) interface{} {
	body, err := ioutil.ReadAll(c.Request.Body)
	if err != nil {
		logger.Info("请求体读取错误")
	}

	var requestBody map[string]interface{}
	err = json.Unmarshal(body, &requestBody)
	if err == nil {
		logger.Info("请求体解析map[string]interface{}")
		return requestBody
	}

	var sliceRequestBody []interface{}
	err = json.Unmarshal(body, &sliceRequestBody)
	if err == nil {
		logger.Info("请求体解析[]interface{}")
		return sliceRequestBody
	}
	return nil
}

// 获取默认字段
func GetStringFieldOrDefault(requestBody map[string]interface{}, fieldName string) (bool, string) {
	if fieldValue, ok := requestBody[fieldName].(string); ok {
		return true, fieldValue
	}
	return false, ""
}

// 字符类型字段映射
func MappingHelper(requestBody map[string]interface{}, row []string, val []interface{}, field string) ([]string, []interface{}) {
	flag, value := GetStringFieldOrDefault(requestBody, field)
	if flag {
		row = append(row, field)
		val = append(val, value)
	}
	return row, val
}

// int类型字段映射
func MappingIntHelper(requestBody map[string]interface{}, row []string, val []interface{}, field string) ([]string, []interface{}) {
	flag, stringValue := GetStringFieldOrDefault(requestBody, field)
	if flag {
		intValue, _ := strconv.Atoi(stringValue)
		row = append(row, field)
		val = append(val, intValue)
	}
	return row, val
}

func GetIndex(rowMesPbom []string) []int {
	var index []int
	var indexMatCode int
	var indexPlant int
	var indexPbomVersion int
	var indexOrderON int

	for i := range rowMesPbom {
		if rowMesPbom[i] == "mat_code" {
			indexMatCode = i
		}
		if rowMesPbom[i] == "plant" {
			indexPlant = i
		}
		if rowMesPbom[i] == "pbom_version" {
			indexPbomVersion = i
		}
		if rowMesPbom[i] == "order_no" {
			indexOrderON = i
		}
	}
	index = append(index, indexMatCode, indexPlant, indexPbomVersion, indexOrderON)
	return index
}

func ResolveAPIconfig(processBody map[string]interface{}) *Configuration {
	var config Configuration
	configData, err := json.Marshal(processBody)
	if err != nil {
		logger.Info("process解析错误")
	}
	err = json.Unmarshal(configData, &config)
	if err != nil {
		logger.Info("process映射错误%v", err)
	}

	return &config
}

func SplitRequestBody(requestBody map[string]interface{}) (map[string]interface{}, map[string]interface{}) {
	var dataBody map[string]interface{}
	var processBody map[string]interface{}

	// 解析data数据
	if val, ok := requestBody["data"].(map[string]interface{}); ok {
		dataBody = val
	}

	// 解析process
	if val, ok := requestBody["process_map"].(map[string]interface{}); ok {
		processBody = val
	}

	logger.Info("dataBody:%v", dataBody)

	return dataBody, processBody
}

var parten map[string]APIDetails

func GetAPIURL(apiName string) string {
	configFile := constants.HSM_OS_ROOT+config.ConfigAll.FILE.Path  + constants.ProjectTemplate + "datasouce" + constants.JsonIdentifier

	configJSON, err := ioutil.ReadFile(configFile)
	if err != nil {
		logger.Info("Error reading config file:%v", err)
	}

	// 解析APIConfig模板文件
	apiMap := make(map[string]APIDetails)

	err = json.Unmarshal(configJSON, &apiMap)
	if err != nil {
		logger.Info("Error parsing config JSON:%v", err)
	}

	// logger.Info("解析的接口配置文件是:%v", apiMap)
	parten = apiMap

	api := apiMap[apiName]

	var pairs []string
	for k, v := range api.QueryArg {
		pairs = append(pairs, fmt.Sprintf("%s=%s", k, v))
	}
	pairsUrl := strings.Join(pairs, "&")

	var url string

	if len(pairsUrl) != 0 {
		url = api.URL + "?" + pairsUrl
	} else {
		url = api.URL
	}
	logger.Info("**********url:%v", url)
	return url
}

func GetGQLURL(apiName string) string {
	configFile := constants.HSM_OS_ROOT+config.ConfigAll.FILE.Path  + constants.ProjectTemplate + "datasouce" + constants.JsonIdentifier

	configJSON, err := ioutil.ReadFile(configFile)
	if err != nil {
		logger.Info("Error reading config file:%v", err)
	}

	// 解析APIConfig模板文件
	apiMap := make(map[string]APIDetails)

	err = json.Unmarshal(configJSON, &apiMap)
	if err != nil {
		logger.Info("Error parsing config JSON:%v", err)
	}

	// logger.Info("解析的接口配置文件是:%v", apiMap)
	parten = apiMap

	api := apiMap[apiName]
	return api.URL
}

// 生成占位符
func ProducePlaceholders(rowMesPbom []string) []string {
	placeholders := make([]string, len(rowMesPbom))
	for i := 0; i < len(rowMesPbom); i++ {
		placeholders[i] = "?"
	}
	return placeholders
}
