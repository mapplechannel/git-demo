package sap

import (
	"bytes"
	"encoding/json"
	"hsm-io-it-back-end/internal/constants"
	"hsm-io-it-back-end/internal/util"
	"hsm-io-it-back-end/pkg/logger"
	"io/ioutil"
	"net/http"
)

func Gateway(routePath string, requestBody map[string]interface{}) (bool, map[string]interface{}) {

	ip := util.ServerCode + constants.DomainName

	urlPrefix := constants.Http + ip + ":6120/api/hsm-io-it/sap/" + routePath
	logger.Info("routePath:%v", routePath)
	searchRequestBody, err := json.Marshal(requestBody)
	if err != nil {
		logger.Info("Error marshalling JSON:%v", err)
		return false, nil
	}

	// 发送 POST 请求，执行查重接口
	resp, err := http.Post(urlPrefix, "application/json", bytes.NewBuffer(searchRequestBody))
	if err != nil {
		logger.Info("Error sending request:%v", err)
		return false, nil
	}
	defer resp.Body.Close()

	logger.Info("response body:%v", resp)

	// 读取响应体
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		logger.Info("Error reading response body:%v", err)
		return false, nil
	}

	// 解析响应体
	var result map[string]interface{}
	err = json.Unmarshal(body, &result)
	if err != nil {
		logger.Info("Error parsing response body:%v", err)
		return false, nil
	}

	logger.Info("接口的响应体为:%v", result)

	return true, result
}
