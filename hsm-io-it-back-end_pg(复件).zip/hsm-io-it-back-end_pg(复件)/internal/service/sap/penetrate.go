package sap

import (
	"fmt"
	"hsm-io-it-back-end/pkg/logger"
	"strings"
	"sync"

	_ "github.com/go-sql-driver/mysql"
)

func SplitMaterialData(requestBody interface{}) {
	SplitData(requestBody, PenetrateMaterialData)
}

func SplitPbomData(requestBody interface{}) {
	SplitData(requestBody, PenetrateProjectBomData)
}

func SplitOrderData(requestBody interface{}) {
	SplitData(requestBody, PenetrateOrderData)
}

func SplitSNData(requestBody interface{}) {
	SplitData(requestBody, PenetrateSNData)
}

func SplitProcessData(requestBody interface{}) {
	SplitData(requestBody, PenetrateProcessData)
}

func SplitProductOrderData(requestBody interface{}) {
	SplitData(requestBody, PenetrateProductOrderData)
}

func SplitFlowData(requestBody interface{}) {
	SplitData(requestBody, PenetrateFlowData)
}

// 通用goroutine启动
func SplitData(requestBody interface{}, penetrateFunc func(requestBody map[string]interface{}) bool) {
	switch reb := requestBody.(type) {
	case map[string]interface{}:
		penetrateFunc(reb)
	case []interface{}:
		concurrencyLimit := make(chan struct{}, 100)
		var wg sync.WaitGroup
		for _, v := range reb {
			SingleRequestBody, ok := v.(map[string]interface{})
			if !ok {
				logger.Info("Element is not a map[string]interface{}")
			}
			wg.Add(1)
			concurrencyLimit <- struct{}{}
			go func(SingleRequestBody map[string]interface{}) {
				defer func() {
					<-concurrencyLimit
					wg.Done()
				}()
				penetrateFunc(SingleRequestBody)
			}(SingleRequestBody)
		}
		wg.Wait()
	}
}

// 执行操作
func PenetrateMaterialData(requestBody map[string]interface{}) bool {
	tableName := "mes_mat_md"
	fieldSlice := []string{"mat_code", "mat_type", "mat_desc", "mat_type_desc", "mat_group_code", "mat_group_name", "erp_unit", "standard", "model_number", "rounding_value"}
	fieldIntSlice := []string{"plant", "is_delete"}
	dataType := "material"
	flag := UniversalAdd(requestBody, fieldSlice, fieldIntSlice, tableName, dataType)
	return flag
}

func PenetrateProjectBomData(requestBody map[string]interface{}) bool {
	tableName := "mes_pbom"
	fieldSlice := []string{"mat_code", "mat_des", "pbom_version", "pbom_code", "standard", "mat_unit"}
	fieldIntSlice := []string{"plant", "is_delete"}
	dataType := "pbom"
	// 主表插入
	flag := UniversalAdd(requestBody, fieldSlice, fieldIntSlice, tableName, dataType)
	if !flag {
		return false
	}

	// 子表插入
	subName := "ErpPbomDetailsModel"
	logger.Info("subName:%v", subName)
	subTableName := "mes_pbom_details"
	subFieldSlice := []string{"mat_code", "mat_des", "erp_code", "replace_group", "pbom_code", "standard", "mat_unit", "mat_num", "position_code", "merge_code"}
	subFieldIntSlice := []string{"level", "is_delete"}
	flag1 := UniversalAddSub(requestBody, subName, subTableName, subFieldSlice, subFieldIntSlice)
	return flag1
}

func PenetrateOrderData(requestBody map[string]interface{}) bool {
	tableName := "mes_order_sap"
	fieldSlice := []string{"order_no", "cmd_time", "order_batch", "order_type", "mat_code", "order_num", "unit", "plan_starttime", "plan_endtime", "process_code", "pbom_code", "order_status"}
	fieldIntSlice := []string{"order_priority", "plant", "is_delete"}
	dataType := "order"
	flag := UniversalAdd(requestBody, fieldSlice, fieldIntSlice, tableName, dataType)
	return flag
}

func PenetrateSNData(requestBody map[string]interface{}) bool {
	tableName := "mes_ordersn_details_sap"
	fieldSlice := []string{"order_no", "sn_no"}
	fieldIntSlice := []string{}
	dataType := "sn"
	flag := UniversalAdd(requestBody, fieldSlice, fieldIntSlice, tableName, dataType)
	return flag
}

func PenetrateProcessData(requestBody map[string]interface{}) bool {
	fieldSlice := []string{"plnnr", "mat_code", "mat_des", "process_code", "process_des", "start_time", "end_time", "erp_update"}
	fieldIntSlice := []string{"plant", "is_delete", "erp_create_id", "erp_update_id"}
	tableName := "mes_processes_product_sap"
	dataType := "process"
	// 主表插入
	flag := UniversalAdd(requestBody, fieldSlice, fieldIntSlice, tableName, dataType)
	if !flag {
		return false
	}
	// 子表插入
	subName := "ErpProductLineDetailsModel"
	subTableName := "mes_processes_product_sap_details"
	subFieldSlice := []string{"plnnr", "mat_code", "mat_des", "mat_details_code", "processes_des", "labor_hour", "labor_hour_unit", "machine_hour", "machine_hour_unit", "labor_prepare_hour", "labor_prepare_hour_unit", "machine_prepare_hour", "machine_prepare_hour_unit", "erp_update", "start_time", "end_time", "process_code"}
	subFieldIntSlice := []string{"plant", "is_delete", "erp_create_id", "erp_update_id", "plnkn", "num"}
	flag1 := UniversalAddSub(requestBody, subName, subTableName, subFieldSlice, subFieldIntSlice)
	return flag1
}

func PenetrateProductOrderData(requestBody map[string]interface{}) bool {
	tableName := "mes_production_order_sap"
	fieldSlice := []string{"order_no", "plan_num", "mat_code", "mat_des", "standard", "mat_unit"}
	fieldIntSlice := []string{"is_delete"}
	dataType := "porder"
	// 主表插入
	flag := UniversalAdd(requestBody, fieldSlice, fieldIntSlice, tableName, dataType)
	if !flag {
		return flag
	}
	// 子表插入
	subName := "ErpProductionOrderDetailsModel"
	subTableName := "mes_production_order_sap_des"
	subFieldSlice := []string{"order_no", "erp_code", "mat_desc_code", "mat_desc_name", "mat_num", "mat_unit", "standard", "process_code"}
	subFieldIntSlice := []string{"is_delete"}
	flag1 := UniversalAddSub(requestBody, subName, subTableName, subFieldSlice, subFieldIntSlice)
	return flag1
}

func PenetrateFlowData(requestBody map[string]interface{}) bool {
	tableName := "mes_processes"
	fieldSlice := []string{"plnnr", "mat_code", "mat_des", "mat_details_code", "processes_des", "erp_update", "process_code"}
	fieldIntSlice := []string{"plant", "is_delete", "plnkn", "num", "erp_create_id", "erp_update_id"}
	dataType := "flow"
	flag := UniversalAdd(requestBody, fieldSlice, fieldIntSlice, tableName, dataType)
	return flag
}

func toCamelMap(oldMap map[string]interface{}) map[string]interface{} {
	newMap := make(map[string]interface{})
	for key, value := range oldMap {
		camelCaseKey := ToCamelCase(key)
		newMap[camelCaseKey] = value
	}
	return newMap
}

// 主表或单表插入
func UniversalAdd(requestBody map[string]interface{}, fieldSlice, fieldIntSlice []string, tableName string, dataType string) bool {
	camelCaseMap := toCamelMap(requestBody)
	var rowMesPbom []string
	var valMesPbom []interface{}

	for i := range fieldSlice {
		rowMesPbom, valMesPbom = MappingHelper(camelCaseMap, rowMesPbom, valMesPbom, fieldSlice[i])
	}

	for i := range fieldIntSlice {
		rowMesPbom, valMesPbom = MappingIntHelper(camelCaseMap, rowMesPbom, valMesPbom, fieldIntSlice[i])
	}

	if dataType == "flow" {
		rowMesPbom = append(rowMesPbom, "sort")
		valMesPbom = append(valMesPbom, 0)
	}

	// 连接数据库
	db, err := ConnectMySQL()
	if err != nil {
		logger.Info("数据库连接失败")
		return false
	}
	defer db.Close()

	// 定义占位符
	placeholders := ProducePlaceholders(rowMesPbom)

	insertStatement := fmt.Sprintf("INSERT INTO %s (%s) VALUES (%s)", tableName, strings.Join(rowMesPbom, ", "), strings.Join(placeholders, ", "))

	logger.Info("valMesPbom:%v", valMesPbom)
	_, err = db.Exec(insertStatement, valMesPbom...)
	if err != nil {
		logger.Info("数据插入失败")
		logger.Info("sqlStatement是：%v", err)
		return false
	} else {
		return true
	}
}

// 子表插入
func UniversalAddSub(requestBody map[string]interface{}, subName, tableName string, fieldSlice, fieldIntSlice []string) bool {
	newRequestBody := toCamelMap(requestBody)
	rowValSlice := make([]interface{}, 0)
	if m, ok := newRequestBody["list"].(map[string]interface{}); ok {
		if l, ok := m[subName].([]interface{}); ok {
			for _, v := range l {
				if k, ok := v.(map[string]interface{}); ok {
					newm := toCamelMap(k)
					logger.Info("Type of data: %v", newm)

					var rowMesPbomDetails []string
					var valMesPbomDetails []interface{}

					for i := range fieldSlice {
						rowMesPbomDetails, valMesPbomDetails = MappingHelper(newm, rowMesPbomDetails, valMesPbomDetails, fieldSlice[i])
					}

					for i := range fieldIntSlice {
						rowMesPbomDetails, valMesPbomDetails = MappingIntHelper(newm, rowMesPbomDetails, valMesPbomDetails, fieldIntSlice[i])
					}
					if subName == "ErpProductLineDetailsModel" {
						rowMesPbomDetails = append(rowMesPbomDetails, "sort")
						valMesPbomDetails = append(valMesPbomDetails, 0)
					}

					rowValSlice = append(rowValSlice, rowMesPbomDetails, valMesPbomDetails)
				}
			}
		} else if p, ok := m[subName].(map[string]interface{}); ok {
			newm := toCamelMap(p)
			var rowMesPbomDetails []string
			var valMesPbomDetails []interface{}

			for i := range fieldSlice {
				rowMesPbomDetails, valMesPbomDetails = MappingHelper(newm, rowMesPbomDetails, valMesPbomDetails, fieldSlice[i])
			}

			for i := range fieldIntSlice {
				rowMesPbomDetails, valMesPbomDetails = MappingIntHelper(newm, rowMesPbomDetails, valMesPbomDetails, fieldIntSlice[i])
			}
			if subName == "ErpProductLineDetailsModel" {
				rowMesPbomDetails = append(rowMesPbomDetails, "sort")
				valMesPbomDetails = append(valMesPbomDetails, 0)
			}
			rowValSlice = append(rowValSlice, rowMesPbomDetails, valMesPbomDetails)
		}
	}

	db, err := ConnectMySQL()
	if err != nil {
		logger.Info("数据库连接失败")
		return false
	}
	defer db.Close()

	// 使用索引每次取出两个元素
	for i := 0; i < len(rowValSlice); i += 2 {
		rowMesPbomDetails := rowValSlice[i].([]string)
		valMesPbomDetails := rowValSlice[i+1].([]interface{})
		placeholders := ProducePlaceholders(rowMesPbomDetails)

		insertStatement := fmt.Sprintf("INSERT INTO %s (%s) VALUES (%s)", tableName, strings.Join(rowMesPbomDetails, ", "), strings.Join(placeholders, ", "))
		_, err = db.Exec(insertStatement, valMesPbomDetails...)
		if err != nil {
			logger.Info("数据插入子表失败")
			logger.Info("sqlStatement是：%v", err)
			return false
		}
	}
	return true
}

// init子表插入
func InitUniversalAddSub(requestBody map[string]interface{}, subName, tableName string, fieldSlice, fieldIntSlice []string) bool {
	rowValSlice := make([]interface{}, 0)
	if l, ok := requestBody[subName].([]interface{}); ok {
		for _, v := range l {
			if k, ok := v.(map[string]interface{}); ok {
				newm := toCamelMap(k)
				logger.Info("Type of data: %v", newm)

				var rowMesPbomDetails []string
				var valMesPbomDetails []interface{}

				for i := range fieldSlice {
					rowMesPbomDetails, valMesPbomDetails = MappingHelper(newm, rowMesPbomDetails, valMesPbomDetails, fieldSlice[i])
				}

				for i := range fieldIntSlice {
					rowMesPbomDetails, valMesPbomDetails = MappingIntHelper(newm, rowMesPbomDetails, valMesPbomDetails, fieldIntSlice[i])
				}
				if subName == "erp_product_line_details_model" {
					rowMesPbomDetails = append(rowMesPbomDetails, "sort")
					valMesPbomDetails = append(valMesPbomDetails, 0)
				}

				rowValSlice = append(rowValSlice, rowMesPbomDetails, valMesPbomDetails)
			}
		}
	} else if p, ok := requestBody[subName].(map[string]interface{}); ok {
		newm := toCamelMap(p)
		var rowMesPbomDetails []string
		var valMesPbomDetails []interface{}

		for i := range fieldSlice {
			rowMesPbomDetails, valMesPbomDetails = MappingHelper(newm, rowMesPbomDetails, valMesPbomDetails, fieldSlice[i])
		}

		for i := range fieldIntSlice {
			rowMesPbomDetails, valMesPbomDetails = MappingIntHelper(newm, rowMesPbomDetails, valMesPbomDetails, fieldIntSlice[i])
		}
		if subName == "erp_product_line_details_model" {
			rowMesPbomDetails = append(rowMesPbomDetails, "sort")
			valMesPbomDetails = append(valMesPbomDetails, 0)
		}
		rowValSlice = append(rowValSlice, rowMesPbomDetails, valMesPbomDetails)
	}

	db, err := ConnectMySQL()
	if err != nil {
		logger.Info("数据库连接失败")
		return false
	}
	defer db.Close()

	// 使用索引每次取出两个元素
	for i := 0; i < len(rowValSlice); i += 2 {
		rowMesPbomDetails := rowValSlice[i].([]string)
		valMesPbomDetails := rowValSlice[i+1].([]interface{})
		placeholders := ProducePlaceholders(rowMesPbomDetails)

		insertStatement := fmt.Sprintf("INSERT INTO %s (%s) VALUES (%s)", tableName, strings.Join(rowMesPbomDetails, ", "), strings.Join(placeholders, ", "))
		_, err = db.Exec(insertStatement, valMesPbomDetails...)
		if err != nil {
			logger.Info("数据插入子表失败")
			logger.Info("sqlStatement是：%v", err)
			return false
		}
	}
	return true
}
