package sap

import (
	"bytes"
	"encoding/json"
	"hsm-io-it-back-end/internal/constants"
	"hsm-io-it-back-end/pkg/logger"
	"io/ioutil"
	"net/http"
	"strconv"
)

type GraphQLReq struct {
	Query     string      `json:"query"`
	Variables interface{} `json:"variables"`
}

func SendGQL(config *Configuration, searchInter *Flow, dataBody map[string]interface{}) {
	logger.Info("searchInter.Interface:%v", searchInter.Interface)
	for k, v := range dataBody {
		if k == "plant" {
			logger.Info("plant :%v", v)
			intV, err := strconv.Atoi(v.(string))
			if err != nil {
				logger.Info("int类型转换错误:%v", err)
			}
			dataBody["plant"] = intV
		}
		if k == "is_delete" {
			logger.Info("is_delete :%v", v)
			intV, err := strconv.Atoi(v.(string))
			if err != nil {
				logger.Info("int类型转换错误:%v", err)
			}
			dataBody["is_delete"] = intV
		}
	}

	variables := parten[searchInter.Interface].GQL.Variables

	for k, v := range variables {
		if subv, ok := v.(map[string]interface{}); ok {
			logger.Info("subv is :%v", subv)
			for sk, sv := range subv {
				subv[sk] = dataBody[sv.(string)]
			}
			variables[k] = subv
		} else {
			variables[k] = dataBody[v.(string)]
		}
	}
	logger.Info("variables is :%v", variables)

	url := GetGQLURL(searchInter.Interface)
	reqBody := GraphQLReq{
		Query:     parten[searchInter.Interface].GQL.Query,
		Variables: variables,
	}

	logger.Info("reqBody:%v", reqBody)

	jsonReq, err := json.Marshal(reqBody)
	if err != nil {
		logger.Info("err:%v", err)
	}
	logger.Info("url:%v", url)

	resp, err := http.Post(url, constants.JsonApplication, bytes.NewBuffer(jsonReq))
	if err != nil {
		logger.Info("http err:%v", err)
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		logger.Info("response err:%v", err)
	}
	logger.Info("body:%v", string(body))
	var res map[string]interface{}
	if err := json.Unmarshal(body, &res); err != nil {
		logger.Info("mapping err:%v", err)
	}

	if data, ok := res[parten[searchInter.Interface].GQL.ResultKey]; ok {
		logger.Info("res data :%v", data)
	}
}
