package constants

import "os"

const (
	Suffix             = ".json"
	Tasks              = "tasks"
	Job                = "job/"
	Project            = "project/"       //项目名称文件夹
	Temp               = "temp/"          //临时文件
	Csv                = ".csv"           //csv文件后缀
	DataBaseInfo       = "data_base_info" //数据库连接信息
	Log                = ".log"
	Hierarchy          = "/" //文件夹层级
	DataBaseConfig     = "databaseConfig/"
	File_ALREADY_EXITS = "文件已存在"
	Txt                = ".txt" //txt文件后缀
	SQLite             = "SQLite"
	Postgres           = "Postgres"
	SQLServer          = "SQLServer"
	MySQL              = "MySQL"
	PostgreSQL         = "PostgreSQL"

	// 调度方式
	Manual_schedule = "1"
	Period_schedule = "2"

	Node1 = "1"
	Node2 = "2"

	ReadyJob    = 0 //作业就绪状态
	RuningJob   = 1 //作业运行状态
	InvalidJob  = 2 //无效作业
	AbnormalJob = 3 //异常作业

	VERSION_0_4_6 = "0.4.6"
	VERSION_0_4_7 = "0.4.7"
	VERSION_0_6_1 = "0.6.1"

	// 数据发布********start

	// 编译状态：underway
	UnderWayStatus = "underway"
	// 编译状态：failed
	FailedStatus = "failed"
	// 编译状态：succeed
	SucceedStatus = "succeed"

	// ioit应用标识
	AppId = "hsm-io-it"
	// 上传文件文件夹
	UpLoad = "upload/"
	// 全选数据
	IsAll = "isAll"
	// 不全选数据
	NotAll = "notAll"
	// 清空发布
	IsClear = "isClear"
	// 不清空发布
	NotClear = "notClear"
	// 作业名称文件
	ArrTxt = "arr.txt"
	// #
	Pound = "#"
	// ".tar.gz"
	TarGz = ".tar.gz"
	// .zip
	Zip = ".zip"
	// 初始化版本V0
	V0 = "V0"
	// 数据发布临时文件夹
	TempDpt = "tempDpt/"
	// 数据发布********end

	// 地址拼接符号
	AddressSplicingSymbols = ":"
	// 连接符"_"
	Underline = "_"
	// @
	At = "@"
	// 分隔符："."
	DotDelimiter = "."
	// "/"
	Slash = "/"
	// 空字符串
	EmptyContent = ""
	// txt文件标识符
	TxtIdentifier = ".txt"
	// xml文件标识符
	XmlIdentifier = ".xml"
	// csv文件标识符
	CsvIdentifier = ".csv"
	// json文件标识符
	JsonIdentifier = ".json"
	// "新建作业"
	NewJob = "新建作业"

	// "新建作业1"
	NewJob1 = "新建作业1"

	// 数据预览文件
	DATAPREVIEW = "dataPreview.json"

	// sk单机部署
	SINGLEDEPLOYMENT = 1
	// sk1+1部署
	DUALDEPLOYMENT = 2
	// sk1+2部署
	MUTILDEPLOYMENT_T = 3
	// sk1+4部署
	MUTILDEPLOYMENT_F = 5

	// PORTAL项目名称
	PORTALNAME = "hsm_io_it"
	// e1：工程师站
	ENGNODE = "e1"
	// s1：数据服务器A
	DATASERVERNODE = "s1"
	// s3：服务器C
	SERVERNODE = "s3"

	// 电子厂数据库连接信息数据文件夹
	MESData = "MESData/"

	// SK配置文件
	NodeManifest = "nodemanifest.ini"

	// 导出标识
	AtDatabaseConfig = "@databaseConfig"
	AtUpload         = "@upload"
	AtJob            = "@J"
	ExportJob        = "J"
	AtNull           = "@null"
	ExportNull       = "null"
	AtProject        = "@P"
	ExportProject    = "P"

	// sapmes接口调用模板
	ProjectTemplate       = "template/"
	ProjectSAPMESTemplate = "SAP_MES-Parten/"
	ProcessFile           = "process.json"
	Manifest              = "manifest"

	Http       = "http://"
	Scheduling = "hsm-scheduling"
	Auth       = "hsm-auth-back-end"

	JsonApplication = "application/json"

	DomainName = ".local"

	HealthPath = "/api/hsm-io-it/health/check"
)

func GetHsmHome() string {
	hsmTemplate := os.Getenv("HSM_HOME")
	if hsmTemplate == "" {
		return "/usr/local/hsm-os"
	}
	return hsmTemplate
}

var HSM_OS_ROOT = GetHsmHome()

// 编译文件存储路径
var TARGZPATH = GetHsmHome() + "/data/mdp/ioit"

// 编译日志路径
var LogPath = GetHsmHome() + "/data/hsm-io-it/data/dpt/log/"

// 备份目录
var BackPath = GetHsmHome() + "/data/hsm-io-it/data/dpt/backup/"

// 项目文件路径
var ProjectPath = GetHsmHome() + "/data/hsm-io-it/data/project/"
