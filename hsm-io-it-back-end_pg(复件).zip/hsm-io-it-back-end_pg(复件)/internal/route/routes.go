package route

import (
	"hsm-io-it-back-end/internal/api/component"
	"hsm-io-it-back-end/internal/api/healthCheck"
	"hsm-io-it-back-end/internal/api/job"
	"hsm-io-it-back-end/internal/api/sapmes"
	"hsm-io-it-back-end/internal/api/task"
	u8kingdee "hsm-io-it-back-end/internal/service/u8Kingdee"
	"hsm-io-it-back-end/middleware"
	"hsm-io-it-back-end/pkg/logger"
	"hsm-io-it-back-end/response"
	"runtime/debug"
	"time"

	"github.com/gin-gonic/gin"
)

func mwRecover() gin.HandlerFunc {
	return func(ctx *gin.Context) {
		defer func() {
			if panicErr := recover(); panicErr != nil {
				logger.Error("mwRecover debug.Stack:%s", string(debug.Stack()))
				logger.Error("mwRecover panicErr:%v", panicErr)
				response.Api_Code_Fail(ctx, response.SERVER_EXCEPTION_CODE, time.Now())
			}
		}()
		ctx.Next()
	}
}

func CollectRoute(r *gin.Engine) *gin.Engine {
	r.Use(middleware.CORSMiddleware())
	//捕获全局panic
	r.Use(mwRecover())

	projectRouter := r.Group("api/hsm-io-it") //
	{
		// 删除项目
		projectRouter.POST("/deletetProject", job.DeleteProject)

		// 导出项目
		projectRouter.POST("/exportData", job.ExportProject)

		// 导出项目查询
		projectRouter.POST("/exportResult", job.ExportResult)

		// 取消导出项目
		projectRouter.POST("/cancel/exportData", job.CancelExportProject)

		// 导入项目
		projectRouter.POST("/importData", job.ImportProject)

		// 导入项目查询
		projectRouter.POST("/importResult", job.ImportResult)

		// 取消导入项目
		projectRouter.POST("/cancel/importData", job.CancelImportProject)
	}

	jobRouter := r.Group("api/hsm-io-it/job")
	{
		// 新增作业
		jobRouter.POST("/add", job.Add)

		// 编码校验
		jobRouter.POST("/checkCode", job.AddCode)

		// 更新作业
		jobRouter.PUT("/update", job.Update)

		// 删除作业
		jobRouter.DELETE("/delete", job.Delete)

		// 获取作业列表
		jobRouter.POST("/getJobList", job.GetJobList)

		// 启动作业
		jobRouter.POST("/start", task.Start)

		jobRouter.POST("/excute", task.Excute)

		jobRouter.POST("/startRT", task.StartRTJob)

		jobRouter.POST("/stopRT", task.StopRTJob)

		// 停止作业
		jobRouter.POST("/stop", task.Stop)

		// 获取作业信息
		jobRouter.POST("/getJobInfo", job.GetJobInfo)

		// 保存作业
		jobRouter.POST("/saveJobInfo", job.SaveJobInfo)

		// 获取作业数据
		jobRouter.POST("/getJobData", job.GetJobData)

		// 获取作业日志
		jobRouter.POST("/getJobLog", job.GetJobLog)

		// 导出作业
		jobRouter.POST("/exportJob", job.ExportJob)

		// 批量导出作业
		jobRouter.POST("/exportBatchJob", job.ExportBatchJob)

		// 导入作业校验
		jobRouter.POST("/importCheckJob", job.ImportCheckJob1)

		// 导入作业
		jobRouter.POST("/importJob", job.ImportJob1)

		// 查询作业
		jobRouter.POST("/search", job.Search)

		// 批量导入作业校验
		jobRouter.POST("/importBatchCheckJobs", job.ImportBatchCheckJobs1)

		// 批量导入作业
		jobRouter.POST("/importBatchJobs", job.ImportBatchJobs1)

		// 返回作业模板
		jobRouter.POST("/template", sapmes.GetTemplate)

		// 获取作业分类
		jobRouter.POST("/getJobCata", job.GetJobCata)

		// 添加作业分类
		jobRouter.POST("/addJobCata", job.AddJobCata)

		// 删除作业分类
		jobRouter.POST("/editeJobCata", job.EditeJobCata)

		// 更新作业分类
		jobRouter.POST("/deleteJobCata", job.DeleteJobCata)

		// 获取IP
		jobRouter.POST("/getJobSchType", job.GetJobSchType)

		// 获取安装路径
		jobRouter.GET("/getSkPath", job.GetSkPath)

	}

	sapRouter := r.Group("api/hsm-io-it/sap") //
	{
		sapRouter.POST("/gateway", sapmes.Gateway)

		sapRouter.POST("/getRepeatData", sapmes.GetRepeatData)

		sapRouter.POST("/addData", sapmes.AddData)

		sapRouter.POST("/deleteData", sapmes.DeleteData)

		sapRouter.POST("/editData", sapmes.EditData)

		sapRouter.POST("/editOrderStatus", sapmes.EditOrderStatus)

		sapRouter.POST("/penetrateMaterial", sapmes.PenetrateMaterial)

		sapRouter.POST("/penetratePbom", sapmes.PenetratePbom)

		sapRouter.POST("/penetrateOrder", sapmes.PenetrateOrder)

		sapRouter.POST("/penetrateSN", sapmes.PenetrateSN)

		sapRouter.POST("/penetrateProcess", sapmes.PenetrateProcess)

		sapRouter.POST("/penetrateProductOrder", sapmes.PenetrateProductOrder)

		sapRouter.POST("/penetrateFlow", sapmes.PenetrateFlow)

		sapRouter.POST("/storeXML", sapmes.StoreXML)
	}

	u8Router := r.Group("api/hsm-io-it/u8")
	{
		u8Router.POST("/saveU8TaskCenter", u8kingdee.SaveU8TaskCenter)
		u8Router.POST("/saveU8Department", u8kingdee.SaveU8Department)
		u8Router.POST("/saveU8Supplier", u8kingdee.SaveU8Supplier)
		u8Router.POST("/saveU8Unit", u8kingdee.SaveU8Unit)
		u8Router.POST("/saveU8CustomerData", u8kingdee.SaveU8CustomerData)
		u8Router.POST("/saveU8Person", u8kingdee.SaveU8Person)
		u8Router.POST("/saveU8ProductionOrder", u8kingdee.SaveU8ProductionOrder)
		u8Router.POST("/saveU8Material", u8kingdee.SaveU8Material)
		u8Router.POST("/saveU8MaterialBOM", u8kingdee.SaveU8MaterialBOM)

		u8Router.POST("/saveU8ProductIn", u8kingdee.SaveU8ProductIn)
	}

	kingdeeRouter := r.Group("api/hsm-io-it/kingdee")
	{
		kingdeeRouter.POST("/saveKingdeeDepartment", u8kingdee.SaveKingdeeDepartment)
		kingdeeRouter.POST("/saveKingdeeWorkCenter", u8kingdee.SaveKingdeeWorkCenter)
		kingdeeRouter.POST("/saveKingdeeSupplier", u8kingdee.SaveKingdeeSupplier)
		kingdeeRouter.POST("/saveKingdeePlanOrder", u8kingdee.SaveKingdeePlanOrder)
		kingdeeRouter.POST("/saveKingdeeUnit", u8kingdee.SaveKingdeeUnit)
		kingdeeRouter.POST("/saveKingdeeCustomer", u8kingdee.SaveKingdeeCustomer)
		kingdeeRouter.POST("/saveKingdeeProductionOrder", u8kingdee.SaveKingdeeProductionOrder)
		kingdeeRouter.POST("/saveKingdeeMaterial", u8kingdee.SaveKingdeeMaterial)
		kingdeeRouter.POST("/saveKingdeeBOM", u8kingdee.SaveKingdeeBOM)
		kingdeeRouter.POST("/saveKingdeeEmployee", u8kingdee.SaveKingdeeEmployee)

		kingdeeRouter.POST("/saveKingdeeProductIn", u8kingdee.SaveKingdeeProductIn)
	}

	engRouter := r.Group("api/hsm-io-it/eng") //
	{
		// ENG树获取默认作业名字 okok
		engRouter.POST("/getDefalutName", job.ENG_GetDefaultName)

		// ENG树新增作业 okok
		engRouter.POST("/add", job.Add)

		// ENG树更新作业
		engRouter.PUT("/update", job.ENG_Update)

		// ENG树删除作业 okok
		engRouter.DELETE("/delete", job.Delete)

		// ENG树获取作业列表 okok
		engRouter.POST("/getJobList", job.GetJobList)
	}

	engTree := r.Group("api/hsm-io-it/dataPublish") //
	{
		// 数据发布获取作业列表 okok
		engTree.GET("/data/release/tree", job.DataPublish_GetJobList)
	}

	engDeleteRouter := r.Group("eng/project") //
	{
		// ENG项目删除 ok
		engDeleteRouter.POST("/deleteNotify", job.ENG_DeleteProject)
	}

	// ok
	dataPublish := r.Group("dpt") //
	{
		// 数据发布编译
		dataPublish.POST("/compile", job.DataPublish_Compress)

		// 数据发布更新
		dataPublish.POST("/dataUpdate", job.DataPublish_Update)

		// 数据发布回滚
		dataPublish.POST("/dataRollback", job.DataPublish_Rollback)

		// 数据发布范围通知
		dataPublish.POST("/publishedRange", job.DataPublish_PublishedRange)

		// 获取数据更新状态 ok
		dataPublish.GET("/getStatus", job.DataPublish_GetDataUpdateStatus)

		// 获取数据编译进度 ok
		dataPublish.POST("/progress", job.DataPublish_GetProgress)

		// 获取数据编译状态 ok
		dataPublish.POST("/status", job.DataPublish_GetStatus)

		// 获取编译日志 ok
		dataPublish.POST("/getLog", job.DataPublish_GetLog)
	}

	// 组态画面和组件之间的交互
	componentRouter := r.Group("api/hsm-io-it/component")
	{
		// 测试连接 okok
		componentRouter.POST("/mysql/testConnectInfo", component.ConnectMySqlTest)

		// 获取连接列表 okok
		componentRouter.POST("/mysql/getConnectList", component.GetConnectList)

		// 添加数据库连接 okok
		componentRouter.POST("/mysql/addConnect", component.AddConenctMySql)

		// 获取数据库连接 okok
		componentRouter.POST("/mysql/getConnect", component.GetConenctMySql)

		// 更新数据库连接 okok
		componentRouter.PUT("/mysql/updateConnect", component.UpdateConnect)

		// 获取表名称 okok
		componentRouter.POST("/mysql/getTables", component.GetTable)

		// 获取数据表主键 okok
		componentRouter.POST("/mysql/getTablesPrimary", component.GetTablePrimary)

		// 获取数据字段 okok
		componentRouter.POST("/mysql/getColumns", component.GetTableColumns)

		// 获取数据 okok
		componentRouter.POST("/mysql/getData", component.GetData)

		// 文件上传 okok
		componentRouter.POST("/file/upload", component.LoadHandler)

		// 连接SFTP服务器 okok
		componentRouter.POST("/file/sftpConnection", component.SftpConnectionHandler)

		// 获取服务器文件目录 okok
		componentRouter.POST("/file/getSftpFiles", component.GetSftpFiles)

		// 读取服务器文件数据 okok
		componentRouter.POST("/file/readSftpFilesData", component.SftpReadFileHandler)

		// 获取上传文件的数据 okok
		componentRouter.POST("/file/getData", component.GetDataHandler)

		// 正则表达式校验 okok
		componentRouter.POST("/validate", component.Validate)

		// 端口检验 okok
		componentRouter.POST("/checkPort", component.PortCheck)

		// 数据预览 okok
		componentRouter.POST("/dataDisplay", component.DataDisplay)

		// xmlToJson
		componentRouter.POST("/xmlToJson", job.XmlToJson)

		// 数据对比
		componentRouter.POST("/dataCompare", job.DataCompare)

		// 组件封装
		componentRouter.POST("/getComponent", job.GetComponent)

		// 组件封装--查询分类
		componentRouter.GET("/getComponentCate", job.GetComponentCate)

		// 组件封装--添加
		componentRouter.POST("/addComponent", job.AddComponent)

		// 业务数据--添加
		componentRouter.POST("/addBusinessData", job.AddBusinessData)

		// 业务数据--查询
		componentRouter.POST("/getBusinessData", job.GetBusinessData)

		// 测试连接
		componentRouter.POST("/testConn", job.TestConn)

		// 数据同步组件
		componentRouter.POST("/syncData", component.SyncDBData)

		//=========================SQLite数据库=========================
		// 新建数据库连接信息，以json的格式存储到json文件中 okok
		componentRouter.POST("/sqlite/addConnect", component.AddConnectSqlite)

		// 获取数据库连接信息List(读取json文件获取已经存在的数据库名字) okok
		componentRouter.POST("/dataBase/getConnectList", component.GetDataBaseConnectList)

		// 测试连接 okok
		componentRouter.POST("/sqlite/testDataBaseConnect", component.ConnectSqliteTest)

		// 更新连接 okok
		componentRouter.PUT("/sqlite/updateConnect", component.UpdateConnectSqlite)

		// 获取查询某个ip上所有的数据库list ok 不确定是否有该接口
		componentRouter.POST("/sqlite/getDataBaseConnectList", component.GetSqliteDataBaseConnectList)

		// 获取数据库下的表 okok
		componentRouter.POST("/sqlite/getTableList", component.GetSqliteTableList)

		// 获取表主键 okok
		componentRouter.POST("/sqlite/getTablesPrimary", component.GetSqliteTablesPrimary)

		// 获取数据库下的表中的字段名 okok
		componentRouter.POST("/sqlite/getTableColumns", component.GetSqliteTableColumns)

		// 获取数据库下的表中的数据 okok
		componentRouter.POST("/sqlite/getTableData", component.GetSqliteTableData)

		//=========================SQLServer数据库=========================
		// 测试连接 ok
		componentRouter.POST("/sqlServer/testDataBaseConnect", component.ConnectSqlSerTest)

		// 新建数据库连接信息，以json的格式存储到json文件中 ok
		componentRouter.POST("/sqlServer/addConnect", component.AddConnectSqlSer)

		// 更新连接 ok
		componentRouter.PUT("/sqlServer/updateConnect", component.UpdateConnectSqlSer)

		// 获取查询某个ip上所有的数据库list ok
		componentRouter.POST("/sqlServer/getDataBaseConnectList", component.GetSqlSerDataBaseConnectList)

		// 获取数据库下的表 ok
		componentRouter.POST("/sqlServer/getTableList", component.GetSqlSerTableList)

		// 获取表主键 ok
		componentRouter.POST("/sqlServer/getTablesPrimary", component.GetSqlSerTablesPrimary)

		// 获取数据库下的表中的字段名 ok
		componentRouter.POST("/sqlServer/getTableColumns", component.GetSqlSerTableColumns)

		// 获取数据库下的表中的数据 ok
		componentRouter.POST("/sqlServer/getTableData", component.GetSqlSerTableData)

		//=========================pg数据库=========================
		// 测试连接 ok
		componentRouter.POST("/postgreSQL/testDataBaseConnect", component.ConnectPGTest)

		// 新建数据库连接信息，以json的格式存储到json文件中 ok
		componentRouter.POST("/postgreSQL/addConnect", component.AddConnectPG)

		// 更新连接 ok
		componentRouter.PUT("/postgreSQL/updateConnect", component.UpdateConnectPG)

		// 获取数据库连接信息List(读取json文件获取已经存在的数据库名字) ok
		componentRouter.POST("/postgreSQL/getConnectList", component.GetPGConnectList)

		// 获取查询某个ip上所有的数据库list ok
		componentRouter.POST("/postgreSQL/getDataBaseConnectList", component.GetPGDataBaseConnectList)

		// 获取模式 ok
		componentRouter.POST("/postgreSQL/getModeList", component.GetPGModeList)

		// 获取模式下的表 ok
		componentRouter.POST("/postgreSQL/getTableList", component.GetPGTableList)

		// 获取表主键 ok
		componentRouter.POST("/postgreSQL/getTablesPrimary", component.GetPGTablesPrimary)

		// 获取模式下的表中的字段名 ok
		componentRouter.POST("/postgreSQL/getTableColumns", component.GetPGTableColumns)

		// 获取模式下的表中的字段名 ok
		componentRouter.POST("/postgreSQL/getTableData", component.GetPGTableData)
	}

	// 电子厂组件 ok
	electronicRouter := r.Group("api/hsm-io-it/electronic/component")
	{
		electronicRouter.POST("/mysql/testConnectInfo", component.ConnectMySqlTest_MES)
		electronicRouter.POST("/mysql/getConnectList", component.GetConnectList_MES)
		electronicRouter.POST("/mysql/addConnect", component.AddConenctMySql_MES)
		electronicRouter.POST("/mysql/getConnect", component.GetConenctMySql_MES)
		electronicRouter.PUT("/mysql/updateConnect", component.UpdateConnect_MES)
		electronicRouter.POST("/mysql/getTables", component.GetTable_MES)
		electronicRouter.POST("/mysql/getTablesPrimary", component.GetTablePrimary_MES)
		electronicRouter.POST("/mysql/getColumns", component.GetTableColumns_MES)
		electronicRouter.POST("/mysql/getData", component.GetData_MES)
	}

	healthCheckRouter := r.Group("test") //
	{
		healthCheckRouter.GET("/alive", healthCheck.Alive)
	}

	healthRouter := r.Group("api/hsm-io-it/health")
	{
		healthRouter.GET("/check", healthCheck.CheckHealth)
	}
	return r
}
