package vo

// 添加作业请求
type CreateJobRequest struct {
	JobKeyInfo
	JobDetailInfo
}

type JobKeyInfo struct {
	NameSpace string `gorm:"type:varchar(255);column:namespace" json:"namespace"`
	SKNode    string `gorm:"type:varchar(255);column:s_node" json:"s_node"`
	Code      string `gorm:"type:varchar(255);column:code" json:"code"`
}

type JobDetailInfo struct {
	Name            string  `gorm:"type:varchar(255);column:name" json:"name"`
	Describe        string  `gorm:"type:varchar(255);column:describe" json:"describe"`
	Schedule        string  `gorm:"type:varchar(255);column:schedule" json:"schedule"`
	ScheduleDetails string  `gorm:"type:varchar(255);column:schedule_details" json:"schedule_details"`
	ScheduleCycle   string  `gorm:"type:varchar(255);column:schedule_cycle" json:"schedule_cycle"`
	ScheduleUnit    string  `gorm:"type:varchar(255);column:schedule_unit" json:"schedule_unit"`
	Content         Content `gorm:"type:jsonb;column:content" json:"content"`
	CronId          string  `gorm:"type:varchar(255);column:cron_id" json:"cron_id"`
	IsHttp          bool    `gorm:"type:bool;column:is_http" json:"is_http"`
	Canvas          Canvas  `gorm:"type:jsonb;column:canvas" json:"canvas"`
	JobType         string  `gorm:"type:varchar(255);column:job_type" json:"job_type"`
	JobClass        string  `gorm:"type:varchar(255);column:job_class" json:"job_class"`
	Template        string  `gorm:"type:varchar(255);column:template" json:"template"`
	Id              string  `gorm:"type:varchar(255);column:id;primaryKey:false" json:"id"`
	Status          int     `gorm:"type:int;column:status" json:"status"`
	CreateTime      string  `gorm:"type:varchar(255);column:create_time" json:"create_time"`
	EditeTime       string  `gorm:"type:varchar(255);column:edite_time" json:"edite_time"`
	CreateUse       string  `gorm:"type:varchar(255);column:create_user" json:"create_user"`
	IsAutoSelectId  bool    `gorm:"type:bool;column:is_auto_select_id" json:"is_auto_select_id"`
	CronDetail      CronExp `gorm:"type:jsonb;column:cron_detail" json:"cron_detail"`
	PeriodDetail    Period  `gorm:"type:jsonb;column:period_detail" json:"period_detail"`
}

type JobNode struct {
	NameSpace string `gorm:"type:varchar(255);column:namespace" json:"namespace"`
	StartNode string `gorm:"type:varchar(255);column:startnode" json:"startnode"`
	Code      string `gorm:"type:varchar(255);column:code" json:"code"`
	StopNode  string `gorm:"type:varchar(255);column:stopnode" json:"stopnode"`
}

type JobCata struct {
	ClCode     string `gorm:"type:varchar(255);column:cl_code" json:"cl_code"`
	CgName     string `gorm:"type:varchar(255);column:cg_name" json:"cg_name"`
	CgParent   string `gorm:"type:varchar(255);column:cg_parent" json:"cg_parent"`
	NameSpace  string `gorm:"type:varchar(255);column:namespace" json:"namespace"`
	SkNode     string `gorm:"type:varchar(10);column:s_node" json:"s_node"`
	CgDescribe string `gorm:"type:text;column:cg_describe" json:"cg_describe"`
}

type ComponentDb struct {
	Label          string `gorm:"type:varchar(255);column:label" json:"label"`
	Value          string `gorm:"type:varchar(255);column:value" json:"value"`
	NodeType       string `gorm:"type:varchar(255);column:node_type" json:"node_type"`
	NodeMark       string `gorm:"type:varchar(255);column:node_mark" json:"node_mark"`
	Img            string `gorm:"type:varchar(255);column:img" json:"img"`
	NoConfigMsg    string `gorm:"type:varchar(255);column:no_config_msg" json:"no_config_msg"`
	NodeData       string `gorm:"type:varchar(255);column:node_data" json:"node_data"`
	CateKey        string `gorm:"type:varchar(255);column:cate_key" json:"cate_key"`
	ApplicableType string `gorm:"type:varchar(255);column:applicable_type" json:"applicable_type"`
	ApiType        string `gorm:"type:varchar(255);column:api_type" json:"api_type"`
}

type ComponentCata struct {
	Label string `gorm:"type:varchar(255);column:label" json:"label"`
	Value string `gorm:"type:varchar(255);column:value" json:"value"`
	Id    string `gorm:"type:varchar(255);column:id" json:"id"`
}

type Canvas map[string]interface{}

type CronExp struct {
	Type          string `json:"type"`          // day,week,month
	EffectiveDate string `json:"effectiveDate"` // 年月日时分秒
	EndDate       string `json:"endDate"`       // date | endless(无限期)
	EndType       string `json:"endType"`       // date | endless(无限期)
	DayOfWeek     string `json:"dayOfWeek"`     //1，2，3
	DayOfMonth    string `json:"dayOfMonth"`    //1，2，3，20
	ExecuteMonth  string `json:"executeMonth"`  // 1，2，3
}

type Period struct {
	ScheduleCycle int    `json:"schedule_cycle"`
	ScheduleUnit  string `json:"schedule_unit"`
	Times         int    `json:"times"`
	EffectiveDate string `json:"effectiveDate"`
	EndDate       string `json:"endDate"` // endless(无限期) | date(结束时间)
	EndType       string `json:"endType"` // endless(无限期) | date(结束时间)
}

type Content struct {
	//benthos完整的yaml
	BenthosYaml string `json:"benthos_yaml"`
	//benthos-yaml使用的组件
	BenthosComponent map[string]interface{} `json:"benthos_componnet"`
	//benthos-yaml节点配子
	NodeYamlMap map[string]interface{} `json:"node_yaml_map"`
	//数据链路
	NodeDataMap map[string]interface{} `json:"node_data_map"`
	//batch业务添加的环境变量列表
	CanvasParamMap []map[string]interface{} `json:"canvas_param"`
}

// 作业模板
type Parten struct {
	NodeIDMap map[string]string `json:"nodeid_map"`
	JobConfig JobDetails        `json:"job_config"`
	LineList  []LineData        `json:"lineList"`
	NodeList  []NodeData        `json:"nodeList"`
}

type LineData struct {
	Anchors   []interface{} `json:"anchors"`
	Connector []interface{} `json:"connector"`
	Source    string        `json:"source"`
	Target    string        `json:"target"`
	UUIDs     [][]string    `json:"uuids"`
}

// 替换后的作业模板
type NParten struct {
	NodeIDMap map[string]string `json:"nodeid_map"`
	JobConfig JobDetails        `json:"job_config"`
	LineList  []NLineData       `json:"lineList"`
	NodeList  []NodeData        `json:"nodeList"`
}

type NLineData struct {
	Source SourceAndTarget `json:"source"`
	Target SourceAndTarget `json:"target"`
	ID     string          `json:"id"`
	Shape  string          `json:"shape"`
}

type SourceAndTarget struct {
	Cell string `json:"cell"`
	Port string `json:"port"`
}

type JobDetails struct {
	NameSpace       string  `json:"namespace" binding:"required"` //工程名
	NickName        string  `json:"nickName"`                     //用户名
	Node            int     `json:"node"`                         //服务器节点
	ENG_node        string  `json:"s_node" binding:"required"`    //服务器节点
	Code            string  `json:"code" `                        //作业编号
	Name            string  `json:"name" binding:"required"`      //作业名称
	Describe        string  `json:"describe"`                     //作业描述
	Schedule        string  `json:"schedule"`                     //调度类型
	ScheduleDetails string  `json:"schedule_details"`             //corn表达式
	ScheduleCycle   string  `json:"schedule_cycle"`               //调度周期
	ScheduleUnit    string  `json:"schedule_unit"`                //调度类型
	Content         Content `json:"content"`
	CronId          string  `json:"cron_id"`
	IsHttp          bool    `json:"is_http"`
	JobType         string  `json:"job_type"`
	JobClass        string  `json:"job_class"`
}

type NodeData struct {
	CateKey      string                 `json:"cateKey"`
	FlowNodeType string                 `json:"flowNodeType"`
	Id           string                 `json:"id"`
	Img          string                 `json:"img"`
	IsConfig     bool                   `json:"isConfig"`
	Label        string                 `json:"label"`
	Message      string                 `json:"message"`
	NeedConfig   bool                   `json:"needConfig"`
	NoConfigMsg  string                 `json:"noConfigMsg"`
	NodeData     string                 `json:"nodeData"`
	Attrs        map[string]interface{} `json:"attrs"`
	Ports        []Ports                `json:"ports"`
	NodeMark     string                 `json:"nodeMark"`
	NodeType     string                 `json:"nodeType"`
	ResultKey    string                 `json:"resultKey"`
	Status       string                 `json:"status"`
	X            int                    `json:"x"`
	Y            int                    `json:"y"`
	Value        string                 `json:"value"`
	Description  string                 `json:"description"`
}

type SyncNodeData struct {
	CateKey      string   `json:"cateKey"`
	FlowNodeType string   `json:"flowNodeType"`
	Id           string   `json:"id"`
	Img          string   `json:"img"`
	IsConfig     bool     `json:"isConfig"`
	Label        string   `json:"label"`
	Message      string   `json:"message"`
	NeedConfig   bool     `json:"needConfig"`
	NoConfigMsg  string   `json:"noConfigMsg"`
	NodeData     string   `json:"nodeData"`
	Attrs        FormItem `json:"attrs"`
	Ports        []Ports  `json:"ports"`
	NodeMark     string   `json:"nodeMark"`
	NodeType     string   `json:"nodeType"`
	ResultKey    string   `json:"resultKey"`
	Status       string   `json:"status"`
	X            int      `json:"x"`
	Y            int      `json:"y"`
	Value        string   `json:"value"`
	Description  string   `json:"description"`
}

type FormItem struct {
	DataAsyncType string         `json:"dataAsyncType"`
	FormItem      FormItemDetail `json:"formItem"`
}

type FormItemDetail struct {
	Source DBSyncDetail `json:"source"`
	Target DBSyncDetail `json:"target"`
}

type DBSyncDetail struct {
	Database string         `json:"database"`
	Module   string         `json:"module"`
	LinkInfo LinkInfoDetail `json:"linkInfo"`
	Tables   []string       `json:"tables"`
	Views    []string       `json:"views"`
}

type LinkInfoDetail struct {
	Databasetype string `json:"databasetype"`
	Host         string `json:"host"`
	Password     string `json:"password"`
	Port         string `json:"port"`
	Username     string `json:"username"`
}

type Ports struct {
	Group string `json:"group"`
	Id    string `json:"id"`
}

type JobListReq struct {
	NameSpace string `json:"namespace"`
	JobClass  string `json:"job_class"`
}

type Component struct {
	Label       string `json:"label"`
	Value       string `json:"value"`
	NodeType    string `json:"nodeType"`
	NodeMark    string `json:"nodeMark"`
	Img         string `json:"img"`
	NoConfigMsg string `json:"noConfigMsg"`
	NodeData    string `json:"nodeData"`
	CateKey     string `json:"cateKey"`
	ApiType     string `json:"apiType"`
}

type BusinessDataReq struct {
	ID   string `gorm:"type:varchar(255);column:id" json:"id"`
	Data string `gorm:"type:text;column:data" json:"data"`
}

type XmlToJson struct {
	Xml string `json:"xml" binding:"required"` //工程名
}

type ExportProjectRequest struct {
	FilePath string `json:"filePath" binding:"required"` //导出路径
}

type DBInfo struct {
	// mysql:root:12345678&tcp(172.21.220.26:3306)/dbname
	TargetDSN    string   `json:"targetdsn"`
	SourceDSN    string   `json:"sourcedsn"`
	TargetDBType string   `json:"targetdbtype"`
	SourceDBType string   `json:"sourcedbtype"`
	Tables       []string `json:"tables"`
	Views        []string `json:"views"`
	Schema       string   `json:"schema"`
}

// 数据库参数
type DatabaseInfoRequest struct {
	Code         string `gorm:"type:varchar(255);column:code" json:"code"`
	Namespace    string `gorm:"type:varchar(255);column:namespace" json:"namespace"`
	ConnectName  string `gorm:"type:varchar(255);column:connectname" json:"connectname"`
	Username     string `gorm:"type:varchar(255);column:username" json:"username"`
	Password     string `gorm:"type:varchar(255);column:password" json:"password"`
	Host         string `gorm:"type:varchar(255);column:host" json:"host"`
	Port         string `gorm:"type:varchar(255);column:port" json:"port"`
	DbName       string `gorm:"type:varchar(255);column:dbname" json:"dbname"`
	DataBaseType string `gorm:"type:varchar(255);column:databasetype" json:"databasetype"`
	SchemaName   string `gorm:"type:varchar(255);column:schemaname" json:"schemaname"`
	Tablename    string `gorm:"type:varchar(255);column:tablename" json:"tablename"`
	Retry        string `gorm:"type:varchar(10);column:retry" json:"retry"`
	DbPath       string `gorm:"type:varchar(255);column:dbpath" json:"dbpath"`
	SQL          string `gorm:"-" json:"sql"`
	SKNode       string `gorm:"type:varchar(255);column:s_node" json:"s_node"`
}

// 连接ftp服务器
type FtpInfo struct {
	Ip       string `json:"ip" binding:"required"`
	Port     int    `json:"port" binding:"required"`
	Username string `json:"username" binding:"required"`
	Password string `json:"password" binding:"required"`
}

// 查询作业请求
type GetJobContent struct {
	Namespace string `json:"namespace" binding:"required"`
	Content   string `json:"content" binding:"required"`
	SessionId string `json:"sessionId"`
}

type CsvTxtInfo struct {
	Path string `json:"path" binding:"required"`
}

type SftpInfo struct {
	Host     string `json:"host" binding:"required"`
	Port     string `json:"port" binding:"required"`
	User     string `json:"user" binding:"required"`
	Password string `json:"password" binding:"required"`
	Retry    string `json:"retry" binding:"required"`
}

type SftpPath struct {
	Path string `json:"path" binding:"omitempty"`
}

type AttrsOfDatabase struct {
	DatabaseAndCodes  []string `json:"databaseandcodes" binding:"required"`
	EDatabaseAndCodes []string `json:"edatabaseandcodes" binding:"required"`
}

type AttrsOfFileUpload struct {
	UploadFilePaths []string `json:"uploadfilepaths" binding:"required"`
}

type ModeAndTableName struct {
	ModeName  string `json:"modename" binding:"required"`
	TableName string `json:"tablename" binding:"required"`
}
type TableSqlPG struct {
	DbOrModeName string `json:"dbormodeName" binding:"required"`
	TableName    string `json:"tablename" binding:"required"`
	SQL          string `json:"sql" binding:"required"`
}

type ValidateRegexp struct {
	ValidateRegexpExpress string `json:"validateRegexpExpress" binding:"required"`
}

type Port struct {
	BatchPort string `json:"batchport" binding:"required"`
}

type Yaml struct {
	BenthosYaml string   `json:"benthos_yaml" binding:"required"`
	Fields      []string `json:"fields"`
}

type ProjectDelRequest struct {
	ProjectId string `json:"projectId" binding:"required"` //工程名
}

// ********data_publish*******
type GetDataPublishRequest struct {
	DataFilePath string `json:"dataFilePath" binding:"required"`
}

type GetDataPublishCompileRequest struct {
	Version     string     `json:"version" binding:"required"`
	ServerRange []SerRange `json:"serverrange" binding:"required"`
}

type LogBody struct {
	Project     string `json:"project"`
	Node        string `json:"node"`
	Level       string `json:"level"`
	Content     string `json:"content"`
	ServiceId   string `json:"serviceId"`
	Type        string `json:"type"`
	DataVersion string `json:"dataVersion"`
	RecordTime  string `json:"recordTime"`
	JumpUrl     string `json:"jumpUrl"`
}

type LogRequest struct {
	Version string `json:"version" binding:"required"`
	Length  int    `json:"length" binding:"required"`
}

type SerRange struct {
	IsClear   bool     `json:"isClear"`
	IsAll     bool     `json:"isAll"`
	ServerId  string   `json:"serverId"`
	AppId     string   `json:"appId"`
	DataRange []string `json:"dataRange"`
	PackName  string   `json:"packName"`
}

type ComponentTypeRep struct {
	ApplicableType string `json:"applicable_type"`
}

type TestConnReq struct {
	Url     string                 `json:"url"`
	Method  string                 `json:"method"`
	Headers []Header               `json:"headers"`
	Data    map[string]interface{} `json:"data"`
	Auth    []Header               `json:"auth"`
}

type Header struct {
	Key   string `json:"key"`
	Value string `json:"value"`
}
