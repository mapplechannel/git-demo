package vo

import (
	"database/sql/driver"
	"encoding/json"
	"hsm-io-it-back-end/pkg/logger"
)

func (CreateJobRequest) TableName() string {
	return "ioit.job_info"
}

func (DatabaseInfoRequest) TableName() string {
	return "ioit.database_info"
}

func (JobCata) TableName() string {
	return "ioit.job_cata"
}

func (BusinessDataReq) TableName() string {
	return "ioit.business_data"
}

func (ComponentDb) TableName() string {
	return "ioit.component"
}

func (ComponentCata) TableName() string {
	return "ioit.component_cata"
}

func (h CronExp) Value() (driver.Value, error) {
	return json.Marshal(h)
}

func (h *CronExp) Scan(value interface{}) error {
	bytes, ok := value.([]byte)
	if !ok {
		logger.Info("type assertion failed")
	}
	return json.Unmarshal(bytes, h)
}

func (h Content) Value() (driver.Value, error) {
	return json.Marshal(h)
}

func (h *Content) Scan(value interface{}) error {
	bytes, ok := value.([]byte)
	if !ok {
		logger.Info("type assertion failed")
	}
	return json.Unmarshal(bytes, h)
}

func (h Period) Value() (driver.Value, error) {
	return json.Marshal(h)
}

func (h *Period) Scan(value interface{}) error {
	bytes, ok := value.([]byte)
	if !ok {
		logger.Info("type assertion failed")
	}
	return json.Unmarshal(bytes, h)
}

func (h Canvas) Value() (driver.Value, error) {
	return json.Marshal(h)
}

func (h *Canvas) Scan(value interface{}) error {
	bytes, ok := value.([]byte)
	if !ok {
		logger.Info("type assertion failed")
	}
	return json.Unmarshal(bytes, h)
}
