package app

import (
	"hsm-io-it-back-end/app"
	"hsm-io-it-back-end/config"
	"hsm-io-it-back-end/pkg/logger"
	"log"

	"github.com/spf13/cobra"
)

var (
	cfgFile        string
	versionCommond = &cobra.Command{
		Use:   "version",
		Short: "print version",
		Long: `print hsm-io-it version. 
		   Usage: hsm-io-it version`,
		Run: func(cmd *cobra.Command, args []string) {
			logger.Info("v1")
		},
	}
)

// 创建一个可执行的cmd命令
func NewRootCommand() *cobra.Command {
	cmd := &cobra.Command{
		Use: "hsm-io-it-back-end",
		Long: `hsm-io-it is a go template. 
			   Usage: hsm-io-it [OPTIONS]
			   Options:
			   -config, --config xxx.yaml`,
		Run: func(cmd *cobra.Command, args []string) {
			// 获取配置信息
			cfg, err := config.NewConfig(cfgFile)
			if err != nil {
				log.Fatalf("Config error: %s", err)
			}
			// 启动服务
			app.Run(cfg)
		},
	}
	cmd.PersistentFlags().StringVar(&cfgFile, "config", "", "config file")
	cmd.AddCommand(versionCommond)
	return cmd
}
